/**
 * Twolittle.bites OS — Phase 5 WhatsApp Deep-Link
 *
 * No WhatsApp API is used. This only generates wa.me links.
 * The user remains responsible for pressing Send in WhatsApp.
 */

function buildInvoiceWhatsAppMessage_(detail) {
  const invoice = detail.invoice;
  const customer = detail.customer || {};
  const items = detail.items || [];
  const businessName =
    getBusinessSetting_('business_name') || 'Twolittle.bites';

  const productsText =
    items.length
      ? items.map(function(item) {
          const quantity =
            Number(item.quantity || 0);

          const quantityText =
            Math.abs(
              quantity -
              Math.round(quantity)
            ) < 0.000001
              ? String(
                  Math.round(quantity)
                )
              : String(quantity);

          return (
            quantityText +
            'x ' +
            String(
              item.product_name_snapshot ||
              item.sku_snapshot ||
              'Product'
            ) +
            ' — ' +
            formatIdrText_(
              item.line_total
            )
          );
        }).join('\n')
      : '-';

  const template =
    getBusinessSetting_('invoice_whatsapp_template') ||
    (
      typeof settingsDefaultInvoiceWhatsAppTemplate_ === 'function'
        ? settingsDefaultInvoiceWhatsAppTemplate_()
        : [
            'Hi {customer_name} 👋',
            '',
            'Berikut invoice dari {business_name}:',
            '{invoice_number}',
            'Diskon: {discount}',
            'Ongkir: {delivery_fee}',
            'Total: {total}',
            'Sisa pembayaran: {remaining}',
            'Jatuh tempo: {due_at}',
            '',
            'Lihat invoice:',
            '{invoice_url}',
            '',
            'Terima kasih 🤎'
          ].join('\n')
    );

  const pdfArchive =
    typeof getInvoicePdfArchiveInfo_ ===
      'function'
      ? getInvoicePdfArchiveInfo_(
          invoice.invoice_id
        )
      : null;

  const values = {
    customer_name: customer.name || '',
    business_name: businessName,
    invoice_number: invoice.invoice_number,
    products: productsText,
    discount: formatIdrText_(invoice.discount),
    delivery_fee: formatIdrText_(invoice.delivery_fee),
    total: formatIdrText_(invoice.grand_total),
    remaining: formatIdrText_(invoice.remaining_amount),
    due_at: formatPublicDateTime_(invoice.due_at),
    invoice_url: buildPublicInvoiceUrl_(invoice.public_token),
    invoice_pdf_url:
      pdfArchive &&
      pdfArchive.downloadUrl
        ? pdfArchive.downloadUrl
        : buildPublicInvoiceUrl_(invoice.public_token)
  };

  if (
    typeof renderSettingsTemplate_ === 'function'
  ) {
    return renderSettingsTemplate_(
      template,
      values
    );
  }

  return String(template).replace(
    /\{([a-z_]+)\}/g,
    function(match, key) {
      return Object.prototype.hasOwnProperty.call(values, key)
        ? String(values[key] == null ? '' : values[key])
        : match;
    }
  );
}

function getInvoiceWhatsAppLink(invoiceId) {
  requirePermission_('INVOICE_READ');

  if (
    typeof getInvoicePdfArchiveInfo_ ===
      'function' &&
    typeof syncInvoicePdfArchiveSafely_ ===
      'function' &&
    !getInvoicePdfArchiveInfo_(
      invoiceId
    )
  ) {
    syncInvoicePdfArchiveSafely_(
      invoiceId,
      'WHATSAPP_LINK'
    );
  }

  const detail = getInvoiceDetail_(invoiceId);
  if (!detail.customer || !detail.customer.whatsapp) {
    throw twbError_(
      'CUSTOMER_WHATSAPP_MISSING',
      'Customer WhatsApp number is missing.'
    );
  }

  const phone = normalizeWhatsApp_(
    detail.customer.whatsapp
  );

  return {
    invoiceId: invoiceId,
    phone: phone,
    message: buildInvoiceWhatsAppMessage_(detail),
    url:
      'https://wa.me/' +
      encodeURIComponent(phone) +
      '?text=' +
      encodeURIComponent(
        buildInvoiceWhatsAppMessage_(detail)
      )
  };
}
