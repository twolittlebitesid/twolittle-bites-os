# APP_ARCHITECTURE.md
# Twolittle.bites OS — Google Apps Script Architecture

**Version:** P0.1  
**Status:** Frozen for implementation

---

## 1. Architecture Overview

```text
Browser
  ↓
HTML Service SPA Shell
  ↓
Frontend Router / Pages / Components
  ↓
ApiClient (single wrapper)
  ↓
google.script.run
  ↓
Server Facade / Services
  ↓
Validation + Authorization + Audit
  ↓
Repository / Database Layer
  ↓
Google Sheets
```

Supporting:
```text
CacheService
PropertiesService
LockService
```

---

## 2. Key Architecture Rules

1. UI never reads/writes Spreadsheet directly.
2. UI calls one client API wrapper.
3. Server service owns business rules.
4. Repository/database layer owns sheet I/O.
5. Batch reads/writes are preferred.
6. Critical writes use `LockService`.
7. Audit happens server-side.
8. Master data is cacheable.
9. Dashboard does not scan every sheet on every page load.
10. Static Stitch HTML is refactored; it is not used as one giant production HTML file.

---

## 3. Recommended Apps Script Files

```text
App.gs
Router.gs
Auth.gs
Permissions.gs

Database.gs
Repository.gs
Schema.gs
IdService.gs
Cache.gs
Validation.gs
AuditLog.gs
Utils.gs

ExecutiveService.gs
BusinessService.gs

CustomerService.gs
OrderService.gs
PreOrderService.gs
InvoiceService.gs
PaymentService.gs

ProductService.gs
RecipeService.gs
RecipeScalingService.gs
UnitService.gs

ProductionService.gs
InventoryService.gs
PurchaseService.gs

FinanceService.gs
MarketingService.gs
ReportService.gs
```

---

## 4. Frontend Files

Apps Script has flat project files, therefore logical folders are represented with naming prefixes/includes.

Suggested:

```text
Index.html

StylesTokens.html
StylesBase.html
StylesComponents.html
StylesResponsive.html

ComponentHeader.html
ComponentNav.html
ComponentModal.html
ComponentToast.html
ComponentTable.html
ComponentStatusChip.html
ComponentQuickActions.html

PageExecutive.html
PageOrders.html
PagePreOrders.html
PageProducts.html
PageRecipeCalculator.html
PageProduction.html
PageInventory.html
PageFinance.html
PageCustomers.html
PagePurchasing.html
PageMarketing.html
PageReports.html
PageSettings.html

JsApp.html
JsRouter.html
JsApiClient.html
JsStore.html
JsFormatters.html
JsForms.html
```

`include(filename)` renders fragments into `Index.html`.

---

## 5. Rendering Strategy

Use a single app shell.

```text
Header
Primary Navigation
Route Container
Floating / Mobile Quick Actions
Modal Root
Toast Root
```

Route navigation swaps page content/state without full page reload where practical.

Initial page payload should not include all operational datasets.

---

## 6. Client API Contract Pattern

Frontend must not call raw server functions from every component.

Use:

```javascript
api.call('orders.list', payload)
api.call('orders.create', payload)
api.call('recipes.scale', payload)
```

`ApiClient` handles:
- loading state;
- success;
- error normalization;
- timeout UX;
- optional retry for safe reads.

Server may expose facade functions compatible with Apps Script limitations.

---

## 7. Standard Server Response

```json
{
  "ok": true,
  "data": {},
  "meta": {
    "requestId": "REQ..."
  }
}
```

Error:

```json
{
  "ok": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Quantity must be greater than 0.",
    "fieldErrors": {}
  }
}
```

Do not expose stack traces to normal users.

---

## 8. Service Responsibilities

### OrderService
- create/update order;
- compute totals;
- validate customer/product;
- status transitions;
- link pre-order;
- coordinate invoice creation.

### PreOrderService
- campaign lifecycle;
- capacity calculation;
- cutoff enforcement;
- override authorization.

### InvoiceService
- generate unique invoice;
- public token/link;
- invoice snapshot;
- status synchronization.

### PaymentService
- payment event;
- invoice balance;
- order payment status;
- finance transaction;
- refund.

### RecipeService
- recipe CRUD/versioning.

### RecipeScalingService
- normalize units;
- exact/full-batch scaling;
- aggregate requirements.

### ProductionService
- production plans;
- requirement snapshot;
- batch execution;
- yield/waste.

### InventoryService
- stock movements;
- current balance;
- low stock;
- stock check.

### PurchaseService
- purchase lifecycle;
- receiving;
- stock movement creation.

### FinanceService
- managerial transaction ledger;
- expenses;
- P&L read model.

---

## 9. Database Layer

`Database.gs` responsibilities:
- resolve spreadsheet;
- get sheet by schema name;
- batch read rows;
- map header → object;
- append rows;
- batch update;
- logical query/filter helpers.

No business calculations belong in Database layer.

---

## 10. Schema Registry

`Schema.gs` should define:
- sheet name;
- required columns;
- primary ID field;
- optional unique fields.

On app startup/admin health check:

```text
validateSchema()
```

must detect missing sheets/columns.

Do not silently create production columns during normal user requests.

---

## 11. ID Service

`IdService.gs`:
- uses script lock;
- generates prefix;
- generates month-scoped sequence where needed;
- does not rely on row count alone.

Sequence may be stored in:
- Script Properties, or
- CONFIG counter keys.

Counter must be lock-protected.

---

## 12. Authentication

MVP:

```text
Session.getActiveUser().getEmail()
```

then lookup `USERS.email`.

If account cannot be reliably resolved in deployment context, deny access rather than assign a default privileged role.

Status:
```text
ACTIVE
INACTIVE
```

---

## 13. Authorization

Every mutating service starts with backend permission validation.

Client route protection is UX only.

---

## 14. Cache Strategy

Good cache candidates:
- products;
- active ingredients;
- suppliers;
- unit conversion;
- settings;
- status labels;
- business config.

Avoid caching rapidly changing:
- payment balance;
- stock after writes;
- active order queue unless short TTL/invalidation exists.

Cache invalidated after relevant mutation.

---

## 15. Lock Strategy

Use locks narrowly around critical state mutation.

Critical:
- ID sequence;
- order + invoice creation;
- payment posting;
- inventory movement;
- purchase receiving;
- production consumption;
- stock opname.

Do not hold lock during slow UI work or unrelated reads.

---

## 16. Performance Rules

- one server call should return page-needed data in a useful aggregate;
- avoid N+1 `google.script.run`;
- avoid `getValue()` inside loops;
- use `getValues()` once;
- use `setValues()` batch;
- paginate large tables;
- dashboard uses prepared summary/read model when data grows;
- cache master data.

---

## 17. Visual Integration

Stitch tokens become CSS variables.

Example:

```css
:root {
  --primary: #DE5D3D;
  --cream: #F6F6D2;
  --pink: #FDD3D7;
  --burnt: #9E3B26;
  --healthy: #2E7D32;
  --attention: #E65100;
  --critical: #C62828;
}
```

Production app should not depend on Tailwind CDN.

Reason:
- smaller runtime dependency;
- predictable Apps Script rendering;
- easier controlled component CSS.

Stitch utility classes are references to recreate, not runtime API contracts.

---

## 18. Responsive Strategy

### Desktop
- max content width ~1440;
- operational navigation visible;
- multi-column cards/tables.

### Tablet
- cards reflow to two columns;
- touch targets >=44px for numeric steppers.

### Mobile
- primary navigation collapses;
- sticky contextual actions;
- tables use responsive card/list or horizontal scroll;
- order, payment, WhatsApp, batch actions prioritized.

---

## 19. Public Invoice View

MVP invoice link can use Apps Script web app route:

```text
...?view=invoice&token=<public_token>
```

Public route:
- token only;
- no internal IDs required in URL;
- read-only;
- returns only invoice-safe customer/order information.

Do not expose management app data to public route.

---

## 20. Logging

### User-level
`ACTIVITY_LOG`

### Technical
Use Apps Script execution log / structured logger for:
- request ID;
- function;
- duration;
- error code.

Do not write secrets or full sensitive payment evidence into logs.

---

## 21. Deployment Environments

Recommended:
```text
DEV
PROD
```

Each environment:
- separate spreadsheet;
- separate script properties;
- separate web app deployment if practical.

Do not test destructive migrations directly on production data.

---

## 22. Phase 1 Build Order

1. Create Spreadsheet + sheets.
2. Write schema headers.
3. Create config/properties.
4. Build `Schema.gs`.
5. Build `Database.gs`.
6. Build `IdService.gs`.
7. Build `Auth.gs` / `Permissions.gs`.
8. Build `AuditLog.gs`.
9. Run database health check.
10. Only then start Product & Recipe engine.
