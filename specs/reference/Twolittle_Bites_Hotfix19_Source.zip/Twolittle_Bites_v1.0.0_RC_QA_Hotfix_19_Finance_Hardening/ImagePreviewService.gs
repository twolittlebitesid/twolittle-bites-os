/**
 * QA Hotfix 13 — server-assisted product image preview.
 *
 * Browser rendering remains the first path. This service is only used as a
 * fallback for Google Drive links that cannot be embedded directly because
 * of Drive sharing / resource-key behavior.
 */

function imagePreviewDriveFileId_(value) {
  var raw = String(value || '').trim();
  if (!raw) return '';

  var fileMatch = raw.match(
    /drive\.google\.com\/file\/d\/([^\/?#]+)/i
  );

  if (fileMatch) {
    return fileMatch[1];
  }

  var idMatch = raw.match(
    /[?&]id=([^&#]+)/i
  );

  return idMatch
    ? decodeURIComponent(idMatch[1])
    : '';
}

function imagePreviewDriveResourceKey_(value) {
  var raw = String(value || '').trim();
  if (!raw) return '';

  var match = raw.match(
    /[?&]resourcekey=([^&#]+)/i
  );

  return match
    ? decodeURIComponent(match[1])
    : '';
}

function resolveDriveImageDataUrl_(raw) {
  raw = String(raw || '').trim();

  if (!raw) {
    throw twbError_(
      'IMAGE_URL_REQUIRED',
      'Image URL is required.'
    );
  }

  var fileId =
    imagePreviewDriveFileId_(raw);

  if (!fileId) {
    throw twbError_(
      'IMAGE_SOURCE_UNSUPPORTED',
      'Server image fallback currently supports Google Drive links only.'
    );
  }

  var resourceKey =
    imagePreviewDriveResourceKey_(raw);

  var file;

  try {
    if (
      resourceKey &&
      typeof DriveApp.getFileByIdAndResourceKey ===
        'function'
    ) {
      file = DriveApp.getFileByIdAndResourceKey(
        fileId,
        resourceKey
      );
    } else {
      file = DriveApp.getFileById(
        fileId
      );
    }
  } catch (e) {
    throw twbError_(
      'IMAGE_DRIVE_ACCESS_FAILED',
      'The image exists, but this Apps Script account cannot read the Google Drive file. Share the file with the script owner or use a public image URL.',
      {
        fileId: fileId,
        message: e && e.message
          ? e.message
          : String(e)
      }
    );
  }

  var blob = file.getBlob();
  var mime = String(
    blob.getContentType() || ''
  ).toLowerCase();

  if (
    mime.indexOf('image/') !== 0
  ) {
    throw twbError_(
      'IMAGE_FILE_TYPE_INVALID',
      'The linked Google Drive file is not an image.'
    );
  }

  var bytes = blob.getBytes();
  var maxBytes = 4500000;

  if (
    bytes.length > maxBytes
  ) {
    throw twbError_(
      'IMAGE_FILE_TOO_LARGE',
      'The linked image is too large for in-app preview. Use an image below 4.5 MB.'
    );
  }

  return {
    source: 'GOOGLE_DRIVE_SERVER_FALLBACK',
    file_id: fileId,
    file_name: file.getName(),
    mime_type: mime,
    byte_size: bytes.length,
    data_url:
      'data:' +
      mime +
      ';base64,' +
      Utilities.base64Encode(bytes)
  };
}

function resolveProductImagePreview(payload) {
  requireAnyPermission_([
    'PRODUCT_READ',
    'ORDER_READ',
    'SETTINGS_READ'
  ]);

  payload = payload || {};

  return resolveDriveImageDataUrl_(
    payload.url
  );
}
