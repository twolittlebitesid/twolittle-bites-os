# PHASE_11_IMPLEMENTATION.md
# Twolittle.bites OS — CRM & Customer Intelligence

**Phase:** 11  
**App Version:** 0.11.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Core principle

Phase 11 does not create a separate CRM database.

```text
CUSTOMERS
+
COMPLETED ORDERS
+
ORDER ITEMS
↓
Customer Intelligence
```

This keeps `Input once, reuse everywhere`.

## Metrics

For every Customer, Phase 11 derives:

```text
Completed Orders
Historical Customer Value
Average Order Value
First Completed Order
Last Completed Order
Recency Days
Average Days Between Orders
Favorite Product
Top Sales Channel
Pre-Order Count
R Score
F Score
M Score
RFM Total
CRM Segment
Dormant / Reactivation Signal
```

`Historical Customer Value` means actual completed-order spend to date.

It is **not** a predicted Customer Lifetime Value model.

## Repeat customer rate

Global repeat customer rate:

```text
customers with 2+ completed Orders
/
customers with 1+ completed Order
```

This is a customer repeat-rate metric, not repeat Orders divided by all Orders.

## RFM-style scoring

The implementation uses a relative quintile-style score against the current customer cohort.

### Recency

```text
fewer days since last completed Order
= better score
```

### Frequency

```text
more completed Orders
= better score
```

### Monetary

```text
more completed-order spend
= better score
```

Each component is scored approximately:

```text
1 → 5
```

Total:

```text
R + F + M
maximum = 15
```

Because the scores are relative, there is no hard-coded assumption such as “Rp1 million always means VIP.”

## CRM segments

Derived live:

```text
DORMANT
→ has completed-order history
→ recency exceeds CRM_DORMANT_DAYS

VIP
→ at least 3 completed Orders
→ RFM total >= 13

HIGH_VALUE
→ Monetary score >= 4
→ RFM total >= 10

REPEAT
→ 2+ completed Orders

NEW
→ no completed Order or one completed Order
```

Dormant takes precedence over value tiers.

These are descriptive operational segments.

## Dormant threshold

Default:

```text
CRM_DORMANT_DAYS = 60
```

This can be changed later without schema changes.

Phase 11 only identifies reactivation candidates. It does not automatically send WhatsApp or marketing messages.

## Customer Profile

Profile includes:

```text
CRM segment
R / F / M scores
Historical value
AOV
Recency
Purchase cadence
Favorite Product
Top Channel
Pre-Order count
Product affinity
Channel mix
Order history
```

Product affinity is based on completed-order quantity and line revenue.

## Privacy-aware limited access

Roles with:

```text
CUSTOMER_READ
```

receive normal profile fields.

Roles with only:

```text
CUSTOMER_READ_LIMITED
```

still receive customer behavior and CRM insight, but:

```text
WhatsApp → masked
Email → masked
Default Address → hidden
Notes → hidden
```

This allows Marketing to use segmentation without exposing unnecessary contact details.

## Stored Customer metrics vs live intelligence

The existing CUSTOMER fields remain:

```text
first_order_date
last_order_date
total_orders
total_spend
average_order_value
favorite_product_id
segment
```

Base metrics continue to update when Orders are completed.

Phase 11's richer:

```text
crm_segment
RFM
recency
cadence
channel preference
reactivation signal
```

are calculated live rather than creating duplicate columns.

The legacy `CUSTOMERS.segment` field remains for compatibility.

## Optional base metric rebuild

OWNER / ADMIN can run:

```javascript
rebuildCustomerMetricsPhase11()
```

This recalculates the stored Customer aggregate fields from completed Orders.

It does not create Orders or modify order history.

## UI

Customers:

```text
Overview
Directory
Segments
Reactivation
```

Overview:
- total customers
- repeat rate
- dormant count
- historical customer value
- buyers
- VIP count
- completed-order AOV
- top customers

Directory:
- CRM segment
- historical value
- AOV
- RFM total
- recency

Segments:
- customer count
- completed Orders
- historical value
- average value per customer

Reactivation:
- dormant customers
- days since last order
- historical value
- favorite product
- top channel

## Install from Phase 10

Replace:

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
CustomerService.gs
PageCustomers.html
JsCustomers.html
StylesComponents.html
StylesResponsive.html
```

Add:

```text
CustomerIntelligenceService.gs
Phase11Setup.gs
Phase11HealthCheck.gs
Phase11SmokeTest.gs
```

## Upgrade

```javascript
upgradeToPhase11()
```

Sets:

```text
APP_VERSION = 0.11.0
SCHEMA_VERSION = 1.0.0
CRM_DORMANT_DAYS = 60
CRM_PROFILE_ORDER_LIMIT = 50
CRM_RFM_METHOD = RELATIVE_QUINTILE_STYLE
```

No Sheet is recreated.

## Validation

```javascript
runPhase11HealthCheck()
runPhase11SmokeTest()
```

Both are read-only against business transaction data.

## Browser QA

1. Open Customers.
2. Check Overview metrics.
3. Open Directory.
4. Open a Customer Profile.
5. Confirm Product Affinity and Order History.
6. Open Segments.
7. Check segment counts/value.
8. Open Reactivation.
9. Confirm only dormant customers appear.
10. Login with a `CUSTOMER_READ_LIMITED` role and verify:
   - WhatsApp masked;
   - email masked;
   - address hidden;
   - notes hidden;
   - behavioral insight still visible.

## Next

**Phase 12 — Marketing & Attribution Engine**
