# QA_HOTFIX_06_WORKFLOW_AND_UI.md
# P0/P1 — Draft Persistence, Variants, Header, Images, Order Filter, Commerce UI

## Closed findings

```text
P0 — New Order loses data when modal is closed / outside area is clicked.
P0 — Variants are not visible in Products.
P0 — Improve the top header across all menus.
P0 — Product says image linked but image does not render.
P0 — Filter Orders by Order Status.
P1 — Improve Commerce Settings styling.
```

## New Order draft persistence

Unfinished New Order / Pre-Order forms are now kept in in-memory draft state.

Closing by:
- X;
- Cancel;
- clicking the modal backdrop;

stores the current form.

Opening New Order again restores:
- Customer selection/search text;
- source channel;
- Order date;
- fulfillment type/date/time;
- address;
- all Product/Variant item rows;
- quantities;
- line discounts;
- production notes;
- order discount;
- delivery fee;
- tax;
- initial status;
- notes.

Drafts are separated between normal Orders and individual Pre-Order campaigns.

A successful Order creation clears its draft.

No Sheet writes occur until Create Order succeeds.

## Product + Variant hierarchy

Products are now grouped by `category`.

Each Product row is followed by its Variants:

```text
TIRAMISU
  Classic Tiramisu
    ↳ Small
    ↳ Large
  Matcha Tiramisu
    ↳ Small
    ↳ Large
```

Variant row shows:
- SKU;
- inherited/override selling price;
- estimated/active-recipe COGS;
- margin;
- status;
- Edit action.

QA Hotfix 06 adds a controlled `variants.update` API using the existing PRODUCT_WRITE permission.

## Product image URL normalization

Existing `PRODUCTS.image_url` remains the source.

Client rendering now normalizes common share URLs.

Google Drive:

```text
https://drive.google.com/file/d/FILE_ID/view
```

becomes a renderable thumbnail URL.

Dropbox share links are converted to raw image mode.

Normal/direct image URLs remain unchanged.

Used in:
- Product Master thumbnail;
- Product Edit live preview;
- New Order selected Product thumbnail.

If a Google Drive image is not shared with an audience that can access it, the browser can still fail to load it. In that case the UI falls back to the Product icon rather than breaking the page.

## Order Status filter

Orders toolbar now includes:

```text
Status
[ All Statuses ▾ ]
```

Statuses include:
- Draft;
- Waiting Payment;
- Confirmed;
- Scheduled;
- In Production;
- Ready;
- On Delivery;
- Completed;
- Cancelled.

The filter combines with:
- All Orders;
- Today;
- Upcoming;
- Need Attention.

The filter is hidden in the Pre-Orders campaign view.

## Global header cleanup

The global header and module banners now share one layout system across all routes:
- consistent header height;
- cleaner active navigation;
- balanced brand/navigation/user spacing;
- consistent module icon;
- consistent module title size;
- consistent banner height/padding;
- responsive tablet/mobile behavior.

No route-specific header implementation is introduced.

## Commerce Settings redesign

Raw multiline textareas are replaced visually by token/chip editors:

```text
Sales Channels
[WHATSAPP ×] [INSTAGRAM ×] [+ input]

Fulfillment Types
[PICKUP ×] [DELIVERY ×]

Payment Methods
[BANK_TRANSFER ×] [QRIS ×]

Expense Categories
[MARKETING 🔒] [ADS 🔒] [...]
```

The existing server contract is unchanged: the chips sync into the same CONFIG lists on Save.

MARKETING and ADS are protected.

Read-only Settings roles cannot add/remove chips.

## Install from QA Hotfix 05

Replace:

```text
JsApp.html
JsOrders.html
PageOrders.html
JsProducts.html
ProductService.gs
ApiGateway.gs
PageSettings.html
JsSettings.html
StylesComponents.html
StylesResponsive.html
Phase16HealthCheck.gs
PRODUCTION_ACCEPTANCE_TEST.md
```

No schema migration.
No `upgradeToPhase16()` rerun.

Then run:

```javascript
runPhase16HealthCheck()
```

Expected additional check:

```text
QA_HOTFIX_06_WORKFLOW_UI = true
```
