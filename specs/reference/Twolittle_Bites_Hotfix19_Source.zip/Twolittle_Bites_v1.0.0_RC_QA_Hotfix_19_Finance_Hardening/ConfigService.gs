function configCacheKey_(prefix, key) {
  return 'TWB_' + prefix + '_' + String(key || '');
}

function getCachedConfigValue_(prefix, key) {
  try {
    const raw = CacheService
      .getScriptCache()
      .get(
        configCacheKey_(
          prefix,
          key
        )
      );

    if (!raw) return null;

    const parsed = JSON.parse(raw);

    return {
      hit: true,
      found: parsed.found === true,
      value: parsed.value
    };
  } catch (e) {
    return null;
  }
}

function putCachedConfigValue_(
  prefix,
  key,
  found,
  value
) {
  try {
    CacheService
      .getScriptCache()
      .put(
        configCacheKey_(
          prefix,
          key
        ),
        JSON.stringify({
          found: found === true,
          value: value
        }),
        300
      );
  } catch (e) {}
}

function clearCachedConfigValue_(
  prefix,
  key
) {
  try {
    CacheService
      .getScriptCache()
      .remove(
        configCacheKey_(
          prefix,
          key
        )
      );
  } catch (e) {}
}

function getConfig_(key) {
  const cached =
    getCachedConfigValue_(
      'CFG',
      key
    );

  if (
    cached &&
    cached.hit
  ) {
    return cached.found
      ? cached.value
      : null;
  }

  const row =
    dbFindOne(
      'CONFIG',
      'config_key',
      key
    );

  const value =
    row
      ? parseConfigValue_(
          row.config_value,
          row.value_type
        )
      : null;

  putCachedConfigValue_(
    'CFG',
    key,
    !!row,
    value
  );

  return value;
}

function getConfig(key) {
  requireCurrentUser_();
  return getConfig_(key);
}

function setConfig_(key, value, valueType, description, actorUserId) {
  const now = nowIso_();
  const existing = dbFindOne('CONFIG', 'config_key', key);
  const payload = {
    config_key: key,
    config_value: stringifyCellValue_(value, valueType || 'STRING'),
    value_type: valueType || 'STRING',
    description: description || '',
    updated_at: now,
    updated_by: actorUserId
  };

  const result = existing
    ? dbUpdateById('CONFIG', key, payload, { validate: true })
    : dbInsertRecord('CONFIG', payload, { validate: true });

  clearCachedConfigValue_(
    'CFG',
    key
  );

  return result;
}

function getBusinessSetting_(key) {
  const cached =
    getCachedConfigValue_(
      'BIZ',
      key
    );

  if (
    cached &&
    cached.hit
  ) {
    return cached.found
      ? cached.value
      : null;
  }

  const row =
    dbFindOne(
      'BUSINESS_SETTINGS',
      'setting_key',
      key
    );

  const value =
    row
      ? parseConfigValue_(
          row.setting_value,
          row.value_type
        )
      : null;

  putCachedConfigValue_(
    'BIZ',
    key,
    !!row,
    value
  );

  return value;
}

function setBusinessSetting_(key, value, valueType, groupName, description, actorUserId) {
  const now = nowIso_();
  const existing = dbFindOne('BUSINESS_SETTINGS', 'setting_key', key);
  const payload = {
    setting_key: key,
    setting_value: stringifyCellValue_(value, valueType || 'STRING'),
    value_type: valueType || 'STRING',
    group_name: groupName || 'BUSINESS',
    description: description || '',
    updated_at: now,
    updated_by: actorUserId
  };

  const result = existing
    ? dbUpdateById('BUSINESS_SETTINGS', key, payload, { validate: true })
    : dbInsertRecord('BUSINESS_SETTINGS', payload, { validate: true });

  clearCachedConfigValue_(
    'BIZ',
    key
  );

  return result;
}
