# QA_HOTFIX_16_STATIC_QA.md

- Server `.gs` syntax: PASS (65 files)
- Client `Js*.html` syntax: PASS (19 files)
- `{delivery_fee}` allowed by Settings validator: PASS
- WhatsApp renderer maps to `invoice.delivery_fee`: PASS
- IDR formatting uses `formatIdrText_()`: PASS
- Default WhatsApp template includes Ongkir: PASS
- Fallback WhatsApp template includes Ongkir: PASS
- Settings live preview sample includes delivery fee: PASS
- Placeholder chips remain dynamic: PASS
- Existing WhatsApp placeholders preserved: PASS
- Phase16 Hotfix16 health guard: PASS
- Canonical sheet count unchanged: PASS (33/33)

- Sheet schema migration required: NO
- Data rewrite required: NO

Runtime/manual boundary:
- Static QA cannot render a real WhatsApp message without an existing Invoice. After applying, run `upgradeToQAHotfix16()` and test a real invoice WhatsApp link.
