/**
 * Twolittle.bites OS — Canonical schema registry.
 * Generated from Phase 0 SHEET_SCHEMA.md.
 */
const TWB_SHEET_SCHEMAS = Object.freeze({
  "CONFIG": {
    "nature": "Primary",
    "headers": [
      "config_key",
      "config_value",
      "value_type",
      "description",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "config_key",
      "config_value",
      "value_type",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "config_key",
    "unique": []
  },
  "USERS": {
    "nature": "Primary",
    "headers": [
      "user_id",
      "email",
      "display_name",
      "role",
      "status",
      "last_login_at",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "user_id",
      "email",
      "display_name",
      "role",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "user_id",
    "unique": [
      "email"
    ]
  },
  "BUSINESS_SETTINGS": {
    "nature": "Primary",
    "headers": [
      "setting_key",
      "setting_value",
      "value_type",
      "group_name",
      "description",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "setting_key",
      "setting_value",
      "value_type",
      "group_name",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "setting_key",
    "unique": []
  },
  "CUSTOMERS": {
    "nature": "Primary",
    "headers": [
      "customer_id",
      "name",
      "whatsapp",
      "email",
      "default_address",
      "segment",
      "first_order_date",
      "last_order_date",
      "total_orders",
      "total_spend",
      "average_order_value",
      "favorite_product_id",
      "notes",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "customer_id",
      "name",
      "whatsapp",
      "segment",
      "total_orders",
      "total_spend",
      "average_order_value",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "customer_id",
    "unique": []
  },
  "PRODUCTS": {
    "nature": "Primary",
    "headers": [
      "product_id",
      "sku",
      "product_name",
      "category",
      "selling_price",
      "base_recipe_id",
      "default_packaging_id",
      "image_url",
      "current_cogs",
      "gross_profit",
      "gross_margin_pct",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "product_id",
      "sku",
      "product_name",
      "category",
      "selling_price",
      "current_cogs",
      "gross_profit",
      "gross_margin_pct",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "product_id",
    "unique": [
      "sku"
    ]
  },
  "PRODUCT_VARIANTS": {
    "nature": "Primary",
    "headers": [
      "variant_id",
      "product_id",
      "variant_name",
      "size",
      "sku",
      "selling_price_override",
      "recipe_id",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "variant_id",
      "product_id",
      "variant_name",
      "sku",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "variant_id",
    "unique": [
      "sku"
    ]
  },
  "INGREDIENTS": {
    "nature": "Primary",
    "headers": [
      "ingredient_id",
      "ingredient_name",
      "category",
      "base_unit",
      "purchase_unit",
      "purchase_to_base_factor",
      "minimum_stock_base",
      "average_cost_per_base_unit",
      "latest_cost_per_base_unit",
      "default_supplier_id",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "ingredient_id",
      "ingredient_name",
      "category",
      "base_unit",
      "purchase_unit",
      "purchase_to_base_factor",
      "minimum_stock_base",
      "average_cost_per_base_unit",
      "latest_cost_per_base_unit",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "ingredient_id",
    "unique": []
  },
  "PACKAGING": {
    "nature": "Primary",
    "headers": [
      "packaging_id",
      "packaging_name",
      "category",
      "base_unit",
      "purchase_unit",
      "purchase_to_base_factor",
      "minimum_stock_base",
      "average_cost_per_base_unit",
      "latest_cost_per_base_unit",
      "default_supplier_id",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "packaging_id",
      "packaging_name",
      "category",
      "base_unit",
      "purchase_unit",
      "purchase_to_base_factor",
      "minimum_stock_base",
      "average_cost_per_base_unit",
      "latest_cost_per_base_unit",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "packaging_id",
    "unique": []
  },
  "UNIT_CONVERSIONS": {
    "nature": "Primary",
    "headers": [
      "conversion_id",
      "scope",
      "item_type",
      "item_id",
      "from_unit",
      "to_unit",
      "factor",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "conversion_id",
      "scope",
      "from_unit",
      "to_unit",
      "factor",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "conversion_id",
    "unique": []
  },
  "RECIPES": {
    "nature": "Primary",
    "headers": [
      "recipe_id",
      "product_id",
      "variant_id",
      "recipe_name",
      "base_yield",
      "yield_unit",
      "scaling_mode",
      "version",
      "status",
      "effective_from",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "recipe_id",
      "product_id",
      "recipe_name",
      "base_yield",
      "yield_unit",
      "scaling_mode",
      "version",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "recipe_id",
    "unique": []
  },
  "RECIPE_ITEMS": {
    "nature": "Primary",
    "headers": [
      "recipe_item_id",
      "recipe_id",
      "item_type",
      "item_id",
      "quantity",
      "unit",
      "quantity_base",
      "waste_allowance_pct",
      "sort_order",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "recipe_item_id",
      "recipe_id",
      "item_type",
      "item_id",
      "quantity",
      "unit",
      "quantity_base",
      "waste_allowance_pct",
      "sort_order",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "recipe_item_id",
    "unique": []
  },
  "PREORDER_CAMPAIGNS": {
    "nature": "Primary",
    "headers": [
      "preorder_campaign_id",
      "campaign_name",
      "start_at",
      "cutoff_at",
      "production_date",
      "fulfillment_date",
      "maximum_capacity",
      "capacity_unit",
      "current_booked",
      "remaining_capacity",
      "status",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "preorder_campaign_id",
      "campaign_name",
      "start_at",
      "cutoff_at",
      "production_date",
      "fulfillment_date",
      "maximum_capacity",
      "capacity_unit",
      "current_booked",
      "remaining_capacity",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "preorder_campaign_id",
    "unique": []
  },
  "ORDERS": {
    "nature": "Primary",
    "headers": [
      "order_id",
      "order_date",
      "customer_id",
      "source_channel",
      "preorder_campaign_id",
      "order_status",
      "payment_status",
      "invoice_status",
      "fulfillment_type",
      "fulfillment_date",
      "fulfillment_time_start",
      "fulfillment_time_end",
      "delivery_address",
      "subtotal",
      "discount",
      "delivery_fee",
      "tax",
      "grand_total",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "order_id",
      "order_date",
      "customer_id",
      "source_channel",
      "order_status",
      "payment_status",
      "invoice_status",
      "fulfillment_type",
      "subtotal",
      "discount",
      "delivery_fee",
      "tax",
      "grand_total",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "order_id",
    "unique": []
  },
  "ORDER_ITEMS": {
    "nature": "Primary",
    "headers": [
      "order_item_id",
      "order_id",
      "product_id",
      "variant_id",
      "product_name_snapshot",
      "sku_snapshot",
      "quantity",
      "unit_price",
      "line_discount",
      "line_total",
      "production_notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "order_item_id",
      "order_id",
      "product_id",
      "product_name_snapshot",
      "sku_snapshot",
      "quantity",
      "unit_price",
      "line_discount",
      "line_total",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "order_item_id",
    "unique": []
  },
  "INVOICES": {
    "nature": "Primary",
    "headers": [
      "invoice_id",
      "invoice_number",
      "order_id",
      "customer_id",
      "invoice_date",
      "due_at",
      "subtotal",
      "discount",
      "delivery_fee",
      "tax",
      "grand_total",
      "paid_amount",
      "remaining_amount",
      "status",
      "last_payment_method",
      "public_token",
      "invoice_url",
      "sent_at",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "invoice_id",
      "invoice_number",
      "order_id",
      "customer_id",
      "invoice_date",
      "subtotal",
      "discount",
      "delivery_fee",
      "tax",
      "grand_total",
      "paid_amount",
      "remaining_amount",
      "status",
      "public_token",
      "invoice_url",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "invoice_id",
    "unique": [
      "invoice_number",
      "public_token"
    ]
  },
  "PAYMENTS": {
    "nature": "Primary",
    "headers": [
      "payment_id",
      "invoice_id",
      "order_id",
      "payment_at",
      "amount",
      "payment_method",
      "reference_no",
      "status",
      "proof_url",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "payment_id",
      "invoice_id",
      "order_id",
      "payment_at",
      "amount",
      "payment_method",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "payment_id",
    "unique": []
  },
  "PRODUCTION_PLANS": {
    "nature": "Primary",
    "headers": [
      "production_plan_id",
      "production_date",
      "source_type",
      "source_id",
      "status",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "production_plan_id",
      "production_date",
      "source_type",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "production_plan_id",
    "unique": []
  },
  "PRODUCTION_PLAN_ITEMS": {
    "nature": "Primary",
    "headers": [
      "plan_item_id",
      "production_plan_id",
      "product_id",
      "variant_id",
      "recipe_id",
      "recipe_version",
      "target_quantity",
      "target_unit",
      "scaling_mode",
      "multiplier",
      "required_batches",
      "expected_output",
      "expected_surplus",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "plan_item_id",
      "production_plan_id",
      "product_id",
      "recipe_id",
      "recipe_version",
      "target_quantity",
      "target_unit",
      "scaling_mode",
      "multiplier",
      "required_batches",
      "expected_output",
      "expected_surplus",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "plan_item_id",
    "unique": []
  },
  "PRODUCTION_REQUIREMENTS": {
    "nature": "Primary",
    "headers": [
      "requirement_id",
      "production_plan_id",
      "plan_item_id",
      "item_type",
      "item_id",
      "required_qty_base",
      "available_stock_base",
      "shortage_qty_base",
      "base_unit",
      "status",
      "calculated_at",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "requirement_id",
      "production_plan_id",
      "item_type",
      "item_id",
      "required_qty_base",
      "available_stock_base",
      "shortage_qty_base",
      "base_unit",
      "status",
      "calculated_at",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "requirement_id",
    "unique": []
  },
  "PRODUCTION_BATCHES": {
    "nature": "Primary",
    "headers": [
      "production_batch_id",
      "plan_item_id",
      "product_id",
      "recipe_id",
      "recipe_version",
      "batch_no",
      "planned_qty",
      "actual_qty",
      "failed_qty",
      "waste_qty",
      "yield_rate_pct",
      "status",
      "started_at",
      "completed_at",
      "pic_user_id",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "production_batch_id",
      "plan_item_id",
      "product_id",
      "recipe_id",
      "recipe_version",
      "batch_no",
      "planned_qty",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "production_batch_id",
    "unique": []
  },
  "INVENTORY": {
    "nature": "Primary",
    "headers": [
      "inventory_id",
      "item_type",
      "item_id",
      "current_stock_base",
      "minimum_stock_base",
      "average_cost_per_base_unit",
      "last_movement_at",
      "updated_at"
    ],
    "required": [
      "inventory_id",
      "item_type",
      "item_id",
      "current_stock_base",
      "minimum_stock_base",
      "average_cost_per_base_unit",
      "updated_at"
    ],
    "primaryKey": "inventory_id",
    "unique": [
      "item_id"
    ]
  },
  "INVENTORY_MOVEMENTS": {
    "nature": "Primary",
    "headers": [
      "movement_id",
      "movement_at",
      "item_type",
      "item_id",
      "movement_type",
      "quantity_in_base",
      "quantity_out_base",
      "balance_after_base",
      "base_unit",
      "reference_type",
      "reference_id",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "movement_id",
      "movement_at",
      "item_type",
      "item_id",
      "movement_type",
      "quantity_in_base",
      "quantity_out_base",
      "balance_after_base",
      "base_unit",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "movement_id",
    "unique": []
  },
  "SUPPLIERS": {
    "nature": "Primary",
    "headers": [
      "supplier_id",
      "supplier_name",
      "contact_person",
      "whatsapp",
      "email",
      "address",
      "lead_time_days",
      "minimum_order_value",
      "status",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "supplier_id",
      "supplier_name",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "supplier_id",
    "unique": []
  },
  "PURCHASES": {
    "nature": "Primary",
    "headers": [
      "purchase_id",
      "supplier_id",
      "purchase_date",
      "expected_date",
      "received_date",
      "status",
      "payment_status",
      "subtotal",
      "delivery_cost",
      "total_cost",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "purchase_id",
      "supplier_id",
      "purchase_date",
      "status",
      "payment_status",
      "subtotal",
      "delivery_cost",
      "total_cost",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "purchase_id",
    "unique": []
  },
  "PURCHASE_ITEMS": {
    "nature": "Primary",
    "headers": [
      "purchase_item_id",
      "purchase_id",
      "item_type",
      "item_id",
      "quantity",
      "unit",
      "quantity_base",
      "unit_cost",
      "total_cost",
      "received_qty_base",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "purchase_item_id",
      "purchase_id",
      "item_type",
      "item_id",
      "quantity",
      "unit",
      "quantity_base",
      "unit_cost",
      "total_cost",
      "received_qty_base",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "purchase_item_id",
    "unique": []
  },
  "EXPENSES": {
    "nature": "Primary",
    "headers": [
      "expense_id",
      "expense_date",
      "category",
      "vendor",
      "amount",
      "payment_method",
      "receipt_url",
      "status",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "expense_id",
      "expense_date",
      "category",
      "amount",
      "payment_method",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "expense_id",
    "unique": []
  },
  "TRANSACTIONS": {
    "nature": "Primary",
    "headers": [
      "transaction_id",
      "transaction_at",
      "transaction_type",
      "category",
      "reference_type",
      "reference_id",
      "amount_in",
      "amount_out",
      "payment_method",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "transaction_id",
      "transaction_at",
      "transaction_type",
      "amount_in",
      "amount_out",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "transaction_id",
    "unique": []
  },
  "BUSINESS_TARGETS": {
    "nature": "Primary",
    "headers": [
      "target_id",
      "period_type",
      "period_start",
      "period_end",
      "metric_key",
      "target_value",
      "unit",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "target_id",
      "period_type",
      "period_start",
      "period_end",
      "metric_key",
      "target_value",
      "unit",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "target_id",
    "unique": []
  },
  "MARKETING_CAMPAIGNS": {
    "nature": "Primary",
    "headers": [
      "marketing_campaign_id",
      "campaign_name",
      "start_date",
      "end_date",
      "budget",
      "spend",
      "revenue_attributed",
      "orders_attributed",
      "new_customers",
      "repeat_customers",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "marketing_campaign_id",
      "campaign_name",
      "start_date",
      "budget",
      "spend",
      "revenue_attributed",
      "orders_attributed",
      "new_customers",
      "repeat_customers",
      "status",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "marketing_campaign_id",
    "unique": []
  },
  "CONTENT": {
    "nature": "Primary",
    "headers": [
      "content_id",
      "marketing_campaign_id",
      "platform",
      "pillar",
      "format",
      "publish_date",
      "url",
      "reach",
      "views",
      "engagement",
      "link_click",
      "orders_attributed",
      "revenue_attributed",
      "notes",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "required": [
      "content_id",
      "platform",
      "reach",
      "views",
      "engagement",
      "link_click",
      "orders_attributed",
      "revenue_attributed",
      "created_at",
      "created_by",
      "updated_at",
      "updated_by"
    ],
    "primaryKey": "content_id",
    "unique": []
  },
  "DAILY_METRICS": {
    "nature": "Derived cache",
    "headers": [
      "metric_date",
      "metric_key",
      "metric_value",
      "unit",
      "calculated_at"
    ],
    "required": [
      "metric_date",
      "metric_key",
      "metric_value",
      "unit",
      "calculated_at"
    ],
    "primaryKey": "metric_date",
    "unique": []
  },
  "MONTHLY_METRICS": {
    "nature": "Derived cache",
    "headers": [
      "month",
      "metric_key",
      "metric_value",
      "unit",
      "calculated_at"
    ],
    "required": [
      "month",
      "metric_key",
      "metric_value",
      "unit",
      "calculated_at"
    ],
    "primaryKey": "month",
    "unique": []
  },
  "ACTIVITY_LOG": {
    "nature": "Primary",
    "headers": [
      "log_id",
      "timestamp",
      "user_id",
      "action",
      "entity_type",
      "entity_id",
      "before_json",
      "after_json",
      "source",
      "notes"
    ],
    "required": [
      "log_id",
      "timestamp",
      "user_id",
      "action",
      "entity_type",
      "entity_id",
      "source"
    ],
    "primaryKey": "log_id",
    "unique": []
  }
});

const TWB_SHEET_ORDER = Object.freeze(["CONFIG", "USERS", "BUSINESS_SETTINGS", "CUSTOMERS", "PRODUCTS", "PRODUCT_VARIANTS", "INGREDIENTS", "PACKAGING", "UNIT_CONVERSIONS", "RECIPES", "RECIPE_ITEMS", "PREORDER_CAMPAIGNS", "ORDERS", "ORDER_ITEMS", "INVOICES", "PAYMENTS", "PRODUCTION_PLANS", "PRODUCTION_PLAN_ITEMS", "PRODUCTION_REQUIREMENTS", "PRODUCTION_BATCHES", "INVENTORY", "INVENTORY_MOVEMENTS", "SUPPLIERS", "PURCHASES", "PURCHASE_ITEMS", "EXPENSES", "TRANSACTIONS", "BUSINESS_TARGETS", "MARKETING_CAMPAIGNS", "CONTENT", "DAILY_METRICS", "MONTHLY_METRICS", "ACTIVITY_LOG"]);

function getSheetSchema_(sheetName) {
  const schema = TWB_SHEET_SCHEMAS[sheetName];
  if (!schema) throw twbError_('UNKNOWN_SHEET', 'Unknown sheet: ' + sheetName);
  return schema;
}

function validateDatabaseSchema() {
  const ss = getDatabaseSpreadsheet_();
  const report = {
    ok: true,
    spreadsheetId: ss.getId(),
    spreadsheetUrl: ss.getUrl(),
    schemaVersion: TWB_APP.SCHEMA_VERSION,
    sheets: []
  };

  TWB_SHEET_ORDER.forEach(function(name) {
    const expected = TWB_SHEET_SCHEMAS[name].headers;
    const sheet = ss.getSheetByName(name);
    if (!sheet) {
      report.ok = false;
      report.sheets.push({ sheet: name, ok: false, issue: 'MISSING_SHEET' });
      return;
    }
    const actual = sheet.getRange(1, 1, 1, Math.max(1, sheet.getLastColumn())).getValues()[0];
    const trimmed = actual.slice(0, expected.length);
    const match = expected.length === trimmed.length &&
      expected.every(function(header, i) { return trimmed[i] === header; });
    if (!match) report.ok = false;
    report.sheets.push({
      sheet: name,
      ok: match,
      expectedColumns: expected.length,
      actualColumns: sheet.getLastColumn(),
      issue: match ? null : 'HEADER_MISMATCH'
    });
  });

  return report;
}
