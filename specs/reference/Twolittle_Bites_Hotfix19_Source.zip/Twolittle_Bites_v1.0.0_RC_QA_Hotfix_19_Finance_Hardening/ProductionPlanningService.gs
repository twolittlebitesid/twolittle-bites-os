/**
 * Twolittle.bites OS — Phase 6 Production Planning Engine
 *
 * Source of truth in this phase:
 * - ORDERS / ORDER_ITEMS provide demand.
 * - RECIPES / RECIPE_ITEMS provide BOM and base yield.
 * - INVENTORY is read only to snapshot current availability.
 *
 * Phase 6 DOES NOT:
 * - deduct inventory;
 * - create inventory movements;
 * - create purchases;
 * - alter order status automatically.
 */

const TWB_PRODUCTION_PLAN_TRANSITIONS = Object.freeze({
  DRAFT: ['PLANNED', 'CANCELLED'],
  PLANNED: ['IN_PROGRESS', 'CANCELLED'],
  IN_PROGRESS: ['COMPLETED'],
  COMPLETED: [],
  CANCELLED: []
});

function normalizeDateKey_(value) {
  if (!value) return '';

  if (
    Object.prototype.toString.call(value) === '[object Date]' &&
    !isNaN(value.getTime())
  ) {
    return Utilities.formatDate(
      value,
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );
  }

  const raw = String(value).trim();
  const direct = raw.match(/^(\d{4}-\d{2}-\d{2})/);
  if (direct) return direct[1];

  const parsed = new Date(raw);
  if (!isNaN(parsed.getTime())) {
    return Utilities.formatDate(
      parsed,
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );
  }

  return raw;
}

function productionEligibleStatuses_() {
  const configured = getConfig_(
    'PRODUCTION_ELIGIBLE_ORDER_STATUSES'
  );

  if (Array.isArray(configured) && configured.length) {
    return configured.map(function(status) {
      return String(status).toUpperCase();
    });
  }

  return ['CONFIRMED', 'SCHEDULED'];
}

function parsePlanOrderIds_(sourceId) {
  return String(sourceId || '')
    .split('|')
    .map(function(id) { return id.trim(); })
    .filter(Boolean);
}

function getLivePlannedOrderIdMapFromRows_(plans) {
  const planned = {};

  (plans || []).forEach(function(plan) {
    if (
      String(plan.source_type).toUpperCase() !== 'ORDER_SET' ||
      String(plan.status).toUpperCase() === 'CANCELLED'
    ) {
      return;
    }

    parsePlanOrderIds_(plan.source_id).forEach(function(orderId) {
      planned[orderId] = plan.production_plan_id;
    });
  });

  return planned;
}

function loadProductionPlanningData_() {
  return {
    customers: listAllRecords_('CUSTOMERS').map(stripInternalFields_),
    orders: listAllRecords_('ORDERS').map(stripInternalFields_),
    orderItems: listAllRecords_('ORDER_ITEMS').map(stripInternalFields_),
    products: listAllRecords_('PRODUCTS').map(stripInternalFields_),
    variants: listAllRecords_('PRODUCT_VARIANTS').map(stripInternalFields_),
    recipes: listAllRecords_('RECIPES').map(stripInternalFields_),
    recipeItems: listAllRecords_('RECIPE_ITEMS').map(stripInternalFields_),
    ingredients: listAllRecords_('INGREDIENTS').map(stripInternalFields_),
    packaging: listAllRecords_('PACKAGING').map(stripInternalFields_),
    inventory: listAllRecords_('INVENTORY').map(stripInternalFields_),
    plans: listAllRecords_('PRODUCTION_PLANS').map(stripInternalFields_),
    planItems: listAllRecords_('PRODUCTION_PLAN_ITEMS').map(stripInternalFields_),
    requirements: listAllRecords_('PRODUCTION_REQUIREMENTS').map(stripInternalFields_)
  };
}

function resolvePlanningRecipe_(group, maps) {
  const product = maps.products[group.productId] || null;
  const variant = group.variantId
    ? maps.variants[group.variantId] || null
    : null;

  if (!product) return null;

  const explicitRecipeId = variant && variant.recipe_id
    ? variant.recipe_id
    : product.base_recipe_id;

  if (explicitRecipeId) {
    const explicit = maps.recipes[explicitRecipeId];
    if (
      explicit &&
      String(explicit.status).toUpperCase() === 'ACTIVE'
    ) {
      return explicit;
    }
  }

  const key =
    String(group.productId) +
    '|' +
    String(group.variantId || '');

  const candidates = maps.activeRecipesByTarget[key] || [];
  return candidates.length ? candidates[0] : null;
}

function buildProductionSnapshotFromData_(orders, data) {
  orders = orders || [];
  data = data || {};

  const customers = data.customers || [];
  const orderItems = data.orderItems || [];
  const products = data.products || [];
  const variants = data.variants || [];
  const recipes = data.recipes || [];
  const recipeItems = data.recipeItems || [];
  const ingredients = data.ingredients || [];
  const packaging = data.packaging || [];
  const inventory = data.inventory || [];

  const maps = {
    customers: {},
    products: {},
    variants: {},
    recipes: {},
    ingredients: {},
    packaging: {},
    inventory: {},
    activeRecipesByTarget: {},
    recipeItems: {}
  };

  customers.forEach(function(row) {
    maps.customers[row.customer_id] = row;
  });
  products.forEach(function(row) {
    maps.products[row.product_id] = row;
  });
  variants.forEach(function(row) {
    maps.variants[row.variant_id] = row;
  });
  recipes.forEach(function(row) {
    maps.recipes[row.recipe_id] = row;

    if (String(row.status).toUpperCase() === 'ACTIVE') {
      const key =
        String(row.product_id) +
        '|' +
        String(row.variant_id || '');

      if (!maps.activeRecipesByTarget[key]) {
        maps.activeRecipesByTarget[key] = [];
      }

      maps.activeRecipesByTarget[key].push(row);
    }
  });

  Object.keys(maps.activeRecipesByTarget).forEach(function(key) {
    maps.activeRecipesByTarget[key].sort(function(a, b) {
      return Number(b.version || 0) - Number(a.version || 0);
    });
  });

  ingredients.forEach(function(row) {
    maps.ingredients[row.ingredient_id] = row;
  });
  packaging.forEach(function(row) {
    maps.packaging[row.packaging_id] = row;
  });
  inventory.forEach(function(row) {
    maps.inventory[row.item_id] = row;
  });

  recipeItems.forEach(function(row) {
    if (!maps.recipeItems[row.recipe_id]) {
      maps.recipeItems[row.recipe_id] = [];
    }
    maps.recipeItems[row.recipe_id].push(row);
  });

  const selectedOrderMap = {};
  orders.forEach(function(order) {
    selectedOrderMap[order.order_id] = order;
  });

  const groupedTargets = {};
  const sourceOrderQty = {};

  orderItems.forEach(function(item) {
    if (!selectedOrderMap[item.order_id]) return;

    const key =
      String(item.product_id) +
      '|' +
      String(item.variant_id || '');

    if (!groupedTargets[key]) {
      groupedTargets[key] = {
        productId: item.product_id,
        variantId: item.variant_id || '',
        targetQuantity: 0,
        orderCountMap: {},
        orderItemCount: 0
      };
    }

    groupedTargets[key].targetQuantity += Number(item.quantity || 0);
    groupedTargets[key].orderCountMap[item.order_id] = true;
    groupedTargets[key].orderItemCount += 1;

    sourceOrderQty[item.order_id] =
      (sourceOrderQty[item.order_id] || 0) +
      Number(item.quantity || 0);
  });

  const blockers = [];
  const planItems = [];
  const requirementMap = {};

  Object.keys(groupedTargets).forEach(function(key) {
    const group = groupedTargets[key];
    const product = maps.products[group.productId] || null;
    const variant = group.variantId
      ? maps.variants[group.variantId] || null
      : null;

    if (!product) {
      blockers.push({
        code: 'PRODUCT_MISSING',
        productId: group.productId,
        message: 'Product not found: ' + group.productId
      });
      return;
    }

    const recipe = resolvePlanningRecipe_(group, maps);

    if (!recipe) {
      blockers.push({
        code: 'ACTIVE_RECIPE_MISSING',
        productId: group.productId,
        variantId: group.variantId,
        productName:
          product.product_name +
          (variant ? ' · ' + variant.variant_name : ''),
        message:
          'No ACTIVE recipe for ' +
          product.product_name +
          (variant ? ' · ' + variant.variant_name : '')
      });
      return;
    }

    const recipeRows = maps.recipeItems[recipe.recipe_id] || [];
    if (!recipeRows.length) {
      blockers.push({
        code: 'RECIPE_ITEMS_MISSING',
        recipeId: recipe.recipe_id,
        productName: product.product_name,
        message: 'Recipe has no BOM items: ' + recipe.recipe_name
      });
      return;
    }

    const scaling = calculateScalingPlan_(
      recipe.base_yield,
      group.targetQuantity,
      recipe.scaling_mode
    );

    planItems.push({
      productId: group.productId,
      variantId: group.variantId,
      productName:
        product.product_name +
        (variant ? ' · ' + variant.variant_name : ''),
      recipeId: recipe.recipe_id,
      recipeName: recipe.recipe_name,
      recipeVersion: Number(recipe.version || 0),
      targetQuantity: roundNumber_(group.targetQuantity, 6),
      targetUnit: recipe.yield_unit,
      scalingMode: scaling.scalingMode,
      multiplier: roundNumber_(scaling.multiplier, 6),
      requiredBatches: roundNumber_(scaling.requiredBatches, 6),
      expectedOutput: roundNumber_(scaling.expectedOutput, 6),
      expectedSurplus: roundNumber_(scaling.expectedSurplus, 6),
      sourceOrderCount: Object.keys(group.orderCountMap).length
    });

    recipeRows.forEach(function(recipeItem) {
      const itemType = String(recipeItem.item_type).toUpperCase();
      const material =
        itemType === 'INGREDIENT'
          ? maps.ingredients[recipeItem.item_id]
          : maps.packaging[recipeItem.item_id];

      if (!material) {
        blockers.push({
          code: 'MATERIAL_MISSING',
          recipeId: recipe.recipe_id,
          itemType: itemType,
          itemId: recipeItem.item_id,
          message:
            'Recipe references missing material: ' +
            recipeItem.item_id
        });
        return;
      }

      const wastePct = Number(
        recipeItem.waste_allowance_pct || 0
      );

      const required =
        Number(recipeItem.quantity_base || 0) *
        (1 + wastePct / 100) *
        Number(scaling.multiplier || 0);

      const reqKey =
        itemType +
        '|' +
        recipeItem.item_id +
        '|' +
        material.base_unit;

      if (!requirementMap[reqKey]) {
        requirementMap[reqKey] = {
          itemType: itemType,
          itemId: recipeItem.item_id,
          itemName:
            itemType === 'INGREDIENT'
              ? material.ingredient_name
              : material.packaging_name,
          category: material.category || '',
          requiredQtyBase: 0,
          baseUnit: material.base_unit,
          minimumStockBase: Number(
            material.minimum_stock_base || 0
          )
        };
      }

      requirementMap[reqKey].requiredQtyBase += required;
    });
  });

  const requirements = Object.keys(requirementMap)
    .map(function(key) {
      const req = requirementMap[key];
      const stock = maps.inventory[req.itemId] || null;
      const available = stock
        ? Number(stock.current_stock_base || 0)
        : 0;

      const minimum = stock
        ? Number(
            stock.minimum_stock_base ||
            req.minimumStockBase ||
            0
          )
        : req.minimumStockBase;

      const required = roundNumber_(
        req.requiredQtyBase,
        6
      );

      const shortage = Math.max(
        0,
        required - available
      );

      const projected = available - required;

      let status = 'SUFFICIENT';
      if (shortage > 0) {
        status = 'SHORTAGE';
      } else if (projected < minimum) {
        status = 'LOW';
      }

      return {
        itemType: req.itemType,
        itemId: req.itemId,
        itemName: req.itemName,
        category: req.category,
        requiredQtyBase: required,
        availableStockBase: roundNumber_(available, 6),
        shortageQtyBase: roundNumber_(shortage, 6),
        projectedStockBase: roundNumber_(projected, 6),
        minimumStockBase: roundNumber_(minimum, 6),
        baseUnit: req.baseUnit,
        status: status
      };
    })
    .sort(function(a, b) {
      if (a.status === b.status) {
        return String(a.itemName).localeCompare(String(b.itemName));
      }
      const weight = {
        SHORTAGE: 1,
        LOW: 2,
        SUFFICIENT: 3
      };
      return (weight[a.status] || 9) - (weight[b.status] || 9);
    });

  const sourceOrders = orders.map(function(order) {
    const customer = maps.customers[order.customer_id] || null;

    return {
      orderId: order.order_id,
      orderDate: normalizeDateKey_(order.order_date),
      fulfillmentDate: normalizeDateKey_(order.fulfillment_date),
      customerId: order.customer_id,
      customerName:
        customer ? customer.name : order.customer_id,
      sourceChannel: order.source_channel,
      orderStatus: order.order_status,
      paymentStatus: order.payment_status,
      grandTotal: Number(order.grand_total || 0),
      totalQuantity: roundNumber_(
        sourceOrderQty[order.order_id] || 0,
        6
      )
    };
  });

  return {
    orders: sourceOrders,
    planItems: planItems,
    requirements: requirements,
    blockers: blockers,
    summary: {
      orderCount: sourceOrders.length,
      targetCount: planItems.length,
      requirementCount: requirements.length,
      shortageCount: requirements.filter(function(row) {
        return row.status === 'SHORTAGE';
      }).length,
      lowCount: requirements.filter(function(row) {
        return row.status === 'LOW';
      }).length
    }
  };
}

function buildProductionPreviewInternal_(fulfillmentDate, data) {
  const dateKey = normalizeDateKey_(fulfillmentDate);
  if (!dateKey) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Fulfillment date is required.'
    );
  }

  data = data || loadProductionPlanningData_();

  const eligibleStatuses = productionEligibleStatuses_();
  const plannedMap = getLivePlannedOrderIdMapFromRows_(
    data.plans
  );

  const allForDate = data.orders.filter(function(order) {
    return normalizeDateKey_(order.fulfillment_date) === dateKey;
  });

  const eligible = allForDate.filter(function(order) {
    return (
      eligibleStatuses.indexOf(
        String(order.order_status).toUpperCase()
      ) >= 0 &&
      !plannedMap[order.order_id]
    );
  });

  const alreadyPlanned = allForDate
    .filter(function(order) {
      return !!plannedMap[order.order_id];
    })
    .map(function(order) {
      return {
        orderId: order.order_id,
        planId: plannedMap[order.order_id],
        status: order.order_status
      };
    });

  const snapshot = buildProductionSnapshotFromData_(
    eligible,
    data
  );

  snapshot.fulfillmentDate = dateKey;
  snapshot.eligibleStatuses = eligibleStatuses;
  snapshot.alreadyPlannedOrders = alreadyPlanned;

  return snapshot;
}

function previewProductionPlan(payload) {
  requirePermission_('PRODUCTION_READ');
  payload = payload || {};

  return buildProductionPreviewInternal_(
    payload.fulfillment_date
  );
}

function productionModuleBootstrap() {
  const user = requirePermission_('PRODUCTION_READ');
  const data = loadProductionPlanningData_();

  const planItemGroups = {};
  data.planItems.forEach(function(item) {
    if (!planItemGroups[item.production_plan_id]) {
      planItemGroups[item.production_plan_id] = [];
    }
    planItemGroups[item.production_plan_id].push(item);
  });

  const requirementGroups = {};
  data.requirements.forEach(function(req) {
    if (!requirementGroups[req.production_plan_id]) {
      requirementGroups[req.production_plan_id] = [];
    }
    requirementGroups[req.production_plan_id].push(req);
  });

  const rows = data.plans.map(function(plan) {
    const items = planItemGroups[plan.production_plan_id] || [];
    const requirements =
      requirementGroups[plan.production_plan_id] || [];

    return Object.assign({}, plan, {
      source_order_count:
        String(plan.source_type).toUpperCase() === 'ORDER_SET'
          ? parsePlanOrderIds_(plan.source_id).length
          : 0,
      target_count: items.length,
      requirement_count: requirements.length,
      shortage_count: requirements.filter(function(req) {
        return String(req.status).toUpperCase() === 'SHORTAGE';
      }).length,
      low_count: requirements.filter(function(req) {
        return String(req.status).toUpperCase() === 'LOW';
      }).length
    });
  });

  rows.sort(function(a, b) {
    const dateCompare =
      String(b.production_date || '').localeCompare(
        String(a.production_date || '')
      );

    return dateCompare ||
      String(b.created_at || '').localeCompare(
        String(a.created_at || '')
      );
  });

  return {
    plans: rows,
    eligibleStatuses: productionEligibleStatuses_(),
    permissions: {
      productionWrite:
        hasPermission_(user, 'PRODUCTION_WRITE'),
      inventoryRead:
        hasPermission_(user, 'INVENTORY_READ')
    }
  };
}

function assertProductionSnapshotReady_(snapshot) {
  if (!snapshot.orders.length) {
    throw twbError_(
      'NO_ELIGIBLE_ORDERS',
      'No unplanned eligible orders were found for this fulfillment date.'
    );
  }

  if (snapshot.blockers.length) {
    throw twbError_(
      'PRODUCTION_SNAPSHOT_BLOCKED',
      'Production plan cannot be created until recipe/material blockers are resolved.',
      {
        blockers: snapshot.blockers
      }
    );
  }

  if (!snapshot.planItems.length) {
    throw twbError_(
      'PRODUCTION_TARGET_EMPTY',
      'No production targets were generated.'
    );
  }
}

function createProductionPlan(payload) {
  const user = requirePermission_('PRODUCTION_WRITE');
  payload = payload || {};

  const fulfillmentDate =
    normalizeDateKey_(payload.fulfillment_date);

  const productionDate =
    normalizeDateKey_(
      payload.production_date ||
      payload.fulfillment_date
    );

  if (!fulfillmentDate) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Fulfillment date is required.'
    );
  }

  if (!productionDate) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Production date is required.'
    );
  }

  const data = loadProductionPlanningData_();
  const snapshot = buildProductionPreviewInternal_(
    fulfillmentDate,
    data
  );

  assertProductionSnapshotReady_(snapshot);

  const orderIds = snapshot.orders.map(function(order) {
    return order.orderId;
  });

  const planId = nextBusinessId('PRODUCTION_PLAN');

  const itemIds = snapshot.planItems.map(function() {
    return nextBusinessId('PRODUCTION_PLAN_ITEM');
  });

  const requirementIds = snapshot.requirements.map(function() {
    return nextBusinessId('REQUIREMENT');
  });

  const now = nowIso_();

  const plan = {
    production_plan_id: planId,
    production_date: productionDate,
    source_type: 'ORDER_SET',
    source_id: orderIds.join('|'),
    status: 'DRAFT',
    notes: normalizeText_(payload.notes),
    created_at: now,
    created_by: user.user_id,
    updated_at: now,
    updated_by: user.user_id
  };

  const planItems = snapshot.planItems.map(function(item, index) {
    return {
      plan_item_id: itemIds[index],
      production_plan_id: planId,
      product_id: item.productId,
      variant_id: item.variantId,
      recipe_id: item.recipeId,
      recipe_version: item.recipeVersion,
      target_quantity: item.targetQuantity,
      target_unit: item.targetUnit,
      scaling_mode: item.scalingMode,
      multiplier: item.multiplier,
      required_batches: item.requiredBatches,
      expected_output: item.expectedOutput,
      expected_surplus: item.expectedSurplus,
      status: 'PLANNED',
      created_at: now,
      created_by: user.user_id,
      updated_at: now,
      updated_by: user.user_id
    };
  });

  const requirements = snapshot.requirements.map(function(req, index) {
    return {
      requirement_id: requirementIds[index],
      production_plan_id: planId,
      plan_item_id: '',
      item_type: req.itemType,
      item_id: req.itemId,
      required_qty_base: req.requiredQtyBase,
      available_stock_base: req.availableStockBase,
      shortage_qty_base: req.shortageQtyBase,
      base_unit: req.baseUnit,
      status: req.status,
      calculated_at: now,
      created_at: now,
      created_by: user.user_id,
      updated_at: now,
      updated_by: user.user_id
    };
  });

  // IDs are reserved before this lock, so we do not nest LockService
  // through nextBusinessId() inside a critical section.
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    const livePlans =
      listAllRecords_('PRODUCTION_PLANS');

    const livePlannedOrders =
      getLivePlannedOrderIdMapFromRows_(livePlans);

    const conflicts = orderIds.filter(function(orderId) {
      return !!livePlannedOrders[orderId];
    });

    if (conflicts.length) {
      throw twbError_(
        'ORDER_ALREADY_PLANNED',
        'One or more orders were added to another production plan.',
        {
          orderIds: conflicts
        }
      );
    }

    dbInsertRecord(
      'PRODUCTION_PLANS',
      plan,
      { validate: true, audit: false }
    );

    dbBulkInsert(
      'PRODUCTION_PLAN_ITEMS',
      planItems,
      { validate: true }
    );

    dbBulkInsert(
      'PRODUCTION_REQUIREMENTS',
      requirements,
      { validate: true }
    );
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'CREATE',
    'PRODUCTION_PLANS',
    planId,
    null,
    {
      productionDate: productionDate,
      fulfillmentDate: fulfillmentDate,
      sourceOrders: orderIds,
      targetCount: planItems.length,
      requirementCount: requirements.length
    },
    'Production plan snapshot created from Order demand.'
  );

  return getProductionPlanDetail_(planId);
}

function getProductionPlanDetail(planId) {
  requirePermission_('PRODUCTION_READ');
  return getProductionPlanDetail_(planId);
}

function getProductionPlanDetail_(planId) {
  const plan = dbFindById(
    'PRODUCTION_PLANS',
    planId
  );

  if (!plan) {
    throw twbError_(
      'NOT_FOUND',
      'Production plan not found: ' + planId
    );
  }

  const planItems = dbFindMany(
    'PRODUCTION_PLAN_ITEMS',
    'production_plan_id',
    planId
  );

  const requirements = dbFindMany(
    'PRODUCTION_REQUIREMENTS',
    'production_plan_id',
    planId
  );

  const products = listAllRecords_('PRODUCTS');
  const variants = listAllRecords_('PRODUCT_VARIANTS');
  const ingredients = listAllRecords_('INGREDIENTS');
  const packaging = listAllRecords_('PACKAGING');
  const orders = listAllRecords_('ORDERS');
  const customers = listAllRecords_('CUSTOMERS');

  const productMap = {};
  products.forEach(function(row) {
    productMap[row.product_id] = row;
  });

  const variantMap = {};
  variants.forEach(function(row) {
    variantMap[row.variant_id] = row;
  });

  const ingredientMap = {};
  ingredients.forEach(function(row) {
    ingredientMap[row.ingredient_id] = row;
  });

  const packagingMap = {};
  packaging.forEach(function(row) {
    packagingMap[row.packaging_id] = row;
  });

  const orderMap = {};
  orders.forEach(function(row) {
    orderMap[row.order_id] = row;
  });

  const customerMap = {};
  customers.forEach(function(row) {
    customerMap[row.customer_id] = row;
  });

  const sourceOrders = parsePlanOrderIds_(
    plan.source_id
  ).map(function(orderId) {
    const order = orderMap[orderId];

    if (!order) {
      return {
        orderId: orderId,
        customerName: '',
        orderStatus: 'MISSING',
        paymentStatus: '',
        fulfillmentDate: '',
        grandTotal: 0
      };
    }

    const customer =
      customerMap[order.customer_id] || null;

    return {
      orderId: order.order_id,
      customerName:
        customer ? customer.name : order.customer_id,
      orderStatus: order.order_status,
      paymentStatus: order.payment_status,
      fulfillmentDate:
        normalizeDateKey_(order.fulfillment_date),
      grandTotal: Number(order.grand_total || 0)
    };
  });

  const enrichedItems = planItems.map(function(item) {
    const product = productMap[item.product_id] || {};
    const variant = item.variant_id
      ? variantMap[item.variant_id] || {}
      : null;

    return Object.assign(
      {},
      stripInternalFields_(item),
      {
        product_name:
          (product.product_name || item.product_id) +
          (
            variant
              ? ' · ' +
                (variant.variant_name || item.variant_id)
              : ''
          )
      }
    );
  });

  const enrichedRequirements = requirements.map(function(req) {
    const type = String(req.item_type).toUpperCase();
    const material =
      type === 'INGREDIENT'
        ? ingredientMap[req.item_id] || {}
        : packagingMap[req.item_id] || {};

    return Object.assign(
      {},
      stripInternalFields_(req),
      {
        item_name:
          type === 'INGREDIENT'
            ? material.ingredient_name || req.item_id
            : material.packaging_name || req.item_id,
        category: material.category || ''
      }
    );
  });

  return {
    plan: stripInternalFields_(plan),
    sourceOrders: sourceOrders,
    items: enrichedItems,
    requirements: enrichedRequirements,
    allowedTransitions:
      TWB_PRODUCTION_PLAN_TRANSITIONS[
        String(plan.status).toUpperCase()
      ] || []
  };
}

function deriveRequirementStatus_(
  required,
  available,
  minimum
) {
  required = Number(required || 0);
  available = Number(available || 0);
  minimum = Number(minimum || 0);

  const shortage = Math.max(
    0,
    required - available
  );

  if (shortage > 0) {
    return {
      shortage: shortage,
      status: 'SHORTAGE'
    };
  }

  if (available - required < minimum) {
    return {
      shortage: 0,
      status: 'LOW'
    };
  }

  return {
    shortage: 0,
    status: 'SUFFICIENT'
  };
}

function refreshProductionRequirementAvailability(planId) {
  const user = requirePermission_('PRODUCTION_WRITE');

  const plan = dbFindById(
    'PRODUCTION_PLANS',
    planId
  );

  if (!plan) {
    throw twbError_(
      'NOT_FOUND',
      'Production plan not found: ' + planId
    );
  }

  const status = String(plan.status).toUpperCase();
  if (
    ['DRAFT', 'PLANNED'].indexOf(status) < 0
  ) {
    throw twbError_(
      'PRODUCTION_PLAN_LOCKED',
      'Stock availability can only be refreshed while plan is DRAFT or PLANNED.'
    );
  }

  const requirements = dbFindMany(
    'PRODUCTION_REQUIREMENTS',
    'production_plan_id',
    planId
  );

  const inventoryRows = listAllRecords_('INVENTORY');
  const ingredientRows = listAllRecords_('INGREDIENTS');
  const packagingRows = listAllRecords_('PACKAGING');

  const inventoryMap = {};
  inventoryRows.forEach(function(row) {
    inventoryMap[row.item_id] = row;
  });

  const materialMinimum = {};
  ingredientRows.forEach(function(row) {
    materialMinimum[row.ingredient_id] =
      Number(row.minimum_stock_base || 0);
  });
  packagingRows.forEach(function(row) {
    materialMinimum[row.packaging_id] =
      Number(row.minimum_stock_base || 0);
  });

  let changed = 0;

  requirements.forEach(function(req) {
    const inventory = inventoryMap[req.item_id] || null;

    const available = inventory
      ? Number(inventory.current_stock_base || 0)
      : 0;

    const minimum = inventory
      ? Number(
          inventory.minimum_stock_base ||
          materialMinimum[req.item_id] ||
          0
        )
      : Number(
          materialMinimum[req.item_id] || 0
        );

    const state = deriveRequirementStatus_(
      req.required_qty_base,
      available,
      minimum
    );

    dbUpdateById(
      'PRODUCTION_REQUIREMENTS',
      req.requirement_id,
      stampUpdate_(user, {
        available_stock_base:
          roundNumber_(available, 6),
        shortage_qty_base:
          roundNumber_(state.shortage, 6),
        status: state.status,
        calculated_at: nowIso_()
      }),
      { validate: true, audit: false }
    );

    changed += 1;
  });

  writeAuditLog_(
    'UPDATE',
    'PRODUCTION_PLANS',
    planId,
    null,
    {
      refreshedRequirements: changed
    },
    'Production stock availability snapshot refreshed.'
  );

  return getProductionPlanDetail_(planId);
}

function validateProductionPlanTransition_(
  fromStatus,
  toStatus
) {
  const from = String(fromStatus || '').toUpperCase();
  const to = String(toStatus || '').toUpperCase();

  if (!TWB_PRODUCTION_PLAN_TRANSITIONS[from]) {
    throw twbError_(
      'PRODUCTION_PLAN_STATUS_INVALID',
      'Unknown production plan status: ' + from
    );
  }

  if (
    TWB_PRODUCTION_PLAN_TRANSITIONS[from].indexOf(to) < 0
  ) {
    throw twbError_(
      'PRODUCTION_PLAN_TRANSITION_INVALID',
      'Cannot move production plan from ' +
      from +
      ' to ' +
      to +
      '.',
      {
        from: from,
        to: to,
        allowed:
          TWB_PRODUCTION_PLAN_TRANSITIONS[from]
      }
    );
  }

  return true;
}

function updateProductionPlanStatus(
  planId,
  targetStatus
) {
  const user = requirePermission_('PRODUCTION_WRITE');

  const plan = dbFindById(
    'PRODUCTION_PLANS',
    planId
  );

  if (!plan) {
    throw twbError_(
      'NOT_FOUND',
      'Production plan not found: ' + planId
    );
  }

  const from = String(plan.status).toUpperCase();
  const to = String(targetStatus || '').toUpperCase();

  validateProductionPlanTransition_(from, to);

  const before = stripInternalFields_(plan);

  const updated = dbUpdateById(
    'PRODUCTION_PLANS',
    planId,
    stampUpdate_(user, {
      status: to
    }),
    { validate: true, audit: false }
  );

  writeAuditLog_(
    'STATUS_CHANGE',
    'PRODUCTION_PLANS',
    planId,
    before,
    updated,
    from + ' → ' + to
  );

  return getProductionPlanDetail_(planId);
}
