/**
 * QA Hotfix 14 — Browser thermal receipt printing.
 *
 * This phase intentionally uses the browser print dialog so USB/LAN thermal
 * printers work through the operating-system printer driver without adding a
 * local bridge. Direct/silent ESC/POS printing remains a later integration.
 */

function receiptBooleanSetting_(key, fallback) {
  var value = getBusinessSetting_(key);
  if (
    value === null ||
    typeof value === 'undefined' ||
    value === ''
  ) {
    return fallback === true;
  }
  return value === true;
}

function receiptPrintingSettings_() {
  var paper = String(
    getBusinessSetting_(
      'receipt_paper_size'
    ) || '80'
  ).trim();

  if (
    ['58', '80'].indexOf(
      paper
    ) < 0
  ) {
    paper = '80';
  }

  var copies = Number(
    getBusinessSetting_(
      'receipt_copies'
    ) || 1
  );

  if (
    !isFinite(copies) ||
    copies < 1
  ) {
    copies = 1;
  }

  copies = Math.max(
    1,
    Math.min(
      3,
      Math.round(copies)
    )
  );

  return {
    printMode: 'BROWSER',
    paperSize: paper,
    paperWidthMm:
      paper === '58'
        ? 58
        : 80,
    contentWidthMm:
      paper === '58'
        ? 50
        : 72,
    copies: copies,
    autoPrintAfterPayment:
      receiptBooleanSetting_(
        'receipt_auto_print_after_payment',
        false
      ),
    showLogo:
      receiptBooleanSetting_(
        'receipt_show_logo',
        true
      ),
    showCustomer:
      receiptBooleanSetting_(
        'receipt_show_customer',
        true
      ),
    showPaymentMethod:
      receiptBooleanSetting_(
        'receipt_show_payment_method',
        true
      ),
    kitchenTicketEnabled:
      receiptBooleanSetting_(
        'kitchen_ticket_enabled',
        false
      )
  };
}

function buildPublicReceiptUrl_(
  publicToken,
  autoPrint
) {
  var token = encodeURIComponent(
    String(
      publicToken || ''
    )
  );

  var base = getWebAppBaseUrl_();
  var url = base
    ? base + '?receipt=' + token
    : '?receipt=' + token;

  if (autoPrint === true) {
    url += '&autoprint=1';
  }

  return url;
}

function buildKitchenTicketUrl_(
  invoiceId,
  autoPrint
) {
  var key = encodeURIComponent(
    String(
      invoiceId || ''
    )
  );

  var base = getWebAppBaseUrl_();
  var url = base
    ? base + '?kitchen_invoice=' + key
    : '?kitchen_invoice=' + key;

  if (autoPrint === true) {
    url += '&autoprint=1';
  }

  return url;
}

function receiptBrandLogoUrl_() {
  var raw = String(
    getBusinessSetting_(
      'brand_logo_url'
    ) || ''
  ).trim();

  if (!raw) return '';

  if (
    typeof imagePreviewDriveFileId_ ===
      'function' &&
    imagePreviewDriveFileId_(raw) &&
    typeof resolveDriveImageDataUrl_ ===
      'function'
  ) {
    try {
      return resolveDriveImageDataUrl_(
        raw
      ).data_url;
    } catch (ignoreDriveLogo) {}
  }

  return raw;
}

function receiptLatestPayment_(payments) {
  return (payments || [])
    .filter(function(payment) {
      return String(
        payment.status || ''
      ).toUpperCase() === 'SUCCESS' &&
        Number(
          payment.amount || 0
        ) > 0;
    })
    .sort(function(a, b) {
      return String(
        b.payment_at || ''
      ).localeCompare(
        String(
          a.payment_at || ''
        )
      );
    })[0] || null;
}

function getPublicReceiptDataByToken_(
  token,
  options
) {
  options = options || {};

  var cleanToken = String(
    token || ''
  ).trim();

  if (!cleanToken) {
    return null;
  }

  var invoice = dbFindOne(
    'INVOICES',
    'public_token',
    cleanToken
  );

  if (!invoice) {
    return null;
  }

  var order = dbFindById(
    'ORDERS',
    invoice.order_id
  );

  var customer = dbFindById(
    'CUSTOMERS',
    invoice.customer_id
  );

  var items = dbFindMany(
    'ORDER_ITEMS',
    'order_id',
    invoice.order_id
  );

  var payments = dbFindMany(
    'PAYMENTS',
    'invoice_id',
    invoice.invoice_id
  );

  var latestPayment =
    receiptLatestPayment_(
      payments
    );

  var settings =
    receiptPrintingSettings_();

  return {
    businessName:
      getBusinessSetting_(
        'business_name'
      ) || 'Twolittle.bites',
    brandLogoUrl:
      settings.showLogo
        ? receiptBrandLogoUrl_()
        : '',
    paperSize:
      settings.paperSize,
    paperWidthMm:
      settings.paperWidthMm,
    contentWidthMm:
      settings.contentWidthMm,
    suggestedCopies:
      settings.copies,
    autoPrint:
      options.autoPrint === true,
    showCustomer:
      settings.showCustomer,
    showPaymentMethod:
      settings.showPaymentMethod,
    kitchenTicketEnabled:
      settings.kitchenTicketEnabled,
    orderId:
      invoice.order_id,
    invoiceId:
      invoice.invoice_id,
    invoiceNumber:
      invoice.invoice_number,
    invoiceDate:
      typeof formatPublicDateTime_ ===
        'function'
        ? formatPublicDateTime_(
            invoice.invoice_date
          )
        : String(
            invoice.invoice_date || ''
          ),
    status:
      String(
        invoice.status || ''
      ).toUpperCase(),
    customerName:
      customer
        ? customer.name || ''
        : '',
    customerWhatsApp:
      customer
        ? customer.whatsapp || ''
        : '',
    fulfillmentType:
      order
        ? order.fulfillment_type || ''
        : '',
    fulfillmentDate:
      order &&
      order.fulfillment_date
        ? (
            typeof formatPublicDate_ ===
              'function'
              ? formatPublicDate_(
                  order.fulfillment_date
                )
              : String(
                  order.fulfillment_date
                )
          )
        : '',
    deliveryAddress:
      order
        ? order.delivery_address || ''
        : '',
    orderNotes:
      order
        ? order.notes || ''
        : '',
    items:
      items.map(function(item) {
        return {
          name:
            item.product_name_snapshot ||
            item.sku_snapshot ||
            'Item',
          sku:
            item.sku_snapshot || '',
          quantity:
            Number(
              item.quantity || 0
            ),
          unitPriceText:
            formatIdrText_(
              item.unit_price
            ),
          discountText:
            formatIdrText_(
              item.line_discount
            ),
          lineTotalText:
            formatIdrText_(
              item.line_total
            ),
          productionNotes:
            item.production_notes || ''
        };
      }),
    subtotalText:
      formatIdrText_(
        invoice.subtotal
      ),
    discountText:
      formatIdrText_(
        invoice.discount
      ),
    deliveryFeeText:
      formatIdrText_(
        invoice.delivery_fee
      ),
    taxText:
      formatIdrText_(
        invoice.tax
      ),
    grandTotalText:
      formatIdrText_(
        invoice.grand_total
      ),
    paidAmountText:
      formatIdrText_(
        invoice.paid_amount
      ),
    remainingAmountText:
      formatIdrText_(
        invoice.remaining_amount
      ),
    paymentMethod:
      latestPayment
        ? latestPayment.payment_method || ''
        : invoice.last_payment_method || '',
    paymentAt:
      latestPayment &&
      latestPayment.payment_at
        ? (
            typeof formatPublicDateTime_ ===
              'function'
              ? formatPublicDateTime_(
                  latestPayment.payment_at
                )
              : String(
                  latestPayment.payment_at
                )
          )
        : '',
    instagram:
      '@twolittle.bites',
    whatsapp:
      '0812 6794 8252',
    generatedAt:
      typeof formatPublicDateTime_ ===
        'function'
        ? formatPublicDateTime_(
            nowIso_()
          )
        : nowIso_()
  };
}

function getInternalKitchenTicketDataByInvoiceId_(
  invoiceId,
  options
) {
  requireAnyPermission_([
    'ORDER_READ',
    'INVOICE_READ'
  ]);

  var invoice = dbFindById(
    'INVOICES',
    invoiceId
  );

  if (!invoice) {
    return null;
  }

  return getPublicReceiptDataByToken_(
    invoice.public_token,
    options || {}
  );
}

function getReceiptUrl(
  invoiceId,
  autoPrint
) {
  requirePermission_(
    'INVOICE_READ'
  );

  var invoice = dbFindById(
    'INVOICES',
    invoiceId
  );

  if (!invoice) {
    throw twbError_(
      'NOT_FOUND',
      'Invoice not found: ' +
        invoiceId
    );
  }

  return {
    receipt_url:
      buildPublicReceiptUrl_(
        invoice.public_token,
        autoPrint === true
      ),
    kitchen_ticket_url:
      buildKitchenTicketUrl_(
        invoice.invoice_id,
        autoPrint === true
      ),
    printing:
      receiptPrintingSettings_()
  };
}
