# QA Hotfix 19 — Finance & Localhost Hardening

Base: Hotfix 18. Date: 28 October 2026 (Asia/Jakarta).

## Changes

1. `PaymentService.gs`
   - SUCCESS payment methods are ordered by actual event timestamp and ID.
   - Reference duplicate check happens under the same script lock as insert.
   - A same-reference retry is accepted only if invoice, status, amount,
     method, and any supplied Proof URL match the original.
   - The response marks a genuine repeat with `already_recorded: true`.
   - Refund balance validation happens *inside* the lock.
   - Refund uses the same reference-conflict/idempotency policy.
2. `JsFinance.html`
   - Retry is clearly labelled as already recorded, not a new payment.
   - Refund form sends a stable per-form reference for safe retries.
3. `LocalBridgeService.gs` and the separately packaged Localhost
   `server.mjs` / `vite.config.mjs`
   - Ordinary requests keep the existing conservative size limit.
   - An 8 MiB payment proof uses a scoped large-request allowance:
     Localhost HTTP JSON up to 12 MiB and signed bridge envelope up to
     16 million base64 characters, only for `payments.record` uploads.
   - The final decoded proof remains subject to the server's 8 MiB,
     type, and file-signature validation.
4. Localhost `index.html` is regenerated from current Hotfix 19 front-end
   templates rather than carrying an older Hotfix 15 snapshot.

## Local verification

- 66 Apps Script files and 19 JavaScript components parse successfully.
- Mocked finance test covers new payment, proof URL persistence,
  duplicate exact retry, conflicting reference, latest payment method,
  first refund, second over-limit refund, and refund exact retry.
- Localhost server syntax and all 20 embedded script blocks parse.
- A maximum 8 MiB proof yields approximately 11.19 MiB Localhost request
  and 14.91 million bridge characters, within the scoped new limits.
- No Sheet schema migration or data mutation performed by local tests.

## Deployment / UAT

1. Apply Hotfix 19 Full (or Delta on Hotfix 18) to the Apps Script project.
2. Publish a new deployment and run the existing Phase 16 health,
   smoke, and regression checks with authorized access.
3. If using Localhost Hybrid, **replace the matching Localhost package too**;
   updating only Apps Script will leave the old 2 MiB proxy limit.
4. Test 0.5/1/2/8 MiB JPG/PNG/WebP/PDF files in native Apps Script mode
   and Localhost mode. Actual Apps Script inbound request limits and
   Drive write latency still require live validation.
5. Record BCA DP then QRIS final payment; verify last method is QRIS.
6. Retry identical reference; verify no second PAYMENTS/TRANSACTIONS row.
7. Reuse reference with different amount; verify explicit rejection.
8. Run two conflicting refunds; only one may pass once available balance
   is exhausted, and ledger balances must reconcile.
9. Test Drive proof viewing as OWNER and FINANCE. Do not grant public
   access to customer payment evidence as a workaround.
10. Run `runPhase16ReleasePreflight()` and require no blocking failures
    before marking the application RELEASED.

## Privacy and known release gate

Uploaded proof files are private by default. Their access by other authorized
staff depends on Drive folder ownership and sharing policy, which must be
decided by the business owner and tested with real accounts. The application
does not automatically grant Drive viewer access or change privacy settings.

This is a code and mocked-test release candidate; no live Apps Script or
Google Drive UAT has been executed in this package.
