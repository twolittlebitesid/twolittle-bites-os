/**
 * Run this once from Apps Script editor.
 * It is idempotent for already-correct sheets and default config rows.
 */
function setupTwolittleBitesPhase1() {
  const props = PropertiesService.getScriptProperties();
  let ss = null;
  let createdSpreadsheet = false;

  const existingId = props.getProperty('TWB_SPREADSHEET_ID');
  if (existingId) {
    ss = SpreadsheetApp.openById(existingId);
  } else {
    ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      ss = SpreadsheetApp.create('Twolittle.bites OS — Database');
      createdSpreadsheet = true;
    }
    props.setProperty('TWB_SPREADSHEET_ID', ss.getId());
  }

  ss.setSpreadsheetTimeZone(TWB_APP.TIMEZONE);

  const createdSheets = [];
  const verifiedSheets = [];
  TWB_SHEET_ORDER.forEach(function(name) {
    const schema = TWB_SHEET_SCHEMAS[name];
    let sheet = ss.getSheetByName(name);

    if (!sheet) {
      sheet = ss.insertSheet(name);
      sheet.getRange(1, 1, 1, schema.headers.length).setValues([schema.headers]);
      formatDatabaseHeader_(sheet, schema.headers.length);
      createdSheets.push(name);
      return;
    }

    if (sheet.getLastRow() === 0 || sheet.getLastColumn() === 0) {
      sheet.getRange(1, 1, 1, schema.headers.length).setValues([schema.headers]);
      formatDatabaseHeader_(sheet, schema.headers.length);
      createdSheets.push(name);
      return;
    }

    const actual = sheet.getRange(1, 1, 1, Math.max(1, sheet.getLastColumn())).getValues()[0];
    const expected = schema.headers;
    const match = expected.every(function(h, i) { return actual[i] === h; });
    if (!match) {
      throw twbError_(
        'SCHEMA_CONFLICT',
        'Sheet ' + name + ' exists but its header does not match Phase 1 schema. Resolve before continuing.'
      );
    }
    formatDatabaseHeader_(sheet, schema.headers.length);
    verifiedSheets.push(name);
  });

  removeDefaultBlankSheet_(ss);

  const owner = ensureInitialOwner_();
  seedDefaults_(owner.user_id);

  const health = runPhase1HealthCheck();
  return {
    ok: health.ok,
    createdSpreadsheet: createdSpreadsheet,
    spreadsheetId: ss.getId(),
    spreadsheetUrl: ss.getUrl(),
    createdSheets: createdSheets,
    verifiedSheets: verifiedSheets,
    initialOwner: owner.email,
    health: health
  };
}

function formatDatabaseHeader_(sheet, width) {
  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, 1, width)
    .setBackground(TWB_APP.BRAND.BURNT)
    .setFontColor('#FFFFFF')
    .setFontWeight('bold')
    .setWrap(true);
  sheet.autoResizeColumns(1, Math.min(width, 12));
}

function removeDefaultBlankSheet_(ss) {
  const candidates = ['Sheet1', 'Sheet 1'];
  candidates.forEach(function(name) {
    const sheet = ss.getSheetByName(name);
    if (!sheet) return;
    if (sheet.getLastRow() <= 1 && sheet.getLastColumn() <= 1 && ss.getSheets().length > 1) {
      ss.deleteSheet(sheet);
    }
  });
}

function ensureInitialOwner_() {
  const props = PropertiesService.getScriptProperties();
  const configured = normalizeEmail_(props.getProperty('TWB_INITIAL_OWNER_EMAIL'));
  const email = configured || normalizeEmail_(Session.getEffectiveUser().getEmail()) || normalizeEmail_(Session.getActiveUser().getEmail());

  if (!email) {
    throw twbError_(
      'INITIAL_OWNER_EMAIL_REQUIRED',
      'Could not determine the initial owner email. Add Script Property TWB_INITIAL_OWNER_EMAIL and rerun setup.'
    );
  }

  const existing = dbFindOne('USERS', 'email', email);
  if (existing) return existing;

  const now = nowIso_();
  const userId = nextBusinessId('USER');
  return dbInsertRecord('USERS', {
    user_id: userId,
    email: email,
    display_name: displayNameFromEmail_(email),
    role: TWB_ROLES.OWNER,
    status: TWB_USER_STATUS.ACTIVE,
    last_login_at: now,
    created_at: now,
    created_by: userId,
    updated_at: now,
    updated_by: userId
  }, { validate: true });
}

function seedDefaults_(ownerUserId) {
  Object.keys(TWB_CONFIG_DEFAULTS).forEach(function(key) {
    const def = TWB_CONFIG_DEFAULTS[key];
    setConfig_(key, def.value, def.type, def.description, ownerUserId);
  });

  TWB_BUSINESS_SETTING_DEFAULTS.forEach(function(row) {
    setBusinessSetting_(row[0], row[1], row[2], row[3], row[4], ownerUserId);
  });
}

function onOpen() {
  try {
    SpreadsheetApp.getUi()
      .createMenu('Twolittle OS')
      .addItem('Phase 1 Setup / Verify', 'setupTwolittleBitesPhase1')
      .addItem('Run Health Check', 'runPhase1HealthCheck')
      .addToUi();
  } catch (e) {
    // Ignore when the script is standalone / no spreadsheet UI is active.
  }
}
