# QA_HOTFIX_08_STATIC_QA.md

Static QA:

- Server `.gs` syntax: PASS
- Client `Js*.html` syntax: PASS
- HTML includes: PASS
- Instagram corrected + clickable: PASS
- WhatsApp contact clickable: PASS
- Google Drive PDF generation service: PASS
- `ANYONE_WITH_LINK / VIEW` implementation: PASS
- Drive resource-key preservation: PASS
- Invoice/payment/refund/fulfillment regeneration hooks: PASS
- Public Invoice Download PDF action: PASS
- WhatsApp `{invoice_pdf_url}` placeholder: PASS
- Smart saved-template migration helper: PASS
- Existing-invoice PDF backfill helper: PASS
- Phase 16 health guard: PASS
- Canonical sheet count unchanged: PASS (33/33)
- Sheet schema migration required: NO
- App Version: 1.0.0
- Schema Version: 1.0.0

Runtime boundary:

Static QA cannot prove Google Drive policy permits `ANYONE_WITH_LINK` or that the
account still has PDF conversion quota. Run:

```javascript
runQAHotfix08PdfSmoke('INV-TLB-202610-000006')
```

with a real invoice number/id, then open the returned `downloadUrl` in an incognito
browser with no Google login.
