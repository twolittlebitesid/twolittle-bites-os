/**
 * Twolittle.bites OS — Phase 10 Finance & Profitability
 *
 * Managerial finance, not statutory accounting.
 *
 * Revenue recognition:
 * - COMPLETED orders only
 * - recognition date = fulfillment_date, else order_date
 * - tax is shown separately and excluded from operating revenue
 *
 * COGS:
 * - future completed orders snapshot one non-cash COGS transaction
 *   per ORDER_ITEM
 * - historical completed orders without snapshots use a clearly
 *   identified current-cost estimate until optional backfill is run
 */

function getExpenseCategories_() {
  var value = getConfig_('EXPENSE_CATEGORIES');
  return Array.isArray(value) ? value : [];
}

function financeDateKey_(value) {
  if (!value) return '';

  if (
    Object.prototype.toString.call(value) === '[object Date]' &&
    !isNaN(value.getTime())
  ) {
    return Utilities.formatDate(
      value,
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );
  }

  var raw = String(value).trim();
  var direct = raw.match(/^(\d{4}-\d{2}-\d{2})/);

  if (direct) return direct[1];

  var parsed = new Date(raw);

  if (!isNaN(parsed.getTime())) {
    return Utilities.formatDate(
      parsed,
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );
  }

  return raw;
}

function financeDefaultPeriod_() {
  var now = new Date();

  var start = Utilities.formatDate(
    new Date(
      now.getFullYear(),
      now.getMonth(),
      1
    ),
    TWB_APP.TIMEZONE,
    'yyyy-MM-dd'
  );

  var end = Utilities.formatDate(
    new Date(
      now.getFullYear(),
      now.getMonth() + 1,
      0
    ),
    TWB_APP.TIMEZONE,
    'yyyy-MM-dd'
  );

  return {
    start: start,
    end: end
  };
}

function normalizeFinancePeriod_(payload) {
  payload = payload || {};

  var defaults = financeDefaultPeriod_();

  var start =
    financeDateKey_(
      payload.period_start
    ) || defaults.start;

  var end =
    financeDateKey_(
      payload.period_end
    ) || defaults.end;

  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(start) ||
    !/^\d{4}-\d{2}-\d{2}$/.test(end)
  ) {
    throw twbError_(
      'FINANCE_PERIOD_INVALID',
      'Period start/end must be valid dates.'
    );
  }

  if (start > end) {
    throw twbError_(
      'FINANCE_PERIOD_INVALID',
      'Period start cannot be after period end.'
    );
  }

  return {
    start: start,
    end: end
  };
}

function financeDateInPeriod_(
  value,
  period
) {
  var key = financeDateKey_(value);

  return (
    !!key &&
    key >= period.start &&
    key <= period.end
  );
}

function expenseCreatePermission_(user) {
  return (
    hasPermission_(user, 'EXPENSE_WRITE') ||
    hasPermission_(user, 'EXPENSE_CREATE') ||
    hasPermission_(user, 'EXPENSE_CREATE_MARKETING')
  );
}

function expenseReadPermission_(user) {
  return (
    hasPermission_(user, 'EXPENSE_READ') ||
    hasPermission_(user, 'EXPENSE_WRITE') ||
    hasPermission_(user, 'PNL_READ')
  );
}

function validateExpenseCategoryForUser_(
  user,
  category
) {
  var normalized =
    String(category || '')
      .toUpperCase();

  var allowed =
    getExpenseCategories_();

  if (
    allowed.length &&
    allowed.indexOf(normalized) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Unknown expense category: ' +
      normalized
    );
  }

  var marketingOnly =
    hasPermission_(
      user,
      'EXPENSE_CREATE_MARKETING'
    ) &&
    !hasPermission_(
      user,
      'EXPENSE_CREATE'
    ) &&
    !hasPermission_(
      user,
      'EXPENSE_WRITE'
    );

  if (
    marketingOnly &&
    ['MARKETING','ADS'].indexOf(
      normalized
    ) < 0
  ) {
    throw twbError_(
      'FORBIDDEN',
      'Marketing role can only create MARKETING or ADS expenses.'
    );
  }

  return normalized;
}

function createExpense(payload) {
  var user =
    requireCurrentUser_();

  if (!expenseCreatePermission_(user)) {
    throw twbError_(
      'FORBIDDEN',
      'Permission denied: expense create'
    );
  }

  payload = payload || {};

  var category =
    validateExpenseCategoryForUser_(
      user,
      payload.category
    );

  var amount =
    requirePositive_(
      payload.amount,
      'amount'
    );

  var method =
    String(
      payload.payment_method || ''
    ).toUpperCase();

  var methods =
    getPaymentMethods_();

  if (!method) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Payment method is required.'
    );
  }

  if (
    methods.length &&
    methods.indexOf(method) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Unknown payment method: ' +
      method
    );
  }

  var expenseId =
    nextBusinessId('EXPENSE');

  var transactionId =
    nextBusinessId('TRANSACTION');

  var now = nowIso_();

  var expense = {
    expense_id: expenseId,
    expense_date:
      financeDateKey_(
        payload.expense_date
      ) ||
      todayIso_(),
    category: category,
    vendor:
      normalizeText_(
        payload.vendor
      ),
    amount:
      Math.round(amount),
    payment_method:
      method,
    receipt_url:
      normalizeText_(
        payload.receipt_url
      ),
    status: 'ACTIVE',
    notes:
      normalizeText_(
        payload.notes
      ),
    created_at: now,
    created_by:
      user.user_id,
    updated_at: now,
    updated_by:
      user.user_id
  };

  var transaction = {
    transaction_id:
      transactionId,
    transaction_at:
      expense.expense_date +
      'T12:00:00',
    transaction_type:
      'EXPENSE',
    category:
      category,
    reference_type:
      'EXPENSE',
    reference_id:
      expenseId,
    amount_in: 0,
    amount_out:
      Math.round(amount),
    payment_method:
      method,
    notes:
      (
        expense.vendor
          ? expense.vendor + ' · '
          : ''
      ) +
      (
        expense.notes ||
        category
      ),
    created_at: now,
    created_by:
      user.user_id,
    updated_at: now,
    updated_by:
      user.user_id
  };

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    dbInsertRecord(
      'EXPENSES',
      expense,
      {
        validate: true,
        audit: false
      }
    );

    dbInsertRecord(
      'TRANSACTIONS',
      transaction,
      {
        validate: true,
        audit: false
      }
    );
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'CREATE',
    'EXPENSES',
    expenseId,
    null,
    expense,
    'Expense recorded.'
  );

  return stripInternalFields_(
    expense
  );
}

function voidExpense(
  expenseId,
  reason
) {
  var user =
    requirePermission_(
      'EXPENSE_WRITE'
    );

  var expense = dbFindById(
    'EXPENSES',
    expenseId
  );

  if (!expense) {
    throw twbError_(
      'NOT_FOUND',
      'Expense not found: ' +
      expenseId
    );
  }

  if (
    String(expense.status).toUpperCase() ===
    'VOID'
  ) {
    return stripInternalFields_(
      expense
    );
  }

  var reasonText =
    normalizeText_(reason);

  if (!reasonText) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Void reason is required.'
    );
  }

  var existingReversal =
    listAllRecords_('TRANSACTIONS')
      .filter(function(row) {
        return (
          String(row.reference_type).toUpperCase() ===
            'EXPENSE_VOID' &&
          String(row.reference_id) ===
            String(expenseId)
        );
      })[0];

  var reversalId =
    existingReversal
      ? ''
      : nextBusinessId(
          'TRANSACTION'
        );

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    dbUpdateById(
      'EXPENSES',
      expenseId,
      stampUpdate_(
        user,
        {
          status: 'VOID',
          notes:
            (
              normalizeText_(
                expense.notes
              )
                ? normalizeText_(
                    expense.notes
                  ) + '\n'
                : ''
            ) +
            '[VOID] ' +
            reasonText
        }
      ),
      {
        validate: true,
        audit: false
      }
    );

    if (!existingReversal) {
      var now = nowIso_();

      dbInsertRecord(
        'TRANSACTIONS',
        {
          transaction_id:
            reversalId,
          transaction_at:
            now,
          transaction_type:
            'EXPENSE_REVERSAL',
          category:
            expense.category,
          reference_type:
            'EXPENSE_VOID',
          reference_id:
            expenseId,
          amount_in:
            Number(
              expense.amount || 0
            ),
          amount_out: 0,
          payment_method:
            expense.payment_method,
          notes:
            'Administrative reversal: ' +
            reasonText,
          created_at: now,
          created_by:
            user.user_id,
          updated_at: now,
          updated_by:
            user.user_id
        },
        {
          validate: true,
          audit: false
        }
      );
    }
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'STATUS_CHANGE',
    'EXPENSES',
    expenseId,
    stripInternalFields_(expense),
    {
      status: 'VOID',
      reason: reasonText
    },
    'Expense voided.'
  );

  return stripInternalFields_(
    dbFindById(
      'EXPENSES',
      expenseId
    )
  );
}

function estimateOrderItemUnitCogs_(
  orderItem,
  productMap,
  variantMap,
  recipeMap
) {
  var product =
    productMap[
      orderItem.product_id
    ] || null;

  if (!product) return 0;

  var variant =
    orderItem.variant_id
      ? (
          variantMap[
            orderItem.variant_id
          ] || null
        )
      : null;

  var recipeId =
    variant &&
    variant.recipe_id
      ? variant.recipe_id
      : product.base_recipe_id;

  if (
    recipeId &&
    recipeMap[recipeId]
  ) {
    try {
      return Number(
        getRecipeEconomics_(
          recipeId
        ).unitCogs || 0
      );
    } catch (ignore) {}
  }

  return Number(
    product.current_cogs || 0
  );
}

function findOrderItemCogsTransaction_(
  orderItemId,
  transactions
) {
  return (transactions || [])
    .filter(function(row) {
      return (
        String(
          row.reference_type || ''
        ).toUpperCase() ===
          'ORDER_ITEM_COGS' &&
        String(row.reference_id) ===
          String(orderItemId) &&
        String(
          row.transaction_type || ''
        ).toUpperCase() ===
          'COGS'
      );
    })[0] || null;
}

function ensureOrderCogsTransactions_(
  orderId,
  actorUser,
  backfillMode
) {
  var order = dbFindById(
    'ORDERS',
    orderId
  );

  if (!order) {
    throw twbError_(
      'NOT_FOUND',
      'Order not found: ' +
      orderId
    );
  }

  if (
    String(order.order_status)
      .toUpperCase() !==
    'COMPLETED'
  ) {
    return {
      created: 0,
      skipped: true
    };
  }

  var items = dbFindMany(
    'ORDER_ITEMS',
    'order_id',
    orderId
  );

  var products =
    listAllRecords_('PRODUCTS');

  var variants =
    listAllRecords_(
      'PRODUCT_VARIANTS'
    );

  var recipes =
    listAllRecords_('RECIPES');

  var transactions =
    listAllRecords_(
      'TRANSACTIONS'
    );

  var productMap = {};
  products.forEach(function(row) {
    productMap[row.product_id] =
      row;
  });

  var variantMap = {};
  variants.forEach(function(row) {
    variantMap[row.variant_id] =
      row;
  });

  var recipeMap = {};
  recipes.forEach(function(row) {
    recipeMap[row.recipe_id] =
      row;
  });

  var pending = [];

  items.forEach(function(item) {
    if (
      findOrderItemCogsTransaction_(
        item.order_item_id,
        transactions
      )
    ) {
      return;
    }

    var unitCogs =
      estimateOrderItemUnitCogs_(
        item,
        productMap,
        variantMap,
        recipeMap
      );

    pending.push({
      item: item,
      unitCogs:
        unitCogs,
      totalCogs:
        Math.round(
          unitCogs *
          Number(
            item.quantity || 0
          )
        ),
      transactionId:
        nextBusinessId(
          'TRANSACTION'
        )
    });
  });

  if (!pending.length) {
    return {
      created: 0,
      skipped: false
    };
  }

  var now = nowIso_();

  var recognitionDate =
    financeDateKey_(
      order.fulfillment_date ||
      order.order_date ||
      now
    );

  var rows =
    pending.map(function(row) {
      return {
        transaction_id:
          row.transactionId,
        transaction_at:
          recognitionDate +
          'T23:59:00',
        transaction_type:
          'COGS',
        category:
          'PRODUCT_COGS',
        reference_type:
          'ORDER_ITEM_COGS',
        reference_id:
          row.item.order_item_id,
        amount_in: 0,
        amount_out:
          row.totalCogs,
        payment_method:
          'NON_CASH',
        notes:
          (
            backfillMode
              ? '[BACKFILLED CURRENT-COST ESTIMATE] '
              : ''
          ) +
          row.item.product_name_snapshot +
          ' · unit COGS ' +
          Math.round(
            row.unitCogs
          ),
        created_at: now,
        created_by:
          actorUser.user_id,
        updated_at: now,
        updated_by:
          actorUser.user_id
      };
    });

  dbBulkInsert(
    'TRANSACTIONS',
    rows,
    {
      validate: true
    }
  );

  return {
    created:
      rows.length,
    skipped: false
  };
}

function backfillCompletedOrderCogsPhase10() {
  var user =
    requirePermission_(
      'TRANSACTION_WRITE'
    );

  var orders =
    listAllRecords_('ORDERS')
      .filter(function(order) {
        return (
          String(
            order.order_status
          ).toUpperCase() ===
          'COMPLETED'
        );
      });

  var created = 0;

  orders.forEach(function(order) {
    var result =
      ensureOrderCogsTransactions_(
        order.order_id,
        user,
        true
      );

    created +=
      Number(
        result.created || 0
      );
  });

  return {
    completedOrders:
      orders.length,
    createdCogsTransactions:
      created,
    warning:
      'Backfilled COGS uses current material/recipe cost, not historical cost at the original completion date.'
  };
}

function calculateManagerialPnlTotals_(
  productSales,
  deliveryRevenue,
  totalCogs,
  operatingExpenses,
  taxCollected
) {
  var revenue =
    Math.round(
      Number(productSales || 0) +
      Number(deliveryRevenue || 0)
    );

  var cogs =
    Math.round(
      Number(totalCogs || 0)
    );

  var expenses =
    Math.round(
      Number(operatingExpenses || 0)
    );

  var grossProfit =
    Math.round(
      revenue - cogs
    );

  var operatingProfit =
    Math.round(
      grossProfit - expenses
    );

  return {
    productSales:
      Math.round(
        Number(productSales || 0)
      ),
    deliveryRevenue:
      Math.round(
        Number(deliveryRevenue || 0)
      ),
    operatingRevenue:
      revenue,
    taxCollected:
      Math.round(
        Number(taxCollected || 0)
      ),
    cogs: cogs,
    grossProfit:
      grossProfit,
    grossMarginPct:
      revenue > 0
        ? roundNumber_(
            (
              grossProfit /
              revenue
            ) * 100,
            2
          )
        : 0,
    operatingExpenses:
      expenses,
    operatingProfit:
      operatingProfit,
    operatingMarginPct:
      revenue > 0
        ? roundNumber_(
            (
              operatingProfit /
              revenue
            ) * 100,
            2
          )
        : 0
  };
}

function buildFinanceAnalytics_(
  payload
) {
  var period =
    normalizeFinancePeriod_(
      payload
    );

  var orders =
    listAllRecords_('ORDERS');

  var items =
    listAllRecords_('ORDER_ITEMS');

  var products =
    listAllRecords_('PRODUCTS');

  var variants =
    listAllRecords_(
      'PRODUCT_VARIANTS'
    );

  var recipes =
    listAllRecords_('RECIPES');

  var expenses =
    listAllRecords_('EXPENSES');

  var transactions =
    listAllRecords_(
      'TRANSACTIONS'
    );

  var productMap = {};
  products.forEach(function(row) {
    productMap[row.product_id] =
      row;
  });

  var variantMap = {};
  variants.forEach(function(row) {
    variantMap[row.variant_id] =
      row;
  });

  var recipeMap = {};
  recipes.forEach(function(row) {
    recipeMap[row.recipe_id] =
      row;
  });

  var itemGroups = {};
  items.forEach(function(item) {
    if (!itemGroups[item.order_id]) {
      itemGroups[item.order_id] =
        [];
    }

    itemGroups[item.order_id].push(
      item
    );
  });

  var completed =
    orders.filter(function(order) {
      if (
        String(
          order.order_status
        ).toUpperCase() !==
        'COMPLETED'
      ) {
        return false;
      }

      return financeDateInPeriod_(
        order.fulfillment_date ||
        order.order_date,
        period
      );
    });

  var productProfit = {};
  var channelProfit = {};

  var productSales = 0;
  var deliveryRevenue = 0;
  var taxCollected = 0;
  var totalCogs = 0;
  var estimatedCogs = 0;
  var snapshottedCogs = 0;

  completed.forEach(function(order) {
    var orderItems =
      itemGroups[
        order.order_id
      ] || [];

    var subtotal =
      Number(
        order.subtotal || 0
      );

    var orderDiscount =
      Number(
        order.discount || 0
      );

    var channel =
      order.source_channel ||
      'UNKNOWN';

    if (!channelProfit[channel]) {
      channelProfit[channel] = {
        channel: channel,
        orderCount: 0,
        units: 0,
        productRevenue: 0,
        deliveryRevenue: 0,
        cogs: 0,
        grossProfit: 0
      };
    }

    channelProfit[channel]
      .orderCount += 1;

    channelProfit[channel]
      .deliveryRevenue +=
      Number(
        order.delivery_fee || 0
      );

    deliveryRevenue +=
      Number(
        order.delivery_fee || 0
      );

    taxCollected +=
      Number(
        order.tax || 0
      );

    orderItems.forEach(function(item) {
      var lineRevenue =
        Number(
          item.line_total || 0
        );

      var discountAllocation =
        subtotal > 0
          ? orderDiscount *
            (
              lineRevenue /
              subtotal
            )
          : 0;

      var recognizedRevenue =
        Math.max(
          0,
          lineRevenue -
          discountAllocation
        );

      var cogsTransaction =
        findOrderItemCogsTransaction_(
          item.order_item_id,
          transactions
        );

      var itemCogs = 0;
      var cogsSource =
        'SNAPSHOT';

      if (cogsTransaction) {
        itemCogs =
          Number(
            cogsTransaction.amount_out || 0
          );

        snapshottedCogs +=
          itemCogs;
      } else {
        var unitCogs =
          estimateOrderItemUnitCogs_(
            item,
            productMap,
            variantMap,
            recipeMap
          );

        itemCogs =
          Math.round(
            unitCogs *
            Number(
              item.quantity || 0
            )
          );

        estimatedCogs +=
          itemCogs;

        cogsSource =
          'CURRENT_COST_ESTIMATE';
      }

      productSales +=
        recognizedRevenue;

      totalCogs +=
        itemCogs;

      var key =
        item.product_id +
        '|' +
        (
          item.variant_id || ''
        );

      if (!productProfit[key]) {
        productProfit[key] = {
          productId:
            item.product_id,
          variantId:
            item.variant_id || '',
          productName:
            item.product_name_snapshot,
          quantity: 0,
          revenue: 0,
          cogs: 0,
          grossProfit: 0,
          grossMarginPct: 0,
          estimatedCogsAmount: 0
        };
      }

      var row =
        productProfit[key];

      row.quantity +=
        Number(
          item.quantity || 0
        );

      row.revenue +=
        recognizedRevenue;

      row.cogs +=
        itemCogs;

      if (
        cogsSource ===
        'CURRENT_COST_ESTIMATE'
      ) {
        row.estimatedCogsAmount +=
          itemCogs;
      }

      channelProfit[channel]
        .units +=
        Number(
          item.quantity || 0
        );

      channelProfit[channel]
        .productRevenue +=
        recognizedRevenue;

      channelProfit[channel]
        .cogs +=
        itemCogs;
    });
  });

  var activeExpenses =
    expenses.filter(function(expense) {
      return (
        String(
          expense.status || ''
        ).toUpperCase() !==
          'VOID' &&
        financeDateInPeriod_(
          expense.expense_date,
          period
        )
      );
    });

  var expenseByCategory = {};
  var operatingExpenses = 0;

  activeExpenses.forEach(function(expense) {
    var category =
      expense.category ||
      'OTHER';

    var amount =
      Number(
        expense.amount || 0
      );

    operatingExpenses +=
      amount;

    expenseByCategory[category] =
      (
        expenseByCategory[category] ||
        0
      ) +
      amount;
  });

  var productRows =
    Object.keys(productProfit)
      .map(function(key) {
        var row =
          productProfit[key];

        row.grossProfit =
          Math.round(
            row.revenue -
            row.cogs
          );

        row.grossMarginPct =
          row.revenue > 0
            ? roundNumber_(
                (
                  row.grossProfit /
                  row.revenue
                ) * 100,
                2
              )
            : 0;

        row.revenue =
          Math.round(
            row.revenue
          );

        row.cogs =
          Math.round(
            row.cogs
          );

        row.estimatedCogsAmount =
          Math.round(
            row.estimatedCogsAmount
          );

        return row;
      })
      .sort(function(a, b) {
        return (
          b.grossProfit -
          a.grossProfit
        );
      });

  var channelRows =
    Object.keys(channelProfit)
      .map(function(key) {
        var row =
          channelProfit[key];

        row.revenue =
          Math.round(
            row.productRevenue +
            row.deliveryRevenue
          );

        row.grossProfit =
          Math.round(
            row.revenue -
            row.cogs
          );

        row.grossMarginPct =
          row.revenue > 0
            ? roundNumber_(
                (
                  row.grossProfit /
                  row.revenue
                ) * 100,
                2
              )
            : 0;

        row.productRevenue =
          Math.round(
            row.productRevenue
          );

        row.deliveryRevenue =
          Math.round(
            row.deliveryRevenue
          );

        row.cogs =
          Math.round(
            row.cogs
          );

        return row;
      })
      .sort(function(a, b) {
        return (
          b.grossProfit -
          a.grossProfit
        );
      });

  var cashTransactions =
    transactions.filter(function(row) {
      return (
        String(
          row.transaction_type || ''
        ).toUpperCase() !==
          'COGS' &&
        financeDateInPeriod_(
          row.transaction_at,
          period
        )
      );
    });

  var cashIn =
    cashTransactions.reduce(
      function(sum, row) {
        return (
          sum +
          Number(
            row.amount_in || 0
          )
        );
      },
      0
    );

  var cashOut =
    cashTransactions.reduce(
      function(sum, row) {
        return (
          sum +
          Number(
            row.amount_out || 0
          )
        );
      },
      0
    );

  var totals =
    calculateManagerialPnlTotals_(
      productSales,
      deliveryRevenue,
      totalCogs,
      operatingExpenses,
      taxCollected
    );

  return {
    period: period,
    basis: {
      revenueRecognition:
        'COMPLETED_ORDER_FULFILLMENT_DATE',
      taxTreatment:
        'EXCLUDED_FROM_OPERATING_REVENUE',
      cogsSnapshot:
        'ORDER_ITEM_COGS_TRANSACTION',
      historicalFallback:
        'CURRENT_COST_ESTIMATE'
    },
    pnl: {
      completedOrders:
        completed.length,
      productSales:
        totals.productSales,
      deliveryRevenue:
        totals.deliveryRevenue,
      operatingRevenue:
        totals.operatingRevenue,
      taxCollected:
        totals.taxCollected,
      cogs:
        totals.cogs,
      grossProfit:
        totals.grossProfit,
      grossMarginPct:
        totals.grossMarginPct,
      operatingExpenses:
        totals.operatingExpenses,
      operatingProfit:
        totals.operatingProfit,
      operatingMarginPct:
        totals.operatingMarginPct,
      snapshottedCogs:
        Math.round(
          snapshottedCogs
        ),
      estimatedCogs:
        Math.round(
          estimatedCogs
        )
    },
    cash: {
      cashIn:
        Math.round(cashIn),
      cashOut:
        Math.round(cashOut),
      netCash:
        Math.round(
          cashIn - cashOut
        )
    },
    expenseByCategory:
      Object.keys(
        expenseByCategory
      )
        .map(function(category) {
          return {
            category: category,
            amount:
              Math.round(
                expenseByCategory[
                  category
                ]
              )
          };
        })
        .sort(function(a, b) {
          return b.amount - a.amount;
        }),
    productProfitability:
      productRows,
    channelProfitability:
      channelRows
  };
}

function financeAnalytics(payload) {
  requireAnyPermission_([
    'PNL_READ',
    'REPORT_READ'
  ]);

  return buildFinanceAnalytics_(
    payload
  );
}
