/**
 * Twolittle.bites OS — Phase 5 Invoice Service
 *
 * Invoice rows snapshot financial totals from the Order.
 * Invoice line items are read from ORDER_ITEMS, which already contain
 * product/SKU/unit-price snapshots.
 */

function getWebAppBaseUrl_() {
  try {
    return String(ScriptApp.getService().getUrl() || '').trim();
  } catch (e) {
    return '';
  }
}

function buildPublicInvoiceUrl_(publicToken) {
  const token = encodeURIComponent(String(publicToken || ''));
  const base = getWebAppBaseUrl_();
  return base
    ? base + '?invoice=' + token
    : '?invoice=' + token;
}

function buildInvoiceNumber_(invoiceId) {
  const prefix = String(
    getBusinessSetting_('invoice_prefix') || 'INV-TLB'
  ).trim();

  const id = String(invoiceId || '');
  const serialPart = id.indexOf('INV-') === 0
    ? id.substring(4)
    : id;

  return prefix + '-' + serialPart;
}

function calculateInvoiceDueAt_() {
  const hours = Number(
    getBusinessSetting_('invoice_due_hours') || 24
  );

  const safeHours = hours > 0 ? hours : 24;
  const date = new Date(
    new Date().getTime() + safeHours * 60 * 60 * 1000
  );

  return Utilities.formatDate(
    date,
    TWB_APP.TIMEZONE,
    "yyyy-MM-dd'T'HH:mm:ssXXX"
  );
}

function getInvoiceByOrderId_(orderId) {
  return dbFindOne('INVOICES', 'order_id', orderId);
}

function getInvoiceDetail(invoiceId) {
  requirePermission_('INVOICE_READ');
  return getInvoiceDetail_(invoiceId);
}

function getInvoiceDetail_(invoiceId) {
  const invoice = dbFindById('INVOICES', invoiceId);
  if (!invoice) {
    throw twbError_('NOT_FOUND', 'Invoice not found: ' + invoiceId);
  }

  const order = dbFindById('ORDERS', invoice.order_id);
  const customer = dbFindById('CUSTOMERS', invoice.customer_id);
  const items = dbFindMany(
    'ORDER_ITEMS',
    'order_id',
    invoice.order_id
  ).map(stripInternalFields_);

  const payments = dbFindMany(
    'PAYMENTS',
    'invoice_id',
    invoiceId
  )
    .map(stripInternalFields_)
    .sort(function(a, b) {
      return String(b.payment_at || '').localeCompare(
        String(a.payment_at || '')
      );
    });

  const cleanInvoice = stripInternalFields_(invoice);
  cleanInvoice.public_url = buildPublicInvoiceUrl_(
    cleanInvoice.public_token
  );

  if (
    typeof buildPublicReceiptUrl_ ===
      'function'
  ) {
    cleanInvoice.receipt_url =
      buildPublicReceiptUrl_(
        cleanInvoice.public_token,
        false
      );
  }

  if (
    typeof buildKitchenTicketUrl_ ===
      'function'
  ) {
    cleanInvoice.kitchen_ticket_url =
      buildKitchenTicketUrl_(
        cleanInvoice.invoice_id,
        false
      );
  }

  return {
    invoice: cleanInvoice,
    order: order ? stripInternalFields_(order) : null,
    customer: customer ? stripInternalFields_(customer) : null,
    items: items,
    payments: payments
  };
}

function createInvoiceForOrder(orderId) {
  const user = requirePermission_('INVOICE_WRITE');
  return ensureInvoiceForOrder_(orderId, user);
}

function ensureInvoiceForOrder_(orderId, actorUser) {
  const existing = getInvoiceByOrderId_(orderId);
  if (existing) {
    if (
      typeof getInvoicePdfArchiveInfo_ ===
        'function' &&
      !getInvoicePdfArchiveInfo_(
        existing.invoice_id
      ) &&
      typeof syncInvoicePdfArchiveSafely_ ===
        'function'
    ) {
      syncInvoicePdfArchiveSafely_(
        existing.invoice_id,
        'ENSURE_EXISTING'
      );
    }

    return getInvoiceDetail_(existing.invoice_id);
  }

  const order = dbFindById('ORDERS', orderId);
  if (!order) {
    throw twbError_('NOT_FOUND', 'Order not found: ' + orderId);
  }

  if (String(order.order_status).toUpperCase() === 'CANCELLED') {
    throw twbError_(
      'INVOICE_ORDER_CANCELLED',
      'Cannot create an invoice for a cancelled order.'
    );
  }

  const invoiceId = nextBusinessId('INVOICE');
  const token = createPublicToken();
  const now = nowIso_();

  const record = {
    invoice_id: invoiceId,
    invoice_number: buildInvoiceNumber_(invoiceId),
    order_id: order.order_id,
    customer_id: order.customer_id,
    invoice_date: todayIso_(),
    due_at: calculateInvoiceDueAt_(),
    subtotal: Number(order.subtotal || 0),
    discount: Number(order.discount || 0),
    delivery_fee: Number(order.delivery_fee || 0),
    tax: Number(order.tax || 0),
    grand_total: Number(order.grand_total || 0),
    paid_amount: 0,
    remaining_amount: Number(order.grand_total || 0),
    status: 'DRAFT',
    last_payment_method: '',
    public_token: token,
    invoice_url: buildPublicInvoiceUrl_(token),
    sent_at: '',
    created_at: now,
    created_by: actorUser.user_id,
    updated_at: now,
    updated_by: actorUser.user_id
  };

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    const raceExisting = getInvoiceByOrderId_(orderId);
    if (raceExisting) {
      return getInvoiceDetail_(raceExisting.invoice_id);
    }

    dbInsertRecord(
      'INVOICES',
      record,
      { validate: true, audit: false }
    );

    dbUpdateById(
      'ORDERS',
      order.order_id,
      stampUpdate_(actorUser, {
        invoice_status: 'DRAFT'
      }),
      { validate: true, audit: false }
    );
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'CREATE',
    'INVOICES',
    invoiceId,
    null,
    record,
    'Invoice created from order totals.'
  );

  if (
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    syncInvoicePdfArchiveSafely_(
      invoiceId,
      'INVOICE_CREATED'
    );
  }

  return getInvoiceDetail_(invoiceId);
}

function markInvoiceSent(invoiceId) {
  const user = requirePermission_('INVOICE_WRITE');
  const invoice = dbFindById('INVOICES', invoiceId);
  if (!invoice) {
    throw twbError_('NOT_FOUND', 'Invoice not found: ' + invoiceId);
  }

  if (['PAID', 'CANCELLED', 'REFUNDED'].indexOf(
    String(invoice.status).toUpperCase()
  ) >= 0) {
    return getInvoiceDetail_(invoiceId);
  }

  const publicUrl = buildPublicInvoiceUrl_(
    invoice.public_token
  );

  const updated = dbUpdateById(
    'INVOICES',
    invoiceId,
    stampUpdate_(user, {
      status: 'SENT',
      sent_at: invoice.sent_at || nowIso_(),
      invoice_url: publicUrl
    }),
    { validate: true, audit: false }
  );

  dbUpdateById(
    'ORDERS',
    invoice.order_id,
    stampUpdate_(user, {
      invoice_status: 'SENT'
    }),
    { validate: true, audit: false }
  );

  writeAuditLog_(
    'STATUS_CHANGE',
    'INVOICES',
    invoiceId,
    stripInternalFields_(invoice),
    updated,
    'Invoice marked as sent.'
  );

  if (
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    syncInvoicePdfArchiveSafely_(
      invoiceId,
      'INVOICE_SENT'
    );
  }

  return getInvoiceDetail_(invoiceId);
}

function cancelInvoice(invoiceId, reason) {
  const user = requirePermission_('INVOICE_WRITE');
  const reasonText = normalizeText_(reason);
  if (!reasonText) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Invoice cancellation reason is required.'
    );
  }

  const invoice = dbFindById('INVOICES', invoiceId);
  if (!invoice) {
    throw twbError_('NOT_FOUND', 'Invoice not found: ' + invoiceId);
  }

  if (Number(invoice.paid_amount || 0) > 0) {
    throw twbError_(
      'INVOICE_HAS_PAYMENT',
      'Invoice with recorded payment cannot be cancelled. Refund first.'
    );
  }

  const updated = dbUpdateById(
    'INVOICES',
    invoiceId,
    stampUpdate_(user, {
      status: 'CANCELLED'
    }),
    { validate: true, audit: false }
  );

  dbUpdateById(
    'ORDERS',
    invoice.order_id,
    stampUpdate_(user, {
      invoice_status: 'CANCELLED'
    }),
    { validate: true, audit: false }
  );

  writeAuditLog_(
    'STATUS_CHANGE',
    'INVOICES',
    invoiceId,
    stripInternalFields_(invoice),
    updated,
    'Invoice cancelled: ' + reasonText
  );

  if (
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    syncInvoicePdfArchiveSafely_(
      invoiceId,
      'INVOICE_CANCELLED'
    );
  }

  return getInvoiceDetail_(invoiceId);
}

function refreshOverdueInvoices_() {
  const invoices = listAllRecords_('INVOICES');
  const nowMs = new Date().getTime();
  const user = requireCurrentUser_();
  let changed = 0;
  const changedInvoiceIds = [];

  invoices.forEach(function(invoice) {
    const status = String(invoice.status || '').toUpperCase();

    if (
      ['SENT', 'WAITING_PAYMENT', 'PARTIAL'].indexOf(status) < 0 ||
      !(Number(invoice.remaining_amount || 0) > 0) ||
      !invoice.due_at
    ) {
      return;
    }

    const dueMs = new Date(invoice.due_at).getTime();
    if (isNaN(dueMs) || dueMs >= nowMs) return;

    dbUpdateById(
      'INVOICES',
      invoice.invoice_id,
      stampUpdate_(user, { status: 'OVERDUE' }),
      { validate: true, audit: false }
    );

    dbUpdateById(
      'ORDERS',
      invoice.order_id,
      stampUpdate_(user, { invoice_status: 'OVERDUE' }),
      { validate: true, audit: false }
    );

    changed += 1;
    changedInvoiceIds.push(
      invoice.invoice_id
    );
  });

  if (
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    changedInvoiceIds.forEach(
      function(invoiceId) {
        syncInvoicePdfArchiveSafely_(
          invoiceId,
          'INVOICE_OVERDUE'
        );
      }
    );
  }

  return changed;
}

function formatIdrText_(value) {
  const rounded = Math.round(Number(value || 0));
  return 'Rp' + String(rounded).replace(
    /\B(?=(\d{3})+(?!\d))/g,
    '.'
  );
}

function formatPublicDateTime_(value) {
  if (!value) return '—';
  const parsed = new Date(value);
  if (isNaN(parsed.getTime())) return String(value);

  return Utilities.formatDate(
    parsed,
    TWB_APP.TIMEZONE,
    'dd MMM yyyy, HH:mm'
  );
}

function formatPublicDate_(value) {
  if (!value) return '—';

  const parsed =
    value instanceof Date
      ? value
      : new Date(value);

  if (isNaN(parsed.getTime())) {
    return String(value)
      .replace(
        /\s+GMT[+-]\d{4}.*$/i,
        ''
      )
      .trim();
  }

  return Utilities.formatDate(
    parsed,
    TWB_APP.TIMEZONE,
    'dd MMM yyyy'
  );
}

function getPublicInvoiceDataByToken_(token) {
  const cleanToken = String(token || '').trim();
  if (!cleanToken) return null;

  const invoice = dbFindOne(
    'INVOICES',
    'public_token',
    cleanToken
  );
  if (!invoice) return null;

  const order = dbFindById('ORDERS', invoice.order_id);
  const customer = dbFindById(
    'CUSTOMERS',
    invoice.customer_id
  );
  const items = dbFindMany(
    'ORDER_ITEMS',
    'order_id',
    invoice.order_id
  );

  const paymentRows = dbFindMany(
    'PAYMENTS',
    'invoice_id',
    invoice.invoice_id
  );

  const latestSuccess = paymentRows
    .filter(function(p) {
      return String(p.status).toUpperCase() === 'SUCCESS';
    })
    .sort(function(a, b) {
      return String(b.payment_at || '').localeCompare(
        String(a.payment_at || '')
      );
    })[0] || null;

  const pdfArchive =
    typeof getInvoicePdfArchiveInfo_ ===
      'function'
      ? getInvoicePdfArchiveInfo_(
          invoice.invoice_id
        )
      : null;

  const rawBrandLogo =
    getBusinessSetting_(
      'brand_logo_url'
    ) || '';

  let publicBrandLogo =
    rawBrandLogo;

  if (
    rawBrandLogo &&
    typeof imagePreviewDriveFileId_ ===
      'function' &&
    imagePreviewDriveFileId_(
      rawBrandLogo
    ) &&
    typeof resolveDriveImageDataUrl_ ===
      'function'
  ) {
    try {
      publicBrandLogo =
        resolveDriveImageDataUrl_(
          rawBrandLogo
        ).data_url;
    } catch (ignoreLogoResolve) {
      publicBrandLogo =
        rawBrandLogo;
    }
  }

  let publicStatus = String(invoice.status || '').toUpperCase();
  const dueMs = invoice.due_at
    ? new Date(invoice.due_at).getTime()
    : NaN;

  if (
    ['SENT', 'WAITING_PAYMENT', 'PARTIAL'].indexOf(publicStatus) >= 0 &&
    Number(invoice.remaining_amount || 0) > 0 &&
    !isNaN(dueMs) &&
    dueMs < new Date().getTime()
  ) {
    publicStatus = 'OVERDUE';
  }

  return {
    businessName:
      getBusinessSetting_('business_name') || 'Twolittle.bites',
    brandLogoUrl:
      publicBrandLogo,
    compactLayout:
      items.length <= 4,
    isPdfRender:
      false,
    publicTitle:
      getBusinessSetting_('invoice_public_title') ||
      (
        typeof settingsDefaultInvoicePublicTitle_ === 'function'
          ? settingsDefaultInvoicePublicTitle_()
          : 'Invoice'
      ),
    publicNote:
      getBusinessSetting_('invoice_public_note') ||
      (
        typeof settingsDefaultInvoicePublicNote_ === 'function'
          ? settingsDefaultInvoicePublicNote_()
          : 'Please follow the payment instructions shared directly by the seller.'
      ),
    invoiceNumber: invoice.invoice_number,
    invoiceDate: formatPublicDate_(invoice.invoice_date),
    dueAt: formatPublicDate_(invoice.due_at),
    status: publicStatus,
    customerName: customer ? customer.name : '',
    customerWhatsApp: customer ? customer.whatsapp : '',
    customerEmail: customer ? customer.email : '',
    deliveryAddress: order ? order.delivery_address : '',
    fulfillmentType: order ? order.fulfillment_type : '',
    fulfillmentDate: order && order.fulfillment_date
      ? formatPublicDate_(order.fulfillment_date)
      : '',
    items: items.map(function(item) {
      return {
        name: item.product_name_snapshot,
        sku: item.sku_snapshot,
        quantity: item.quantity,
        unitPriceText: formatIdrText_(item.unit_price),
        discountText: formatIdrText_(item.line_discount),
        lineTotalText: formatIdrText_(item.line_total)
      };
    }),
    subtotalText: formatIdrText_(invoice.subtotal),
    discountText: formatIdrText_(invoice.discount),
    deliveryFeeText: formatIdrText_(invoice.delivery_fee),
    taxText: formatIdrText_(invoice.tax),
    grandTotalText: formatIdrText_(invoice.grand_total),
    paidAmountText: formatIdrText_(invoice.paid_amount),
    remainingAmountText: formatIdrText_(invoice.remaining_amount),
    pdfViewUrl:
      pdfArchive
        ? pdfArchive.viewUrl || ''
        : '',
    pdfDownloadUrl:
      pdfArchive
        ? pdfArchive.downloadUrl || ''
        : '',
    lastPaymentMethod:
      invoice.last_payment_method ||
      (latestSuccess ? latestSuccess.payment_method : ''),
    generatedAt: formatPublicDateTime_(nowIso_())
  };
}
