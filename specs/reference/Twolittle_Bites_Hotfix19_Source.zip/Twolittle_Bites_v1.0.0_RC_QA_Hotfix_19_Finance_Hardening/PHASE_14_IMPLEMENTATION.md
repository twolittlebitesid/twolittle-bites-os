# PHASE_14_IMPLEMENTATION.md
# Twolittle.bites OS — Settings & Administration

**Phase:** 14  
**App Version:** 0.14.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Core principle

Phase 14 turns the Settings shell into an operational administration module without exposing arbitrary database configuration.

```text
Settings UI
↓
Whitelisted Settings Service
↓
CONFIG / BUSINESS_SETTINGS / USERS
↓
Existing Engines
```

There is no generic “edit any config key” endpoint.

## Settings tabs

```text
Business
Commerce
Invoice & WhatsApp
Automation
Users
System
```

## Permission model

### OWNER

```text
Read Settings
Write Settings
Manage Users
Manage Roles
Create another OWNER
```

### ADMIN

Phase 14 adds:

```text
SETTINGS_WRITE
```

ADMIN can update operational settings but cannot manage application users.

### FINANCE

Keeps:

```text
SETTINGS_READ
```

Finance can review configuration but receives a read-only UI.

### PRODUCTION / MARKETING

No Settings route unless their role permissions are changed in code.

## Business settings

Editable:

```text
business_name
whatsapp_country_code
```

Read-only for v1.0:

```text
timezone
currency
```

The application still uses fixed:

```text
Asia/Jakarta
IDR
```

for consistent date / financial behavior.

## Configurable WhatsApp normalization

Phase 14 updates `normalizeWhatsApp_()`.

Previously Indonesian prefix `62` was hardcoded.

Now:

```text
BUSINESS_SETTINGS.whatsapp_country_code
```

is used, with `62` as safe fallback.

Example:

```text
0812...
→ country code 62
→ 62812...
```

## Commerce lists

Editable CONFIG lists:

```text
SALES_CHANNELS
FULFILLMENT_TYPES
PAYMENT_METHODS
EXPENSE_CATEGORIES
```

Input accepts newline / comma / semicolon and normalizes into uppercase configuration tokens.

Example:

```text
bank transfer
→ BANK_TRANSFER
```

Duplicates are removed.

Historical Orders / Payments / Expenses are not rewritten when allowed lists change.

### Expense category protection

The category list must keep:

```text
MARKETING
ADS
```

because Phase 12 Campaign Spend uses those categories.

## Payment-method compatibility

Phase 14 writes:

```text
CONFIG.PAYMENT_METHODS
```

and synchronizes legacy:

```text
BUSINESS_SETTINGS.payment_methods
```

so the Phase 5 payment fallback remains compatible.

## Invoice settings

Editable:

```text
invoice_prefix
invoice_due_hours
```

Validation:

```text
invoice_prefix
2–20 chars
A–Z / 0–9 / hyphen

invoice_due_hours
1–720
```

The setting affects new invoices.

Existing invoice numbers and due dates are historical snapshots and are not rewritten.

## WhatsApp invoice template

New Business Setting:

```text
invoice_whatsapp_template
```

Supported placeholders:

```text
{customer_name}
{business_name}
{invoice_number}
{total}
{remaining}
{due_at}
{invoice_url}
```

Required:

```text
{invoice_number}
{invoice_url}
```

Unknown placeholders are rejected.

This template is used by the existing wa.me deep-link flow.

It does not auto-send WhatsApp messages.

## Automation & governance

Editable:

```text
AUTO_INVOICE_ON_ORDER
AUTO_CONFIRM_ON_PAID
NEGATIVE_STOCK_ALLOWED
ALLOW_ADMIN_PREORDER_OVERRIDE
PREORDER_ALMOST_FULL_RATIO
CRM_DORMANT_DAYS
REPORT_CACHE_LOOKBACK_DAYS
```

Validation:

```text
PREORDER_ALMOST_FULL_RATIO
0.05 – 0.50

CRM_DORMANT_DAYS
7 – 3650

REPORT_CACHE_LOOKBACK_DAYS
30 – 1460
```

Changes affect future engine behavior / future calculations.

They do not rewrite transaction history.

## User administration

Stored in existing:

```text
USERS
```

OWNER-only.

Create:

```text
Google Account Email
Display Name
Role
```

Roles:

```text
OWNER
ADMIN
PRODUCTION
MARKETING
FINANCE
```

Update:

```text
Display Name
Role
Status
```

Email is immutable.

Users are never deleted through Phase 14.

Access removal uses:

```text
status = INACTIVE
```

## OWNER lockout protection

Phase 14 blocks:

```text
current OWNER
→ demote self

current OWNER
→ deactivate self
```

It also guarantees:

```text
at least 1 ACTIVE OWNER
```

If ownership needs to transfer:

```text
OWNER A
→ create OWNER B
→ OWNER B logs in
→ OWNER B may later change OWNER A
```

## Audit behavior

Settings group updates create audit events.

User create/update also writes audit history.

No generic unrestricted CONFIG API is exposed.

## System panel

Read-only:

```text
App Version
Schema Version
Phase
Database Health
Application Timezone
Application Currency
Valid / Expected Sheets
Web App Deployment status
```

## Install from Phase 13

Replace:

```text
Constants.gs
Permissions.gs
Utils.gs
WhatsAppService.gs
AppShellService.gs
ApiGateway.gs
Index.html
JsApp.html
PageSettings.html
StylesComponents.html
StylesResponsive.html
```

Add:

```text
SettingsService.gs
JsSettings.html
Phase14Setup.gs
Phase14HealthCheck.gs
Phase14SmokeTest.gs
```

## Upgrade

Run once as OWNER:

```javascript
upgradeToPhase14()
```

It sets:

```text
APP_VERSION = 0.14.0
SCHEMA_VERSION = 1.0.0

SETTINGS_GOVERNANCE_MODE
= WHITELISTED_FIELDS_ONLY

USER_ADMIN_MODE
= OWNER_ONLY

USER_DELETE_MODE
= DEACTIVATE_ONLY
```

It also seeds the default `invoice_whatsapp_template` only when missing and synchronizes configured payment methods into the legacy Business Setting fallback.

No Sheet is recreated.

## Validation

Run:

```javascript
runPhase14HealthCheck()
runPhase14SmokeTest()
```

Both validation suites are read-only.

They do not:
- modify Config;
- modify Business Settings;
- create Users;
- deactivate Users.

## Browser QA

1. Open Settings as OWNER.
2. Business:
   - change Business Name;
   - save;
   - refresh.
3. Commerce:
   - add a test Sales Channel;
   - verify it appears in new Order source options.
4. Invoice:
   - change invoice prefix;
   - create a test invoice;
   - confirm only the new invoice uses the new prefix.
5. WhatsApp:
   - edit template;
   - open a real invoice WhatsApp link;
   - verify placeholders render.
6. Automation:
   - toggle a low-risk config;
   - save and refresh.
7. Users:
   - create a test ADMIN account;
   - verify Settings write but no Users tab.
8. Login as FINANCE:
   - Settings visible;
   - fields read-only.
9. Attempt to demote/deactivate the currently logged-in OWNER:
   - blocked.
10. Verify System shows 33/33 healthy sheets.

## Next

**Phase 15 — System Hardening & Automation**
