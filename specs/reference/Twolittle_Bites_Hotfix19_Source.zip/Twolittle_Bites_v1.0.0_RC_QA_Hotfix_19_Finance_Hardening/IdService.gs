function nextBusinessId(entityKey) {
  const def = TWB_ID_DEFINITIONS[entityKey];
  if (!def) throw twbError_('UNKNOWN_ID_ENTITY', 'Unknown ID entity: ' + entityKey);

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const props = PropertiesService.getScriptProperties();
    const period = def.monthly ? monthKey_() : '';
    const sequenceKey = 'TWB_SEQ_' + entityKey + (period ? '_' + period : '');
    const next = Number(props.getProperty(sequenceKey) || 0) + 1;
    props.setProperty(sequenceKey, String(next));
    const serial = String(next).padStart(6, '0');
    return def.monthly ? [def.prefix, period, serial].join('-') : [def.prefix, serial].join('-');
  } finally {
    lock.releaseLock();
  }
}

function createPublicToken() {
  return randomPublicToken_();
}
