/**
 * Twolittle.bites OS — Phase 12 Marketing & Attribution Engine
 *
 * Attribution model:
 * MANUAL_LAST_TOUCH
 *
 * Link storage:
 * ACTIVITY_LOG acts as an immutable mapping ledger so the existing
 * 33-sheet schema can be preserved.
 *
 * This is operational attribution, not proof of causal incrementality.
 */

function marketingReadUser_() {
  return requireAnyPermission_([
    'MARKETING_READ',
    'REPORT_MARKETING_READ'
  ]);
}

function marketingWriteUser_() {
  return requirePermission_(
    'MARKETING_WRITE'
  );
}

function marketingDateKey_(value) {
  return financeDateKey_(value);
}

function marketingOperatingRevenue_(order) {
  return Math.max(
    0,
    Math.round(
      Number(order.grand_total || 0) -
      Number(order.tax || 0)
    )
  );
}

function marketingAttributionSource_() {
  return 'PHASE12_MARKETING';
}

function marketingParseJson_(value) {
  if (!value) return null;

  try {
    return JSON.parse(
      String(value)
    );
  } catch (e) {
    return null;
  }
}

function writeMarketingLinkLog_(
  action,
  entityType,
  entityId,
  payload,
  notes
) {
  var user =
    requireCurrentUser_();

  var record = {
    log_id:
      nextBusinessId(
        'ACTIVITY_LOG'
      ),
    timestamp:
      nowIso_(),
    user_id:
      user.user_id,
    action:
      action,
    entity_type:
      entityType,
    entity_id:
      entityId,
    before_json: '',
    after_json:
      payload
        ? safeJson_(payload)
        : '',
    source:
      marketingAttributionSource_(),
    notes:
      notes || ''
  };

  return dbInsertRecord(
    'ACTIVITY_LOG',
    record,
    {
      validate: true,
      audit: false
    }
  );
}

function marketingLatestLinkMap_(
  entityType,
  logs
) {
  var relevant =
    (logs || [])
      .filter(function(log) {
        return (
          String(
            log.source || ''
          ) ===
            marketingAttributionSource_() &&
          String(
            log.entity_type || ''
          ) ===
            String(entityType)
        );
      })
      .sort(function(a, b) {
        return String(
          a.timestamp || ''
        ).localeCompare(
          String(
            b.timestamp || ''
          )
        );
      });

  var map = {};

  relevant.forEach(function(log) {
    var action =
      String(log.action || '')
        .toUpperCase();

    if (
      action.indexOf(
        '_CLEAR'
      ) >= 0
    ) {
      delete map[
        log.entity_id
      ];
      return;
    }

    var payload =
      marketingParseJson_(
        log.after_json
      );

    if (payload) {
      map[
        log.entity_id
      ] = payload;
    }
  });

  return map;
}

function marketingAttributionMap_(logs) {
  return marketingLatestLinkMap_(
    'ORDER_MARKETING_ATTRIBUTION',
    logs
  );
}

function marketingExpenseLinkMap_(logs) {
  return marketingLatestLinkMap_(
    'EXPENSE_MARKETING_LINK',
    logs
  );
}

function marketingCampaignStatusAllowed_(status) {
  return [
    'DRAFT',
    'ACTIVE',
    'PAUSED',
    'COMPLETED',
    'CANCELLED'
  ].indexOf(
    String(status || '')
      .toUpperCase()
  ) >= 0;
}

function validateMarketingCampaignPayload_(
  payload,
  existing
) {
  payload = payload || {};
  existing = existing || {};

  var name =
    normalizeText_(
      Object.prototype.hasOwnProperty.call(
        payload,
        'campaign_name'
      )
        ? payload.campaign_name
        : existing.campaign_name
    );

  if (!name) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Campaign name is required.'
    );
  }

  var startDate =
    marketingDateKey_(
      Object.prototype.hasOwnProperty.call(
        payload,
        'start_date'
      )
        ? payload.start_date
        : existing.start_date
    );

  if (!startDate) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Campaign start date is required.'
    );
  }

  var endDate =
    marketingDateKey_(
      Object.prototype.hasOwnProperty.call(
        payload,
        'end_date'
      )
        ? payload.end_date
        : existing.end_date
    );

  if (
    endDate &&
    endDate < startDate
  ) {
    throw twbError_(
      'MARKETING_DATE_INVALID',
      'Campaign end date cannot be before start date.'
    );
  }

  var budget =
    requireNonNegative_(
      Object.prototype.hasOwnProperty.call(
        payload,
        'budget'
      )
        ? payload.budget
        : (
            existing.budget || 0
          ),
      'budget'
    );

  return {
    campaignName: name,
    startDate: startDate,
    endDate: endDate,
    budget:
      Math.round(budget)
  };
}

function createMarketingCampaign(payload) {
  var user =
    marketingWriteUser_();

  var data =
    validateMarketingCampaignPayload_(
      payload
    );

  var id =
    nextBusinessId(
      'MARKETING_CAMPAIGN'
    );

  var now =
    nowIso_();

  var record = {
    marketing_campaign_id:
      id,
    campaign_name:
      data.campaignName,
    start_date:
      data.startDate,
    end_date:
      data.endDate,
    budget:
      data.budget,
    spend: 0,
    revenue_attributed: 0,
    orders_attributed: 0,
    new_customers: 0,
    repeat_customers: 0,
    status: 'DRAFT',
    created_at: now,
    created_by:
      user.user_id,
    updated_at: now,
    updated_by:
      user.user_id
  };

  dbInsertRecord(
    'MARKETING_CAMPAIGNS',
    record,
    {
      validate: true,
      audit: false
    }
  );

  writeAuditLog_(
    'CREATE',
    'MARKETING_CAMPAIGNS',
    id,
    null,
    record,
    'Marketing campaign created.'
  );

  return stripInternalFields_(
    record
  );
}

function updateMarketingCampaign(
  campaignId,
  payload
) {
  var user =
    marketingWriteUser_();

  var existing =
    dbFindById(
      'MARKETING_CAMPAIGNS',
      campaignId
    );

  if (!existing) {
    throw twbError_(
      'NOT_FOUND',
      'Marketing campaign not found: ' +
      campaignId
    );
  }

  var data =
    validateMarketingCampaignPayload_(
      payload,
      existing
    );

  var patch = {
    campaign_name:
      data.campaignName,
    start_date:
      data.startDate,
    end_date:
      data.endDate,
    budget:
      data.budget
  };

  if (
    Object.prototype.hasOwnProperty.call(
      payload || {},
      'status'
    )
  ) {
    var status =
      String(
        payload.status || ''
      ).toUpperCase();

    if (
      !marketingCampaignStatusAllowed_(
        status
      )
    ) {
      throw twbError_(
        'VALIDATION_ENUM',
        'Invalid campaign status.'
      );
    }

    patch.status =
      status;
  }

  return dbUpdateById(
    'MARKETING_CAMPAIGNS',
    campaignId,
    stampUpdate_(
      user,
      patch
    ),
    {
      validate: true,
      audit: true,
      action: 'UPDATE'
    }
  );
}

function updateMarketingCampaignStatus(
  campaignId,
  status
) {
  return updateMarketingCampaign(
    campaignId,
    {
      status:
        String(
          status || ''
        ).toUpperCase()
    }
  );
}

function validateContentMetrics_(payload) {
  payload = payload || {};

  return {
    reach:
      requireNonNegative_(
        payload.reach || 0,
        'reach'
      ),
    views:
      requireNonNegative_(
        payload.views || 0,
        'views'
      ),
    engagement:
      requireNonNegative_(
        payload.engagement || 0,
        'engagement'
      ),
    linkClick:
      requireNonNegative_(
        payload.link_click || 0,
        'link_click'
      )
  };
}

function createMarketingContent(payload) {
  var user =
    marketingWriteUser_();

  payload = payload || {};

  var platform =
    normalizeText_(
      payload.platform
    );

  if (!platform) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Platform is required.'
    );
  }

  var campaignId =
    normalizeText_(
      payload.marketing_campaign_id
    );

  if (campaignId) {
    var campaign =
      dbFindById(
        'MARKETING_CAMPAIGNS',
        campaignId
      );

    if (!campaign) {
      throw twbError_(
        'NOT_FOUND',
        'Marketing campaign not found: ' +
        campaignId
      );
    }
  }

  var metrics =
    validateContentMetrics_(
      payload
    );

  var id =
    nextBusinessId(
      'CONTENT'
    );

  var now =
    nowIso_();

  var record = {
    content_id:
      id,
    marketing_campaign_id:
      campaignId,
    platform:
      platform,
    pillar:
      normalizeText_(
        payload.pillar
      ),
    format:
      normalizeText_(
        payload.format
      ),
    publish_date:
      marketingDateKey_(
        payload.publish_date
      ),
    url:
      normalizeText_(
        payload.url
      ),
    reach:
      metrics.reach,
    views:
      metrics.views,
    engagement:
      metrics.engagement,
    link_click:
      metrics.linkClick,
    orders_attributed: 0,
    revenue_attributed: 0,
    notes:
      normalizeText_(
        payload.notes
      ),
    created_at: now,
    created_by:
      user.user_id,
    updated_at: now,
    updated_by:
      user.user_id
  };

  dbInsertRecord(
    'CONTENT',
    record,
    {
      validate: true,
      audit: false
    }
  );

  writeAuditLog_(
    'CREATE',
    'CONTENT',
    id,
    null,
    record,
    'Marketing content created.'
  );

  return stripInternalFields_(
    record
  );
}

function updateMarketingContent(
  contentId,
  payload
) {
  var user =
    marketingWriteUser_();

  var existing =
    dbFindById(
      'CONTENT',
      contentId
    );

  if (!existing) {
    throw twbError_(
      'NOT_FOUND',
      'Content not found: ' +
      contentId
    );
  }

  payload = payload || {};

  var metrics =
    validateContentMetrics_(
      Object.assign(
        {},
        existing,
        payload
      )
    );

  var campaignId =
    Object.prototype.hasOwnProperty.call(
      payload,
      'marketing_campaign_id'
    )
      ? normalizeText_(
          payload.marketing_campaign_id
        )
      : existing.marketing_campaign_id;

  if (campaignId) {
    var campaign =
      dbFindById(
        'MARKETING_CAMPAIGNS',
        campaignId
      );

    if (!campaign) {
      throw twbError_(
        'NOT_FOUND',
        'Marketing campaign not found: ' +
        campaignId
      );
    }
  }

  var patch = {
    marketing_campaign_id:
      campaignId,
    platform:
      normalizeText_(
        Object.prototype.hasOwnProperty.call(
          payload,
          'platform'
        )
          ? payload.platform
          : existing.platform
      ),
    pillar:
      normalizeText_(
        Object.prototype.hasOwnProperty.call(
          payload,
          'pillar'
        )
          ? payload.pillar
          : existing.pillar
      ),
    format:
      normalizeText_(
        Object.prototype.hasOwnProperty.call(
          payload,
          'format'
        )
          ? payload.format
          : existing.format
      ),
    publish_date:
      marketingDateKey_(
        Object.prototype.hasOwnProperty.call(
          payload,
          'publish_date'
        )
          ? payload.publish_date
          : existing.publish_date
      ),
    url:
      normalizeText_(
        Object.prototype.hasOwnProperty.call(
          payload,
          'url'
        )
          ? payload.url
          : existing.url
      ),
    reach:
      metrics.reach,
    views:
      metrics.views,
    engagement:
      metrics.engagement,
    link_click:
      metrics.linkClick,
    notes:
      normalizeText_(
        Object.prototype.hasOwnProperty.call(
          payload,
          'notes'
        )
          ? payload.notes
          : existing.notes
      )
  };

  return dbUpdateById(
    'CONTENT',
    contentId,
    stampUpdate_(
      user,
      patch
    ),
    {
      validate: true,
      audit: true,
      action: 'UPDATE'
    }
  );
}

function validateMarketingAttribution_(
  orderId,
  campaignId,
  contentId
) {
  var order =
    dbFindById(
      'ORDERS',
      orderId
    );

  if (!order) {
    throw twbError_(
      'NOT_FOUND',
      'Order not found: ' +
      orderId
    );
  }

  if (
    String(
      order.order_status || ''
    ).toUpperCase() ===
    'CANCELLED'
  ) {
    throw twbError_(
      'MARKETING_ORDER_CANCELLED',
      'Cancelled Orders cannot be attributed.'
    );
  }

  var campaign =
    dbFindById(
      'MARKETING_CAMPAIGNS',
      campaignId
    );

  if (!campaign) {
    throw twbError_(
      'NOT_FOUND',
      'Marketing campaign not found: ' +
      campaignId
    );
  }

  if (
    String(
      campaign.status || ''
    ).toUpperCase() ===
    'CANCELLED'
  ) {
    throw twbError_(
      'MARKETING_CAMPAIGN_CANCELLED',
      'Cancelled campaign cannot receive new attribution.'
    );
  }

  var content = null;

  if (contentId) {
    content =
      dbFindById(
        'CONTENT',
        contentId
      );

    if (!content) {
      throw twbError_(
        'NOT_FOUND',
        'Content not found: ' +
        contentId
      );
    }

    if (
      String(
        content.marketing_campaign_id || ''
      ) !==
      String(campaignId)
    ) {
      throw twbError_(
        'MARKETING_CONTENT_CAMPAIGN_MISMATCH',
        'Selected content does not belong to the selected campaign.'
      );
    }
  }

  return {
    order: order,
    campaign: campaign,
    content: content
  };
}

function setMarketingAttribution(payload) {
  var user =
    marketingWriteUser_();

  payload = payload || {};

  var orderId =
    normalizeText_(
      payload.order_id
    );

  var campaignId =
    normalizeText_(
      payload.marketing_campaign_id
    );

  var contentId =
    normalizeText_(
      payload.content_id
    );

  if (
    !orderId ||
    !campaignId
  ) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Order and campaign are required.'
    );
  }

  var validated =
    validateMarketingAttribution_(
      orderId,
      campaignId,
      contentId
    );

  writeMarketingLinkLog_(
    'MARKETING_ATTRIBUTION_SET',
    'ORDER_MARKETING_ATTRIBUTION',
    orderId,
    {
      marketing_campaign_id:
        campaignId,
      content_id:
        contentId,
      attribution_model:
        'MANUAL_LAST_TOUCH',
      source_channel:
        validated.order.source_channel || '',
      attributed_at:
        nowIso_(),
      attributed_by:
        user.user_id
    },
    'Manual last-touch attribution set.'
  );

  syncMarketingAggregates_(
    user
  );

  return {
    orderId: orderId,
    campaignId: campaignId,
    contentId: contentId,
    attributionModel:
      'MANUAL_LAST_TOUCH'
  };
}

function clearMarketingAttribution(
  orderId
) {
  var user =
    marketingWriteUser_();

  var order =
    dbFindById(
      'ORDERS',
      orderId
    );

  if (!order) {
    throw twbError_(
      'NOT_FOUND',
      'Order not found: ' +
      orderId
    );
  }

  writeMarketingLinkLog_(
    'MARKETING_ATTRIBUTION_CLEAR',
    'ORDER_MARKETING_ATTRIBUTION',
    orderId,
    null,
    'Marketing attribution cleared.'
  );

  syncMarketingAggregates_(
    user
  );

  return {
    orderId:
      orderId,
    cleared:
      true
  };
}

function createMarketingSpend(payload) {
  var user =
    marketingWriteUser_();

  payload = payload || {};

  var campaignId =
    normalizeText_(
      payload.marketing_campaign_id
    );

  var campaign =
    dbFindById(
      'MARKETING_CAMPAIGNS',
      campaignId
    );

  if (!campaign) {
    throw twbError_(
      'NOT_FOUND',
      'Marketing campaign not found: ' +
      campaignId
    );
  }

  var category =
    String(
      payload.category || 'ADS'
    ).toUpperCase();

  if (
    ['ADS','MARKETING'].indexOf(
      category
    ) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Marketing spend category must be ADS or MARKETING.'
    );
  }

  var expense =
    createExpense({
      expense_date:
        payload.expense_date,
      category:
        category,
      vendor:
        payload.vendor,
      amount:
        payload.amount,
      payment_method:
        payload.payment_method,
      receipt_url:
        payload.receipt_url,
      notes:
        (
          '[MKT ' +
          campaignId +
          '] ' +
          (
            normalizeText_(
              payload.notes
            ) || campaign.campaign_name
          )
        )
    });

  writeMarketingLinkLog_(
    'MARKETING_EXPENSE_LINK_SET',
    'EXPENSE_MARKETING_LINK',
    expense.expense_id,
    {
      marketing_campaign_id:
        campaignId,
      linked_at:
        nowIso_(),
      linked_by:
        user.user_id
    },
    'Expense linked to marketing campaign.'
  );

  syncMarketingAggregates_(
    user
  );

  return {
    expense: expense,
    campaignId:
      campaignId
  };
}

function marketingFirstOrderByCustomer_(
  orders
) {
  var map = {};

  (orders || [])
    .filter(function(order) {
      return (
        String(
          order.order_status || ''
        ).toUpperCase() !==
        'CANCELLED'
      );
    })
    .forEach(function(order) {
      var customerId =
        order.customer_id;

      var key =
        marketingDateKey_(
          order.order_date ||
          order.created_at
        ) +
        '|' +
        String(
          order.created_at || ''
        ) +
        '|' +
        String(
          order.order_id || ''
        );

      if (
        !map[customerId] ||
        key <
          map[customerId].key
      ) {
        map[customerId] = {
          key: key,
          orderId:
            order.order_id
        };
      }
    });

  return map;
}

function buildMarketingAnalytics_() {
  var campaigns =
    listAllRecords_(
      'MARKETING_CAMPAIGNS'
    );

  var content =
    listAllRecords_(
      'CONTENT'
    );

  var orders =
    listAllRecords_(
      'ORDERS'
    );

  var customers =
    listAllRecords_(
      'CUSTOMERS'
    );

  var customerMap = {};

  customers.forEach(function(customer) {
    customerMap[
      customer.customer_id
    ] = customer;
  });

  var expenses =
    listAllRecords_(
      'EXPENSES'
    );

  var logs =
    listAllRecords_(
      'ACTIVITY_LOG'
    );

  var attributionMap =
    marketingAttributionMap_(
      logs
    );

  var expenseLinkMap =
    marketingExpenseLinkMap_(
      logs
    );

  var firstOrders =
    marketingFirstOrderByCustomer_(
      orders
    );

  var campaignAgg = {};
  var contentAgg = {};

  campaigns.forEach(function(campaign) {
    campaignAgg[
      campaign.marketing_campaign_id
    ] = {
      marketing_campaign_id:
        campaign.marketing_campaign_id,
      campaign_name:
        campaign.campaign_name,
      start_date:
        campaign.start_date,
      end_date:
        campaign.end_date,
      budget:
        Number(
          campaign.budget || 0
        ),
      spend: 0,
      revenue_attributed: 0,
      orders_attributed: 0,
      new_customers: 0,
      repeat_customers: 0,
      status:
        campaign.status,
      attributed_completed_orders:
        0
    };
  });

  content.forEach(function(row) {
    contentAgg[
      row.content_id
    ] = {
      content_id:
        row.content_id,
      marketing_campaign_id:
        row.marketing_campaign_id,
      orders_attributed: 0,
      revenue_attributed: 0
    };
  });

  expenses.forEach(function(expense) {
    if (
      String(
        expense.status || ''
      ).toUpperCase() ===
      'VOID'
    ) {
      return;
    }

    var link =
      expenseLinkMap[
        expense.expense_id
      ];

    if (!link) return;

    var agg =
      campaignAgg[
        link.marketing_campaign_id
      ];

    if (!agg) return;

    agg.spend +=
      Number(
        expense.amount || 0
      );
  });

  var attributedRows = [];
  var unattributedRows = [];

  orders.forEach(function(order) {
    var status =
      String(
        order.order_status || ''
      ).toUpperCase();

    if (status === 'CANCELLED') {
      return;
    }

    var link =
      attributionMap[
        order.order_id
      ];

    if (!link) {
      unattributedRows.push(
        order
      );
      return;
    }

    var campaign =
      campaignAgg[
        link.marketing_campaign_id
      ];

    if (!campaign) {
      return;
    }

    var completed =
      status === 'COMPLETED';

    var revenue =
      completed
        ? marketingOperatingRevenue_(
            order
          )
        : 0;

    var first =
      firstOrders[
        order.customer_id
      ];

    var isNew =
      first &&
      String(
        first.orderId
      ) ===
      String(
        order.order_id
      );

    campaign
      .orders_attributed += 1;

    if (completed) {
      campaign
        .attributed_completed_orders += 1;

      campaign
        .revenue_attributed +=
        revenue;
    }

    if (isNew) {
      campaign
        .new_customers += 1;
    } else {
      campaign
        .repeat_customers += 1;
    }

    if (
      link.content_id &&
      contentAgg[
        link.content_id
      ]
    ) {
      contentAgg[
        link.content_id
      ].orders_attributed += 1;

      if (completed) {
        contentAgg[
          link.content_id
        ].revenue_attributed +=
          revenue;
      }
    }

    attributedRows.push({
      order_id:
        order.order_id,
      order_date:
        order.order_date,
      customer_id:
        order.customer_id,
      customer_name:
        customerMap[
          order.customer_id
        ]
          ? customerMap[
              order.customer_id
            ].name
          : order.customer_id,
      source_channel:
        order.source_channel,
      order_status:
        order.order_status,
      payment_status:
        order.payment_status,
      grand_total:
        Number(
          order.grand_total || 0
        ),
      operating_revenue:
        revenue,
      marketing_campaign_id:
        link.marketing_campaign_id,
      content_id:
        link.content_id || '',
      attribution_model:
        link.attribution_model ||
        'MANUAL_LAST_TOUCH',
      new_customer:
        !!isNew
    });
  });

  var campaignRows =
    campaigns.map(function(campaign) {
      var agg =
        campaignAgg[
          campaign.marketing_campaign_id
        ];

      var spend =
        Math.round(
          agg.spend
        );

      var revenue =
        Math.round(
          agg.revenue_attributed
        );

      return Object.assign(
        {},
        stripInternalFields_(
          campaign
        ),
        {
          spend_live:
            spend,
          revenue_attributed_live:
            revenue,
          orders_attributed_live:
            agg.orders_attributed,
          attributed_completed_orders:
            agg.attributed_completed_orders,
          new_customers_live:
            agg.new_customers,
          repeat_customers_live:
            agg.repeat_customers,
          roas:
            spend > 0
              ? roundNumber_(
                  revenue /
                  spend,
                  2
                )
              : null,
          cac:
            agg.new_customers > 0
              ? Math.round(
                  spend /
                  agg.new_customers
                )
              : null,
          cost_per_attributed_order:
            agg.orders_attributed > 0
              ? Math.round(
                  spend /
                  agg.orders_attributed
                )
              : null,
          budget_used_pct:
            Number(
              campaign.budget || 0
            ) > 0
              ? roundNumber_(
                  (
                    spend /
                    Number(
                      campaign.budget
                    )
                  ) * 100,
                  1
                )
              : null
        }
      );
    });

  var campaignMap = {};
  campaignRows.forEach(function(row) {
    campaignMap[
      row.marketing_campaign_id
    ] = row;
  });

  var contentRows =
    content.map(function(row) {
      var agg =
        contentAgg[
          row.content_id
        ] || {
          orders_attributed: 0,
          revenue_attributed: 0
        };

      var clicks =
        Number(
          row.link_click || 0
        );

      var reach =
        Number(
          row.reach || 0
        );

      var engagement =
        Number(
          row.engagement || 0
        );

      return Object.assign(
        {},
        stripInternalFields_(
          row
        ),
        {
          campaign_name:
            row.marketing_campaign_id &&
            campaignMap[
              row.marketing_campaign_id
            ]
              ? campaignMap[
                  row.marketing_campaign_id
                ].campaign_name
              : '',
          orders_attributed_live:
            agg.orders_attributed,
          revenue_attributed_live:
            Math.round(
              agg.revenue_attributed
            ),
          click_to_order_pct:
            clicks > 0
              ? roundNumber_(
                  (
                    agg.orders_attributed /
                    clicks
                  ) * 100,
                  2
                )
              : null,
          engagement_rate_pct:
            reach > 0
              ? roundNumber_(
                  (
                    engagement /
                    reach
                  ) * 100,
                  2
                )
              : null
        }
      );
    });

  var nonCancelledOrders =
    orders.filter(function(order) {
      return (
        String(
          order.order_status || ''
        ).toUpperCase() !==
        'CANCELLED'
      );
    });

  var completedOrders =
    nonCancelledOrders.filter(
      function(order) {
        return (
          String(
            order.order_status || ''
          ).toUpperCase() ===
          'COMPLETED'
        );
      }
    );

  var completedRevenue =
    completedOrders.reduce(
      function(sum, order) {
        return (
          sum +
          marketingOperatingRevenue_(
            order
          )
        );
      },
      0
    );

  var attributedRevenue =
    campaignRows.reduce(
      function(sum, row) {
        return (
          sum +
          Number(
            row.revenue_attributed_live || 0
          )
        );
      },
      0
    );

  var spend =
    campaignRows.reduce(
      function(sum, row) {
        return (
          sum +
          Number(
            row.spend_live || 0
          )
        );
      },
      0
    );

  var attributedOrders =
    attributedRows.length;

  var newCustomers =
    campaignRows.reduce(
      function(sum, row) {
        return (
          sum +
          Number(
            row.new_customers_live || 0
          )
        );
      },
      0
    );

  var channelMap = {};

  nonCancelledOrders.forEach(
    function(order) {
      var channel =
        order.source_channel ||
        'UNKNOWN';

      if (!channelMap[channel]) {
        channelMap[channel] = {
          channel: channel,
          orders: 0,
          completedOrders: 0,
          operatingRevenue: 0,
          attributedOrders: 0
        };
      }

      channelMap[channel]
        .orders += 1;

      if (
        String(
          order.order_status || ''
        ).toUpperCase() ===
        'COMPLETED'
      ) {
        channelMap[channel]
          .completedOrders += 1;

        channelMap[channel]
          .operatingRevenue +=
          marketingOperatingRevenue_(
            order
          );
      }

      if (
        attributionMap[
          order.order_id
        ]
      ) {
        channelMap[channel]
          .attributedOrders += 1;
      }
    }
  );

  var channels =
    Object.keys(channelMap)
      .map(function(key) {
        var row =
          channelMap[key];

        row.operatingRevenue =
          Math.round(
            row.operatingRevenue
          );

        row.attributionCoveragePct =
          row.orders > 0
            ? roundNumber_(
                (
                  row.attributedOrders /
                  row.orders
                ) * 100,
                1
              )
            : 0;

        return row;
      })
      .sort(function(a, b) {
        return (
          b.operatingRevenue -
          a.operatingRevenue
        );
      });

  var mappedExpenses =
    expenses
      .filter(function(expense) {
        return !!expenseLinkMap[
          expense.expense_id
        ];
      })
      .map(function(expense) {
        var link =
          expenseLinkMap[
            expense.expense_id
          ];

        var campaign =
          campaignMap[
            link.marketing_campaign_id
          ];

        return Object.assign(
          {},
          stripInternalFields_(
            expense
          ),
          {
            marketing_campaign_id:
              link.marketing_campaign_id,
            campaign_name:
              campaign
                ? campaign.campaign_name
                : link.marketing_campaign_id
          }
        );
      })
      .sort(function(a, b) {
        return String(
          b.expense_date || ''
        ).localeCompare(
          String(
            a.expense_date || ''
          )
        );
      });

  return {
    summary: {
      campaigns:
        campaignRows.length,
      activeCampaigns:
        campaignRows.filter(
          function(row) {
            return (
              String(
                row.status || ''
              ).toUpperCase() ===
              'ACTIVE'
            );
          }
        ).length,
      content:
        contentRows.length,
      spend:
        Math.round(spend),
      attributedRevenue:
        Math.round(
          attributedRevenue
        ),
      attributedOrders:
        attributedOrders,
      newCustomers:
        newCustomers,
      roas:
        spend > 0
          ? roundNumber_(
              attributedRevenue /
              spend,
              2
            )
          : null,
      cac:
        newCustomers > 0
          ? Math.round(
              spend /
              newCustomers
            )
          : null,
      attributionCoveragePct:
        nonCancelledOrders.length > 0
          ? roundNumber_(
              (
                attributedOrders /
                nonCancelledOrders.length
              ) * 100,
              1
            )
          : 0,
      attributedRevenueCoveragePct:
        completedRevenue > 0
          ? roundNumber_(
              (
                attributedRevenue /
                completedRevenue
              ) * 100,
              1
            )
          : 0
    },
    campaigns:
      campaignRows,
    content:
      contentRows,
    attributedOrders:
      attributedRows
        .sort(function(a, b) {
          return String(
            b.order_date || ''
          ).localeCompare(
            String(
              a.order_date || ''
            )
          );
        }),
    unattributedOrders:
      unattributedRows
        .sort(function(a, b) {
          return String(
            b.order_date || ''
          ).localeCompare(
            String(
              a.order_date || ''
            )
          );
        })
        .slice(0, 200)
        .map(function(order) {
          return Object.assign(
            {},
            stripInternalFields_(order),
            {
              customer_name:
                customerMap[
                  order.customer_id
                ]
                  ? customerMap[
                      order.customer_id
                    ].name
                  : order.customer_id
            }
          );
        }),
    spend:
      mappedExpenses,
    channels:
      channels
  };
}

function syncMarketingAggregates_(
  actorUser
) {
  var user =
    actorUser ||
    requireCurrentUser_();

  var analytics =
    buildMarketingAnalytics_();

  analytics.campaigns
    .forEach(function(row) {
      dbUpdateById(
        'MARKETING_CAMPAIGNS',
        row.marketing_campaign_id,
        stampUpdate_(
          user,
          {
            spend:
              row.spend_live,
            revenue_attributed:
              row.revenue_attributed_live,
            orders_attributed:
              row.orders_attributed_live,
            new_customers:
              row.new_customers_live,
            repeat_customers:
              row.repeat_customers_live
          }
        ),
        {
          validate: true,
          audit: false
        }
      );
    });

  analytics.content
    .forEach(function(row) {
      dbUpdateById(
        'CONTENT',
        row.content_id,
        stampUpdate_(
          user,
          {
            orders_attributed:
              row.orders_attributed_live,
            revenue_attributed:
              row.revenue_attributed_live
          }
        ),
        {
          validate: true,
          audit: false
        }
      );
    });

  return analytics;
}

function rebuildMarketingAggregatesPhase12() {
  var user =
    marketingWriteUser_();

  var analytics =
    syncMarketingAggregates_(
      user
    );

  return {
    campaigns:
      analytics.campaigns.length,
    content:
      analytics.content.length,
    attributedOrders:
      analytics.attributedOrders.length,
    spend:
      analytics.summary.spend,
    attributedRevenue:
      analytics.summary.attributedRevenue
  };
}

function marketingModuleBootstrap() {
  var user =
    marketingReadUser_();

  var analytics =
    buildMarketingAnalytics_();

  analytics.permissions = {
    marketingWrite:
      hasPermission_(
        user,
        'MARKETING_WRITE'
      ),
    expenseCreate:
      (
        hasPermission_(
          user,
          'EXPENSE_CREATE'
        ) ||
        hasPermission_(
          user,
          'EXPENSE_WRITE'
        ) ||
        hasPermission_(
          user,
          'EXPENSE_CREATE_MARKETING'
        )
      )
  };

  analytics.config = {
    attributionModel:
      'MANUAL_LAST_TOUCH',
    revenueBasis:
      'COMPLETED_ORDER_OPERATING_REVENUE',
    causalityNote:
      'Operational attribution only; does not establish causal incrementality.'
  };

  analytics.paymentMethods =
    getPaymentMethods_();

  return analytics;
}
