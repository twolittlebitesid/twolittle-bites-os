/**
 * Route metadata belongs on the server so visibility is role-aware.
 * Client-side hiding is UX only; service functions must still enforce permissions.
 */
const TWB_APP_ROUTES = Object.freeze([
  { id: 'executive',  label: 'Executive',  icon: 'space_dashboard', primary: true,  anyPermissions: ['EXECUTIVE_READ'] },
  { id: 'orders',     label: 'Orders',     icon: 'receipt_long',    primary: true,  anyPermissions: ['ORDER_READ'] },
  { id: 'products',   label: 'Products',   icon: 'bakery_dining',   primary: true,  anyPermissions: ['PRODUCT_READ'] },
  { id: 'production', label: 'Production', icon: 'oven_gen',        primary: true,  anyPermissions: ['PRODUCTION_READ'] },
  { id: 'inventory',  label: 'Inventory',  icon: 'inventory_2',     primary: true,  anyPermissions: ['INVENTORY_READ'] },
  { id: 'finance',    label: 'Finance',    icon: 'payments',        primary: true,  anyPermissions: ['TRANSACTION_READ','PNL_READ','INVOICE_READ'] },

  { id: 'business',   label: 'Business',   icon: 'monitoring',      primary: false, anyPermissions: ['BUSINESS_READ'] },
  { id: 'customers',  label: 'Customers',  icon: 'group',           primary: false, anyPermissions: ['CUSTOMER_READ','CUSTOMER_READ_LIMITED'] },
  { id: 'purchasing', label: 'Purchasing', icon: 'shopping_cart',   primary: false, anyPermissions: ['PURCHASE_READ'] },
  { id: 'marketing',  label: 'Marketing',  icon: 'campaign',        primary: false, anyPermissions: ['MARKETING_READ'] },
  { id: 'reports',    label: 'Reports',    icon: 'analytics',       primary: false, anyPermissions: ['REPORT_READ','REPORT_OPERATIONAL_READ','REPORT_MARKETING_READ'] },
  { id: 'settings',   label: 'Settings',   icon: 'settings',        primary: false, anyPermissions: ['SETTINGS_READ'] }
]);

function getAppBootstrap_() {
  const user = requireCurrentUser_();
  const schemaReport = validateDatabaseSchema();
  const businessName = getBusinessSetting_('business_name') || TWB_APP.NAME;
  const visibleRoutes = TWB_APP_ROUTES
    .filter(function(route) { return routeVisibleToUser_(route, user); })
    .map(function(route) {
      return {
        id: route.id,
        label: route.label,
        icon: route.icon,
        primary: route.primary
      };
    });

  if (!visibleRoutes.length) {
    throw twbError_('NO_VISIBLE_ROUTES', 'Your account is active but has no visible application modules.');
  }

  return {
    app: {
      name: TWB_APP.NAME,
      phase: Number(TWB_APP.PHASE),
      appVersion: TWB_APP.APP_VERSION,
      schemaVersion: TWB_APP.SCHEMA_VERSION,
      timezone: TWB_APP.TIMEZONE,
      currency: TWB_APP.CURRENCY
    },
    business: {
      name: businessName
    },
    user: {
      userId: user.user_id,
      displayName: user.display_name,
      email: user.email,
      role: user.role
    },
    navigation: visibleRoutes,
    foundation: {
      schemaOk: schemaReport.ok,
      validSheets: schemaReport.sheets.filter(function(s) { return s.ok; }).length,
      expectedSheets: TWB_SHEET_ORDER.length
    },
    featureFlags: {
      appShell: true,
      executiveDashboard: true,
      businessHealth: true,
      productEngine: true,
      recipeEngine: true,
      recipeScaling: true,
      basicCogs: true,
      customerEngine: true,
      orderEngine: true,
      invoiceEngine: true,
      paymentEngine: true,
      whatsappInvoiceLink: true,
      financeTransactionLedger: true,
      productionEngine: true,
      productionPlanning: true,
      materialRequirementSnapshot: true,
      inventoryEngine: true,
      inventoryMovementLedger: true,
      inventoryAdjustment: true,
      productionInventoryUsage: true,
      purchasingEngine: true,
      supplierEngine: true,
      purchaseReceiving: true,
      purchasePriceHistory: true,
      preorderEngine: true,
      preorderCapacityLock: true,
      preorderAntiOversell: true,
      expenseEngine: true,
      managerialPnl: true,
      productProfitability: true,
      channelProfitability: true,
      historicalCogsSnapshot: true,
      customerIntelligence: true,
      rfmStyleSegmentation: true,
      customerProfiles: true,
      dormantSignals: true,
      customerPrivacyMasking: true,
      marketingEngine: true,
      marketingAttribution: true,
      marketingSpendLink: true,
      marketingRoas: true,
      marketingCacStyle: true,
      reportsEngine: true,
      dailyMetricsCache: true,
      monthlyMetricsCache: true,
      businessTargets: true,
      csvExport: true,
      settingsEngine: true,
      settingsGovernance: true,
      userAdministration: true,
      configurableWhatsAppTemplate: true,
      systemDiagnostics: true,
      systemIntegrityChecks: true,
      databaseBackups: true,
      scheduledMaintenance: true,
      configReadCache: true,
      optimizedFullSheetReads: true,
      productionReleaseGate: true,
      releasePreflight: true,
      releaseBackup: true,
      releaseRollbackPlan: true
    }
  };
}

function routeVisibleToUser_(route, user) {
  const rolePermissions = TWB_ROLE_PERMISSIONS[user.role] || [];
  if (rolePermissions.indexOf('*') >= 0) return true;
  return (route.anyPermissions || []).some(function(permission) {
    return rolePermissions.indexOf(permission) >= 0;
  });
}

function getAppPing_() {
  const user = requireCurrentUser_();
  return {
    appVersion: TWB_APP.APP_VERSION,
    schemaVersion: TWB_APP.SCHEMA_VERSION,
    userId: user.user_id,
    now: nowIso_()
  };
}
