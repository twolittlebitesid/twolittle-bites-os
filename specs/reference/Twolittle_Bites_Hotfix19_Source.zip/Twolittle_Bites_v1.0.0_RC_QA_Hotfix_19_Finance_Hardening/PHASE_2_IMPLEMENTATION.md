# PHASE_2_IMPLEMENTATION.md
# Twolittle.bites OS — App Shell

**App version:** 0.2.0  
**Schema version:** 1.0.0 (unchanged)  
**Phase:** 2  
**Status:** Ready to install

---

## Scope

Phase 2 turns the Google Stitch visual baseline into a real Google Apps Script web application shell.

Implemented:

- `doGet()` HTML Service entry point
- responsive app shell
- Phase 1 authenticated bootstrap
- role-aware navigation
- desktop primary navigation + More menu
- mobile navigation drawer
- hash router
- single `google.script.run` API wrapper
- normalized RPC success/error envelope
- loading state
- fatal error state
- toast notifications
- contextual/floating quick action shell
- responsive module pages
- system readiness values from the real database
- Phase 2 health check
- Phase 2 smoke test

Not implemented intentionally:

- create order
- product/recipe CRUD
- real business KPI dashboard
- inventory transactions
- invoice/payment logic
- production logic

Those remain disabled rather than being simulated with fake business data.

---

## Important

This package is a **complete runtime package**. It includes the Phase 1 `.gs` files plus Phase 2 files.

When adding it to the same Apps Script project:

1. Keep the existing Phase 1 files.
2. Replace `Constants.gs` with this version.
3. Add the new `.gs` and `.html` files.
4. `appsscript.json` remains compatible.
5. Do **not** upload `phase2_manifest.json` to Apps Script.

---

## New server files

```text
WebApp.gs
AppShellService.gs
ApiGateway.gs
Phase2HealthCheck.gs
```

## New HTML files

```text
Index.html

StylesTokens.html
StylesBase.html
StylesComponents.html
StylesResponsive.html

ComponentHeader.html
ComponentQuickActions.html
ComponentToast.html

PageExecutive.html
PageOrders.html
PageProducts.html
PageProduction.html
PageInventory.html
PageFinance.html
PageBusiness.html
PageCustomers.html
PagePurchasing.html
PageMarketing.html
PageReports.html
PageSettings.html

JsApiClient.html
JsRouter.html
JsApp.html
```

---

## Install / Upgrade

### 1. Add files

Add all new Phase 2 files to the Apps Script project.

Replace:
```text
Constants.gs
```

with the Phase 2 version so:

```text
PHASE = 2
APP_VERSION = 0.2.0
SCHEMA_VERSION = 1.0.0
```

No database migration is required.

### 2. Run health check

Run from Apps Script editor:

```javascript
runPhase2HealthCheck()
```

Expected:

```text
ok: true
phase: 2
APP_BOOTSTRAP: true
HTML_PARTIALS: true
INDEX_TEMPLATE: true
```

### 3. Run smoke test

```javascript
runPhase2SmokeTest()
```

Expected:

```text
ok: true
```

### 4. Deploy as Web App

Apps Script:

```text
Deploy
→ New deployment
→ Web app
```

Recommended during development:

```text
Execute as: User accessing the web app
Who has access: only intended Google accounts / domain users
```

The exact deployment options depend on the Google account/workspace environment.

### 5. Open deployment URL

The signed-in Google email must already exist as an ACTIVE row in `USERS`.

---

## Router

Routes:

```text
#executive
#orders
#products
#production
#inventory
#finance
#business
#customers
#purchasing
#marketing
#reports
#settings
```

Navigation visibility comes from backend role permissions.

---

## RPC Contract

Frontend:

```javascript
TWB.api.call('app.bootstrap', {})
TWB.api.call('app.ping', {})
```

Server:

```javascript
apiCall(action, payload)
```

Envelope:

```json
{
  "ok": true,
  "data": {},
  "meta": {
    "requestId": "...",
    "durationMs": 12,
    "appVersion": "0.2.0"
  }
}
```

---

## Design normalization

The Stitch prototype is used as the visual baseline but not copied as a fixed 1280×2399 canvas.

Phase 2 uses:

- warm cream/light application canvas
- terracotta as primary brand/action
- soft pink as supporting surface
- responsive cards
- Gaegu headlines
- Poppins body/interface text
- healthy/attention/critical semantic status colors

No Tailwind CDN is required by the production shell.

---

## Exit criteria

Phase 2 passes when:

- app opens as Web App;
- authenticated user is resolved;
- navigation reflects role;
- every visible route renders;
- mobile drawer works;
- desktop navigation works;
- API bootstrap works;
- errors are surfaced;
- no fake operational KPI is presented;
- `runPhase2HealthCheck()` passes;
- `runPhase2SmokeTest()` passes.

Next: **Phase 3 — Product & Recipe Engine**.
