# CONVENTIONS.md
# Twolittle.bites OS — Naming, IDs, Data & Status Conventions

**Version:** P0.1  
**Status:** Frozen

---

## 1. Naming Conventions

### Google Sheet names
`UPPER_SNAKE_CASE`

Examples:
```text
ORDER_ITEMS
INVENTORY_MOVEMENTS
PRODUCTION_BATCHES
```

### Column names
`lower_snake_case`

Examples:
```text
order_id
grand_total
updated_at
```

### Apps Script files
`PascalCase` by responsibility.

```text
OrderService.gs
RecipeService.gs
Database.gs
```

### JavaScript functions
`camelCase`

```text
createOrder()
calculateRecipeScaling()
recordPayment()
```

### Constants
`UPPER_SNAKE_CASE`

```text
ORDER_STATUS
DEFAULT_TIMEZONE
MAX_PAGE_SIZE
```

### UI routes
`kebab-case`

```text
executive
orders
pre-orders
products
recipe-calculator
production
inventory
finance
settings
```

---

## 2. ID Convention

IDs are generated server-side and never based on Google Sheet row numbers.

| Entity | Prefix | Example |
| --- | --- | --- |
| User | USR | USR-000001 |
| Customer | CUS | CUS-000001 |
| Product | PRD | PRD-000001 |
| Variant | VAR | VAR-000001 |
| Recipe | RCP | RCP-000001 |
| Recipe Item | RCI | RCI-000001 |
| Ingredient | ING | ING-000001 |
| Packaging | PKG | PKG-000001 |
| Unit Conversion | UCV | UCV-000001 |
| Pre-Order Campaign | PRE | PRE-202610-000001 |
| Order | ORD | ORD-202610-000001 |
| Order Item | ORI | ORI-000001 |
| Invoice | INV | INV-202610-000001 |
| Payment | PAY | PAY-202610-000001 |
| Production Plan | PPL | PPL-202610-000001 |
| Production Plan Item | PPI | PPI-000001 |
| Production Requirement | REQ | REQ-000001 |
| Production Batch | BAT | BAT-202610-000001 |
| Inventory Row | STK | STK-000001 |
| Inventory Movement | MOV | MOV-202610-000001 |
| Supplier | SUP | SUP-000001 |
| Purchase | PUR | PUR-202610-000001 |
| Purchase Item | PUI | PUI-000001 |
| Expense | EXP | EXP-202610-000001 |
| Transaction | TRX | TRX-202610-000001 |
| Business Target | TGT | TGT-000001 |
| Marketing Campaign | MKT | MKT-202610-000001 |
| Content | CNT | CNT-000001 |
| Activity Log | LOG | LOG-202610-000001 |

### ID generation

Month-scoped operational IDs:
```text
PREFIX-YYYYMM-000001
```

Master IDs:
```text
PREFIX-000001
```

ID generation must run under `LockService`.

`PRE` is reserved for **Pre-Order Campaign**.  
`PUR` is reserved for **Purchase**.  
This avoids ambiguity of `PO`.

---

## 3. Date / Time

Application timezone:
```text
Asia/Jakarta
```

Storage:

```text
date      → YYYY-MM-DD
time      → HH:mm
datetime  → ISO 8601
```

Examples:
```text
2026-10-03
17:00
2026-10-03T17:00:00+07:00
```

---

## 4. Money

All user-facing business currency:
```text
IDR
```

Storage:
```text
integer Rupiah
```

Example:
```text
Rp 45.000 → 45000
```

Do not store formatted currency strings in numeric source fields.

---

## 5. Quantity

For aggregation, normalize to base unit:

```text
Weight → g
Volume → ml
Count  → pcs
```

Keep entered unit where useful for display/audit.

Do not aggregate `kg + g` before normalization.

---

## 6. Phone / WhatsApp

Canonical format:
```text
628xxxxxxxxxx
```

Rules:
- strip spaces;
- strip `+`;
- `08...` normalized to `628...`;
- do not use phone formatting as display value in database.

---

## 7. Status Machine Values

Storage uses stable uppercase machine values. UI may show friendly labels.

| Domain | Machine Value | UI Label | Semantic Color |
| --- | --- | --- | --- |
| ORDER_STATUS | DRAFT | Draft | neutral |
| ORDER_STATUS | WAITING_PAYMENT | Waiting Payment | attention |
| ORDER_STATUS | CONFIRMED | Confirmed | healthy |
| ORDER_STATUS | SCHEDULED | Scheduled | neutral |
| ORDER_STATUS | IN_PRODUCTION | In Production | production |
| ORDER_STATUS | READY | Ready | healthy |
| ORDER_STATUS | ON_DELIVERY | On Delivery | neutral |
| ORDER_STATUS | COMPLETED | Completed | healthy |
| ORDER_STATUS | CANCELLED | Cancelled | critical |
| PAYMENT_STATUS | UNPAID | Unpaid | attention |
| PAYMENT_STATUS | WAITING_PAYMENT | Waiting Payment | attention |
| PAYMENT_STATUS | PARTIAL | Partial | attention |
| PAYMENT_STATUS | PAID | Paid | healthy |
| PAYMENT_STATUS | REFUNDED | Refunded | neutral |
| PAYMENT_STATUS | FAILED | Failed | critical |
| INVOICE_STATUS | DRAFT | Draft | neutral |
| INVOICE_STATUS | SENT | Sent | neutral |
| INVOICE_STATUS | WAITING_PAYMENT | Waiting Payment | attention |
| INVOICE_STATUS | PARTIAL | Partial | attention |
| INVOICE_STATUS | PAID | Paid | healthy |
| INVOICE_STATUS | OVERDUE | Overdue | critical |
| INVOICE_STATUS | CANCELLED | Cancelled | critical |
| INVOICE_STATUS | REFUNDED | Refunded | neutral |
| PREORDER_STATUS | DRAFT | Draft | neutral |
| PREORDER_STATUS | OPEN | Open | healthy |
| PREORDER_STATUS | ALMOST_FULL | Almost Full | attention |
| PREORDER_STATUS | FULL | Full | critical |
| PREORDER_STATUS | CLOSED | Closed | neutral |
| PREORDER_STATUS | COMPLETED | Completed | healthy |
| PREORDER_STATUS | CANCELLED | Cancelled | critical |
| FULFILLMENT_STATUS | WAITING | Waiting | neutral |
| FULFILLMENT_STATUS | COURIER_BOOKED | Courier Booked | neutral |
| FULFILLMENT_STATUS | READY | Ready | healthy |
| FULFILLMENT_STATUS | ON_DELIVERY | On Delivery | neutral |
| FULFILLMENT_STATUS | DELIVERED | Delivered | healthy |
| FULFILLMENT_STATUS | PICKED_UP | Picked Up | healthy |
| REQUIREMENT_STATUS | SUFFICIENT | Sufficient | healthy |
| REQUIREMENT_STATUS | LOW | Low | attention |
| REQUIREMENT_STATUS | SHORTAGE | Shortage | critical |

---

## 8. Additional Statuses

### Product
```text
ACTIVE
INACTIVE
SEASONAL
ARCHIVED
```

### Recipe
```text
DRAFT
ACTIVE
INACTIVE
ARCHIVED
```

### Production Plan
```text
DRAFT
READY
IN_PROGRESS
COMPLETED
CANCELLED
```

### Production Plan Item
```text
PLANNED
READY
IN_PROGRESS
COMPLETED
CANCELLED
```

### Production Batch
```text
PLANNED
IN_PROGRESS
COMPLETED
CANCELLED
```

### Purchase
```text
DRAFT
ORDERED
PARTIAL_RECEIVED
RECEIVED
CANCELLED
```

### Payment event
```text
PENDING
VERIFIED
FAILED
REFUNDED
```

### User
```text
ACTIVE
INACTIVE
```

---

## 9. Semantic Color Contract

```text
healthy    #2E7D32
attention  #E65100
critical   #C62828
production #9E3B26 on #FDD3D7
neutral    surface/secondary token
```

Color is presentation only. Business logic must evaluate machine status, never color.

---

## 10. Boolean / Null

Boolean:
```text
TRUE / FALSE
```

Unknown/not applicable:
```text
blank
```

Do not use mixed values such as:
```text
"-"
"N/A"
"none"
```
inside typed source columns.

---

## 11. Soft Delete / Archive

Preferred:
```text
status = ARCHIVED
```

Critical operational entities use cancellation/refund/reversal, not delete.

---

## 12. JSON Fields

Only use JSON for:
- audit before/after snapshots;
- flexible configuration values;
- metadata that is not queried as a primary business dimension.

Do not hide relational business data inside JSON.

---

## 13. Calculation Precision

Recipe quantity:
- use numeric decimal;
- keep calculation precision internally;
- apply display rounding only at UI layer when appropriate.

Money:
- final posted values integer Rupiah.

Percentage:
```text
58.8 means 58.8%
```

---

## 14. Status Transition Principle

A status transition must:
1. validate current status;
2. validate target status;
3. validate role permission;
4. perform related side effects;
5. write Activity Log.

Do not allow arbitrary dropdown changes on critical workflow rows from the UI.
