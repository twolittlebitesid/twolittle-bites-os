/**
 * Twolittle.bites OS — QA Hotfix 08
 * Google Drive PDF archive for public invoices.
 */

function invoicePdfResolveInvoice_(
  identifier
) {
  var key =
    String(
      identifier || ''
    ).trim();

  if (!key) {
    return null;
  }

  var invoice =
    dbFindById(
      'INVOICES',
      key
    );

  if (!invoice) {
    invoice =
      dbFindOne(
        'INVOICES',
        'invoice_number',
        key
      );
  }

  return invoice;
}

function invoicePdfArchivePropertyKey_(invoiceId) {
  return (
    'TWB_INVOICE_PDF_V1_' +
    String(invoiceId || '')
      .replace(/[^A-Za-z0-9_-]/g, '_')
  );
}

function invoicePdfFolderPropertyKey_(scope) {
  return (
    'TWB_INVOICE_PDF_FOLDER_' +
    String(scope || '')
      .replace(/[^A-Za-z0-9_-]/g, '_')
      .toUpperCase()
  );
}

function invoicePdfPublicViewUrl_(
  fileId,
  resourceKey
) {
  if (!fileId) {
    return '';
  }

  var url =
    'https://drive.google.com/file/d/' +
    encodeURIComponent(fileId) +
    '/view';

  if (resourceKey) {
    url +=
      '?resourcekey=' +
      encodeURIComponent(
        resourceKey
      );
  }

  return url;
}

function invoicePdfPublicDownloadUrl_(
  fileId,
  resourceKey
) {
  if (!fileId) {
    return '';
  }

  var url =
    'https://drive.google.com/uc?export=download&id=' +
    encodeURIComponent(fileId);

  if (resourceKey) {
    url +=
      '&resourcekey=' +
      encodeURIComponent(
        resourceKey
      );
  }

  return url;
}

function getInvoicePdfArchiveInfo_(invoiceId) {
  var raw =
    PropertiesService
      .getScriptProperties()
      .getProperty(
        invoicePdfArchivePropertyKey_(
          invoiceId
        )
      );

  if (!raw) {
    return null;
  }

  try {
    var info =
      JSON.parse(raw);

    if (
      !info ||
      !info.fileId
    ) {
      return null;
    }

    info.viewUrl =
      info.viewUrl ||
      invoicePdfPublicViewUrl_(
        info.fileId,
        info.resourceKey || ''
      );

    info.downloadUrl =
      info.downloadUrl ||
      invoicePdfPublicDownloadUrl_(
        info.fileId,
        info.resourceKey || ''
      );

    return info;
  } catch (e) {
    return null;
  }
}

function invoicePdfExistingFolder_(
  propertyKey
) {
  var props =
    PropertiesService
      .getScriptProperties();

  var id =
    props.getProperty(
      propertyKey
    );

  if (!id) {
    return null;
  }

  try {
    var folder =
      DriveApp.getFolderById(
        id
      );

    if (
      typeof folder.isTrashed ===
        'function' &&
      folder.isTrashed()
    ) {
      return null;
    }

    return folder;
  } catch (e) {
    return null;
  }
}

function invoicePdfFirstLiveFolder_(
  iterator
) {
  while (
    iterator &&
    iterator.hasNext()
  ) {
    var folder =
      iterator.next();

    try {
      if (
        typeof folder.isTrashed !==
          'function' ||
        !folder.isTrashed()
      ) {
        return folder;
      }
    } catch (ignore) {}
  }

  return null;
}

function invoicePdfRootFolder_() {
  var key =
    invoicePdfFolderPropertyKey_(
      'ROOT'
    );

  var existing =
    invoicePdfExistingFolder_(
      key
    );

  if (existing) {
    return existing;
  }

  var folder =
    invoicePdfFirstLiveFolder_(
      DriveApp.getFoldersByName(
        'Twolittle.bites OS'
      )
    );

  if (!folder) {
    folder =
      DriveApp.createFolder(
        'Twolittle.bites OS'
      );
  }

  PropertiesService
    .getScriptProperties()
    .setProperty(
      key,
      folder.getId()
    );

  return folder;
}

function invoicePdfChildFolder_(
  parent,
  propertyScope,
  folderName
) {
  var key =
    invoicePdfFolderPropertyKey_(
      propertyScope
    );

  var existing =
    invoicePdfExistingFolder_(
      key
    );

  if (existing) {
    return existing;
  }

  var folder =
    invoicePdfFirstLiveFolder_(
      parent.getFoldersByName(
        folderName
      )
    );

  if (!folder) {
    folder =
      parent.createFolder(
        folderName
      );
  }

  PropertiesService
    .getScriptProperties()
    .setProperty(
      key,
      folder.getId()
    );

  return folder;
}

function invoicePdfArchiveFolder_(
  invoice
) {
  var rawDate =
    String(
      invoice.invoice_date ||
      todayIso_()
    );

  var match =
    rawDate.match(
      /^(\d{4})-(\d{2})/
    );

  var year =
    match
      ? match[1]
      : Utilities.formatDate(
          new Date(),
          TWB_APP.TIMEZONE,
          'yyyy'
        );

  var month =
    match
      ? Number(match[2])
      : Number(
          Utilities.formatDate(
            new Date(),
            TWB_APP.TIMEZONE,
            'MM'
          )
        );

  var monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];

  var monthName =
    monthNames[
      Math.max(
        1,
        Math.min(
          12,
          month
        )
      ) - 1
    ];

  var root =
    invoicePdfRootFolder_();

  var invoices =
    invoicePdfChildFolder_(
      root,
      'INVOICES',
      'Invoices'
    );

  var yearFolder =
    invoicePdfChildFolder_(
      invoices,
      'YEAR_' + year,
      year
    );

  return invoicePdfChildFolder_(
    yearFolder,
    'MONTH_' +
      year +
      '_' +
      String(month).padStart(
        2,
        '0'
      ),
    String(month)
      .padStart(
        2,
        '0'
      ) +
      ' ' +
      monthName
  );
}

function invoicePdfFileName_(
  invoice
) {
  return (
    String(
      invoice.invoice_number ||
      invoice.invoice_id ||
      'invoice'
    )
      .replace(
        /[\\/:*?"<>|]+/g,
        '-'
      )
      .trim() +
    '.pdf'
  );
}

function buildInvoicePdfBlob_(
  invoice
) {
  var data =
    getPublicInvoiceDataByToken_(
      invoice.public_token
    );

  if (!data) {
    throw twbError_(
      'INVOICE_PDF_DATA_NOT_FOUND',
      'Public invoice data could not be built.'
    );
  }

  data.pdfViewUrl = '';
  data.pdfDownloadUrl = '';
  data.isPdfRender = true;

  var template =
    HtmlService
      .createTemplateFromFile(
        'PublicInvoice'
      );

  template.invoice =
    data;

  var html =
    template
      .evaluate()
      .getContent();

  var htmlBlob =
    Utilities.newBlob(
      html,
      'text/html',
      String(
        invoice.invoice_number ||
        invoice.invoice_id
      ) + '.html'
    );

  return htmlBlob
    .getAs(
      'application/pdf'
    )
    .setName(
      invoicePdfFileName_(
        invoice
      )
    );
}

function generateInvoicePdfArchive_(
  invoiceId,
  source
) {
  var invoice =
    invoicePdfResolveInvoice_(
      invoiceId
    );

  if (!invoice) {
    throw twbError_(
      'NOT_FOUND',
      'Invoice not found: ' +
        invoiceId
    );
  }

  invoiceId =
    invoice.invoice_id;

  var previous =
    getInvoicePdfArchiveInfo_(
      invoiceId
    );

  var folder =
    invoicePdfArchiveFolder_(
      invoice
    );

  var blob =
    buildInvoicePdfBlob_(
      invoice
    );

  var file =
    folder.createFile(
      blob
    );

  try {
    file.setSharing(
      DriveApp.Access
        .ANYONE_WITH_LINK,
      DriveApp.Permission
        .VIEW
    );
  } catch (sharingError) {
    try {
      file.setTrashed(
        true
      );
    } catch (ignoreTrash) {}

    throw twbError_(
      'INVOICE_PDF_PUBLIC_SHARE_FAILED',
      'PDF was generated, but Google Drive did not allow public link sharing. Check Drive sharing policy.',
      {
        invoiceId:
          invoiceId,
        cause:
          String(
            sharingError &&
            sharingError.message
              ? sharingError.message
              : sharingError
          )
      }
    );
  }

  var resourceKey = '';

  try {
    if (
      typeof file.getResourceKey ===
        'function'
    ) {
      resourceKey =
        file.getResourceKey() ||
        '';
    }
  } catch (ignoreResourceKey) {}

  var info = {
    invoiceId:
      invoiceId,
    invoiceNumber:
      invoice.invoice_number,
    fileId:
      file.getId(),
    resourceKey:
      resourceKey,
    fileName:
      file.getName(),
    folderId:
      folder.getId(),
    viewUrl:
      invoicePdfPublicViewUrl_(
        file.getId(),
        resourceKey
      ),
    downloadUrl:
      invoicePdfPublicDownloadUrl_(
        file.getId(),
        resourceKey
      ),
    generatedAt:
      nowIso_(),
    source:
      String(
        source ||
        'MANUAL'
      ),
    publicAccess:
      'ANYONE_WITH_LINK'
  };

  PropertiesService
    .getScriptProperties()
    .setProperty(
      invoicePdfArchivePropertyKey_(
        invoiceId
      ),
      JSON.stringify(
        info
      )
    );

  if (
    previous &&
    previous.fileId &&
    previous.fileId !==
      info.fileId
  ) {
    try {
      DriveApp
        .getFileById(
          previous.fileId
        )
        .setTrashed(
          true
        );
    } catch (ignoreOldFile) {}
  }

  return info;
}

function syncInvoicePdfArchiveSafely_(
  invoiceId,
  source
) {
  try {
    return generateInvoicePdfArchive_(
      invoiceId,
      source
    );
  } catch (e) {
    if (
      typeof recordSystemError_ ===
        'function'
    ) {
      recordSystemError_({
        action:
          'INVOICE_PDF_SYNC',
        code:
          e.code ||
          'INVOICE_PDF_SYNC_FAILED',
        message:
          e.message ||
          String(e),
        stack:
          e.stack ||
          '',
        requestId:
          String(
            invoiceId ||
            ''
          )
      });
    }

    return null;
  }
}

function regenerateInvoicePdf(
  invoiceId
) {
  requirePermission_(
    'INVOICE_WRITE'
  );

  return generateInvoicePdfArchive_(
    invoiceId,
    'MANUAL_REGENERATE'
  );
}

function getInvoicePdfArchive(
  invoiceId
) {
  requirePermission_(
    'INVOICE_READ'
  );

  var invoice =
    invoicePdfResolveInvoice_(
      invoiceId
    );

  return invoice
    ? getInvoicePdfArchiveInfo_(
        invoice.invoice_id
      )
    : null;
}

function runQAHotfix08PdfSmoke(
  invoiceId
) {
  requirePermission_(
    'INVOICE_WRITE'
  );

  var info =
    generateInvoicePdfArchive_(
      invoiceId,
      'QA_HOTFIX_08_SMOKE'
    );

  return {
    ok:
      !!(
        info &&
        info.fileId &&
        info.downloadUrl
      ),
    invoiceId:
      invoiceId,
    fileId:
      info
        ? info.fileId
        : '',
    viewUrl:
      info
        ? info.viewUrl
        : '',
    downloadUrl:
      info
        ? info.downloadUrl
        : '',
    publicAccess:
      info
        ? info.publicAccess
        : ''
  };
}
