/**
 * Twolittle.bites OS — Phase 14 upgrade.
 */
function upgradeToPhase14() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER
    ]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'SETTINGS_GOVERNANCE_MODE',
    'WHITELISTED_FIELDS_ONLY',
    'STRING',
    'Settings UI only exposes explicitly whitelisted configuration fields.',
    user.user_id
  );

  setConfig_(
    'USER_ADMIN_MODE',
    'OWNER_ONLY',
    'STRING',
    'Application user and role administration is restricted to OWNER.',
    user.user_id
  );

  setConfig_(
    'USER_DELETE_MODE',
    'DEACTIVATE_ONLY',
    'STRING',
    'Application users are deactivated rather than deleted.',
    user.user_id
  );

  if (
    !getBusinessSetting_(
      'invoice_whatsapp_template'
    )
  ) {
    setBusinessSetting_(
      'invoice_whatsapp_template',
      settingsDefaultInvoiceWhatsAppTemplate_(),
      'STRING',
      'WHATSAPP',
      'Invoice WhatsApp deep-link message template.',
      user.user_id
    );
  }

  var configuredMethods =
    getConfig_(
      'PAYMENT_METHODS'
    );

  if (
    Array.isArray(
      configuredMethods
    ) &&
    configuredMethods.length
  ) {
    setBusinessSetting_(
      'payment_methods',
      configuredMethods,
      'JSON',
      'PAYMENT',
      'Available payment methods.',
      user.user_id
    );
  }

  return runPhase14HealthCheck();
}
