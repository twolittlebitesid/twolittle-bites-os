# QA Hotfix 15 — Localhost Hybrid Runtime Foundation

## Goal

Run the internal Twolittle.bites OS frontend from:

```text
http://127.0.0.1:5173
```

while keeping the existing Apps Script services, Google Sheets database, Google Drive invoice/PDF system, permissions, IDs, payments, inventory movements, and finance logic authoritative in the cloud.

This is a **hybrid local runtime**, not a second database.

## Architecture

```text
Local browser
http://127.0.0.1:5173
        │
        ├─ static UI served locally
        ├─ route cache
        ├─ search / filter locally
        ├─ IndexedDB read cache
        │
        └─ POST /api
             ↓
        local Node proxy
        signs request with HMAC-SHA256
             ↓ HTTPS
        Apps Script doPost()
             ↓
        signed bridge validation
             ↓
        actor mapped to existing USERS record
             ↓
        existing API Gateway / Services
             ↓
        Google Sheets + Drive
```

## Why the local proxy exists

The browser does not call Apps Script directly. Direct localhost → Apps Script requests create cross-origin/authentication problems and would require exposing credentials to browser JavaScript.

The default zero-dependency Node server therefore acts as a local-only proxy on `127.0.0.1`. An optional Vite development configuration is included for live development.

The shared bridge secret is stored only in:

```text
Apps Script Script Properties
.env.local on the trusted computer
```

It is never embedded in `index.html` or browser JavaScript.

## Signed request protection

Each local proxy request contains:

```text
actor email
request timestamp
one-time nonce
action
base64 JSON payload
HMAC-SHA256 signature
```

Apps Script validates:

- localhost bridge enabled;
- actor exactly matches the actor bound to the bridge secret;
- actor is still an ACTIVE record in USERS;
- timestamp is within 5 minutes;
- nonce has not already been used;
- HMAC signature matches.

The request then runs through the **existing permission matrix** using the configured actor.

## Authentication hardening

`Auth.gs` no longer falls back from `Session.getActiveUser()` to `Session.getEffectiveUser()` for application requests.

This is important when a deployment accepts public requests: an anonymous visitor must never be interpreted as the script owner merely because the web app executes as the owner.

The trusted localhost bridge is the only alternative identity path and must pass HMAC validation first.

## Local data cache

Selected read actions are stored in IndexedDB:

```text
twolittle_bites_local_v1
└─ api_cache
```

The strategy is:

```text
Cached read exists
→ return immediately
→ render quickly
→ refresh from cloud in background
→ replace cache with fresh response
```

The header status shows:

```text
Local · Synced
Local · Cached
Local · Syncing…
Local · Offline
Local · Sync issue
```

Examples of cached read modules:

- App bootstrap
- Products
- Customers / customer profile
- Orders / order detail
- Finance / invoice detail
- Inventory
- Production
- Purchasing
- Marketing
- Business
- Executive
- Reports
- Settings
- Recipe detail / scale

Large image-resolver payloads are intentionally not persisted to the API cache.

## Writes remain authoritative

This hotfix does **not** queue financial or stock mutations offline.

Actions such as:

```text
Order create/update status
Invoice creation
Payment / refund
Inventory movement
Production completion
Purchase receiving
Expense creation
Settings writes
```

still require a successful cloud response before the UI treats them as completed.

After a real mutation succeeds, local read cache is cleared so old server data cannot silently survive a write.

Non-mutating uncached calls such as image resolution no longer clear the entire cache.

## Printing

Hotfix 14 browser thermal printing remains supported.

Public Receipt stays cloud-based.

For Localhost mode, Kitchen Ticket is rendered through:

```text
/kitchen.html?invoice_id=...
```

and loads its data through the signed local API. This avoids exposing `production_notes` through an anonymous public GET route.

## Localhost package

A separate package is provided:

```text
Twolittle_Bites_Localhost_v1.0.0.zip
```

It contains:

```text
index.html
kitchen.html
server.mjs
vite.config.mjs
package.json
.env.example
README_LOCALHOST.md
start-localhost.command
start-localhost.sh
start-localhost.bat
```

## Setup

### 1. Apply Hotfix 15 to Apps Script

Save the changed/new `.gs` and `.html` files and deploy a new Apps Script Web App version.

### 2. Create/rotate local bridge

Run as OWNER:

```javascript
setupLocalhostBridge()
```

Copy the returned:

```text
actorEmail
localApiSecret
webAppUrl
```

The secret is intentionally shown only by setup/rotation, not by status calls.

### 3. Self-test inside Apps Script

```javascript
runQAHotfix15LocalBridgeSelfTest()
```

Expected:

```text
ok = true
bridgeEnabled = true
action = app.ping
```

### 4. Configure localhost package

Copy:

```text
.env.example
```

to:

```text
.env.local
```

and fill the three values returned by `setupLocalhostBridge()`.

### 5. Run locally

Default runtime (Node 18+, no dependency install):

```bash
npm start
```

Optional Vite development mode:

```bash
npm install
npm run dev
```

Open:

```text
http://127.0.0.1:5173
```

Verify:

```text
http://127.0.0.1:5173/local-health
```

## Deployment access requirement

The local Node/Vite proxy is not an interactive browser session. The Apps Script deployment used in `TWB_APPS_SCRIPT_URL` therefore has to accept the proxy request without redirecting to an interactive Google login screen.

The `doPost()` API is separately protected by the HMAC bridge.

If organization policy prevents that deployment mode, this package will report `LOCAL_BACKEND_RESPONSE_INVALID`; an OAuth-based local proxy would be required instead.

## Disable localhost access

Run as OWNER:

```javascript
disableLocalhostBridge()
```

This deletes the shared secret and disables signed local API requests.

## No data/schema migration

- App version: 1.0.0
- Schema version: 1.0.0
- Sheets: unchanged 33/33
- Data rewrite: none
