# PHASE_12_QA.md

Static QA:

- Server `.gs` syntax: PASS
- Client `Js*.html` syntax: PASS
- HTML include references: PASS
- Existing Marketing/Order/Expense schema compatibility: PASS
- Marketing API actions: PASS
- ACTIVITY_LOG attribution/spend ledger: PASS
- ADMIN Marketing permissions: PASS
- RPC client-safe bridge retained: PASS
- Previous validation cleanup: PASS
- Schema migration required: NO
- App Version: 0.12.0
- Schema Version: 1.0.0

Marketing safeguards:
- attribution model is explicitly MANUAL_LAST_TOUCH
- no claim of causal incrementality
- cancelled Orders cannot be attributed
- cancelled Campaign cannot receive new attribution
- optional Content must belong to selected Campaign
- latest SET/CLEAR log determines active Order attribution
- marketing Spend uses Finance Expense source of truth
- VOID Expenses are excluded from live campaign spend
- attributed revenue only from COMPLETED Orders
- tax excluded from attributed operating revenue
- new customer uses first non-cancelled Order
- zero spend does not produce infinite ROAS
- zero new customers does not produce invalid CAC
- source_channel remains separate from Campaign attribution
- no separate attribution table
