# PHASE_13_QA.md

Static QA:

- Server `.gs` syntax: PASS
- Client `Js*.html` syntax: PASS
- HTML include references: PASS
- Existing Target / Daily / Monthly schema compatibility: PASS
- Report API actions: PASS
- Rebuildable metrics cache implementation: PASS
- Role-aware report scopes: PASS
- RPC client-safe bridge retained: PASS
- Previous validation cleanup: PASS
- Schema migration required: NO
- App Version: 0.13.0
- Schema Version: 1.0.0

Report safeguards:
- source tables remain authoritative
- cache rebuild does not mutate operational history
- cancelled Orders excluded from demand metrics
- completed revenue uses fulfillment date fallback order date
- operating revenue excludes tax
- COGS transaction excluded from cash movement
- VOID expenses excluded
- marketing spend derived from active linked Expenses
- cancelled Production Plans excluded
- weekly aggregation starts Monday
- monthly ratios are recalculated, not summed
- Report access is role-aware
- CSV exports enforce report scope
- Health/Smoke do not rebuild caches or create targets
