# OPERATOR_GUIDE.md
# Twolittle.bites OS v1.0

## Daily operating flow

```text
Customer
→ Order / Pre-Order
→ Invoice
→ Payment
→ Confirmed Order
→ Production Plan
→ Ingredient Requirement
→ Inventory
→ Purchasing if needed
→ Production
→ Fulfillment
→ Completed Order
→ Finance / CRM / Marketing / Reports
```

## What is authoritative

```text
Orders
→ operational order state

Payments
→ payment events

Transactions
→ finance cash / managerial transaction ledger

Inventory Movements
→ inventory source of truth

Production Requirement snapshots
→ historical production requirements

Order Item snapshots
→ historical item/pricing snapshot

Activity Log
→ audit + Phase 12 attribution link history
```

Do not manually edit cached/derived fields when an operational workflow exists.

## Daily checks

Recommended:
- waiting-payment Orders;
- today's production plan;
- inventory shortage/low stock;
- purchasing receipts;
- unpaid/partial invoices;
- completed Orders;
- cash/expense entry.

## Weekly checks

- Production shortages and waste.
- Repeat-customer rate.
- Campaign attribution coverage.
- Expenses.
- Report trends.
- Diagnostics recent errors.

## Monthly checks

- P&L.
- Gross margin.
- Operating profit.
- Marketing ROAS/CAC-style metric.
- CRM segments.
- Target vs Actual.
- MONTHLY_METRICS freshness.
- Backup availability.

## Settings governance

OWNER:
- system owner;
- user/role changes;
- backups/recovery;
- release actions.

ADMIN:
- operating settings;
- diagnostics.

PRODUCTION:
- production/inventory operations.

MARKETING:
- marketing/CRM-limited workflows.

FINANCE:
- finance/report workflows;
- Settings read-only.

## Backup

Manual:

```text
Settings → Diagnostics → Backup Now
```

Automated:
- daily maintenance trigger, if configured.

Backup is an exact Google Spreadsheet copy.

## Recovery

Never overwrite the production spreadsheet casually.

Use:

```text
Recovery Copy
```

to inspect a backup in a separate Spreadsheet first.

## Errors

If UI shows “Server request failed”:
1. open Settings → Diagnostics;
2. inspect Recent Server Errors;
3. run Regression;
4. run Integrity diagnostics;
5. do not alter Sheets manually before understanding the failed workflow.

## Release / rollback

Release state is visible under:

```text
Settings → Release
```

If production becomes unsafe:

```text
Rollback Required
```

then follow `ROLLBACK_PLAN.md`.
