# PHASE_4_IMPLEMENTATION.md
# Twolittle.bites OS — Order Engine

**Phase:** 4  
**App Version:** 0.4.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

---

## Activated in Phase 4

### Customer Foundation
- create customer
- normalize WhatsApp number
- duplicate candidate prevention by WhatsApp
- customer directory
- completed-order metrics:
  - total orders
  - total spend
  - AOV
  - first / last completed order
  - favorite product
  - NEW / REPEAT foundation

### Order Engine
- New Order form
- customer selection / inline customer creation
- product / variant selection
- quantity
- line discount
- production note
- order discount
- delivery fee
- tax
- order source
- fulfillment type/date/time/address
- price snapshot
- SKU/name snapshot
- order totals
- status machine
- cancellation reason
- order detail
- audit log

---

## Important source-of-truth decisions

### Product price snapshot

Order items store:
```text
product_name_snapshot
sku_snapshot
unit_price
line_discount
line_total
```

A future Product price change does not alter an existing order.

### Payment status

Phase 4 does not create payment transactions yet.

New orders use:
```text
payment_status = UNPAID
invoice_status = DRAFT
```

The dedicated Invoice / Payment engine will own these statuses in the next phase.

### Order status

Allowed flow:

```text
DRAFT
 ├─ WAITING_PAYMENT
 ├─ CONFIRMED
 └─ CANCELLED

WAITING_PAYMENT
 ├─ CONFIRMED
 └─ CANCELLED

CONFIRMED
 ├─ SCHEDULED
 ├─ IN_PRODUCTION
 └─ CANCELLED

SCHEDULED
 ├─ IN_PRODUCTION
 └─ CANCELLED

IN_PRODUCTION
 ├─ READY
 └─ CANCELLED

READY
 ├─ ON_DELIVERY
 ├─ COMPLETED
 └─ CANCELLED

ON_DELIVERY
 ├─ COMPLETED
 └─ CANCELLED

COMPLETED  → terminal
CANCELLED  → terminal
```

Completed order cannot be cancelled through Phase 4; it requires a refund/reversal flow later.

---

## Installation from Phase 3

Use `Twolittle_Bites_Phase_4_Delta.zip`.

### Replace
```text
Constants.gs
AppShellService.gs
ApiGateway.gs
Index.html
JsApp.html
PageOrders.html
PageCustomers.html
ComponentHeader.html
ComponentQuickActions.html
StylesComponents.html
StylesResponsive.html
```

### Add
```text
CustomerService.gs
OrderService.gs
JsOrders.html
JsCustomers.html
Phase4Setup.gs
Phase4HealthCheck.gs
Phase4SmokeTest.gs
```

Do not add `phase4_manifest.json` to Apps Script.

---

## One-time upgrade

Run:
```javascript
upgradeToPhase4()
```

It:
- validates the existing 33 sheets;
- changes CONFIG App Version to `0.4.0`;
- keeps Schema Version `1.0.0`;
- seeds `ORDER_DEFAULT_STATUS`;
- runs Phase 4 health check.

No sheet is recreated or cleared.

---

## Verify

```javascript
runPhase4HealthCheck()
runPhase4SmokeTest()
```

Expected overall:
```text
ok: true
phase: 4
appVersion: 0.4.0
schemaVersion: 1.0.0
```

---

## Recommended browser test

1. Update Web App deployment.
2. Open Customers.
3. Create a Customer.
4. Open Orders.
5. Create a New Order with your existing Product.
6. Check price snapshot and total.
7. Open order detail.
8. Move status forward.
9. Create another test order and cancel it with a reason.

No sample customer/order data is inserted automatically.
