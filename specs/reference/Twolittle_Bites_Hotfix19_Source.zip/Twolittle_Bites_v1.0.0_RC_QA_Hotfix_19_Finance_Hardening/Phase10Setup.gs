/**
 * Twolittle.bites OS — Phase 10 upgrade.
 */
function upgradeToPhase10() {
  var user =
    requireRole_([TWB_ROLES.OWNER]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'FINANCE_REVENUE_RECOGNITION',
    'COMPLETED_ORDER_FULFILLMENT_DATE',
    'STRING',
    'Managerial P&L recognizes completed orders using fulfillment date.',
    user.user_id
  );

  setConfig_(
    'FINANCE_COGS_SNAPSHOT_MODE',
    'ORDER_ITEM_TRANSACTION_ON_COMPLETION',
    'STRING',
    'Completed order items snapshot non-cash COGS into TRANSACTIONS.',
    user.user_id
  );

  setConfig_(
    'FINANCE_TAX_TREATMENT',
    'EXCLUDE_FROM_OPERATING_REVENUE',
    'STRING',
    'Tax collected is shown separately from operating revenue.',
    user.user_id
  );

  return runPhase10HealthCheck();
}
