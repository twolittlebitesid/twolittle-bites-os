/**
 * Twolittle.bites OS — Phase 8 upgrade.
 */
function upgradeToPhase8() {
  const user = requireRole_([TWB_ROLES.OWNER]);

  const schema = validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'PURCHASE_RECEIPT_INVENTORY_MODE',
    'MOVEMENT_LEDGER',
    'STRING',
    'Received purchases create PURCHASE_RECEIPT inventory movements.',
    user.user_id
  );

  setConfig_(
    'PURCHASE_PAYMENT_MODE',
    'TRACK_ONLY',
    'STRING',
    'Supplier payment workflow remains outside Phase 8.',
    user.user_id
  );

  return runPhase8HealthCheck();
}
