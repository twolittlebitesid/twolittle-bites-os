/**
 * Twolittle.bites OS — Phase 8 Purchasing Engine
 *
 * Flow:
 * shortage / reorder signal
 * → supplier
 * → purchase
 * → receiving
 * → PURCHASE_RECEIPT inventory movement
 * → latest/average material cost
 */

const TWB_PURCHASE_TRANSITIONS = Object.freeze({
  DRAFT: ['ORDERED', 'CANCELLED'],
  ORDERED: ['CANCELLED'],
  PARTIAL: [],
  RECEIVED: [],
  CANCELLED: []
});

function purchasingMaterialMaps_() {
  const ingredients = listAllRecords_('INGREDIENTS');
  const packaging = listAllRecords_('PACKAGING');

  const ingredientMap = {};
  const packagingMap = {};

  ingredients.forEach(function(row) {
    ingredientMap[row.ingredient_id] = row;
  });

  packaging.forEach(function(row) {
    packagingMap[row.packaging_id] = row;
  });

  return {
    ingredients: ingredients,
    packaging: packaging,
    ingredientMap: ingredientMap,
    packagingMap: packagingMap
  };
}

function supplierModuleRows_() {
  return listAllRecords_('SUPPLIERS')
    .map(stripInternalFields_)
    .sort(function(a, b) {
      return String(a.supplier_name || '').localeCompare(
        String(b.supplier_name || '')
      );
    });
}

function createSupplier(payload) {
  const user = requirePermission_('PURCHASE_WRITE');
  payload = payload || {};

  const name = normalizeText_(payload.supplier_name);
  if (!name) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Supplier name is required.'
    );
  }

  const record = stampCreate_(user, {
    supplier_id: nextBusinessId('SUPPLIER'),
    supplier_name: name,
    contact_person: normalizeText_(payload.contact_person),
    whatsapp: normalizeWhatsApp_(payload.whatsapp || ''),
    email: normalizeEmail_(payload.email || ''),
    address: normalizeText_(payload.address),
    lead_time_days: requireNonNegative_(
      payload.lead_time_days || 0,
      'lead_time_days'
    ),
    minimum_order_value: requireNonNegative_(
      payload.minimum_order_value || 0,
      'minimum_order_value'
    ),
    status: 'ACTIVE',
    notes: normalizeText_(payload.notes)
  });

  return dbInsertRecord(
    'SUPPLIERS',
    record,
    {
      validate: true,
      audit: true,
      action: 'CREATE'
    }
  );
}

function updateSupplier(supplierId, payload) {
  const user = requirePermission_('PURCHASE_WRITE');

  const current = dbFindById(
    'SUPPLIERS',
    supplierId
  );

  if (!current) {
    throw twbError_(
      'NOT_FOUND',
      'Supplier not found: ' + supplierId
    );
  }

  payload = payload || {};
  const patch = {};

  [
    'supplier_name',
    'contact_person',
    'address',
    'notes'
  ].forEach(function(field) {
    if (Object.prototype.hasOwnProperty.call(payload, field)) {
      patch[field] = normalizeText_(payload[field]);
    }
  });

  if (Object.prototype.hasOwnProperty.call(payload, 'whatsapp')) {
    patch.whatsapp = normalizeWhatsApp_(payload.whatsapp);
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'email')) {
    patch.email = normalizeEmail_(payload.email);
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'lead_time_days')) {
    patch.lead_time_days = requireNonNegative_(
      payload.lead_time_days,
      'lead_time_days'
    );
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'minimum_order_value')) {
    patch.minimum_order_value = requireNonNegative_(
      payload.minimum_order_value,
      'minimum_order_value'
    );
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'status')) {
    patch.status = String(payload.status || '').toUpperCase();
    assertOneOf_(
      patch.status,
      ['ACTIVE', 'INACTIVE', 'ARCHIVED'],
      'status'
    );
  }

  return dbUpdateById(
    'SUPPLIERS',
    supplierId,
    stampUpdate_(user, patch),
    {
      validate: true,
      audit: true,
      action: 'UPDATE'
    }
  );
}

function buildPurchasingShortageSuggestions_(
  plans,
  requirements,
  inventory,
  purchases,
  purchaseItems,
  movements,
  materialMaps
) {
  const planMap = {};
  const usagePosted = {};

  movements.forEach(function(movement) {
    if (
      String(movement.movement_type).toUpperCase() === 'PRODUCTION_USAGE' &&
      String(movement.reference_type).toUpperCase() === 'PRODUCTION_PLAN'
    ) {
      usagePosted[movement.reference_id] = true;
    }
  });

  plans.forEach(function(plan) {
    const status = String(plan.status || '').toUpperCase();

    if (
      ['DRAFT', 'PLANNED', 'IN_PROGRESS'].indexOf(status) >= 0 &&
      !usagePosted[plan.production_plan_id]
    ) {
      planMap[plan.production_plan_id] = true;
    }
  });

  const requiredByItem = {};

  requirements.forEach(function(req) {
    if (!planMap[req.production_plan_id]) return;

    if (!requiredByItem[req.item_id]) {
      requiredByItem[req.item_id] = {
        itemType: req.item_type,
        itemId: req.item_id,
        requiredQtyBase: 0,
        planCountMap: {}
      };
    }

    requiredByItem[req.item_id].requiredQtyBase +=
      Number(req.required_qty_base || 0);

    requiredByItem[req.item_id]
      .planCountMap[req.production_plan_id] = true;
  });

  const inventoryMap = {};
  inventory.forEach(function(row) {
    inventoryMap[row.item_id] = row;
  });

  const openPurchaseMap = {};
  purchases.forEach(function(purchase) {
    const status = String(purchase.status || '').toUpperCase();

    if (['ORDERED', 'PARTIAL'].indexOf(status) >= 0) {
      openPurchaseMap[purchase.purchase_id] = true;
    }
  });

  const incomingByItem = {};
  purchaseItems.forEach(function(item) {
    if (!openPurchaseMap[item.purchase_id]) return;

    const outstanding = Math.max(
      0,
      Number(item.quantity_base || 0) -
      Number(item.received_qty_base || 0)
    );

    incomingByItem[item.item_id] =
      (incomingByItem[item.item_id] || 0) +
      outstanding;
  });

  const allMaterialIds = {};
  Object.keys(requiredByItem).forEach(function(id) {
    allMaterialIds[id] = true;
  });
  inventory.forEach(function(row) {
    allMaterialIds[row.item_id] = true;
  });

  const result = [];

  Object.keys(allMaterialIds).forEach(function(itemId) {
    const req =
      requiredByItem[itemId] || {
        itemType:
          materialMaps.ingredientMap[itemId]
            ? 'INGREDIENT'
            : 'PACKAGING',
        itemId: itemId,
        requiredQtyBase: 0,
        planCountMap: {}
      };

    const material =
      String(req.itemType).toUpperCase() === 'INGREDIENT'
        ? materialMaps.ingredientMap[itemId]
        : materialMaps.packagingMap[itemId];

    if (!material) return;

    const stockRow = inventoryMap[itemId] || {};
    const current = Number(
      stockRow.current_stock_base || 0
    );
    const minimum = Number(
      stockRow.minimum_stock_base ||
      material.minimum_stock_base ||
      0
    );
    const activeRequirement = Number(
      req.requiredQtyBase || 0
    );
    const incoming = Number(
      incomingByItem[itemId] || 0
    );

    const recommended = Math.max(
      0,
      activeRequirement +
      minimum -
      current -
      incoming
    );

    if (!(recommended > 0)) return;

    const productionShortage = Math.max(
      0,
      activeRequirement -
      current -
      incoming
    );

    result.push({
      itemType: req.itemType,
      itemId: itemId,
      itemName:
        String(req.itemType).toUpperCase() === 'INGREDIENT'
          ? material.ingredient_name
          : material.packaging_name,
      category: material.category || '',
      baseUnit: material.base_unit,
      purchaseUnit: material.purchase_unit,
      purchaseToBaseFactor:
        Number(material.purchase_to_base_factor || 1),
      defaultSupplierId:
        material.default_supplier_id || '',
      currentStockBase: roundNumber_(current, 6),
      activeRequirementBase:
        roundNumber_(activeRequirement, 6),
      incomingBase: roundNumber_(incoming, 6),
      minimumStockBase: roundNumber_(minimum, 6),
      productionShortageBase:
        roundNumber_(productionShortage, 6),
      recommendedPurchaseBase:
        roundNumber_(recommended, 6),
      recommendedPurchaseQty:
        roundNumber_(
          recommended /
          Number(material.purchase_to_base_factor || 1),
          6
        ),
      planCount:
        Object.keys(req.planCountMap || {}).length,
      urgency:
        productionShortage > 0
          ? 'SHORTAGE'
          : 'REORDER'
    });
  });

  result.sort(function(a, b) {
    const weight = {
      SHORTAGE: 1,
      REORDER: 2
    };

    return (
      (weight[a.urgency] || 9) -
      (weight[b.urgency] || 9)
    ) ||
    String(a.itemName).localeCompare(
      String(b.itemName)
    );
  });

  return result;
}

function purchasingModuleBootstrap() {
  const user = requirePermission_('PURCHASE_READ');

  const suppliers = supplierModuleRows_();
  const purchases = listAllRecords_('PURCHASES')
    .map(stripInternalFields_);
  const purchaseItems = listAllRecords_('PURCHASE_ITEMS')
    .map(stripInternalFields_);

  const materialMaps = purchasingMaterialMaps_();

  const inventory = listAllRecords_('INVENTORY')
    .map(stripInternalFields_);
  const plans = listAllRecords_('PRODUCTION_PLANS')
    .map(stripInternalFields_);
  const requirements = listAllRecords_('PRODUCTION_REQUIREMENTS')
    .map(stripInternalFields_);
  const movements = listAllRecords_('INVENTORY_MOVEMENTS')
    .map(stripInternalFields_);

  const supplierMap = {};
  suppliers.forEach(function(row) {
    supplierMap[row.supplier_id] = row;
  });

  const itemGroups = {};
  purchaseItems.forEach(function(item) {
    if (!itemGroups[item.purchase_id]) {
      itemGroups[item.purchase_id] = [];
    }
    itemGroups[item.purchase_id].push(item);
  });

  const purchaseRows = purchases.map(function(purchase) {
    const supplier =
      supplierMap[purchase.supplier_id] || {};

    const items =
      itemGroups[purchase.purchase_id] || [];

    const orderedBase =
      items.reduce(function(sum, item) {
        return sum +
          Number(item.quantity_base || 0);
      }, 0);

    const receivedBase =
      items.reduce(function(sum, item) {
        return sum +
          Number(item.received_qty_base || 0);
      }, 0);

    return Object.assign(
      {},
      purchase,
      {
        supplier_name:
          supplier.supplier_name ||
          purchase.supplier_id,
        item_count: items.length,
        ordered_qty_base: orderedBase,
        received_qty_base: receivedBase,
        receive_progress_pct:
          orderedBase > 0
            ? roundNumber_(
                (receivedBase / orderedBase) * 100,
                1
              )
            : 0
      }
    );
  });

  purchaseRows.sort(function(a, b) {
    return String(b.created_at || '').localeCompare(
      String(a.created_at || '')
    );
  });

  const shortages =
    buildPurchasingShortageSuggestions_(
      plans,
      requirements,
      inventory,
      purchases,
      purchaseItems,
      movements,
      materialMaps
    );

  const priceHistory =
    buildPurchasePriceHistory_(
      purchases,
      purchaseItems,
      suppliers,
      materialMaps
    );

  const materials = []
    .concat(
      materialMaps.ingredients.map(function(row) {
        return {
          item_type: 'INGREDIENT',
          item_id: row.ingredient_id,
          item_name: row.ingredient_name,
          category: row.category,
          base_unit: row.base_unit,
          purchase_unit: row.purchase_unit,
          purchase_to_base_factor:
            Number(row.purchase_to_base_factor || 1),
          default_supplier_id:
            row.default_supplier_id || '',
          latest_cost_per_base_unit:
            Number(row.latest_cost_per_base_unit || 0),
          average_cost_per_base_unit:
            Number(row.average_cost_per_base_unit || 0),
          status: row.status
        };
      })
    )
    .concat(
      materialMaps.packaging.map(function(row) {
        return {
          item_type: 'PACKAGING',
          item_id: row.packaging_id,
          item_name: row.packaging_name,
          category: row.category,
          base_unit: row.base_unit,
          purchase_unit: row.purchase_unit,
          purchase_to_base_factor:
            Number(row.purchase_to_base_factor || 1),
          default_supplier_id:
            row.default_supplier_id || '',
          latest_cost_per_base_unit:
            Number(row.latest_cost_per_base_unit || 0),
          average_cost_per_base_unit:
            Number(row.average_cost_per_base_unit || 0),
          status: row.status
        };
      })
    )
    .filter(function(row) {
      return String(row.status).toUpperCase() === 'ACTIVE';
    });

  return {
    suppliers: suppliers,
    purchases: purchaseRows,
    materials: materials,
    shortages: shortages,
    priceHistory: priceHistory.slice(0, 500),
    permissions: {
      purchaseWrite:
        hasPermission_(user, 'PURCHASE_WRITE'),
      inventoryAdjust:
        hasPermission_(user, 'INVENTORY_ADJUST')
    }
  };
}

function buildPurchasePriceHistory_(
  purchases,
  purchaseItems,
  suppliers,
  materialMaps
) {
  const purchaseMap = {};
  purchases.forEach(function(row) {
    purchaseMap[row.purchase_id] = row;
  });

  const supplierMap = {};
  suppliers.forEach(function(row) {
    supplierMap[row.supplier_id] = row;
  });

  return purchaseItems
    .map(function(item) {
      const purchase =
        purchaseMap[item.purchase_id] || {};

      const supplier =
        supplierMap[purchase.supplier_id] || {};

      const material =
        String(item.item_type).toUpperCase() === 'INGREDIENT'
          ? materialMaps.ingredientMap[item.item_id] || {}
          : materialMaps.packagingMap[item.item_id] || {};

      const baseCost =
        Number(item.quantity_base || 0) > 0
          ? Number(item.total_cost || 0) /
            Number(item.quantity_base || 0)
          : 0;

      return {
        purchaseItemId: item.purchase_item_id,
        purchaseId: item.purchase_id,
        purchaseDate: purchase.purchase_date || '',
        purchaseStatus: purchase.status || '',
        supplierId: purchase.supplier_id || '',
        supplierName:
          supplier.supplier_name ||
          purchase.supplier_id ||
          '',
        itemType: item.item_type,
        itemId: item.item_id,
        itemName:
          String(item.item_type).toUpperCase() === 'INGREDIENT'
            ? material.ingredient_name || item.item_id
            : material.packaging_name || item.item_id,
        quantity: Number(item.quantity || 0),
        unit: item.unit,
        unitCost: Number(item.unit_cost || 0),
        totalCost: Number(item.total_cost || 0),
        quantityBase: Number(item.quantity_base || 0),
        baseUnit: material.base_unit || '',
        costPerBaseUnit:
          roundNumber_(baseCost, 6)
      };
    })
    .sort(function(a, b) {
      return String(b.purchaseDate || '').localeCompare(
        String(a.purchaseDate || '')
      );
    });
}

function resolvePurchaseItemInput_(input) {
  const type =
    String(input.item_type || '').toUpperCase();

  assertOneOf_(
    type,
    ['INGREDIENT', 'PACKAGING'],
    'item_type'
  );

  const itemId = normalizeText_(input.item_id);
  const material = getMaterialByType_(
    type,
    itemId
  );

  if (
    String(material.status || '').toUpperCase() !== 'ACTIVE'
  ) {
    throw twbError_(
      'MATERIAL_INACTIVE',
      'Material is not active: ' + itemId
    );
  }

  const quantity =
    requirePositive_(
      input.quantity,
      'quantity'
    );

  const unit =
    canonicalUnit_(
      input.unit ||
      material.purchase_unit ||
      material.base_unit
    );

  const quantityBase =
    convertItemUnit_(
      type,
      itemId,
      quantity,
      unit,
      material.base_unit
    );

  const unitCost =
    requireNonNegative_(
      input.unit_cost,
      'unit_cost'
    );

  return {
    itemType: type,
    itemId: itemId,
    material: material,
    quantity: quantity,
    unit: unit,
    quantityBase:
      roundNumber_(quantityBase, 6),
    unitCost: Math.round(unitCost),
    totalCost:
      Math.round(quantity * unitCost)
  };
}

function createPurchase(payload) {
  const user = requirePermission_('PURCHASE_WRITE');
  payload = payload || {};

  const supplierId =
    normalizeText_(payload.supplier_id);

  const supplier = dbFindById(
    'SUPPLIERS',
    supplierId
  );

  if (!supplier) {
    throw twbError_(
      'NOT_FOUND',
      'Supplier not found: ' + supplierId
    );
  }

  if (
    String(supplier.status).toUpperCase() !== 'ACTIVE'
  ) {
    throw twbError_(
      'SUPPLIER_INACTIVE',
      'Supplier is not active.'
    );
  }

  const inputItems =
    Array.isArray(payload.items)
      ? payload.items
      : [];

  if (!inputItems.length) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Purchase must contain at least one item.'
    );
  }

  const resolved =
    inputItems.map(resolvePurchaseItemInput_);

  const duplicateMap = {};
  resolved.forEach(function(row) {
    const key =
      row.itemType + '|' + row.itemId;

    if (duplicateMap[key]) {
      throw twbError_(
        'PURCHASE_ITEM_DUPLICATE',
        'A material can only appear once in a purchase.'
      );
    }

    duplicateMap[key] = true;
  });

  const subtotal =
    resolved.reduce(function(sum, row) {
      return sum + Number(row.totalCost || 0);
    }, 0);

  const deliveryCost =
    requireNonNegative_(
      payload.delivery_cost || 0,
      'delivery_cost'
    );

  const purchaseId =
    nextBusinessId('PURCHASE');

  const itemIds =
    resolved.map(function() {
      return nextBusinessId('PURCHASE_ITEM');
    });

  const now = nowIso_();

  const purchase = {
    purchase_id: purchaseId,
    supplier_id: supplierId,
    purchase_date:
      normalizeText_(payload.purchase_date) ||
      todayIso_(),
    expected_date:
      normalizeText_(payload.expected_date),
    received_date: '',
    status: 'DRAFT',
    payment_status: 'UNPAID',
    subtotal: Math.round(subtotal),
    delivery_cost: Math.round(deliveryCost),
    total_cost:
      Math.round(subtotal + deliveryCost),
    notes: normalizeText_(payload.notes),
    created_at: now,
    created_by: user.user_id,
    updated_at: now,
    updated_by: user.user_id
  };

  const items =
    resolved.map(function(row, index) {
      return {
        purchase_item_id: itemIds[index],
        purchase_id: purchaseId,
        item_type: row.itemType,
        item_id: row.itemId,
        quantity: row.quantity,
        unit: row.unit,
        quantity_base: row.quantityBase,
        unit_cost: row.unitCost,
        total_cost: row.totalCost,
        received_qty_base: 0,
        created_at: now,
        created_by: user.user_id,
        updated_at: now,
        updated_by: user.user_id
      };
    });

  let insertedHeader = false;

  try {
    dbInsertRecord(
      'PURCHASES',
      purchase,
      { validate: true, audit: false }
    );

    insertedHeader = true;

    dbBulkInsert(
      'PURCHASE_ITEMS',
      items,
      { validate: true }
    );
  } catch (e) {
    if (insertedHeader) {
      try {
        dbUpdateById(
          'PURCHASES',
          purchaseId,
          stampUpdate_(user, {
            status: 'CANCELLED',
            notes:
              (
                normalizeText_(purchase.notes)
                  ? normalizeText_(purchase.notes) + '\n'
                  : ''
              ) +
              '[SYSTEM] Purchase item creation failed: ' +
              (e.message || e)
          }),
          { validate: true, audit: false }
        );
      } catch (ignore) {}
    }

    throw e;
  }

  writeAuditLog_(
    'CREATE',
    'PURCHASES',
    purchaseId,
    null,
    {
      purchase: purchase,
      itemCount: items.length
    },
    'Purchase draft created.'
  );

  return getPurchaseDetail_(purchaseId);
}

function validatePurchaseTransition_(fromStatus, toStatus) {
  const from =
    String(fromStatus || '').toUpperCase();

  const to =
    String(toStatus || '').toUpperCase();

  if (!TWB_PURCHASE_TRANSITIONS[from]) {
    throw twbError_(
      'PURCHASE_STATUS_INVALID',
      'Unknown purchase status: ' + from
    );
  }

  if (
    TWB_PURCHASE_TRANSITIONS[from].indexOf(to) < 0
  ) {
    throw twbError_(
      'PURCHASE_TRANSITION_INVALID',
      'Cannot move purchase from ' +
      from +
      ' to ' +
      to +
      '.',
      {
        from: from,
        to: to,
        allowed:
          TWB_PURCHASE_TRANSITIONS[from]
      }
    );
  }

  return true;
}

function updatePurchaseStatus(
  purchaseId,
  targetStatus,
  notes
) {
  const user = requirePermission_('PURCHASE_WRITE');

  const purchase = dbFindById(
    'PURCHASES',
    purchaseId
  );

  if (!purchase) {
    throw twbError_(
      'NOT_FOUND',
      'Purchase not found: ' + purchaseId
    );
  }

  const from =
    String(purchase.status).toUpperCase();

  const to =
    String(targetStatus || '').toUpperCase();

  validatePurchaseTransition_(from, to);

  if (to === 'CANCELLED') {
    const items = dbFindMany(
      'PURCHASE_ITEMS',
      'purchase_id',
      purchaseId
    );

    const hasReceived =
      items.some(function(item) {
        return Number(
          item.received_qty_base || 0
        ) > 0;
      });

    if (hasReceived) {
      throw twbError_(
        'PURCHASE_HAS_RECEIPT',
        'A purchase with received goods cannot be cancelled.'
      );
    }
  }

  const updated = dbUpdateById(
    'PURCHASES',
    purchaseId,
    stampUpdate_(user, {
      status: to,
      notes:
        normalizeText_(notes) ||
        purchase.notes
    }),
    { validate: true, audit: false }
  );

  writeAuditLog_(
    'STATUS_CHANGE',
    'PURCHASES',
    purchaseId,
    stripInternalFields_(purchase),
    updated,
    from + ' → ' + to
  );

  return getPurchaseDetail_(purchaseId);
}

function getPurchaseDetail(purchaseId) {
  requirePermission_('PURCHASE_READ');
  return getPurchaseDetail_(purchaseId);
}

function getPurchaseDetail_(purchaseId) {
  const purchase = dbFindById(
    'PURCHASES',
    purchaseId
  );

  if (!purchase) {
    throw twbError_(
      'NOT_FOUND',
      'Purchase not found: ' + purchaseId
    );
  }

  const supplier = dbFindById(
    'SUPPLIERS',
    purchase.supplier_id
  );

  const maps = purchasingMaterialMaps_();

  const items = dbFindMany(
    'PURCHASE_ITEMS',
    'purchase_id',
    purchaseId
  ).map(function(item) {
    const material =
      String(item.item_type).toUpperCase() === 'INGREDIENT'
        ? maps.ingredientMap[item.item_id] || {}
        : maps.packagingMap[item.item_id] || {};

    return Object.assign(
      {},
      stripInternalFields_(item),
      {
        item_name:
          String(item.item_type).toUpperCase() === 'INGREDIENT'
            ? material.ingredient_name || item.item_id
            : material.packaging_name || item.item_id,
        base_unit: material.base_unit || '',
        remaining_qty_base:
          Math.max(
            0,
            Number(item.quantity_base || 0) -
            Number(item.received_qty_base || 0)
          ),
        cost_per_base_unit:
          Number(item.quantity_base || 0) > 0
            ? roundNumber_(
                Number(item.total_cost || 0) /
                Number(item.quantity_base || 0),
                6
              )
            : 0
      }
    );
  });

  return {
    purchase: stripInternalFields_(purchase),
    supplier:
      supplier
        ? stripInternalFields_(supplier)
        : null,
    items: items,
    allowedTransitions:
      TWB_PURCHASE_TRANSITIONS[
        String(purchase.status).toUpperCase()
      ] || []
  };
}

function calculateWeightedAverageCost_(
  oldQty,
  oldAverage,
  receiptQty,
  receiptCost
) {
  oldQty = Math.max(0, Number(oldQty || 0));
  oldAverage = Number(oldAverage || 0);
  receiptQty = Math.max(0, Number(receiptQty || 0));
  receiptCost = Number(receiptCost || 0);

  const newQty = oldQty + receiptQty;

  if (!(newQty > 0)) {
    return roundNumber_(receiptCost, 6);
  }

  return roundNumber_(
    (
      oldQty * oldAverage +
      receiptQty * receiptCost
    ) / newQty,
    6
  );
}

function updateMaterialCostAfterReceipt_(
  itemType,
  itemId,
  receivedQtyBase,
  costPerBase,
  inventoryBefore,
  actorUser
) {
  const sheet =
    String(itemType).toUpperCase() === 'INGREDIENT'
      ? 'INGREDIENTS'
      : 'PACKAGING';

  const material = dbFindById(
    sheet,
    itemId
  );

  const inventory = dbFindOne(
    'INVENTORY',
    'item_id',
    itemId
  );

  if (!material || !inventory) return;

  const oldQty =
    Math.max(
      0,
      Number(inventoryBefore || 0)
    );

  const oldAverage =
    Number(
      inventory.average_cost_per_base_unit ||
      material.average_cost_per_base_unit ||
      0
    );

  const receiptQty =
    Number(receivedQtyBase || 0);

  const receiptCost =
    Number(costPerBase || 0);

  const newAverage =
    calculateWeightedAverageCost_(
      oldQty,
      oldAverage,
      receiptQty,
      receiptCost
    );

  dbUpdateById(
    sheet,
    itemId,
    stampUpdate_(actorUser, {
      latest_cost_per_base_unit:
        roundNumber_(receiptCost, 6),
      average_cost_per_base_unit:
        roundNumber_(newAverage, 6)
    }),
    { validate: true, audit: false }
  );

  dbUpdateById(
    'INVENTORY',
    inventory.inventory_id,
    {
      average_cost_per_base_unit:
        roundNumber_(newAverage, 6),
      updated_at: nowIso_()
    },
    { validate: true, audit: false }
  );
}

function refreshProductEconomicsForPurchasedMaterial_(
  itemType,
  itemId,
  actorUser
) {
  const recipeItems = listAllRecords_('RECIPE_ITEMS')
    .filter(function(item) {
      return (
        String(item.item_type).toUpperCase() ===
          String(itemType).toUpperCase() &&
        String(item.item_id) === String(itemId)
      );
    });

  if (!recipeItems.length) return 0;

  const recipeIds = {};
  recipeItems.forEach(function(item) {
    recipeIds[item.recipe_id] = true;
  });

  const recipes = listAllRecords_('RECIPES')
    .filter(function(recipe) {
      return (
        recipeIds[recipe.recipe_id] &&
        String(recipe.status).toUpperCase() === 'ACTIVE' &&
        !recipe.variant_id
      );
    });

  let updated = 0;

  recipes.forEach(function(recipe) {
    recalculateProductEconomics_(
      recipe.product_id,
      recipe.recipe_id,
      actorUser
    );
    updated += 1;
  });

  return updated;
}

function receivePurchase(payload) {
  const user = requirePermission_('PURCHASE_WRITE');

  if (!hasPermission_(user, 'INVENTORY_ADJUST')) {
    throw twbError_(
      'FORBIDDEN',
      'INVENTORY_ADJUST permission is required to receive goods.'
    );
  }

  payload = payload || {};

  const purchaseId =
    normalizeText_(payload.purchase_id);

  const purchase = dbFindById(
    'PURCHASES',
    purchaseId
  );

  if (!purchase) {
    throw twbError_(
      'NOT_FOUND',
      'Purchase not found: ' + purchaseId
    );
  }

  const purchaseStatus =
    String(purchase.status).toUpperCase();

  if (
    ['ORDERED', 'PARTIAL'].indexOf(purchaseStatus) < 0
  ) {
    throw twbError_(
      'PURCHASE_NOT_RECEIVABLE',
      'Only ORDERED or PARTIAL purchases can receive goods.'
    );
  }

  const receiptToken =
    normalizeText_(payload.receipt_token) ||
    Utilities.getUuid();

  const lines =
    Array.isArray(payload.items)
      ? payload.items
      : [];

  if (!lines.length) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'At least one receipt line is required.'
    );
  }

  const existingItems = dbFindMany(
    'PURCHASE_ITEMS',
    'purchase_id',
    purchaseId
  );

  const itemMap = {};
  existingItems.forEach(function(item) {
    itemMap[item.purchase_item_id] = item;
  });

  const prepared = lines.map(function(line) {
    const purchaseItem =
      itemMap[line.purchase_item_id];

    if (!purchaseItem) {
      throw twbError_(
        'NOT_FOUND',
        'Purchase item not found: ' +
        line.purchase_item_id
      );
    }

    const material =
      getMaterialByType_(
        purchaseItem.item_type,
        purchaseItem.item_id
      );

    const enteredQty =
      requirePositive_(
        line.quantity,
        'receipt quantity'
      );

    const enteredUnit =
      canonicalUnit_(
        line.unit ||
        purchaseItem.unit ||
        material.purchase_unit ||
        material.base_unit
      );

    const receivedBase =
      convertItemUnit_(
        purchaseItem.item_type,
        purchaseItem.item_id,
        enteredQty,
        enteredUnit,
        material.base_unit
      );

    const remaining =
      Math.max(
        0,
        Number(purchaseItem.quantity_base || 0) -
        Number(purchaseItem.received_qty_base || 0)
      );

    if (receivedBase > remaining + 0.000001) {
      throw twbError_(
        'PURCHASE_RECEIPT_EXCEEDS_REMAINING',
        'Received quantity exceeds remaining purchase quantity.',
        {
          purchaseItemId:
            purchaseItem.purchase_item_id,
          remainingQtyBase: remaining,
          attemptedQtyBase: receivedBase
        }
      );
    }

    const referenceId =
      purchaseItem.purchase_item_id +
      '#' +
      receiptToken;

    const inventory =
      getOrCreateInventoryRow_(
        purchaseItem.item_type,
        purchaseItem.item_id,
        user
      );

    return {
      purchaseItem: purchaseItem,
      material: material,
      inventoryId: inventory.inventory_id,
      receivedBase:
        roundNumber_(receivedBase, 6),
      referenceId: referenceId,
      movementId:
        nextBusinessId('INVENTORY_MOVEMENT')
    };
  });

  const allReferenceIds =
    prepared.map(function(row) {
      return row.referenceId;
    });

  const currentMovements =
    listAllRecords_('INVENTORY_MOVEMENTS');

  const existingReferenceMap = {};
  currentMovements.forEach(function(movement) {
    existingReferenceMap[movement.reference_id] = true;
  });

  const duplicateCount =
    allReferenceIds.filter(function(ref) {
      return !!existingReferenceMap[ref];
    }).length;

  if (duplicateCount === allReferenceIds.length) {
    return getPurchaseDetail_(purchaseId);
  }

  if (duplicateCount > 0) {
    throw twbError_(
      'PURCHASE_RECEIPT_TOKEN_INCONSISTENT',
      'Receipt token is partially present. Use a new receipt token or inspect the ledger.'
    );
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  const insertedMovements = [];
  const receivedCostUpdates = [];

  try {
    const liveMovements =
      listAllRecords_('INVENTORY_MOVEMENTS');

    const liveReferenceMap = {};
    liveMovements.forEach(function(movement) {
      liveReferenceMap[movement.reference_id] = true;
    });

    const liveDuplicateCount =
      allReferenceIds.filter(function(ref) {
        return !!liveReferenceMap[ref];
      }).length;

    if (liveDuplicateCount === allReferenceIds.length) {
      return getPurchaseDetail_(purchaseId);
    }

    if (liveDuplicateCount > 0) {
      throw twbError_(
        'PURCHASE_RECEIPT_TOKEN_INCONSISTENT',
        'Receipt token became partially present while posting.'
      );
    }

    const livePurchase = dbFindById(
      'PURCHASES',
      purchaseId
    );

    if (
      ['ORDERED', 'PARTIAL'].indexOf(
        String(livePurchase.status).toUpperCase()
      ) < 0
    ) {
      throw twbError_(
        'PURCHASE_NOT_RECEIVABLE',
        'Purchase status changed before receipt posting.'
      );
    }

    prepared.forEach(function(row) {
      const liveItem = dbFindById(
        'PURCHASE_ITEMS',
        row.purchaseItem.purchase_item_id
      );

      const remaining =
        Math.max(
          0,
          Number(liveItem.quantity_base || 0) -
          Number(liveItem.received_qty_base || 0)
        );

      if (
        row.receivedBase >
        remaining + 0.000001
      ) {
        throw twbError_(
          'PURCHASE_RECEIPT_EXCEEDS_REMAINING',
          'Receipt quantity is no longer available.'
        );
      }

      const inventory = dbFindById(
        'INVENTORY',
        row.inventoryId
      );

      const before =
        Number(
          inventory.current_stock_base || 0
        );

      const after =
        before + row.receivedBase;

      const costPerBase =
        Number(liveItem.quantity_base || 0) > 0
          ? Number(liveItem.total_cost || 0) /
            Number(liveItem.quantity_base || 0)
          : 0;

      const now = nowIso_();

      const movement = {
        movement_id: row.movementId,
        movement_at:
          normalizeText_(payload.received_at) ||
          now,
        item_type: liveItem.item_type,
        item_id: liveItem.item_id,
        movement_type: 'PURCHASE_RECEIPT',
        quantity_in_base: row.receivedBase,
        quantity_out_base: 0,
        balance_after_base:
          roundNumber_(after, 6),
        base_unit: row.material.base_unit,
        reference_type: 'PURCHASE_ITEM',
        reference_id: row.referenceId,
        notes:
          'Receipt for ' +
          purchaseId +
          ' / ' +
          liveItem.purchase_item_id,
        created_at: now,
        created_by: user.user_id,
        updated_at: now,
        updated_by: user.user_id
      };

      dbInsertRecord(
        'INVENTORY_MOVEMENTS',
        movement,
        { validate: true, audit: false }
      );

      dbUpdateById(
        'INVENTORY',
        inventory.inventory_id,
        {
          current_stock_base:
            roundNumber_(after, 6),
          last_movement_at:
            movement.movement_at,
          updated_at: now
        },
        { validate: true, audit: false }
      );

      dbUpdateById(
        'PURCHASE_ITEMS',
        liveItem.purchase_item_id,
        stampUpdate_(user, {
          received_qty_base:
            roundNumber_(
              Number(liveItem.received_qty_base || 0) +
              row.receivedBase,
              6
            )
        }),
        { validate: true, audit: false }
      );

      insertedMovements.push(movement);

      receivedCostUpdates.push({
        itemType: liveItem.item_type,
        itemId: liveItem.item_id,
        receivedQtyBase: row.receivedBase,
        costPerBase: costPerBase,
        inventoryBefore: before
      });
    });

    const refreshedItems = dbFindMany(
      'PURCHASE_ITEMS',
      'purchase_id',
      purchaseId
    );

    const allReceived =
      refreshedItems.every(function(item) {
        return (
          Number(item.received_qty_base || 0) >=
          Number(item.quantity_base || 0) -
          0.000001
        );
      });

    const anyReceived =
      refreshedItems.some(function(item) {
        return Number(item.received_qty_base || 0) > 0;
      });

    dbUpdateById(
      'PURCHASES',
      purchaseId,
      stampUpdate_(user, {
        status:
          allReceived
            ? 'RECEIVED'
            : (
                anyReceived
                  ? 'PARTIAL'
                  : livePurchase.status
              ),
        received_date:
          allReceived
            ? (
                normalizeDateKey_(payload.received_at) ||
                todayIso_()
              )
            : livePurchase.received_date
      }),
      { validate: true, audit: false }
    );
  } finally {
    lock.releaseLock();
  }

  const affected = {};

  receivedCostUpdates.forEach(function(row) {
    updateMaterialCostAfterReceipt_(
      row.itemType,
      row.itemId,
      row.receivedQtyBase,
      row.costPerBase,
      row.inventoryBefore,
      user
    );

    const key =
      row.itemType + '|' + row.itemId;

    if (!affected[key]) {
      affected[key] = row;
    }
  });

  Object.keys(affected).forEach(function(key) {
    const row = affected[key];

    refreshProductEconomicsForPurchasedMaterial_(
      row.itemType,
      row.itemId,
      user
    );
  });

  writeAuditLog_(
    'CREATE',
    'INVENTORY_MOVEMENTS',
    purchaseId,
    null,
    {
      purchaseId: purchaseId,
      receiptToken: receiptToken,
      movementCount: insertedMovements.length
    },
    'Purchase receipt posted to inventory.'
  );

  return getPurchaseDetail_(purchaseId);
}
