# PHASE_10_IMPLEMENTATION.md
# Twolittle.bites OS — Finance & Profitability

**Phase:** 10  
**App Version:** 0.10.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Managerial P&L

Phase 10 adds:

```text
Completed Order
↓
Product Sales
+ Delivery Revenue
= Operating Revenue
- COGS
= Gross Profit
- Operating Expenses
= Operating Profit
```

Tax collected is displayed separately and excluded from operating revenue.

## Revenue recognition

Revenue is recognized from:

```text
order_status = COMPLETED
```

Period date:

```text
fulfillment_date
fallback → order_date
```

This is a managerial reporting convention, not statutory accounting.

## Historical COGS

The existing schema has no `cogs_snapshot` column on `ORDER_ITEMS`.

Phase 10 avoids silently treating today's Product COGS as historical fact.

### Going forward

When an Order becomes `COMPLETED`:

```text
ORDER_ITEM
↓
current Recipe / Material cost
↓
COGS transaction
```

Transaction:

```text
transaction_type = COGS
category         = PRODUCT_COGS
reference_type   = ORDER_ITEM_COGS
reference_id     = order_item_id
payment_method   = NON_CASH
amount_out       = item COGS
```

This is a **managerial non-cash transaction**.

It is included in P&L COGS but excluded from Cash Movement.

### Existing completed Orders

If no COGS snapshot exists, analytics uses:

```text
CURRENT_COST_ESTIMATE
```

The UI warns when a selected period contains estimated historical COGS.

Optional backfill:

```javascript
backfillCompletedOrderCogsPhase10()
```

This creates missing COGS transactions for existing COMPLETED Orders using current recipe/material cost at the time of backfill.

It cannot reconstruct original historical cost.

## Product profitability

Revenue per Order Item:

```text
line_total
- proportional allocation of Order-level discount
```

Then:

```text
Product Gross Profit
= allocated Product Revenue
- Item COGS
```

Delivery revenue and tax are not assigned to Product profitability.

## Channel profitability

Per `source_channel`:

```text
Product Revenue
+ Delivery Revenue
- COGS
= Channel Gross Profit
```

This is before operating expenses because the current EXPENSES schema has no channel attribution field.

## Expenses

Expense creation writes:

```text
EXPENSES
+
TRANSACTIONS
```

Expense Transaction:

```text
transaction_type = EXPENSE
reference_type   = EXPENSE
amount_out       = expense amount
```

Expense status:

```text
ACTIVE
VOID
```

Voiding never deletes history.

It creates:

```text
transaction_type = EXPENSE_REVERSAL
reference_type   = EXPENSE_VOID
amount_in        = original expense
```

This is an administrative reversal.

## Cash movement

Cash reporting uses `TRANSACTIONS`, excluding:

```text
transaction_type = COGS
```

So:

```text
Cash In
- Cash Out
= Net Cash Movement
```

and inventory consumption does not pretend to be cash spending.

## Existing purchasing boundary

Purchase receiving remains inventory movement, not an expense.

Supplier payment is still tracked separately from receiving.

Phase 10 does not automatically expense material purchases because material cost enters P&L through COGS when completed products are sold.

## UI

Finance tabs:

```text
Overview
P&L
Expenses
Profitability
Invoices
Payments
Transactions
```

P&L supports custom date range.

Profitability includes:
- Product Revenue
- Product COGS
- Product Gross Profit / Margin
- Channel Revenue
- Channel COGS
- Channel Gross Profit / Margin

## Install from Phase 9

Replace:

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
FinanceService.gs
OrderService.gs
Index.html
JsApp.html
ComponentQuickActions.html
PageFinance.html
StylesComponents.html
StylesResponsive.html
```

Add:

```text
FinanceAnalyticsService.gs
JsFinanceAnalytics.html
Phase10Setup.gs
Phase10HealthCheck.gs
Phase10SmokeTest.gs
```

## Upgrade

```javascript
upgradeToPhase10()
```

Sets:

```text
APP_VERSION = 0.10.0
SCHEMA_VERSION = 1.0.0
FINANCE_REVENUE_RECOGNITION = COMPLETED_ORDER_FULFILLMENT_DATE
FINANCE_COGS_SNAPSHOT_MODE = ORDER_ITEM_TRANSACTION_ON_COMPLETION
FINANCE_TAX_TREATMENT = EXCLUDE_FROM_OPERATING_REVENUE
```

No Sheet is recreated.

## Validation

```javascript
runPhase10HealthCheck()
runPhase10SmokeTest()
```

Both validation suites are read-only.

## Browser QA

1. Open Finance.
2. Record an Expense.
3. Confirm:
   - EXPENSES row created;
   - matching EXPENSE Transaction created.
4. Open P&L and select the expense period.
5. Complete a new Order.
6. Confirm one COGS Transaction exists per Order Item.
7. Check Product profitability.
8. Check Channel profitability.
9. Check Cash Movement does not include COGS.
10. Void a test Expense and confirm reversal without deleting history.

## Optional historical action

Only if desired:

```javascript
backfillCompletedOrderCogsPhase10()
```

Review the warning before using it.

## Next

**Phase 11 — CRM & Customer Intelligence**
