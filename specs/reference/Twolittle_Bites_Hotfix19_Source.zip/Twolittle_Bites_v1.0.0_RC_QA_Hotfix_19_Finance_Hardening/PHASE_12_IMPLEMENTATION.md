# PHASE_12_IMPLEMENTATION.md
# Twolittle.bites OS — Marketing & Attribution Engine

**Phase:** 12  
**App Version:** 0.12.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Core flow

```text
Marketing Campaign
↓
Content
↓
Marketing Expense
↓
Manual Last-Touch Attribution
↓
Order
↓
Completed Order
↓
Attributed Operating Revenue
↓
ROAS / CAC-style metrics
```

## Important interpretation

Phase 12 implements **operational attribution**.

It does not claim that the Campaign or Content caused the Order.

The active model is:

```text
MANUAL_LAST_TOUCH
```

One Order can have:
- one active Campaign;
- zero or one active Content item.

The latest mapping wins.

## Why no schema migration

The existing database already contains:

```text
MARKETING_CAMPAIGNS
CONTENT
ORDERS
EXPENSES
TRANSACTIONS
ACTIVITY_LOG
```

but `ORDERS` has no campaign/content attribution columns and `EXPENSES` has no campaign ID.

Instead of adding duplicate tables or changing the 33-sheet schema, Phase 12 uses `ACTIVITY_LOG` as an immutable mapping ledger.

### Order attribution log

```text
entity_type = ORDER_MARKETING_ATTRIBUTION
entity_id   = order_id
source      = PHASE12_MARKETING
action      = MARKETING_ATTRIBUTION_SET
```

Payload:

```text
marketing_campaign_id
content_id
attribution_model
source_channel
attributed_at
attributed_by
```

Clearing attribution adds:

```text
MARKETING_ATTRIBUTION_CLEAR
```

It does not delete the earlier log.

### Expense → Campaign link

```text
entity_type = EXPENSE_MARKETING_LINK
entity_id   = expense_id
source      = PHASE12_MARKETING
```

This keeps Finance as the source of truth for actual spend.

## Campaigns

Campaign fields reuse the current schema:

```text
campaign_name
start_date
end_date
budget
spend
revenue_attributed
orders_attributed
new_customers
repeat_customers
status
```

Statuses supported:

```text
DRAFT
ACTIVE
PAUSED
COMPLETED
CANCELLED
```

The stored aggregate fields are materialized for compatibility.

The Marketing UI derives live values from Orders, attribution logs, and linked Expenses.

## Content

Content can store:

```text
Campaign
Platform
Pillar
Format
Publish Date
URL
Reach
Views
Engagement
Link Clicks
```

Manual platform metrics remain input data.

The following are derived from attribution mappings:

```text
Orders Attributed
Revenue Attributed
Click → Order Rate
Engagement Rate
```

No social platform API integration is introduced in Phase 12.

## Marketing spend

Marketing spend is not written directly into an independent marketing ledger.

Flow:

```text
Marketing → Record Spend
↓
Phase 10 createExpense()
↓
EXPENSES
+
TRANSACTIONS
↓
ACTIVITY_LOG links Expense to Campaign
```

Allowed categories:

```text
ADS
MARKETING
```

Campaign spend is calculated from linked non-VOID Expenses.

If the Expense is voided in Finance, live Campaign spend automatically excludes it.

## Revenue attribution

Attributed Revenue is recognized only when:

```text
order_status = COMPLETED
```

Revenue basis:

```text
grand_total - tax
```

Therefore:

```text
Attributed Operating Revenue
= completed Order value excluding tax
```

This matches the managerial operating-revenue convention introduced in Phase 10.

Delivery revenue remains part of the Order operating revenue.

## Attributed Orders

Order count includes active attributed Orders that are not:

```text
CANCELLED
```

An attributed Order may therefore appear in Order count before it contributes attributed revenue.

This allows the UI to distinguish:
- attributed demand;
- completed attributed revenue.

## New customer attribution

A customer is counted as new when the attributed Order is that customer's:

```text
first non-cancelled Order
```

Cancelled historical Orders are ignored.

This is an operational acquisition definition.

It is not a cohort-based causal acquisition model.

## ROAS

Per Campaign and overall:

```text
ROAS
=
Attributed Completed Operating Revenue
/
Linked Marketing Spend
```

Displayed as:

```text
3.20×
```

If Spend is zero, ROAS is shown as unavailable instead of infinity.

## CAC-style metric

```text
CAC-style
=
Linked Marketing Spend
/
Attributed New Customers
```

This is intentionally called **CAC-style**, because attribution is manual last-touch and does not establish incremental customer acquisition.

## Cost per attributed Order

Campaign metric:

```text
Spend
/
Attributed non-cancelled Orders
```

## Attribution coverage

Order coverage:

```text
Attributed non-cancelled Orders
/
All non-cancelled Orders
```

Revenue coverage:

```text
Attributed completed operating revenue
/
All completed operating revenue
```

These are data-quality / attribution-completeness metrics.

They are not campaign performance scores.

## Source channel vs attribution

`ORDERS.source_channel` remains unchanged.

Example:

```text
source_channel = WHATSAPP
campaign       = Instagram Launch
content        = Reel 03
```

Interpretation:

```text
WHATSAPP
= where the Order arrived

Instagram Launch / Reel 03
= which manually selected marketing touch receives attribution credit
```

These fields should not be treated as interchangeable.

## Permissions

Marketing module read:

```text
MARKETING_READ
or
REPORT_MARKETING_READ
```

Write:

```text
MARKETING_WRITE
```

Marketing Spend also requires an Expense-create capability.

Phase 12 adds to ADMIN:

```text
MARKETING_READ
MARKETING_WRITE
REPORT_MARKETING_READ
```

MARKETING role keeps:

```text
MARKETING_READ
MARKETING_WRITE
EXPENSE_CREATE_MARKETING
REPORT_MARKETING_READ
```

## UI

Marketing:

```text
Overview
Campaigns
Content
Attribution
Spend
```

Overview:
- Marketing Spend
- Attributed Revenue
- ROAS
- Attributed Orders
- New Customers
- CAC-style
- Attribution Coverage
- Revenue Coverage
- Source Channel performance

Campaigns:
- Budget
- Spend
- Orders
- Revenue
- ROAS
- CAC
- Status

Content:
- Reach
- Views
- Engagement
- Clicks
- Orders
- Revenue

Attribution:
- unattributed Order queue;
- active mappings;
- assign Campaign;
- optional Content;
- clear active mapping without deleting history.

Spend:
- linked Finance Expenses.

## Aggregate rebuild

Optional:

```javascript
rebuildMarketingAggregatesPhase12()
```

This recalculates and materializes:

```text
MARKETING_CAMPAIGNS.spend
MARKETING_CAMPAIGNS.revenue_attributed
MARKETING_CAMPAIGNS.orders_attributed
MARKETING_CAMPAIGNS.new_customers
MARKETING_CAMPAIGNS.repeat_customers

CONTENT.orders_attributed
CONTENT.revenue_attributed
```

The Marketing dashboard itself derives live values, so this function is maintenance rather than a daily requirement.

## Install from Phase 11

Replace:

```text
Constants.gs
Permissions.gs
AppShellService.gs
ApiGateway.gs
Index.html
JsApp.html
PageMarketing.html
StylesComponents.html
StylesResponsive.html
```

Add:

```text
MarketingService.gs
JsMarketing.html
Phase12Setup.gs
Phase12HealthCheck.gs
Phase12SmokeTest.gs
```

## Upgrade

Run once:

```javascript
upgradeToPhase12()
```

Sets:

```text
APP_VERSION = 0.12.0
SCHEMA_VERSION = 1.0.0

MARKETING_ATTRIBUTION_MODEL
= MANUAL_LAST_TOUCH

MARKETING_REVENUE_BASIS
= COMPLETED_ORDER_OPERATING_REVENUE

MARKETING_SPEND_SOURCE
= LINKED_ACTIVE_EXPENSES

MARKETING_ATTRIBUTION_STORAGE
= ACTIVITY_LOG_LEDGER
```

No Sheet is recreated.

## Validation

```javascript
runPhase12HealthCheck()
runPhase12SmokeTest()
```

Both are read-only.

They do not create:
- Campaigns;
- Content;
- Expenses;
- Attribution mappings.

## Browser QA

1. Open Marketing.
2. Create Campaign.
3. Change status to ACTIVE.
4. Create Content linked to Campaign.
5. Record Marketing Spend.
6. Confirm:
   - EXPENSES row created;
   - Finance Transaction created;
   - Campaign Spend updates.
7. Open Attribution.
8. Assign an Order to Campaign + Content.
9. Confirm:
   - Attributed Order count updates;
   - Content Order count updates.
10. Complete the Order.
11. Refresh Marketing.
12. Confirm:
   - Attributed Revenue appears;
   - ROAS recalculates.
13. Clear the Order attribution.
14. Confirm the Order returns to the unattributed queue.
15. Verify historical attribution logs remain in ACTIVITY_LOG.

## Next

**Phase 13 — Reports, Metrics Cache & Export**
