# QA_HOTFIX_08_INVOICE_LINKS_DRIVE_PDF.md

## Clickable contacts

- Instagram: `@twolittle.bites` → `https://www.instagram.com/twolittle.bites/`
- Order & inquiries: `0812 6794 8252` → `https://wa.me/6281267948252`

## Google Drive PDF archive

Each invoice is archived under:

```text
Twolittle.bites OS/
└── Invoices/
    └── YYYY/
        └── MM Month/
            └── INV-....pdf
```

Each PDF is set to `Anyone with the link — Viewer`.

If the Google account / Workspace policy blocks public link sharing, the core invoice/payment action still completes and the PDF sync error is logged. Manual regeneration will surface the policy error.

## Regeneration

PDF regenerates after:
- invoice creation;
- mark sent;
- cancel;
- overdue transition;
- payment / recalculation;
- refund;
- fulfillment detail update.

The previous PDF is trashed only after the replacement PDF is generated and shared successfully.

## Public invoice

The footer contains clickable Instagram/WhatsApp links plus:
- `Download PDF`
- `WhatsApp Us`

## WhatsApp

New placeholder:

```text
{invoice_pdf_url}
```

Template validation requires `{invoice_number}` plus at least one of:
- `{invoice_url}`
- `{invoice_pdf_url}`

If you want the customer link to avoid Apps Script entirely:

```text
Lihat invoice:
{invoice_pdf_url}
```

## Runtime QA

Use a real internal `invoice_id`:

```javascript
runQAHotfix08PdfSmoke('INV-202610-000006')
```

Expected:
- `ok = true`
- `publicAccess = ANYONE_WITH_LINK`
- returned Drive `downloadUrl` opens in incognito without Google login.

## Install from QA Hotfix 07

ADD:
- `InvoicePdfService.gs`

REPLACE:
- `InvoiceService.gs`
- `PaymentService.gs`
- `OrderService.gs`
- `ApiGateway.gs`
- `WhatsAppService.gs`
- `SettingsService.gs`
- `JsSettings.html`
- `PublicInvoice.html`
- `Phase16HealthCheck.gs`
- `PRODUCTION_ACCEPTANCE_TEST.md`

No Sheet schema migration and no Phase 16 upgrade rerun.


## Apply the saved WhatsApp template migration

After replacing the files, run:

```javascript
upgradeToQAHotfix08()
```

This does **not** overwrite the wording of your custom template. If the current
template contains `{invoice_url}` and does not yet contain `{invoice_pdf_url}`,
it only replaces that placeholder with `{invoice_pdf_url}`.

For existing invoices that pre-date this hotfix, backfill in small batches:

```javascript
backfillInvoicePdfsQAHotfix08(10)
```

Repeat until:

```text
remainingWithoutPdf = 0
```

The batch is capped at 25 invoices per run to reduce Apps Script execution-time risk.
