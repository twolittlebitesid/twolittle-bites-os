# QA_HOTFIX_04_EDIT_AND_PRODUCT_IMAGES.md
# P0 — Consistent Edit Actions + Product Image Display

## Requests closed

```text
P0 — Add Edit action to Customer and other editable master data.
P0 — Display existing Product images from image_url links.
```

## Edit actions

QA Hotfix 04 adds visible Edit actions to master records that already have safe update endpoints:

```text
Customers
→ customers.update

Products
→ products.update

Ingredients / Packaging
→ materials.update

Suppliers
→ suppliers.update
```

Marketing Campaign / Content and Settings Users already had edit workflows and remain unchanged.

Transactional / historical records are intentionally not converted into unrestricted Edit forms:

```text
Orders
Payments
Transactions
Inventory Movements
Purchase Receipts
Completed production history
```

Those continue to use controlled workflow actions/status transitions so audit history is not bypassed.

## Customer Edit

The Customer action column now contains:

```text
Edit
Open Profile
```

Edit supports:

```text
Name
WhatsApp
Email
Default Address
Notes
Status
```

Derived CRM fields are not manually editable:

```text
RFM
Historical Value
Completed Orders
AOV
Favorite Product
Recency
Segment
```

They continue to be calculated from operational history.

## Product Edit

Product rows now have Edit.

Editable:

```text
Product Name
SKU
Category
Selling Price
Status
Image URL
```

The modal includes a live image preview.

## Material Edit

Ingredient and Packaging rows now have Edit.

Editable:

```text
Name
Category
Base Unit
Purchase Unit
Conversion Factor
Purchase Unit Cost
Minimum Stock
Status
```

Material type cannot be changed after creation.

## Supplier Edit

Supplier rows now have Edit.

Editable:

```text
Supplier Name
Contact Person
WhatsApp
Email
Lead Time
Minimum Order Value
Address
Notes
Status
```

## Product images

Existing `PRODUCTS.image_url` is now rendered in:

```text
Products → Product Master
New Order → selected Product row
Product Edit → live image preview
```

Behavior:

```text
valid image URL
→ image thumbnail

empty / broken URL
→ bakery/product fallback icon
```

No schema migration is required because `image_url` already exists in the PRODUCTS sheet.

## Permissions

Edit buttons only render when the current role already has the corresponding write permission.

No permission broadening is introduced.

## Health guard

`runPhase16HealthCheck()` now includes:

```text
QA_HOTFIX_04_EDIT_AND_IMAGES
```

Expected:

```text
true
Editable Customer/Product/Material/Supplier masters + linked product image thumbnails loaded
```

## Install from QA Hotfix 03

Replace:

```text
JsCustomers.html
JsProducts.html
PageProducts.html
JsPurchasing.html
PagePurchasing.html
JsOrders.html
StylesComponents.html
StylesResponsive.html
Phase16HealthCheck.gs
```

No upgrade function is required.

Then run:

```javascript
runPhase16HealthCheck()
```

and continue manual QA.
