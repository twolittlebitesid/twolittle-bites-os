# QA_HOTFIX_03_INTEGRITY.md
# P0 — False Data Integrity Failure from Derived Metric Caches

## Symptom

Phase 16 Health Check returned:

```text
DATA_INTEGRITY = false
5452 issue(s) across 2 group(s)
```

while the rest of the system checks passed.

## Root cause

`DAILY_METRICS` and `MONTHLY_METRICS` are derived caches.

Their rows are uniquely identified by:

```text
DAILY_METRICS
metric_date + metric_key

MONTHLY_METRICS
month + metric_key
```

The Phase 15 integrity checker incorrectly applied the Schema's single `primaryKey`
field literally:

```text
DAILY_METRICS.primaryKey = metric_date
MONTHLY_METRICS.primaryKey = month
```

A single date legitimately has many metric rows, for example:

```text
2026-10-01 | OPERATING_REVENUE
2026-10-01 | COMPLETED_ORDERS
2026-10-01 | CASH_IN
2026-10-01 | MARKETING_SPEND
...
```

Therefore every second and subsequent metric on the same date/month was falsely
reported as a duplicate.

This explains both characteristics of the runtime result:

```text
2 issue groups
thousands of issues
```

The two groups are expected to have been:

```text
PK_DAILY_METRICS
PK_MONTHLY_METRICS
```

## Fix

The integrity engine now uses explicit composite keys for these two caches:

```text
DAILY_METRICS  → metric_date + metric_key
MONTHLY_METRICS → month + metric_key
```

All other sheets continue using their normal canonical primary key.

The check is not disabled. It will still report:
- blank metric date/month;
- blank metric key;
- a true duplicate of the same date/month + metric key.

## Added health guard

Phase 16 Health now includes:

```text
DERIVED_CACHE_COMPOSITE_KEYS
```

Expected:

```text
true
DAILY_METRICS = metric_date + metric_key
MONTHLY_METRICS = month + metric_key
```

## Focused diagnostic

If DATA_INTEGRITY is still false after this hotfix:

```javascript
runQAHotfix03IntegrityDiagnostic()
```

This prints the exact remaining issue groups, counts, and up to 10 examples per group.

## Installation

From QA Hotfix 02, replace:

```text
SystemHardeningService.gs
Phase16HealthCheck.gs
```

No upgrade function or schema migration is required.

Then run:

```javascript
runPhase16HealthCheck()
```

If DATA_INTEGRITY still fails:

```javascript
runQAHotfix03IntegrityDiagnostic()
```

Do not mark RELEASED until real remaining integrity issues are understood.
