/**
 * Recipe scaling engine.
 */

function calculateScalingPlan_(baseYield, targetQuantity, scalingMode) {
  const base = requirePositive_(baseYield, 'base_yield');
  const target = requirePositive_(targetQuantity, 'target_quantity');
  const mode = String(scalingMode || 'EXACT').toUpperCase();
  assertOneOf_(mode, ['EXACT', 'FULL_BATCH'], 'scaling_mode');

  if (mode === 'FULL_BATCH') {
    const batches = Math.ceil(target / base);
    const expectedOutput = batches * base;
    return {
      scalingMode: mode,
      multiplier: batches,
      requiredBatches: batches,
      expectedOutput: expectedOutput,
      expectedSurplus: expectedOutput - target
    };
  }

  const multiplier = target / base;
  return {
    scalingMode: mode,
    multiplier: multiplier,
    requiredBatches: multiplier,
    expectedOutput: target,
    expectedSurplus: 0
  };
}

function scaleRecipe(recipeId, targetQuantity, modeOverride) {
  requirePermission_('RECIPE_READ');

  const detail = getRecipeDetail_(recipeId);
  const recipe = detail.recipe;
  const mode = modeOverride
    ? String(modeOverride).toUpperCase()
    : recipe.scaling_mode;

  const plan = calculateScalingPlan_(
    recipe.base_yield,
    targetQuantity,
    mode
  );

  let totalCost = 0;
  const requirements = detail.items.map(function(item) {
    const wastePct = Number(item.waste_allowance_pct || 0);
    const quantityWithWasteBase =
      Number(item.quantity_base) * (1 + wastePct / 100);
    const requiredBase =
      quantityWithWasteBase * Number(plan.multiplier);
    const unitCost =
      getItemCostPerBaseUnit_(item.item_type, item.item_id);
    const lineCost = requiredBase * unitCost;
    totalCost += lineCost;

    return {
      recipeItemId: item.recipe_item_id,
      itemType: item.item_type,
      itemId: item.item_id,
      itemName: item.item_name,
      enteredQuantity: Number(item.quantity),
      enteredUnit: item.unit,
      baseQuantity: Number(item.quantity_base),
      wasteAllowancePct: wastePct,
      requiredQtyBase: roundNumber_(requiredBase, 6),
      baseUnit: item.base_unit,
      costPerBaseUnit: roundNumber_(unitCost, 6),
      estimatedLineCost: Math.round(lineCost)
    };
  });

  const estimatedBatchCost = Math.round(totalCost);
  const outputQuantity = Number(plan.expectedOutput);
  const estimatedCogsPerOutput =
    outputQuantity > 0
      ? Math.round(estimatedBatchCost / outputQuantity)
      : 0;

  return {
    recipe: recipe,
    product: detail.product,
    variant: detail.variant,
    targetQuantity: Number(targetQuantity),
    targetUnit: recipe.yield_unit,
    scalingMode: plan.scalingMode,
    multiplier: roundNumber_(plan.multiplier, 6),
    requiredBatches: roundNumber_(plan.requiredBatches, 6),
    expectedOutput: roundNumber_(plan.expectedOutput, 6),
    expectedSurplus: roundNumber_(plan.expectedSurplus, 6),
    requirements: requirements,
    estimatedBatchCost: estimatedBatchCost,
    estimatedCogsPerOutput: estimatedCogsPerOutput
  };
}
