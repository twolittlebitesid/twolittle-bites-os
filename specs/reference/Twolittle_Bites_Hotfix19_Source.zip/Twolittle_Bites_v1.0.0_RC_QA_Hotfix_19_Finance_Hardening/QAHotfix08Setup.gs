/**
 * Twolittle.bites OS — QA Hotfix 08 setup helpers.
 */

function upgradeToQAHotfix08() {
  var user =
    requirePermission_(
      'SETTINGS_WRITE'
    );

  var current =
    String(
      getBusinessSetting_(
        'invoice_whatsapp_template'
      ) ||
      settingsDefaultInvoiceWhatsAppTemplate_()
    );

  var updated =
    current;

  if (
    updated.indexOf(
      '{invoice_pdf_url}'
    ) < 0 &&
    updated.indexOf(
      '{invoice_url}'
    ) >= 0
  ) {
    updated =
      updated.replace(
        /\{invoice_url\}/g,
        '{invoice_pdf_url}'
      );
  }

  updated =
    settingsValidateWhatsAppTemplate_(
      updated
    );

  var changed =
    updated !==
    current;

  if (changed) {
    setBusinessSetting_(
      'invoice_whatsapp_template',
      updated,
      'STRING',
      'WHATSAPP',
      'Invoice WhatsApp template using public Google Drive PDF link.',
      user.user_id
    );

    writeAuditLog_(
      'UPDATE',
      'BUSINESS_SETTINGS',
      'INVOICE_WHATSAPP_TEMPLATE',
      {
        invoice_whatsapp_template:
          current
      },
      {
        invoice_whatsapp_template:
          updated
      },
      'QA Hotfix 08 switched invoice link placeholder to {invoice_pdf_url}.'
    );
  }

  return {
    ok:
      true,
    templateChanged:
      changed,
    template:
      updated,
    health:
      runPhase16HealthCheck()
  };
}

function backfillInvoicePdfsQAHotfix08(
  limit
) {
  requirePermission_(
    'INVOICE_WRITE'
  );

  var maxRows =
    Math.max(
      1,
      Math.min(
        25,
        Number(limit || 10)
      )
    );

  var invoices =
    listAllRecords_(
      'INVOICES'
    );

  var candidates =
    invoices
      .filter(
        function(invoice) {
          return !getInvoicePdfArchiveInfo_(
            invoice.invoice_id
          );
        }
      )
      .slice(
        0,
        maxRows
      );

  var generated = [];
  var failed = [];

  candidates.forEach(
    function(invoice) {
      try {
        var info =
          generateInvoicePdfArchive_(
            invoice.invoice_id,
            'QA_HOTFIX_08_BACKFILL'
          );

        generated.push({
          invoiceId:
            invoice.invoice_id,
          invoiceNumber:
            invoice.invoice_number,
          downloadUrl:
            info.downloadUrl
        });
      } catch (e) {
        failed.push({
          invoiceId:
            invoice.invoice_id,
          invoiceNumber:
            invoice.invoice_number,
          error:
            e.message ||
            String(e)
        });
      }
    }
  );

  var remaining =
    Math.max(
      0,
      invoices.filter(
        function(invoice) {
          return !getInvoicePdfArchiveInfo_(
            invoice.invoice_id
          );
        }
      ).length
    );

  return {
    ok:
      failed.length === 0,
    attempted:
      candidates.length,
    generated:
      generated,
    failed:
      failed,
    remainingWithoutPdf:
      remaining
  };
}
