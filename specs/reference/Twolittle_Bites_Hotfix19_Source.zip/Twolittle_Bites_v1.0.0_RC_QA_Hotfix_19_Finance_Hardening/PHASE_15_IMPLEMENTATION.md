# PHASE_15_IMPLEMENTATION.md
# Twolittle.bites OS — System Hardening & Automation

**Phase:** 15  
**App Version:** 0.15.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Scope

Phase 15 hardens the existing application rather than adding another business domain.

```text
Diagnostics
Integrity Checks
Cross-module Regression
Performance Optimization
Error Ring Buffer
Exact Database Backup
Non-destructive Recovery Copy
Scheduled Maintenance
```

## 1. Performance optimization

### Internal full-sheet reads

Before Phase 15, `listAllRecords_()` repeatedly called paginated `dbList()`.

Phase 15 changes internal full-table reads to:

```text
1 Sheet
→ 1 getRange()
→ 1 getValues()
```

`dbList()` remains available for paginated repository usage.

This reduces Apps Script / Spreadsheet round trips across:
- Orders
- Finance
- CRM
- Production
- Inventory
- Purchasing
- Pre-orders
- Marketing
- Reports
- Settings

### CONFIG / BUSINESS_SETTINGS read cache

`getConfig_()` and `getBusinessSetting_()` now use:

```text
CacheService.getScriptCache()
TTL = 300 seconds
```

Writes invalidate the affected cache key immediately.

Authentication is intentionally **not** cached, so user deactivation / role changes do not inherit a 5-minute access delay.

## 2. Lock hardening

Inventory posting previously had a potential nested ScriptLock path:

```text
Inventory write lock
↓
getOrCreateInventoryRow_()
↓
nextBusinessId()
↓
ScriptLock
```

Phase 15 ensures required Inventory rows **before** entering critical stock-write locks, then re-reads them inside the lock.

Applied to:
- manual Inventory movement
- Production Usage posting

Movement IDs continue to be reserved before stock-write locks.

## 3. Error ring buffer

`ApiGateway.gs` keeps normal Cloud / Stackdriver error output.

Phase 15 additionally stores the latest 50 RPC error metadata entries in Script Properties.

Stored:

```text
timestamp
request_id
action
error code
message
stack
resolved Google email
```

Not stored:

```text
RPC payload
payment details
customer address
order contents
```

The Diagnostics UI returns at most 25 recent entries.

The ring buffer can be cleared from Settings → Diagnostics.

## 4. Consolidated integrity diagnostics

Diagnostics validate:

### Primary keys
- blank primary IDs
- duplicate primary IDs

Across all 33 canonical sheets.

### Core references
Examples:

```text
Order → Customer
Order Item → Order
Order Item → Product
Invoice → Order
Invoice → Customer
Payment → Invoice
Payment → Order
Production Item → Plan
Production Requirement → Plan
Inventory → Ingredient / Packaging
Purchase → Supplier
Purchase Item → Purchase
Content → Marketing Campaign
Marketing Attribution → Order / Campaign / Content
Marketing Expense Link → Expense / Campaign
```

### Financial arithmetic

```text
Invoice Remaining
=
Grand Total - Paid Amount
```

and Purchase receipt quantity must not exceed ordered quantity.

### Inventory ledger

Uses existing Inventory reconciliation:

```text
INVENTORY.current_stock_base
vs
Σ INVENTORY_MOVEMENTS
```

### OWNER protection

Diagnostics requires:

```text
ACTIVE OWNER >= 1
```

## 5. Cross-module regression

Run:

```javascript
runPhase15RegressionSuite()
```

This is read-only.

It bootstraps:

```text
Products
Customers
Orders
Finance
Production
Inventory
Purchasing
Pre-orders
Marketing
Reports
Settings
```

and reports pass/fail + duration per module.

The same suite is available from Settings → Diagnostics → Regression.

## 6. Exact database backups

Backup source:

```text
current TWB database Google Spreadsheet
```

Phase 15 uses Drive `makeCopy()`.

This preserves:
- all 33 sheets
- cell values
- spreadsheet-native types
- formatting
- sheet structure

Backup folder:

```text
Twolittle.bites OS Backups
```

The folder ID is stored in:

```text
CONFIG.SYSTEM_BACKUP_FOLDER_ID
```

After copying, Phase 15 verifies:
- all 33 canonical sheets exist;
- every canonical header matches Schema.gs.

A failed verification trashes the invalid backup copy.

Manual backup:

```javascript
createSystemBackupPhase15()
```

OWNER only.

## 7. Non-destructive recovery

Recovery does **not** overwrite production.

Use:

```javascript
createRecoveryCopyFromBackupPhase15(backupFileId)
```

Flow:

```text
Backup
↓
Schema verification
↓
New RECOVERY COPY spreadsheet
↓
Schema verification
```

Current `TWB_SPREADSHEET_ID` is never changed automatically.

Database switchover remains an explicit production-release decision.

## 8. Backup retention

Default:

```text
SYSTEM_BACKUP_RETENTION_DAYS = 30
```

Scheduled/manual maintenance moves backups older than retention to Trash.

Allowed configuration range is handled through Config rather than adding a sheet.

## 9. Scheduled maintenance

Phase 15 does **not** silently create a trigger during upgrade.

OWNER must explicitly run:

```javascript
configurePhase15MaintenanceAutomation()
```

or use Settings → Diagnostics.

Schedule:

```text
Daily around 02:15
Asia/Jakarta
```

Maintenance can perform:

```text
Verified Database Backup
↓
Report Cache Rebuild
↓
Old Backup Cleanup
```

Controls:

```text
SYSTEM_BACKUP_ENABLED
SYSTEM_REPORT_CACHE_REBUILD_ENABLED
```

Remove trigger:

```javascript
removePhase15MaintenanceAutomation()
```

Manual run:

```javascript
runPhase15MaintenanceNow()
```

## 10. Diagnostics UI

Phase 15 adds:

```text
Settings
└── Diagnostics
```

Visible to:

```text
OWNER
ADMIN
```

OWNER-only controls:
- Backup Now
- Recovery Copy
- Configure Trigger
- Remove Trigger
- Run Maintenance Now

ADMIN can:
- run integrity diagnostics
- run cross-module regression
- review recent server errors

FINANCE keeps Settings read-only but does not receive Diagnostics controls.

## 11. Phase 15 upgrade

Run as OWNER:

```javascript
upgradeToPhase15()
```

Sets / preserves:

```text
APP_VERSION = 0.15.0
SCHEMA_VERSION = 1.0.0

SYSTEM_HARDENING_MODE = PHASE15
SYSTEM_BACKUP_RETENTION_DAYS = 30
SYSTEM_BACKUP_ENABLED = TRUE
SYSTEM_REPORT_CACHE_REBUILD_ENABLED = TRUE
SYSTEM_INTERNAL_READ_MODE = SINGLE_RANGE_FULL_SHEET
SYSTEM_CONFIG_CACHE_TTL_SECONDS = 300
```

No trigger is created automatically.

No database Sheet is recreated.

## 12. Validation order

Run:

```javascript
upgradeToPhase15()
runPhase15HealthCheck()
runPhase15SmokeTest()
runPhase15RegressionSuite()
```

Only after those pass, optionally run:

```javascript
createSystemBackupPhase15()
configurePhase15MaintenanceAutomation()
```

## Health Check

Expected groups:

```text
DATA_FOUNDATION
PHASE15_SERVICES
CONFIG_APP_VERSION
FAST_FULL_SHEET_READ
CONFIG_READ_CACHE
DATA_INTEGRITY
AUTOMATION_CAPABILITY
SYSTEM_DIAGNOSTICS_BOOTSTRAP
PHASE15_API_GATEWAY
PHASE15_UI_PARTIALS
```

`DATA_INTEGRITY` intentionally fails when the existing database contains real orphan/mismatch issues. Fix or reconcile the underlying data rather than bypassing the check.

## Smoke Test

Expected:

```text
RPC_SYSTEM_DIAGNOSTICS
FULL_READ_PARITY
PERFORMANCE_PROFILE
ERROR_RING_BUFFER_READ
HARDENING_UI_RENDER
RPC_ERROR_ENVELOPE_REGRESSION
```

The final error-envelope smoke deliberately calls an unknown RPC action. This adds one expected `UNKNOWN_API_ACTION` entry to the diagnostic error ring buffer; it does not mutate business data.

## Browser QA

1. Open Settings → Diagnostics.
2. Run Diagnostics.
3. Confirm Integrity status.
4. Run Regression.
5. Confirm all module bootstraps pass.
6. OWNER: click Backup Now.
7. Open the generated Google Sheet backup.
8. Use Recovery Copy and verify production DB stays unchanged.
9. Configure Daily Trigger.
10. Run Maintenance Now once.
11. Confirm:
   - backup created;
   - report cache rebuilt;
   - Diagnostics remains healthy.
12. Check ordinary flows after the performance optimization:
   - Orders
   - Products
   - Finance
   - Production
   - Inventory
   - Purchasing
   - Customers
   - Marketing
   - Reports
13. Verify no stale Phase 7 runtime-diagnostic instruction remains in browser RPC errors.

## Next

**Phase 16 — Production Release / v1.0**
