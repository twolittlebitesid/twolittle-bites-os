# QA_HOTFIX_12_FULL_UI_CONSISTENCY.md

# P0 — Full UI Consistency + Product Image Reload Repair

## Findings closed

```text
P0 — Product image link exists but thumbnail does not reload reliably.
P0 — Too many repeated KPI/card groups after Experience Upgrade 11.
P0 — Search should be above the card area on every page.
P0 — QA the whole UI, not only the reported page.
```

## Product image repair

The client now uses a reusable image loading chain:

1. Direct image URL / normalized Dropbox URL.
2. Google Drive thumbnail URL when a Drive file ID is detected.
3. Google Drive `uc?export=view` fallback.
4. Product icon fallback when all candidates fail.

Every Product image is versioned using:

```text
product.updated_at
```

so saving an edited Product invalidates the old browser image cache without forcing a new image download on every normal render.

The same loader is used in:

- Product Master thumbnail;
- Product Edit live preview;
- New Order Product thumbnail.

## Duplicate card cleanup

Experience Upgrade 11 had added a second KPI/card layer above native page KPIs. That created visual repetition.

Hotfix 12 removes those duplicate experience KPI cards.

The existing page-owned KPI cards remain the source of page summary information.

The Experience layer is now limited to:

- search / filter utility;
- compact Order pipeline strip;
- compact Inventory restock list;
- compact Reports previous-period comparison.

No second KPI grid is generated.

## Search position

Every production page now has a search utility slot physically placed before its first card/loading/period-card area:

```text
Executive
Business
Orders
Customers
Products
Production
Inventory
Purchasing
Finance
Marketing
Reports
Settings
```

Pages with server/client data filters use their native data state:

- Orders;
- Customers;
- Products;
- Inventory.

Other pages use a lightweight DOM text filter against the visible table/list records for the active tab.

Search does not filter or mutate source data.

## QA scope

Static QA verifies:

- every `.gs` file parses;
- every client `Js*.html` script parses;
- all Index includes resolve;
- all 12 page templates have a top search utility slot;
- no duplicate DOM IDs inside each page template;
- duplicate Experience KPI card renderer is gone;
- image loader uses versioned URL candidates;
- route cache remains mounted / no menu reload regression;
- reduced-motion CSS remains present;
- all prior Hotfix health guards remain present;
- 33 canonical sheet schema remains unchanged;
- Permissions file is unchanged from Hotfix 11.

Runtime QA is still required for actual browser image access because a Google Drive file can only load if its sharing policy allows the webapp browser to fetch it.
