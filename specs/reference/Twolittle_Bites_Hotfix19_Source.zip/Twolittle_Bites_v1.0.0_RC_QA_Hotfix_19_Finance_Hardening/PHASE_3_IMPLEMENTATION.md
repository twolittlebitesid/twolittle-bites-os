# PHASE_3_IMPLEMENTATION.md
# Twolittle.bites OS — Product & Recipe Engine

**Phase:** 3  
**App Version:** 0.3.0  
**Schema Version:** 1.0.0  
**Database Migration:** Not required

---

## What is activated

### Product Master
- Products
- Variants
- SKU
- Category
- Selling price
- Status
- Current COGS / gross profit / gross margin cache

### Material Master
- Ingredients
- Packaging
- Base unit
- Purchase unit
- Purchase → base conversion factor
- Purchase unit cost
- Latest cost per base unit
- Initial zero inventory cache row

### Recipe / BOM
- Product / optional Variant
- Base Yield
- Yield Unit
- EXACT / FULL_BATCH
- Recipe Version
- Recipe Items
- Waste Allowance
- Draft → Active
- Active recipe replaces the previous active version for the same Product/Variant

### Unit Conversion
Built-in:
```text
kg ↔ g
mg ↔ g
liter ↔ ml
dozen ↔ pcs
```

Material purchase conversion:
```text
1 pack mascarpone = 500 g
```

Custom item conversion is supported through `UNIT_CONVERSIONS`.

### Recipe Calculator
Core:
```text
multiplier = target / base_yield
required = normalized_base_qty × (1 + waste%) × multiplier
```

FULL_BATCH:
```text
required_batches = CEILING(target / base_yield)
expected_output = required_batches × base_yield
surplus = expected_output - target
```

### Basic COGS
Phase 3 cost basis:
```text
latest_cost_per_base_unit
```

Falls back to average cost when latest cost is zero.

Recipe:
```text
Batch COGS = Σ(material qty incl. waste × cost/base unit)
Unit COGS  = Batch COGS / Base Yield
```

Activating a base-product recipe recalculates:
```text
PRODUCTS.current_cogs
PRODUCTS.gross_profit
PRODUCTS.gross_margin_pct
```

---

## Installation — from the current working Phase 2 project

Use `Twolittle_Bites_Phase_3_Delta.zip`.

### Replace existing files
```text
Constants.gs
AppShellService.gs
ApiGateway.gs
Index.html
PageProducts.html
JsApp.html
StylesComponents.html
StylesResponsive.html
ComponentQuickActions.html
```

### Add new files
```text
ServiceUtils.gs
ProductService.gs
UnitService.gs
CogsService.gs
RecipeService.gs
RecipeScalingService.gs
Phase3Setup.gs
Phase3HealthCheck.gs
Phase3SmokeTest.gs
JsProducts.html
```

Keep all working Phase 1 / Phase 2 files.

Do not add:
```text
phase3_manifest.json
```
to Apps Script.

---

## One-time upgrade

After adding the files:

```javascript
upgradeToPhase3()
```

This:
- validates the existing 33-sheet schema;
- keeps Schema Version `1.0.0`;
- updates CONFIG app version to `0.3.0`;
- adds `RECIPE_COST_BASIS = LATEST_COST`;
- runs Phase 3 health check.

It does not recreate or clear any sheet.

---

## Verification

Run:

```javascript
runPhase3HealthCheck()
```

Then:

```javascript
runPhase3SmokeTest()
```

Both should return:
```text
ok: true
phase: 3
appVersion: 0.3.0
schemaVersion: 1.0.0
```

---

## Browser test

Update the Web App deployment and open Products.

Expected tabs:
```text
Overview
Products
Materials
Recipes / BOM
Recipe Calculator
```

Recommended first live test:
1. Create Mascarpone:
   - Base Unit: g
   - Purchase Unit: pack
   - Factor: 500
   - Purchase Cost: e.g. Rp 75,000
2. Create Cream:
   - Base Unit: ml
   - Purchase Unit: liter
   - Factor: 1000
3. Create Product.
4. Create Recipe Base Yield 10.
5. Activate Recipe.
6. Open Calculator and target 5 / 20 / 27.

No sample business rows are inserted automatically.

---

## Performance hardening

`products.bootstrap` reads Products, Variants, Ingredients, Packaging, Recipes and Recipe Items in batched table reads, then joins/calculates recipe summary in memory.

It does **not** call Google Sheets once per recipe row.
