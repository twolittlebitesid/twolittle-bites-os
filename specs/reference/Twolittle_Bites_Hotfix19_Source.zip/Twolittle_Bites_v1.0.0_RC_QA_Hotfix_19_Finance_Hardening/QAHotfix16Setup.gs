/**
 * QA Hotfix 16 — WhatsApp delivery fee placeholder.
 */

function upgradeToQAHotfix16() {
  var user = requirePermission_(
    'SETTINGS_WRITE'
  );

  var current = String(
    getBusinessSetting_(
      'invoice_whatsapp_template'
    ) ||
    settingsDefaultInvoiceWhatsAppTemplate_()
  );

  var updated = current;
  var changed = false;

  if (
    updated.indexOf(
      '{delivery_fee}'
    ) < 0
  ) {
    updated = updated.replace(
      /(^|\n)(Ongkir\s*:\s*)(?=\n|$)/i,
      '$1$2{delivery_fee}'
    );

    changed =
      updated !== current;
  }

  if (changed) {
    settingsValidateWhatsAppTemplate_(
      updated
    );

    setBusinessSetting_(
      'invoice_whatsapp_template',
      updated,
      'STRING',
      'INVOICE',
      'WhatsApp invoice template.',
      user.user_id
    );

    writeAuditLog_(
      'UPDATE',
      'BUSINESS_SETTINGS',
      'invoice_whatsapp_template',
      { value: current },
      { value: updated },
      'QA Hotfix 16 filled an existing empty Ongkir line with {delivery_fee}.'
    );
  }

  return {
    ok: true,
    templateUpdated: changed,
    placeholderSupported:
      settingsAllowedWhatsAppPlaceholders_()
        .indexOf(
          'delivery_fee'
        ) >= 0,
    template: updated,
    health: runPhase16HealthCheck()
  };
}
