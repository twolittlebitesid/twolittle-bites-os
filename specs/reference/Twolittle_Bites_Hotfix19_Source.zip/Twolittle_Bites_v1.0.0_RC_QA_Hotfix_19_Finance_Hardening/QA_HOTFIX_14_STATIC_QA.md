# QA_HOTFIX_14_STATIC_QA.md

- Server `.gs` syntax: PASS (62 files)
- Client `Js*.html` syntax: PASS (18 files)
- Index include references: PASS
- Duplicate DOM IDs inside Page templates: PASS
- Printing Settings UI/service/API: PASS
- 58/80 mm receipt templates: PASS
- Auto-print-after-payment client flow: PASS
- Order + Finance Print Receipt actions: PASS
- Kitchen Ticket internal-auth route: PASS
- Public-token kitchen-note leak prevented: PASS
- Hotfix 13 Invoice/Image/Payment behavior preserved: PASS
- Route cache / no-menu-reload preserved: PASS
- Reduced-motion support preserved: PASS
- Phase16 Hotfix 14 health guard: PASS
- Phase16 Hotfix 14 smoke guard: PASS
- Canonical sheet count unchanged: PASS (33/33)
- Sheet schema migration required: NO
- Data rewrite required: NO
- App Version: 1.0.0
- Schema Version: 1.0.0

Runtime/manual boundary:
- browser print dialog and physical thermal printer cannot be verified statically;
- actual printer driver, paper size, margins, and popup policy must be tested on the cashier device.
