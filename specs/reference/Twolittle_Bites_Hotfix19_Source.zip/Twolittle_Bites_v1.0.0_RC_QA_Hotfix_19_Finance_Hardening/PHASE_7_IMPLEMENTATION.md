# PHASE_7_IMPLEMENTATION.md
# Twolittle.bites OS — Inventory Engine

**Phase:** 7  
**App Version:** 0.7.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Source of truth

```text
INVENTORY_MOVEMENTS
↓
ledger balance
↓
INVENTORY.current_stock_base
```

Do not manually edit `current_stock_base`.

## Movement types

IN:
- OPENING_BALANCE
- MANUAL_IN
- ADJUSTMENT_IN
- RETURN_IN
- PURCHASE_RECEIPT (reserved for Phase 8)

OUT:
- MANUAL_OUT
- ADJUSTMENT_OUT
- PRODUCTION_USAGE
- WASTE

## Upgrade behavior

`upgradeToPhase7()`:
1. validates the existing 33-sheet schema;
2. sets app version to `0.7.0`;
3. creates any missing INVENTORY cache rows at zero;
4. for a material that already has non-zero cached stock but no movement history, creates one `OPENING_BALANCE` movement;
5. runs Phase 7 health check.

This establishes the ledger without destroying existing stock.

## Negative stock

`NEGATIVE_STOCK_ALLOWED` remains `false` by default.

Any OUT movement that would make stock negative is blocked.

## Production usage

Phase 7 can post the frozen `PRODUCTION_REQUIREMENTS` from a Production Plan.

```text
Production Plan
↓
Material Requirements
↓
PRODUCTION_USAGE movements
↓
Inventory decreases
```

Guardrails:
- usage can only be posted once per Production Plan;
- PLANNED / IN_PROGRESS / COMPLETED are accepted;
- shortage blocks posting when negative stock is disabled;
- the Production Plan status is not changed automatically.

This is planned consumption, not batch-level actual variance.

## Stock adjustment

Physical count:

```text
cached stock = 920 g
physical count = 900 g
↓
ADJUSTMENT_OUT 20 g
↓
new balance = 900 g
```

## Reconciliation

Inventory Overview compares cached stock to the sum of its movement ledger.

OWNER / ADMIN can run:

```javascript
rebuildInventoryBalancesFromLedger()
```

This overwrites cached balances from the ledger source of truth.

## Installation

Use `Twolittle_Bites_Phase_7_Delta.zip`.

Replace:
- Constants.gs
- AppShellService.gs
- ApiGateway.gs
- Index.html
- JsApp.html
- PageInventory.html
- StylesComponents.html
- StylesResponsive.html

Add:
- InventoryService.gs
- JsInventory.html
- Phase7Setup.gs
- Phase7HealthCheck.gs
- Phase7SmokeTest.gs

## Run

```javascript
upgradeToPhase7()
runPhase7HealthCheck()
runPhase7SmokeTest()
```

## Browser QA

1. Open Inventory.
2. Confirm materials appear.
3. Post Stock In.
4. Post Stock Out.
5. Record Physical Count adjustment.
6. Record Waste.
7. Check Movements ledger.
8. Check cached balance.
9. Open Production Usage.
10. Post one eligible Production Plan.
11. Confirm movements and stock decrease.
12. Confirm same Production Plan cannot be posted twice.

## Phase boundary

Phase 7 does not create supplier purchases.

Next: **Phase 8 — Purchasing Engine**.
