/**
 * Twolittle.bites OS — Phase 16 / v1.0 upgrade.
 *
 * This marks the codebase as the v1.0 release candidate.
 * It does NOT create an Apps Script deployment automatically.
 */
function upgradeToPhase16() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER
    ]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'RELEASE_VERSION',
    '1.0.0',
    'STRING',
    'Current production release candidate version.',
    user.user_id
  );

  setConfig_(
    'RELEASE_CHANNEL',
    'PRODUCTION',
    'STRING',
    'Release channel for v1.0.',
    user.user_id
  );

  if (
    getConfig_(
      'RELEASE_STATUS'
    ) === null
  ) {
    setConfig_(
      'RELEASE_STATUS',
      'PRE_RELEASE',
      'STRING',
      'Internal production release status.',
      user.user_id
    );
  }

  setConfig_(
    'RELEASE_FEATURE_FREEZE',
    true,
    'BOOLEAN',
    'Feature scope is frozen for v1.0; only release-blocking fixes should be added.',
    user.user_id
  );

  setConfig_(
    'RELEASE_PREFLIGHT_BACKUP_MAX_HOURS',
    24,
    'NUMBER',
    'Maximum age of the verified database backup accepted by release preflight.',
    user.user_id
  );

  setConfig_(
    'RELEASE_MANUAL_DEPLOYMENT_REQUIRED',
    true,
    'BOOLEAN',
    'Apps Script deployment versioning remains an explicit manual release action.',
    user.user_id
  );

  setConfig_(
    'RELEASE_DOCUMENTATION_VERSION',
    '1.0.0',
    'STRING',
    'Operator / deployment / rollback documentation version.',
    user.user_id
  );

  return runPhase16HealthCheck();
}
