/**
 * Products, variants, ingredients and packaging.
 */

function productModuleBootstrap() {
  requireAnyPermission_(['PRODUCT_READ', 'RECIPE_READ']);

  const products = listAllRecords_('PRODUCTS').map(stripInternalFields_);
  const variants = listAllRecords_('PRODUCT_VARIANTS').map(stripInternalFields_);
  const ingredients = listAllRecords_('INGREDIENTS').map(stripInternalFields_);
  const packaging = listAllRecords_('PACKAGING').map(stripInternalFields_);
  const recipes = listAllRecords_('RECIPES').map(stripInternalFields_);
  const recipeItems = listAllRecords_('RECIPE_ITEMS').map(stripInternalFields_);

  const productMap = {};
  products.forEach(function(row) { productMap[row.product_id] = row; });
  const variantMap = {};
  variants.forEach(function(row) { variantMap[row.variant_id] = row; });
  const ingredientMap = {};
  ingredients.forEach(function(row) { ingredientMap[row.ingredient_id] = row; });
  const packagingMap = {};
  packaging.forEach(function(row) { packagingMap[row.packaging_id] = row; });

  const recipeItemGroups = {};
  recipeItems.forEach(function(item) {
    if (!recipeItemGroups[item.recipe_id]) recipeItemGroups[item.recipe_id] = [];
    recipeItemGroups[item.recipe_id].push(item);
  });

  const recipeSummaries = recipes.map(function(recipe) {
    const rows = recipeItemGroups[recipe.recipe_id] || [];
    let batchCogs = 0;

    rows.forEach(function(item) {
      const material = item.item_type === 'INGREDIENT'
        ? ingredientMap[item.item_id]
        : packagingMap[item.item_id];

      if (!material) return;

      const latest = Number(material.latest_cost_per_base_unit || 0);
      const average = Number(material.average_cost_per_base_unit || 0);
      const costPerBase = latest > 0 ? latest : average;
      const waste = Number(item.waste_allowance_pct || 0);
      const qty = Number(item.quantity_base || 0) * (1 + waste / 100);
      batchCogs += qty * costPerBase;
    });

    batchCogs = Math.round(batchCogs);
    const baseYield = Number(recipe.base_yield || 0);
    const unitCogs = baseYield > 0 ? Math.round(batchCogs / baseYield) : 0;

    return Object.assign({}, recipe, {
      product_name: productMap[recipe.product_id]
        ? productMap[recipe.product_id].product_name
        : recipe.product_id,
      variant_name: recipe.variant_id && variantMap[recipe.variant_id]
        ? variantMap[recipe.variant_id].variant_name
        : '',
      batch_cogs: batchCogs,
      unit_cogs: unitCogs,
      item_count: rows.length
    });
  });

  return {
    products: products,
    variants: variants,
    ingredients: ingredients,
    packaging: packaging,
    recipes: recipeSummaries,
    units: {
      weight: ['mg', 'g', 'kg'],
      volume: ['ml', 'liter'],
      count: ['pcs', 'dozen', 'tray', 'pack', 'box', 'carton', 'cup']
    },
    permissions: {
      productWrite: hasPermission_(requireCurrentUser_(), 'PRODUCT_WRITE'),
      recipeWrite: hasPermission_(requireCurrentUser_(), 'RECIPE_WRITE')
    }
  };
}

function createProduct(payload) {
  const user = requirePermission_('PRODUCT_WRITE');
  payload = payload || {};

  const name = normalizeText_(payload.product_name);
  const sku = normalizeSku_(payload.sku);
  const category = normalizeText_(payload.category);
  const price = requireNonNegative_(payload.selling_price, 'selling_price');
  const status = String(payload.status || 'ACTIVE').toUpperCase();

  if (!name) throw twbError_('VALIDATION_REQUIRED', 'Product name is required.');
  if (!sku) throw twbError_('VALIDATION_REQUIRED', 'SKU is required.');
  if (!category) throw twbError_('VALIDATION_REQUIRED', 'Category is required.');
  assertOneOf_(status, ['ACTIVE', 'INACTIVE', 'SEASONAL', 'ARCHIVED'], 'status');

  const record = stampCreate_(user, {
    product_id: nextBusinessId('PRODUCT'),
    sku: sku,
    product_name: name,
    category: category,
    selling_price: price,
    base_recipe_id: '',
    default_packaging_id: '',
    image_url: normalizeText_(payload.image_url),
    current_cogs: 0,
    gross_profit: price,
    gross_margin_pct: price > 0 ? 100 : 0,
    status: status
  });

  return dbInsertRecord('PRODUCTS', record, {
    audit: true,
    action: 'CREATE'
  });
}

function updateProduct(productId, payload) {
  const user = requirePermission_('PRODUCT_WRITE');
  const current = dbFindById('PRODUCTS', productId);
  if (!current) throw twbError_('NOT_FOUND', 'Product not found: ' + productId);

  payload = payload || {};
  const patch = {};

  if (Object.prototype.hasOwnProperty.call(payload, 'product_name')) {
    patch.product_name = normalizeText_(payload.product_name);
    if (!patch.product_name) throw twbError_('VALIDATION_REQUIRED', 'Product name is required.');
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'sku')) {
    patch.sku = normalizeSku_(payload.sku);
    if (!patch.sku) throw twbError_('VALIDATION_REQUIRED', 'SKU is required.');
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'category')) {
    patch.category = normalizeText_(payload.category);
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'selling_price')) {
    patch.selling_price = requireNonNegative_(payload.selling_price, 'selling_price');
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'image_url')) {
    patch.image_url = normalizeText_(payload.image_url);
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'status')) {
    patch.status = String(payload.status).toUpperCase();
    assertOneOf_(patch.status, ['ACTIVE', 'INACTIVE', 'SEASONAL', 'ARCHIVED'], 'status');
  }

  const price = Object.prototype.hasOwnProperty.call(patch, 'selling_price')
    ? Number(patch.selling_price)
    : Number(current.selling_price || 0);
  const cogs = Number(current.current_cogs || 0);
  patch.gross_profit = Math.round(price - cogs);
  patch.gross_margin_pct = price > 0
    ? roundNumber_((patch.gross_profit / price) * 100, 2)
    : 0;

  return dbUpdateById('PRODUCTS', productId, stampUpdate_(user, patch), {
    audit: true,
    action: 'UPDATE'
  });
}

function createProductVariant(payload) {
  const user = requirePermission_('PRODUCT_WRITE');
  payload = payload || {};

  const product = dbFindById('PRODUCTS', payload.product_id);
  if (!product) throw twbError_('NOT_FOUND', 'Product not found: ' + payload.product_id);

  const variantName = normalizeText_(payload.variant_name);
  const sku = normalizeSku_(payload.sku);
  const status = String(payload.status || 'ACTIVE').toUpperCase();

  if (!variantName) throw twbError_('VALIDATION_REQUIRED', 'Variant name is required.');
  if (!sku) throw twbError_('VALIDATION_REQUIRED', 'Variant SKU is required.');
  assertOneOf_(status, ['ACTIVE', 'INACTIVE', 'ARCHIVED'], 'status');

  const record = stampCreate_(user, {
    variant_id: nextBusinessId('VARIANT'),
    product_id: product.product_id,
    variant_name: variantName,
    size: normalizeText_(payload.size),
    sku: sku,
    selling_price_override: optionalNumber_(payload.selling_price_override),
    recipe_id: '',
    status: status
  });

  return dbInsertRecord('PRODUCT_VARIANTS', record, {
    audit: true,
    action: 'CREATE'
  });
}

function updateProductVariant(
  variantId,
  payload
) {
  const user =
    requirePermission_(
      'PRODUCT_WRITE'
    );

  const current =
    dbFindById(
      'PRODUCT_VARIANTS',
      variantId
    );

  if (!current) {
    throw twbError_(
      'NOT_FOUND',
      'Variant not found: ' +
        variantId
    );
  }

  payload = payload || {};

  const patch = {};

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'variant_name'
    )
  ) {
    patch.variant_name =
      normalizeText_(
        payload.variant_name
      );

    if (!patch.variant_name) {
      throw twbError_(
        'VALIDATION_REQUIRED',
        'Variant name is required.'
      );
    }
  }

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'size'
    )
  ) {
    patch.size =
      normalizeText_(
        payload.size
      );
  }

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'sku'
    )
  ) {
    patch.sku =
      normalizeSku_(
        payload.sku
      );

    if (!patch.sku) {
      throw twbError_(
        'VALIDATION_REQUIRED',
        'Variant SKU is required.'
      );
    }
  }

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'selling_price_override'
    )
  ) {
    patch.selling_price_override =
      optionalNumber_(
        payload.selling_price_override
      );
  }

  if (
    Object.prototype.hasOwnProperty.call(
      payload,
      'status'
    )
  ) {
    patch.status =
      String(
        payload.status ||
        ''
      ).toUpperCase();

    assertOneOf_(
      patch.status,
      [
        'ACTIVE',
        'INACTIVE',
        'ARCHIVED'
      ],
      'status'
    );
  }

  return dbUpdateById(
    'PRODUCT_VARIANTS',
    variantId,
    stampUpdate_(
      user,
      patch
    ),
    {
      audit: true,
      action: 'UPDATE'
    }
  );
}

function createMaterial(itemType, payload) {
  const user = requirePermission_('PRODUCT_WRITE');
  payload = payload || {};

  const type = String(itemType || '').toUpperCase();
  assertOneOf_(type, ['INGREDIENT', 'PACKAGING'], 'item_type');

  const nameField = type === 'INGREDIENT' ? 'ingredient_name' : 'packaging_name';
  const name = normalizeText_(payload[nameField] || payload.name);
  const category = normalizeText_(payload.category);
  const baseUnit = canonicalUnit_(payload.base_unit);
  const purchaseUnit = canonicalUnit_(payload.purchase_unit);
  const factor = requirePositive_(payload.purchase_to_base_factor, 'purchase_to_base_factor');
  const minStock = requireNonNegative_(payload.minimum_stock_base || 0, 'minimum_stock_base');
  const purchaseUnitCost = requireNonNegative_(payload.purchase_unit_cost || 0, 'purchase_unit_cost');
  const costPerBase = factor > 0 ? purchaseUnitCost / factor : 0;
  const status = String(payload.status || 'ACTIVE').toUpperCase();

  if (!name) throw twbError_('VALIDATION_REQUIRED', 'Material name is required.');
  if (!category) throw twbError_('VALIDATION_REQUIRED', 'Material category is required.');
  if (!baseUnit) throw twbError_('VALIDATION_REQUIRED', 'Base unit is required.');
  if (!purchaseUnit) throw twbError_('VALIDATION_REQUIRED', 'Purchase unit is required.');
  assertOneOf_(status, ['ACTIVE', 'INACTIVE', 'ARCHIVED'], 'status');

  const sheet = type === 'INGREDIENT' ? 'INGREDIENTS' : 'PACKAGING';
  const entityKey = type === 'INGREDIENT' ? 'INGREDIENT' : 'PACKAGING';
  const idField = type === 'INGREDIENT' ? 'ingredient_id' : 'packaging_id';
  const itemId = nextBusinessId(entityKey);

  const record = stampCreate_(user, {
    [idField]: itemId,
    [nameField]: name,
    category: category,
    base_unit: baseUnit,
    purchase_unit: purchaseUnit,
    purchase_to_base_factor: factor,
    minimum_stock_base: minStock,
    average_cost_per_base_unit: roundNumber_(costPerBase, 6),
    latest_cost_per_base_unit: roundNumber_(costPerBase, 6),
    default_supplier_id: normalizeText_(payload.default_supplier_id),
    status: status
  });

  const created = dbInsertRecord(sheet, record, {
    audit: true,
    action: 'CREATE'
  });

  // Initialize the materialized inventory row at zero.
  if (!dbFindOne('INVENTORY', 'item_id', itemId)) {
    dbInsertRecord('INVENTORY', {
      inventory_id: nextBusinessId('INVENTORY'),
      item_type: type,
      item_id: itemId,
      current_stock_base: 0,
      minimum_stock_base: minStock,
      average_cost_per_base_unit: roundNumber_(costPerBase, 6),
      last_movement_at: '',
      updated_at: nowIso_()
    }, { validate: true, audit: false });
  }

  return created;
}

function updateMaterial(itemType, itemId, payload) {
  const user = requirePermission_('PRODUCT_WRITE');
  payload = payload || {};

  const type = String(itemType || '').toUpperCase();
  assertOneOf_(type, ['INGREDIENT', 'PACKAGING'], 'item_type');

  const sheet = type === 'INGREDIENT' ? 'INGREDIENTS' : 'PACKAGING';
  const current = dbFindById(sheet, itemId);
  if (!current) throw twbError_('NOT_FOUND', type + ' not found: ' + itemId);

  const patch = {};
  const nameField = type === 'INGREDIENT' ? 'ingredient_name' : 'packaging_name';

  if (Object.prototype.hasOwnProperty.call(payload, 'name')) {
    patch[nameField] = normalizeText_(payload.name);
  }
  ['category', 'base_unit', 'purchase_unit', 'default_supplier_id'].forEach(function(field) {
    if (Object.prototype.hasOwnProperty.call(payload, field)) {
      patch[field] = field.indexOf('_unit') >= 0
        ? canonicalUnit_(payload[field])
        : normalizeText_(payload[field]);
    }
  });
  if (Object.prototype.hasOwnProperty.call(payload, 'purchase_to_base_factor')) {
    patch.purchase_to_base_factor =
      requirePositive_(payload.purchase_to_base_factor, 'purchase_to_base_factor');
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'minimum_stock_base')) {
    patch.minimum_stock_base =
      requireNonNegative_(payload.minimum_stock_base, 'minimum_stock_base');
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'status')) {
    patch.status = String(payload.status).toUpperCase();
    assertOneOf_(patch.status, ['ACTIVE', 'INACTIVE', 'ARCHIVED'], 'status');
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'purchase_unit_cost')) {
    const factor = Number(
      Object.prototype.hasOwnProperty.call(patch, 'purchase_to_base_factor')
        ? patch.purchase_to_base_factor
        : current.purchase_to_base_factor
    );
    const purchaseCost =
      requireNonNegative_(payload.purchase_unit_cost, 'purchase_unit_cost');
    patch.latest_cost_per_base_unit = roundNumber_(purchaseCost / factor, 6);

    if (!(Number(current.average_cost_per_base_unit) > 0)) {
      patch.average_cost_per_base_unit = patch.latest_cost_per_base_unit;
    }
  }

  const updated = dbUpdateById(sheet, itemId, stampUpdate_(user, patch), {
    audit: true,
    action: 'UPDATE'
  });

  const inventory = dbFindOne('INVENTORY', 'item_id', itemId);
  if (inventory) {
    const inventoryPatch = {
      updated_at: nowIso_()
    };
    if (Object.prototype.hasOwnProperty.call(patch, 'minimum_stock_base')) {
      inventoryPatch.minimum_stock_base = patch.minimum_stock_base;
    }
    if (Object.prototype.hasOwnProperty.call(patch, 'average_cost_per_base_unit')) {
      inventoryPatch.average_cost_per_base_unit = patch.average_cost_per_base_unit;
    }
    dbUpdateById('INVENTORY', inventory.inventory_id, inventoryPatch, {
      validate: true,
      audit: false
    });
  }

  return updated;
}
