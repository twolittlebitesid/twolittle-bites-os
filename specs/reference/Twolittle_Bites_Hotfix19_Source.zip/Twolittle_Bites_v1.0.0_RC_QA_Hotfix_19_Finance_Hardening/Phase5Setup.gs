/**
 * One-time Phase 5 upgrade.
 * No schema migration is required.
 */
function upgradeToPhase5() {
  const user = requireRole_([TWB_ROLES.OWNER]);

  const schema = validateDatabaseSchema();
  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy. Resolve schema issues first.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'AUTO_INVOICE_ON_ORDER',
    true,
    'BOOLEAN',
    'Automatically create an invoice after a new order is created.',
    user.user_id
  );

  setConfig_(
    'AUTO_CONFIRM_ON_PAID',
    true,
    'BOOLEAN',
    'Move WAITING_PAYMENT orders to CONFIRMED when fully paid.',
    user.user_id
  );

  setConfig_(
    'WHATSAPP_INVOICE_MODE',
    'DEEPLINK',
    'STRING',
    'MVP WhatsApp mode. Generates wa.me link; user presses Send manually.',
    user.user_id
  );

  return runPhase5HealthCheck();
}

function backfillMissingInvoicesPhase5() {
  const user = requireAnyPermission_([
    'INVOICE_WRITE'
  ]);

  const orders = listAllRecords_('ORDERS');
  const created = [];
  const skipped = [];

  orders.forEach(function(order) {
    if (
      String(order.order_status).toUpperCase() === 'CANCELLED'
    ) {
      skipped.push({
        orderId: order.order_id,
        reason: 'CANCELLED'
      });
      return;
    }

    const existing = getInvoiceByOrderId_(order.order_id);
    if (existing) {
      skipped.push({
        orderId: order.order_id,
        reason: 'EXISTS'
      });
      return;
    }

    const detail = ensureInvoiceForOrder_(
      order.order_id,
      user
    );

    created.push({
      orderId: order.order_id,
      invoiceId: detail.invoice.invoice_id,
      invoiceNumber: detail.invoice.invoice_number
    });
  });

  return {
    ok: true,
    created: created,
    skipped: skipped
  };
}
