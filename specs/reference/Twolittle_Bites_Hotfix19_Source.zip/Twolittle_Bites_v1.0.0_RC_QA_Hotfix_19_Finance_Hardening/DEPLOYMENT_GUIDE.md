# DEPLOYMENT_GUIDE.md
# Twolittle.bites OS v1.0 — Apps Script Production Deployment

## Principle

Phase 16 prepares and verifies the release.

Apps Script deployment remains an explicit operator action.

## Before deployment

Required:

```text
runPhase16HealthCheck() = PASS
runPhase16SmokeTest() = PASS
runPhase15RegressionSuite() = 11/11
createPhase16ReleaseBackup() = verified
runPhase16ReleasePreflight() = blockingFailures 0
RELEASE_STATUS = PRODUCTION_READY
```

## Deploy

In Google Apps Script:

1. Click **Deploy**.
2. Open **Manage deployments**.
3. Select the production Web App deployment.
4. Edit the deployment.
5. Choose **New version**.
6. Add description:

```text
Twolittle.bites OS v1.0.0 Production Release
```

7. Preserve the intended Web App access configuration.
8. Deploy.
9. Copy the `/exec` production URL.

Do not create a new database spreadsheet for a normal code release.

## Immediately after deployment

Open the production URL in:
- normal desktop browser;
- mobile viewport / mobile browser.

Complete the critical section of `PRODUCTION_ACCEPTANCE_TEST.md`.

## Mark release

After live verification:

```text
Settings → Release → Mark Released
```

Enter:
- deployed `/exec` URL;
- concise release notes.

## Deployment freeze

After v1.0 is marked released:
- do not make untracked hot changes to the Apps Script project;
- every production change should have a version/release note;
- create a backup before a change that can affect data.

## If deployment fails

Do not modify business data to “fix” a code deployment.

Use `ROLLBACK_PLAN.md`.


## Optional Localhost Hybrid Runtime

QA Hotfix 15 provides a separate `Twolittle_Bites_Localhost_v1.0.0.zip` frontend package.

After the Apps Script project is updated and deployed, run:

```javascript
setupLocalhostBridge()
runQAHotfix15LocalBridgeSelfTest()
```

Copy the returned URL / actor / secret into the localhost package `.env.local`, then run:

```bash
npm start
```

The default localhost runtime uses the included zero-dependency `server.mjs` and binds to `127.0.0.1`. The bridge secret stays server-side. Optional Vite development mode is available with `npm install && npm run dev`. See `README_LOCALHOST.md` inside the localhost ZIP for the complete workflow.
