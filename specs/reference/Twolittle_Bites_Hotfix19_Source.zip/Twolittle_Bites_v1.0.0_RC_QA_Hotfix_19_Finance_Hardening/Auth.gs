function resolveCurrentEmail_() {
  if (
    typeof TWB_REQUEST_CONTEXT !== 'undefined' &&
    TWB_REQUEST_CONTEXT &&
    TWB_REQUEST_CONTEXT.trustedLocalBridge === true &&
    TWB_REQUEST_CONTEXT.actorEmail
  ) {
    return normalizeEmail_(
      TWB_REQUEST_CONTEXT.actorEmail
    );
  }

  const active = normalizeEmail_(Session.getActiveUser().getEmail());
  if (active) return active;

  // Security hardening: never fall back to getEffectiveUser() for normal
  // application requests. A public web-app deployment that executes as the
  // owner would otherwise be able to resolve an anonymous request as the
  // owner. Manual setup functions that need the effective account resolve it
  // explicitly instead of going through application authentication.
  return '';
}

function getCurrentUser() {
  const email = resolveCurrentEmail_();
  if (!email) {
    throw twbError_(
      'IDENTITY_UNAVAILABLE',
      'Google account identity is unavailable. Check deployment access/execution settings.'
    );
  }
  const user = dbFindOne('USERS', 'email', email);
  if (!user || user.status !== TWB_USER_STATUS.ACTIVE) {
    throw twbError_('ACCESS_DENIED', 'This Google account is not an active Twolittle.bites OS user.');
  }
  return sanitizeUser_(user);
}

function requireCurrentUser_() {
  return getCurrentUser();
}

function sanitizeUser_(user) {
  const copy = Object.assign({}, user);
  delete copy.__row;
  return copy;
}
