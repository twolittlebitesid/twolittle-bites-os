# Twolittle.bites OS — v1.0.0

**Phase 16 / Production Release**

```text
App Version     1.0.0
Schema Version  1.0.0
Canonical Sheets 33
Schema Migration NONE
```

Install from Phase 15 with:

`Twolittle_Bites_Phase_16_Delta.zip`

Then run:

```javascript
upgradeToPhase16()
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
createPhase16ReleaseBackup()
runPhase16ReleasePreflight()
markPhase16ProductionReady()
```

When preflight passes, deploy a new Apps Script Web App version manually.

After live verification:

```text
Settings → Release → Mark Released
```

Read before production deployment:

```text
RELEASE_CHECKLIST.md
DEPLOYMENT_GUIDE.md
PRODUCTION_ACCEPTANCE_TEST.md
ROLLBACK_PLAN.md
OPERATOR_GUIDE.md
```

This package completes the original v1.0 roadmap.

## Pre-release P0 closure

The v1.0 candidate now includes functional **Executive** and **Business** engines. The earlier Phase 2 shell placeholders have been removed. Final regression target is now **13/13 modules**.


## QA Hotfix 03

Fixes a false `DATA_INTEGRITY` release blocker caused by treating
`DAILY_METRICS.metric_date` and `MONTHLY_METRICS.month` as standalone unique keys.

Integrity now validates composite cache keys:

```text
metric_date + metric_key
month + metric_key
```

Focused diagnostic:

```javascript
runQAHotfix03IntegrityDiagnostic()
```


## QA Hotfix 04

Adds permission-aware Edit actions for Customer, Product, Material, and Supplier masters.

Existing `PRODUCTS.image_url` is now visible in:
- Product Master thumbnails;
- Product Edit live preview;
- selected Product rows in New Order.

No schema migration is required.


## QA Hotfix 06

- preserves unfinished New Order / Pre-Order modal drafts in memory;
- adds Order Status filtering;
- groups Products by Category and shows Variants under each Product;
- adds controlled Variant Edit;
- normalizes common image share URLs before Product image rendering;
- normalizes global app/module headers;
- redesigns Commerce Settings as chip/token editors.

No schema migration or Phase 16 upgrade rerun is required.


## QA Hotfix 07

Public Invoice polish:
- smaller invoice number;
- date-only Invoice Date and Due display;
- no raw GMT/timezone string;
- `DELIVERY DETAILS` label;
- date-only delivery date;
- closing `See you for another little bite! 🤎` contact block.

No schema migration.


## QA Hotfix 08

- Instagram corrected to `@twolittle.bites` and made clickable.
- Order/inquiry number opens WhatsApp.
- Invoice PDF archives are generated automatically in Google Drive.
- Drive PDFs are set to `Anyone with the link — Viewer`.
- PDF regenerates on invoice/payment/refund/fulfillment changes.
- Public Invoice shows `Download PDF`.
- WhatsApp templates support `{invoice_pdf_url}`.

No Sheet schema migration.


Apply the existing saved WhatsApp template migration:

```javascript
upgradeToQAHotfix08()
```

Backfill older invoices in batches:

```javascript
backfillInvoicePdfsQAHotfix08(10)
```


## QA Hotfix 09

Repairs a deployment mismatch where `Phase16HealthCheck.gs` was newer than
`SystemHardeningService.gs`.

Re-ships the composite-key integrity engine for:
- `DAILY_METRICS`: `metric_date + metric_key`
- `MONTHLY_METRICS`: `month + metric_key`

Run:

```javascript
runQAHotfix09IntegrityRepairCheck()
runPhase16HealthCheck()
```

No schema migration or data rewrite.


## QA Hotfix 10

Improves the public invoice experience by:
- aligning preview and PDF-safe rendering,
- keeping small invoices on one page,
- replacing the text-only brand header with configurable logo support,
- adding a visible Brand Logo URL placement in Settings → Business.


## Experience Upgrade 11

Adds a lightweight motion system plus decision-oriented utility across Orders, Customers,
Products, Production, Inventory, Purchasing, Finance, Marketing, and Reports. Existing
Executive, Business, and Settings equivalents are preserved instead of duplicated.

No Sheet schema migration or source-of-truth change.


## QA Hotfix 12

- fixes Product image reload/cache behavior with `updated_at` versioning and fallback candidates;
- removes duplicate Experience KPI/card grids;
- standardizes Search above cards on all 12 pages;
- adds full static UI consistency checks and Phase 16 health/smoke guards.

No schema migration or data rewrite.


## QA Hotfix 13

- removes the redundant bottom-bar `Operating System Active` label;
- adds a direct Invoice quick action;
- adds `+` Record Payment shortcuts in Orders and Finance Invoices;
- adds server-assisted Google Drive image preview fallback;
- applies the same image fallback to Business logo preview and public Invoice/PDF logo rendering;
- filters profit-sensitive Executive targets for roles without `PNL_READ`.

No schema migration or data rewrite.


## QA Hotfix 14

Adds lightweight thermal printing through the browser:
- 58 / 80 mm Receipt
- Print Receipt from Orders and Finance Invoices
- optional auto-open print after successful payment
- configurable receipt content
- optional permission-protected Kitchen Ticket

This phase does not add silent/direct ESC/POS printing or a local print bridge.


## QA Hotfix 15

Adds an optional Localhost Hybrid Runtime while keeping Apps Script/Sheets/Drive authoritative:

- signed HMAC localhost bridge;
- existing USERS / permission matrix preserved for local calls;
- removal of unsafe effective-user fallback for public requests;
- dual-runtime `TWB.api` adapter (`google.script.run` or local `/api` proxy);
- IndexedDB cache-first read path with background revalidation;
- Local Synced/Cached/Offline indicator;
- local permission-protected Kitchen Ticket path;
- separate localhost package with a zero-dependency Node runtime and optional Vite development mode.

Writes are still server-authoritative. This hotfix does not enable offline payment, stock, or finance mutation queues.


## QA Hotfix 16

WhatsApp invoice templates now support `{delivery_fee}`, mapped to `invoice.delivery_fee` and formatted as IDR.


## QA Hotfix 17

Adds Bulk Order Progress to Orders:
- row selection + Select Visible
- selected-count action bar
- Advance Next Step
- explicit forward target statuses
- server-side preflight against the canonical Order transition graph
- 100-Order batch limit
- terminal-order and bulk-cancellation protection
- localhost cache invalidation for bulk mutations

No Sheet schema migration or data rewrite.


## QA Hotfix 18

Adds direct payment proof upload to Finance → Record Payment (also available
through the Order payment shortcut):
- JPG, PNG, WebP, or PDF, up to 8 MB;
- automatically stores the file under
  `Twolittle.bites OS / Payment Proofs / YYYY / MM`;
- file name is `YYYY-MM-DD_Customer-Name_PAYMENT-ID.ext`, using the
  payment date in Asia/Jakarta and the Customer master name;
- saves the Drive view URL in existing `PAYMENTS.proof_url`;
- shows **View proof** on Invoice payment events and Finance → Payments;
- retains the existing manual Proof URL alternative.

Payment proofs are **not** shared publicly by this feature. Drive access must
be configured for authorized business users if they need to view the files.
There is no Sheet schema migration, no new permissions, and no data rewrite.

See `QA_HOTFIX_18_PAYMENT_PROOF_UPLOAD.md` for testing and deployment notes.


## QA Hotfix 19

Finance and Localhost hardening following whole-app QA:
- the latest SUCCESS payment method now follows `payment_at`, not sheet row order;
- references are checked under the payment/refund transaction lock;
- exact payment/refund retries are idempotent and flagged as already recorded;
- conflicting reused references are rejected;
- refund available balance is recalculated inside the insert lock;
- Localhost signed request handling supports an 8 MiB proof upload with
  action-specific size ceilings, while ordinary actions keep their small limit;
- the updated Localhost package bundles the current Hotfix 19 front-end.

No Sheet schema migration or prior data rewrite is needed.
Proof files remain private: OWNER/FINANCE Drive access must be verified
separately before production rollout.

See `QA_HOTFIX_19_FINANCE_HARDENING.md` for integration and deployment tests.
