# DATA_MODEL.md
# Twolittle.bites OS — Canonical Data Model

**Version:** P0.1  
**Status:** Frozen  
**Database:** Google Sheets (MVP)

---

## 1. Data Modeling Rules

1. Setiap entity utama memiliki stable business ID.
2. Reference antar sheet menggunakan ID, bukan row number.
3. Row number tidak pernah dianggap identifier.
4. Nilai uang menggunakan integer Rupiah.
5. Quantity disimpan dalam base unit saat memungkinkan.
6. Master data dapat di-inactivate; historical records tidak dihapus.
7. Operational events dicatat melalui ledger/movement/log.
8. Cached/derived values boleh disimpan untuk performance, tetapi source-of-truth harus jelas.
9. Order, invoice, payment, purchase, production, stock movement, dan transaction memiliki audit trail.
10. Recipe yang sudah dipakai produksi harus tetap dapat direkonstruksi melalui version.

---

## 2. Entity Domains

### Identity & Configuration
- CONFIG
- USERS
- BUSINESS_SETTINGS

### Customer & Commerce
- CUSTOMERS
- PREORDER_CAMPAIGNS
- ORDERS
- ORDER_ITEMS
- INVOICES
- PAYMENTS

### Product & Recipe
- PRODUCTS
- PRODUCT_VARIANTS
- RECIPES
- RECIPE_ITEMS
- INGREDIENTS
- PACKAGING
- UNIT_CONVERSIONS

### Operations
- PRODUCTION_PLANS
- PRODUCTION_PLAN_ITEMS
- PRODUCTION_REQUIREMENTS
- PRODUCTION_BATCHES
- INVENTORY
- INVENTORY_MOVEMENTS
- SUPPLIERS
- PURCHASES
- PURCHASE_ITEMS

### Finance
- TRANSACTIONS
- EXPENSES

### Growth & Management
- BUSINESS_TARGETS
- MARKETING_CAMPAIGNS
- CONTENT
- DAILY_METRICS
- MONTHLY_METRICS
- ACTIVITY_LOG

---

## 3. Canonical Relationships

### 3.1 Customer → Order

```text
CUSTOMERS 1 ───── N ORDERS
```

`ORDERS.customer_id` wajib menunjuk customer valid.

Customer dapat dibuat saat membuat order tanpa perlu keluar dari flow order.

---

### 3.2 Pre-Order → Order

```text
PREORDER_CAMPAIGNS 1 ───── N ORDERS
```

`ORDERS.preorder_campaign_id` nullable.

Order biasa:
```text
preorder_campaign_id = blank
```

Pre-order:
```text
preorder_campaign_id = PRE-...
```

Capacity menggunakan confirmed/reserved quantity berdasarkan order yang memenuhi capacity rule.

---

## 4. Order Model

```text
ORDERS 1 ───── N ORDER_ITEMS
```

Header order menyimpan data level order:
- customer
- source channel
- fulfillment
- totals
- workflow status

Order item menyimpan:
- product/variant
- quantity
- unit price snapshot
- line discount
- line total
- production note

Harga order harus berupa snapshot saat order dibuat. Perubahan harga product setelahnya tidak mengubah histori order.

---

## 5. Invoice & Payment Model

MVP:

```text
ORDER 1 ───── 1 ACTIVE INVOICE
INVOICE 1 ───── N PAYMENTS
```

Sistem tetap menggunakan `invoice_id` terpisah dari `order_id`.

Payment bukan boolean `paid`. Setiap pembayaran adalah record.

```text
invoice.grand_total
- SUM(valid payment.amount)
= remaining_amount
```

Partial payment dan DP otomatis didukung oleh model 1:N.

Refund dicatat sebagai payment/transaction event yang dapat diaudit, bukan menghapus payment lama.

---

## 6. Product Model

```text
PRODUCT 1 ───── N PRODUCT_VARIANTS
PRODUCT 1 ───── N RECIPES
```

Product adalah commercial item.

Variant digunakan bila ada perbedaan seperti:
- size
- flavor
- packaging configuration
- price

Variant bersifat optional.

---

## 7. Recipe Model

```text
PRODUCT / VARIANT
       ↓
     RECIPE
       ↓
  RECIPE_ITEMS
       ↓
INGREDIENT / PACKAGING
```

Recipe header:
- base yield
- yield unit
- scaling mode
- version
- status

Recipe item:
- item type
- ingredient/packaging ID
- quantity
- unit
- normalized/base quantity
- optional waste allowance

### Scaling

```text
multiplier = target_production / base_yield
required_item = base_item_qty × multiplier
```

### Full batch

```text
required_batches = CEILING(target / base_yield)
expected_output = required_batches × base_yield
surplus = expected_output - target
```

Recipe version yang dipakai production plan disimpan sebagai snapshot reference.

---

## 8. Unit Model

Base dimensions:

### Weight
```text
g
```

Display/purchase unit may include:
```text
mg, g, kg
```

### Volume
```text
ml
```

Display/purchase unit may include:
```text
ml, liter
```

### Count
```text
pcs
```

Display/purchase unit may include:
```text
pcs, dozen, tray, pack, box, carton
```

Custom conversion terkait item dapat digunakan:

```text
1 pack mascarpone = 500 g
1 tray egg = 30 pcs
```

Normalized quantity selalu dihitung sebelum aggregation.

---

## 9. Production Model

```text
PRODUCTION_PLAN
  └── PRODUCTION_PLAN_ITEM
       ├── PRODUCTION_REQUIREMENT
       └── PRODUCTION_BATCH
```

Production Plan adalah container berdasarkan tanggal/source.

Production Plan Item adalah target produk yang akan dibuat.

Production Requirement adalah snapshot kebutuhan material saat plan dihitung.

Production Batch adalah actual execution.

### Why persist PRODUCTION_REQUIREMENTS?

Requirement dipersist sebagai snapshot agar:
- kebutuhan batch lama tidak berubah ketika recipe diedit;
- shortage pada saat planning dapat diaudit;
- purchasing dapat refer ke requirement tertentu.

---

## 10. Inventory Model

### Canonical source of truth

```text
INVENTORY_MOVEMENTS
```

`INVENTORY.current_stock_base` adalah materialized balance/cache.

Tidak boleh mengubah current stock hanya dengan mengedit cell balance.

Stock berubah melalui movement:

```text
PURCHASE
PRODUCTION_USAGE
MANUAL_ADJUSTMENT
WASTE
RETURN
STOCK_OPNAME
```

Formula conceptual:

```text
stock =
SUM(quantity_in_base)
-
SUM(quantity_out_base)
```

Untuk performance, balance after movement dapat disimpan.

---

## 11. Purchasing Model

```text
SUPPLIER 1 ───── N PURCHASES
PURCHASE 1 ───── N PURCHASE_ITEMS
```

Saat purchase item diterima:

```text
PURCHASE_ITEM
→ INVENTORY_MOVEMENT(PURCHASE)
→ INVENTORY balance refresh
```

Shortage dari production requirement dapat menjadi draft purchase list tetapi tidak otomatis dianggap purchase sampai user confirm.

---

## 12. Finance Model

`TRANSACTIONS` adalah managerial cash/transaction ledger MVP.

Transaction types:
- SALES
- EXPENSE
- PURCHASE
- REFUND
- OTHER_INCOME
- OWNER_INJECTION
- WITHDRAWAL

Source events dapat menghasilkan transaction:
- payment verified → SALES
- expense recorded → EXPENSE
- purchase payment → PURCHASE
- refund → REFUND

Finance MVP bukan full double-entry accounting.

---

## 13. Customer Metrics

Customer derived/cached metrics:
- first_order_date
- last_order_date
- total_orders
- total_spend
- average_order_value
- favorite_product_id
- segment

Source tetap berasal dari completed/eligible orders.

Initial rules:
```text
REPEAT: total_orders >= 2
DORMANT: days_since_last_order > 60
```

Segment rule dapat dikembangkan tanpa mengubah historical order.

---

## 14. Marketing Attribution

```text
MARKETING_CAMPAIGN
  └── CONTENT
```

Order memiliki source channel.

Future attribution dapat menggunakan campaign/content reference, tetapi MVP tidak memerlukan multi-touch attribution.

Revenue attributed harus bisa ditelusuri ke order IDs atau rule yang terdokumentasi.

---

## 15. Audit Model

Critical mutation membuat `ACTIVITY_LOG`:

```text
CREATE
UPDATE
DELETE / ARCHIVE
STATUS_CHANGE
PAYMENT
STOCK_ADJUSTMENT
```

Operational history idealnya menggunakan status/archive, bukan hard delete.

---

## 16. Entity Cardinality Summary

| Parent | Child | Cardinality | Required |
|---|---|---:|---|
| CUSTOMER | ORDER | 1:N | yes on order |
| PREORDER_CAMPAIGN | ORDER | 1:N | optional |
| ORDER | ORDER_ITEM | 1:N | yes |
| ORDER | INVOICE | 1:1 active MVP | yes after save/issue |
| INVOICE | PAYMENT | 1:N | optional until paid |
| PRODUCT | PRODUCT_VARIANT | 1:N | optional |
| PRODUCT | RECIPE | 1:N | optional until production |
| RECIPE | RECIPE_ITEM | 1:N | yes for active recipe |
| PRODUCTION_PLAN | PRODUCTION_PLAN_ITEM | 1:N | yes |
| PRODUCTION_PLAN_ITEM | PRODUCTION_REQUIREMENT | 1:N | generated |
| PRODUCTION_PLAN_ITEM | PRODUCTION_BATCH | 1:N | optional |
| SUPPLIER | PURCHASE | 1:N | yes on purchase |
| PURCHASE | PURCHASE_ITEM | 1:N | yes |
| INVENTORY ITEM | INVENTORY_MOVEMENT | 1:N | yes |
| MARKETING_CAMPAIGN | CONTENT | 1:N | optional |

---

## 17. Data Ownership

| Data | Canonical source |
|---|---|
| Customer identity | CUSTOMERS |
| Product price | PRODUCTS / PRODUCT_VARIANTS |
| Ordered price | ORDER_ITEMS snapshot |
| Recipe composition | RECIPES + RECIPE_ITEMS |
| Recipe scaling result | PRODUCTION_REQUIREMENTS snapshot |
| Stock history | INVENTORY_MOVEMENTS |
| Current stock | INVENTORY cache from movements |
| Invoice balance | INVOICES + valid PAYMENTS |
| Sales cash | TRANSACTIONS generated from payment event |
| Revenue dashboard | eligible orders/transactions according to metric definition |
| COGS | recipe/material cost snapshot/calculation |
| Production actual | PRODUCTION_BATCHES |
| Audit history | ACTIVITY_LOG |

---

## 18. Deletion Policy

### Hard delete allowed
Only for clearly erroneous, unused setup/master records before they have references, and only Owner.

### Archive / cancel required
- Products with historical orders
- Recipes used in production
- Customers with order history
- Orders
- Invoices
- Payments
- Purchases
- Stock movements
- Production batches
- Transactions

---

## 19. Concurrency Rules

Critical actions use script lock:
- business ID generation;
- creating order + invoice atomically;
- posting payment;
- receiving purchase into stock;
- recording production material usage;
- manual stock adjustment;
- stock opname.

A failed multi-step critical action must not leave partial records without an error/audit marker.
