/**
 * Twolittle.bites OS — Phase 16 self-contained Health Check.
 *
 * Read-only against business transaction data.
 * Release readiness itself is evaluated separately by:
 * runPhase16ReleasePreflight()
 */
function runPhase16HealthCheck() {
  var checks = [];

  function pushCheck_(name, ok, detail) {
    var row = {};
    row.check = name;
    row.ok = !!ok;
    row.detail = String(
      detail == null
        ? ''
        : detail
    );
    checks.push(row);
  }

  try {
    var schema =
      validateDatabaseSchema();

    var sheets =
      schema.sheets || [];

    var valid =
      sheets.filter(function(row) {
        return row.ok === true;
      }).length;

    pushCheck_(
      'DATA_FOUNDATION',
      schema.ok === true &&
        sheets.length === 33 &&
        valid === 33,
      valid +
        '/' +
        sheets.length +
        ' sheets valid'
    );
  } catch (e) {
    pushCheck_(
      'DATA_FOUNDATION',
      false,
      e.message ||
        String(e)
    );
  }

  var runtime = [
    ['buildPhase16Preflight_', typeof buildPhase16Preflight_ === 'function'],
    ['runPhase16ReleasePreflight', typeof runPhase16ReleasePreflight === 'function'],
    ['createPhase16ReleaseBackup', typeof createPhase16ReleaseBackup === 'function'],
    ['markPhase16ProductionReady', typeof markPhase16ProductionReady === 'function'],
    ['markPhase16Released', typeof markPhase16Released === 'function'],
    ['markPhase16RollbackRequired', typeof markPhase16RollbackRequired === 'function'],
    ['executiveModuleBootstrap', typeof executiveModuleBootstrap === 'function'],
    ['businessModuleBootstrap', typeof businessModuleBootstrap === 'function'],
    ['systemIntegrityReport_', typeof systemIntegrityReport_ === 'function'],
    ['systemRegressionSuite_', typeof systemRegressionSuite_ === 'function'],
    ['createSystemBackupPhase15', typeof createSystemBackupPhase15 === 'function'],
    ['apiCall', typeof apiCall === 'function'],
    ['clientSafeResponse_', typeof clientSafeResponse_ === 'function']
  ];

  var missing =
    runtime
      .filter(function(row) {
        return !row[1];
      })
      .map(function(row) {
        return row[0];
      });

  pushCheck_(
    'PHASE16_SERVICES',
    missing.length === 0,
    missing.length
      ? 'Missing: ' +
        missing.join(', ')
      : 'Release gate + Phase 15 hardening services loaded'
  );

  try {
    var executiveEnvelope =
      apiCall(
        'executive.bootstrap',
        {}
      );

    var businessEnvelope =
      apiCall(
        'business.bootstrap',
        {}
      );

    pushCheck_(
      'EXECUTIVE_BUSINESS_ENGINES',
      executiveEnvelope &&
        executiveEnvelope.ok === true &&
        executiveEnvelope.data &&
        executiveEnvelope.data.finance &&
        businessEnvelope &&
        businessEnvelope.ok === true &&
        businessEnvelope.data &&
        Array.isArray(
          businessEnvelope.data.healthCards
        ),
      'Executive and Business return live engine payloads'
    );
  } catch (e) {
    pushCheck_(
      'EXECUTIVE_BUSINESS_ENGINES',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var version =
      getConfig_(
        'APP_VERSION'
      );

    pushCheck_(
      'CONFIG_APP_VERSION',
      String(
        version || ''
      ) ===
        '1.0.0' &&
        String(
          TWB_APP.APP_VERSION
        ) ===
        '1.0.0',
      'Config ' +
        version +
        ' · Runtime ' +
        TWB_APP.APP_VERSION
    );
  } catch (e) {
    pushCheck_(
      'CONFIG_APP_VERSION',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var status =
      releaseStatusSnapshot_();

    pushCheck_(
      'RELEASE_CONFIGURATION',
      status.releaseVersion ===
        '1.0.0' &&
        status.releaseChannel ===
          'PRODUCTION' &&
        status.featureFreeze ===
          true,
      status.releaseStatus +
        ' · ' +
        status.releaseChannel +
        ' · freeze=' +
        status.featureFreeze
    );
  } catch (e) {
    pushCheck_(
      'RELEASE_CONFIGURATION',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var dailyKeys =
      systemIntegrityKeyFields_(
        'DAILY_METRICS',
        getSheetSchema_(
          'DAILY_METRICS'
        )
      );

    var monthlyKeys =
      systemIntegrityKeyFields_(
        'MONTHLY_METRICS',
        getSheetSchema_(
          'MONTHLY_METRICS'
        )
      );

    var integrityEngineVersion =
      typeof systemIntegrityEngineVersion_ ===
        'function'
        ? systemIntegrityEngineVersion_()
        : '';

    pushCheck_(
      'DERIVED_CACHE_COMPOSITE_KEYS',
      integrityEngineVersion ===
        'QA_HOTFIX_09_COMPOSITE_KEYS_V1' &&
        dailyKeys.join('|') ===
          'metric_date|metric_key' &&
        monthlyKeys.join('|') ===
          'month|metric_key',
      integrityEngineVersion
        ? (
            integrityEngineVersion +
            ' · DAILY_METRICS = metric_date + metric_key · MONTHLY_METRICS = month + metric_key'
          )
        : 'Composite-key integrity engine version marker missing'
    );
  } catch (e) {
    pushCheck_(
      'DERIVED_CACHE_COMPOSITE_KEYS',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var integrity =
      systemIntegrityReport_();

    pushCheck_(
      'DATA_INTEGRITY',
      integrity.ok === true,
      integrity.ok
        ? 'No integrity issue detected'
        : integrity.totalIssues +
          ' issue(s) across ' +
          integrity.issueGroups +
          ' group(s)'
    );
  } catch (e) {
    pushCheck_(
      'DATA_INTEGRITY',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var preview =
      buildPhase16Preflight_({
        includeRegression:
          false
      });

    pushCheck_(
      'RELEASE_PREFLIGHT_ENGINE',
      Array.isArray(
        preview.checks
      ) &&
        Array.isArray(
          preview.warnings
        ) &&
        typeof preview.blockingFailures ===
          'number',
      preview.blockingFailures +
        ' current blocking condition(s); full regression intentionally not run here'
    );
  } catch (e) {
    pushCheck_(
      'RELEASE_PREFLIGHT_ENGINE',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var envelope =
      apiCall(
        'release.bootstrap',
        {}
      );

    pushCheck_(
      'PHASE16_API_GATEWAY',
      envelope &&
        envelope.ok === true &&
        envelope.data &&
        envelope.data.status &&
        envelope.data.preflightSummary,
      envelope &&
      envelope.ok
        ? 'release.bootstrap RPC available'
        : (
            envelope &&
            envelope.error
              ? envelope.error.code +
                ': ' +
                envelope.error.message
              : 'release.bootstrap RPC failed'
          )
    );
  } catch (e) {
    pushCheck_(
      'PHASE16_API_GATEWAY',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var js =
      HtmlService
        .createHtmlOutputFromFile(
          'JsSettings'
        )
        .getContent();

    var page =
      HtmlService
        .createHtmlOutputFromFile(
          'PageSettings'
        )
        .getContent();

    pushCheck_(
      'PHASE16_UI_PARTIALS',
      js.indexOf(
        'loadRelease'
      ) >= 0 &&
        js.indexOf(
          'markProductionReady'
        ) >= 0 &&
        page.indexOf(
          'data-settings-panel="release"'
        ) >= 0 &&
        page.indexOf(
          'data-release-preflight'
        ) >= 0,
      'Release gate UI readable'
    );
  } catch (e) {
    pushCheck_(
      'PHASE16_UI_PARTIALS',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var routerJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsRouter'
        )
        .getContent();

    var appJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsApp'
        )
        .getContent();

    var orderJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var chartJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsCharts'
        )
        .getContent();

    var header =
      HtmlService
        .createHtmlOutputFromFile(
          'ComponentHeader'
        )
        .getContent();

    var quick =
      HtmlService
        .createHtmlOutputFromFile(
          'ComponentQuickActions'
        )
        .getContent();

    var settingsPage =
      HtmlService
        .createHtmlOutputFromFile(
          'PageSettings'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_02_UI',
      routerJs.indexOf(
        'routeNodes: new Map()'
      ) >= 0 &&
        routerJs.indexOf(
          'if (firstVisit)'
        ) >= 0 &&
        appJs.indexOf(
          'pendingWhatsAppQueue'
        ) >= 0 &&
        orderJs.indexOf(
          'bindCustomerSearch'
        ) >= 0 &&
        orderJs.indexOf(
          'openWhatsAppQueue'
        ) >= 0 &&
        chartJs.indexOf(
          'renderLine'
        ) >= 0 &&
        header.indexOf(
          'Business Operating System'
        ) < 0 &&
        quick.indexOf(
          'data-global-whatsapp'
        ) >= 0 &&
        settingsPage.indexOf(
          'data-whatsapp-live-preview'
        ) >= 0 &&
        settingsPage.indexOf(
          'data-invoice-public-preview'
        ) >= 0,
      'Route cache + active WhatsApp + customer search + charts + live invoice previews loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_02_UI',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var customerJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsCustomers'
        )
        .getContent();

    var productJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsProducts'
        )
        .getContent();

    var purchasingJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsPurchasing'
        )
        .getContent();

    var orderJsQa04 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var productPage =
      HtmlService
        .createHtmlOutputFromFile(
          'PageProducts'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_04_EDIT_AND_IMAGES',
      customerJs.indexOf(
        'data-customer-edit'
      ) >= 0 &&
        customerJs.indexOf(
          "'customers.update'"
        ) >= 0 &&
        productJs.indexOf(
          'data-product-edit'
        ) >= 0 &&
        productJs.indexOf(
          'data-material-edit'
        ) >= 0 &&
        productJs.indexOf(
          'productIdentityCell'
        ) >= 0 &&
        purchasingJs.indexOf(
          'data-supplier-edit'
        ) >= 0 &&
        purchasingJs.indexOf(
          "'suppliers.update'"
        ) >= 0 &&
        orderJsQa04.indexOf(
          'data-order-product-thumb'
        ) >= 0 &&
        productPage.indexOf(
          '<th>Status</th><th></th>'
        ) >= 0,
      'Editable Customer/Product/Material/Supplier masters + linked product image thumbnails loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_04_EDIT_AND_IMAGES',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var waPlaceholders =
      settingsAllowedWhatsAppPlaceholders_();

    var waServiceSource =
      HtmlService
        .createHtmlOutput(
          ''
        );

    var supported =
      waPlaceholders.indexOf(
        'products'
      ) >= 0 &&
      waPlaceholders.indexOf(
        'discount'
      ) >= 0 &&
      typeof buildInvoiceWhatsAppMessage_ ===
        'function';

    pushCheck_(
      'QA_HOTFIX_05_WA_PLACEHOLDERS',
      supported,
      '{products} + {discount} WhatsApp invoice placeholders supported'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_05_WA_PLACEHOLDERS',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var ordersJsQa06 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var productsJsQa06 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsProducts'
        )
        .getContent();

    var settingsJsQa06 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsSettings'
        )
        .getContent();

    var appJsQa06 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsApp'
        )
        .getContent();

    var ordersPageQa06 =
      HtmlService
        .createHtmlOutputFromFile(
          'PageOrders'
        )
        .getContent();

    var settingsPageQa06 =
      HtmlService
        .createHtmlOutputFromFile(
          'PageSettings'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_06_WORKFLOW_UI',
      ordersJsQa06.indexOf(
        'newOrderDrafts'
      ) >= 0 &&
        ordersJsQa06.indexOf(
          'captureNewOrderDraft_'
        ) >= 0 &&
        ordersPageQa06.indexOf(
          'data-order-status-filter'
        ) >= 0 &&
        productsJsQa06.indexOf(
          'buildVariantRow'
        ) >= 0 &&
        productsJsQa06.indexOf(
          'data-variant-edit'
        ) >= 0 &&
        appJsQa06.indexOf(
          'normalizeImageUrl'
        ) >= 0 &&
        settingsJsQa06.indexOf(
          'renderCommerceEditor'
        ) >= 0 &&
        settingsPageQa06.indexOf(
          'commerce-settings-grid'
        ) >= 0,
      'Order draft restore + status filter + Product variants + image URL normalization + Commerce chip editor loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_06_WORKFLOW_UI',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var publicInvoiceQa07 =
      HtmlService
        .createHtmlOutputFromFile(
          'PublicInvoice'
        )
        .getContent();

    var dateOnlyReady =
      typeof formatPublicDate_ ===
        'function';

    pushCheck_(
      'QA_HOTFIX_07_PUBLIC_INVOICE',
      dateOnlyReady &&
        publicInvoiceQa07.indexOf(
          'Delivery Details'
        ) >= 0 &&
        publicInvoiceQa07.indexOf(
          'See you for another little bite!'
        ) >= 0 &&
        publicInvoiceQa07.indexOf(
          '@twolittle.bites'
        ) >= 0 &&
        publicInvoiceQa07.indexOf(
          '0812 6794 8252'
        ) >= 0,
      'Public invoice uses compact invoice number + date-only fields + Delivery Details + closing contact block'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_07_PUBLIC_INVOICE',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var publicInvoiceQa08 =
      HtmlService
        .createHtmlOutputFromFile(
          'PublicInvoice'
        )
        .getContent();

    var pdfServiceLoaded =
      typeof regenerateInvoicePdf ===
        'function' &&
      typeof getInvoicePdfArchiveInfo_ ===
        'function' &&
      typeof syncInvoicePdfArchiveSafely_ ===
        'function';

    var placeholdersQa08 =
      typeof settingsAllowedWhatsAppPlaceholders_ ===
        'function'
        ? settingsAllowedWhatsAppPlaceholders_()
        : [];

    pushCheck_(
      'QA_HOTFIX_08_INVOICE_DRIVE_PDF',
      pdfServiceLoaded &&
        publicInvoiceQa08.indexOf(
          '@twolittle.bites'
        ) >= 0 &&
        publicInvoiceQa08.indexOf(
          'https://wa.me/6281267948252'
        ) >= 0 &&
        publicInvoiceQa08.indexOf(
          'Download PDF'
        ) >= 0 &&
        placeholdersQa08.indexOf(
          'invoice_pdf_url'
        ) >= 0,
      'Clickable Instagram/WhatsApp + public Drive PDF archive + {invoice_pdf_url} support loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_08_INVOICE_DRIVE_PDF',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var experienceJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsExperience'
        )
        .getContent();

    var experienceStyles =
      HtmlService
        .createHtmlOutputFromFile(
          'StylesExperience'
        )
        .getContent();

    var indexExperience =
      HtmlService
        .createHtmlOutputFromFile(
          'Index'
        )
        .getContent();

    var ordersExperiencePage =
      HtmlService
        .createHtmlOutputFromFile(
          'PageOrders'
        )
        .getContent();

    pushCheck_(
      'EXPERIENCE_UPGRADE_11',
      experienceJs.indexOf(
        'renderOrders'
      ) >= 0 &&
        experienceJs.indexOf(
          'renderReports'
        ) >= 0 &&
        experienceStyles.indexOf(
          'prefers-reduced-motion'
        ) >= 0 &&
        experienceStyles.indexOf(
          'twbRouteEnter'
        ) >= 0 &&
        indexExperience.indexOf(
          "include('StylesExperience')"
        ) >= 0 &&
        indexExperience.indexOf(
          "include('JsExperience')"
        ) >= 0 &&
        ordersExperiencePage.indexOf(
          'data-experience-slot="orders"'
        ) >= 0,
      'Decision utility cards/filters + lightweight motion system loaded'
    );
  } catch (e) {
    pushCheck_(
      'EXPERIENCE_UPGRADE_11',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var exp12 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsExperience'
        )
        .getContent();

    var app12 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsApp'
        )
        .getContent();

    var products12 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsProducts'
        )
        .getContent();

    var orders12 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var pageFiles12 = [
      'PageExecutive',
      'PageBusiness',
      'PageOrders',
      'PageCustomers',
      'PageProducts',
      'PageProduction',
      'PageInventory',
      'PagePurchasing',
      'PageFinance',
      'PageMarketing',
      'PageReports',
      'PageSettings'
    ];

    var allSearchSlots12 =
      pageFiles12.every(
        function(fileName) {
          return HtmlService
            .createHtmlOutputFromFile(
              fileName
            )
            .getContent()
            .indexOf(
              'data-experience-slot='
            ) >= 0;
        }
      );

    pushCheck_(
      'QA_HOTFIX_12_UI_CONSISTENCY',
      allSearchSlots12 &&
        exp12.indexOf(
          'data-exp-page-search'
        ) >= 0 &&
        exp12.indexOf(
          'experience-card'
        ) < 0 &&
        app12.indexOf(
          'TWB.imageCandidates'
        ) >= 0 &&
        app12.indexOf(
          'TWB.setImageSource'
        ) >= 0 &&
        products12.indexOf(
          'product.updated_at'
        ) >= 0 &&
        orders12.indexOf(
          'product.updated_at'
        ) >= 0,
      'All 12 pages have top search utility · duplicate experience KPI cards removed · product images use versioned reload/fallback chain'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_12_UI_CONSISTENCY',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var quick13 =
      HtmlService
        .createHtmlOutputFromFile(
          'ComponentQuickActions'
        )
        .getContent();

    var app13 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsApp'
        )
        .getContent();

    var orders13 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var finance13 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsFinance'
        )
        .getContent();

    var products13 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsProducts'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_13_INVOICE_PAYMENT_IMAGE',
      quick13.indexOf(
        'Operating System Active'
      ) < 0 &&
        quick13.indexOf(
          'data-global-invoices'
        ) >= 0 &&
        app13.indexOf(
          "'images.resolve'"
        ) >= 0 &&
        app13.indexOf(
          'resolveImageDataUrl'
        ) >= 0 &&
        orders13.indexOf(
          'data-order-payment'
        ) >= 0 &&
        finance13.indexOf(
          'data-invoice-payment'
        ) >= 0 &&
        products13.indexOf(
          'schedulePreview'
        ) >= 0 &&
        typeof resolveProductImagePreview ===
          'function',
      'Bottom status removed · Invoice shortcut + payment + actions loaded · Google Drive server image fallback available'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_13_INVOICE_PAYMENT_IMAGE',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var settings14 =
      HtmlService
        .createHtmlOutputFromFile(
          'PageSettings'
        )
        .getContent();

    var finance14 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsFinance'
        )
        .getContent();

    var orders14 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var receipt14 =
      HtmlService
        .createHtmlOutputFromFile(
          'PublicReceipt'
        )
        .getContent();

    var kitchen14 =
      HtmlService
        .createHtmlOutputFromFile(
          'PublicKitchenTicket'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_14_THERMAL_PRINTING',
      typeof receiptPrintingSettings_ ===
        'function' &&
        typeof getPublicReceiptDataByToken_ ===
          'function' &&
        typeof buildPublicReceiptUrl_ ===
          'function' &&
        typeof buildKitchenTicketUrl_ ===
          'function' &&
        settings14.indexOf(
          'data-settings-tab="printing"'
        ) >= 0 &&
        settings14.indexOf(
          'data-settings-printing-form'
        ) >= 0 &&
        finance14.indexOf(
          'Print Receipt'
        ) >= 0 &&
        finance14.indexOf(
          'autoPrintAfterPayment'
        ) >= 0 &&
        orders14.indexOf(
          'data-order-receipt'
        ) >= 0 &&
        receipt14.indexOf(
          'window.print()'
        ) >= 0 &&
        kitchen14.indexOf(
          'KITCHEN TICKET'
        ) >= 0,
      '58/80 mm browser receipt printing + auto-print-after-payment + optional kitchen ticket loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_14_THERMAL_PRINTING',
      false,
      e.message || String(e)
    );
  }

  try {
    var api15 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsApiClient'
        )
        .getContent();

    var runtime15 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsLocalRuntime'
        )
        .getContent();

    var header15 =
      HtmlService
        .createHtmlOutputFromFile(
          'ComponentHeader'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_15_LOCALHOST_HYBRID',
      typeof handleLocalBridgePost_ ===
        'function' &&
        typeof setupLocalhostBridge ===
          'function' &&
        typeof localBridgeSignature_ ===
          'function' &&
        api15.indexOf(
          "mode || ''"
        ) >= 0 &&
        api15.indexOf(
          'indexedDB.open'
        ) >= 0 &&
        api15.indexOf(
          'localMutationActions'
        ) >= 0 &&
        api15.indexOf(
          'fetchLocalNetwork_'
        ) >= 0 &&
        runtime15.indexOf(
          'Local · Synced'
        ) >= 0 &&
        header15.indexOf(
          'local-runtime-status'
        ) >= 0,
      'Signed localhost bridge + role-preserving actor context + IndexedDB cache-first reads + runtime sync indicator loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_15_LOCALHOST_HYBRID',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var wa16Placeholders =
      settingsAllowedWhatsAppPlaceholders_();

    var wa16Source =
      String(
        buildInvoiceWhatsAppMessage_
      );

    var settings16Js =
      HtmlService
        .createHtmlOutputFromFile(
          'JsSettings'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_16_WA_DELIVERY_FEE',
      wa16Placeholders.indexOf(
        'delivery_fee'
      ) >= 0 &&
        wa16Source.indexOf(
          'delivery_fee'
        ) >= 0 &&
        settings16Js.indexOf(
          'delivery_fee'
        ) >= 0,
      '{delivery_fee} WhatsApp placeholder maps to invoice.delivery_fee and is available in Settings preview'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_16_WA_DELIVERY_FEE',
      false,
      e.message || String(e)
    );
  }

  try {
    var orderService17 =
      String(bulkProgressOrders);

    var ordersUi17 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    var ordersPage17 =
      HtmlService
        .createHtmlOutputFromFile(
          'PageOrders'
        )
        .getContent();

    var apiClient17 =
      HtmlService
        .createHtmlOutputFromFile(
          'JsApiClient'
        )
        .getContent();

    pushCheck_(
      'QA_HOTFIX_17_BULK_ORDER_PROGRESS',
      orderService17.indexOf(
        'ORDER_BULK_LIMIT'
      ) >= 0 &&
        orderService17.indexOf(
          'validateOrderTransition_'
        ) >= 0 &&
        orderService17.indexOf(
          'getOrderNextProgressStatus_'
        ) >= 0 &&
        ordersPage17.indexOf(
          'data-order-bulk-bar'
        ) >= 0 &&
        ordersPage17.indexOf(
          'data-order-select-visible'
        ) >= 0 &&
        ordersUi17.indexOf(
          'applyBulkProgress'
        ) >= 0 &&
        ordersUi17.indexOf(
          'orders.bulkProgress'
        ) >= 0 &&
        apiClient17.indexOf(
          "'orders.bulkProgress'"
        ) >= 0,
      'Bulk Order Progress selection + select visible + NEXT/TARGET transition validation + localhost cache invalidation loaded'
    );
  } catch (e) {
    pushCheck_(
      'QA_HOTFIX_17_BULK_ORDER_PROGRESS',
      false,
      e.message || String(e)
    );
  }

  var result = {};
  result.ok =
    checks.every(function(check) {
      return check.ok;
    });
  result.phase = 16;
  result.appVersion =
    TWB_APP.APP_VERSION;
  result.schemaVersion =
    TWB_APP.SCHEMA_VERSION;
  result.checks =
    checks;

  console.log(
    JSON.stringify(
      result,
      null,
      2
    )
  );

  return result;
}
