# QA_HOTFIX_15_STATIC_QA.md

Full-package static QA:

- Server `.gs` syntax: PASS (64 files)
- Client `Js*.html` syntax: PASS (19 script blocks)
- Apps Script Index include references: PASS
- Duplicate DOM IDs inside Page templates: PASS
- Localhost flattened Index has no Apps Script template/include tokens: PASS
- Localhost inline JS syntax: PASS (21 script blocks)
- Zero-dependency `server.mjs` syntax: PASS
- Optional Vite config syntax: PASS
- Zero-dependency local `/local-health` smoke: PASS
- Local servers bind to `127.0.0.1`: PASS
- Browser bundle does not contain `TWB_LOCAL_API_SECRET`: PASS
- HMAC-SHA256 signing implemented on local proxy + Apps Script: PASS
- Timestamp / nonce replay / actor / signature validation: PASS
- Anonymous `Session.getEffectiveUser()` fallback removed from application auth: PASS
- Dual Apps Script / LOCAL API adapter: PASS
- IndexedDB cache-first read path: PASS
- Cache invalidation limited to explicit mutation actions: PASS
- Cloud unreachable maps to Local Offline state: PASS
- Local runtime Synced/Cached/Offline indicator: PASS
- Local Kitchen Ticket uses signed API data: PASS
- Prior Hotfix 13/14 Invoice/Image/Payment/Printing behavior preserved: PASS
- Route cache / no-menu-reload preserved: PASS
- Reduced-motion support preserved: PASS
- Phase16 Hotfix 15 health guard: PASS
- Phase16 Hotfix 15 smoke guard: PASS
- Canonical sheet count unchanged: PASS (33/33)
- Sheet schema migration required: NO
- Data rewrite required: NO
- App Version: 1.0.0
- Schema Version: 1.0.0

Runtime/manual boundary:

The local static server is runtime-smoke-tested. The actual Apps Script deployment handshake cannot be completed in this build environment because it requires the user's deployed Web App URL and bridge secret.

Required runtime checks after deployment:

```javascript
setupLocalhostBridge()
runQAHotfix15LocalBridgeSelfTest()
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
```

Then configure `.env.local`, run `npm start`, verify `http://127.0.0.1:5173/local-health`, open the localhost UI, and test one real cloud write plus one cached read with internet temporarily unavailable.
