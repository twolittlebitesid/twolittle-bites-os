# PHASE_13_IMPLEMENTATION.md
# Twolittle.bites OS — Reports, Metrics Cache & Export

**Phase:** 13  
**App Version:** 0.13.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Core reporting architecture

```text
Operational Source Tables
↓
Live Report Calculation
↓
Daily / Weekly Business Review
↓
Rebuildable DAILY_METRICS
↓
Rebuildable MONTHLY_METRICS
↓
Targets
↓
CSV Export
```

The source of truth remains:
- Orders
- Payments / Transactions
- Expenses
- Production
- Inventory requirements
- Marketing attribution
- Campaign-linked Expenses

`DAILY_METRICS` and `MONTHLY_METRICS` are **derived caches**, not authoritative business records.

## Report access

### OWNER / ADMIN / FINANCE with REPORT_READ

Full reporting view:

```text
Finance
Operations
Marketing
Targets
Exports
```

### PRODUCTION

`REPORT_OPERATIONAL_READ`:

```text
Production Plans
Completed Plans
Shortage Requirements
Waste
Operational exports
```

Finance and Marketing data are not returned to the client.

### MARKETING

`REPORT_MARKETING_READ`:

```text
Marketing Spend
Attributed Revenue
Attributed Orders
New Customers
ROAS
Attribution Coverage
Marketing export
```

Full P&L and operational data are not returned to the client.

## Interactive period

Default:

```text
current calendar month
```

Users can select:

```text
From
To
```

Interactive range is capped at 732 days.

Reports calculate live for the selected period.

## Daily metrics

The live daily metric engine derives:

```text
ORDERS_CREATED
COMPLETED_ORDERS
OPERATING_REVENUE
EXPENSES
CASH_IN
CASH_OUT

NEW_CUSTOMERS
MARKETING_SPEND
ATTRIBUTED_ORDERS
ATTRIBUTED_REVENUE

PRODUCTION_PLANS
PRODUCTION_COMPLETED_PLANS
SHORTAGE_REQUIREMENTS
WASTE_QTY
```

Definitions:

### Orders Created

Non-cancelled Orders grouped by:

```text
order_date
```

### Completed Orders / Revenue

Completed Orders grouped by:

```text
fulfillment_date
fallback → order_date
```

Operating revenue:

```text
grand_total - tax
```

### Expenses

Active non-VOID Expenses grouped by:

```text
expense_date
```

### Cash

`TRANSACTIONS` grouped by `transaction_at`.

COGS transactions are excluded because Phase 10 treats COGS as non-cash managerial cost.

### Marketing Spend

Active Expenses with a Phase 12 Campaign link.

### Attributed Orders

Non-cancelled Orders with an active Phase 12 attribution mapping.

### Attributed Revenue

Completed attributed Order operating revenue.

### New Customers

Customer's first non-cancelled Order.

### Production

Uses `production_date`.

Cancelled plans are excluded.

### Shortage

Counts requirement lines with:

```text
status = SHORTAGE
or
shortage_qty_base > 0
```

for active production plans.

### Waste

Sum of recorded `PRODUCTION_BATCHES.waste_qty`.

## Weekly review

Weeks start on:

```text
MONDAY
```

Daily additive metrics are grouped into Monday-based weeks.

No weekly cache sheet is required.

## DAILY_METRICS cache

Default rebuild window:

```text
400 days
```

Config:

```text
REPORT_CACHE_LOOKBACK_DAYS = 400
```

Rebuild:

```javascript
rebuildReportMetricCaches()
```

or use:

```text
Reports → Rebuild Cache
```

OWNER / ADMIN only.

The rebuild:
1. recalculates daily metrics from source data;
2. clears derived rows below the header;
3. writes fresh daily rows;
4. aggregates them into monthly rows.

It does not mutate Orders, Finance, Production, Inventory, or Marketing history.

## MONTHLY_METRICS cache

Additive metrics are aggregated from daily cache.

Derived monthly metrics:

```text
AOV
CASH_NET
ROAS
ATTRIBUTION_COVERAGE_PCT
PRODUCTION_COMPLETION_RATE_PCT
```

Examples:

```text
AOV
= Operating Revenue / Completed Orders

Cash Net
= Cash In - Cash Out

ROAS
= Attributed Revenue / Marketing Spend

Attribution Coverage
= Attributed Orders / Orders Created

Production Completion
= Completed Plans / Production Plans
```

If monthly cache has not been built yet, the Monthly tab falls back to aggregating the selected live report period.

## Finance Overview

Full report access also calls the Phase 10 managerial Finance engine for:

```text
Operating Revenue
COGS
Gross Profit
Gross Margin
Operating Expenses
Operating Profit
Operating Margin
Cash In
Cash Out
Net Cash
Estimated COGS warning basis
```

This keeps Report P&L aligned with Finance.

## Business Targets

Phase 13 activates the existing:

```text
BUSINESS_TARGETS
```

Supported target metrics:

```text
OPERATING_REVENUE
COMPLETED_ORDERS
OPERATING_PROFIT
GROSS_MARGIN_PCT
ATTRIBUTED_REVENUE
ATTRIBUTED_ORDERS
NEW_CUSTOMERS
PRODUCTION_COMPLETED_PLANS
```

Period types:

```text
DAILY
WEEKLY
MONTHLY
CUSTOM
```

Target status:

```text
ACTIVE
ARCHIVED
CANCELLED
```

Target vs Actual uses the currently selected report period.

Target creation requires:

```text
OWNER
or BUSINESS_UPDATE permission
```

## CSV export

Exports are generated server-side as CSV text and downloaded in the browser with UTF-8 BOM.

Available:

```text
Period Summary
Daily Metrics
Weekly Metrics
Monthly Metrics
Targets
Marketing Attribution
Production Plans
Finance Transactions
```

Access is permission-aware:
- Marketing Attribution → marketing report access
- Production Plans → operational report access
- Finance Transactions → full report access

## Important cache rule

Never manually edit derived metric cache rows as business data.

Correct workflow:

```text
Source data changes
↓
Live reports reflect source
↓
Rebuild cache
↓
DAILY_METRICS / MONTHLY_METRICS refreshed
```

## Install from Phase 12

Replace:

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
Index.html
JsApp.html
PageReports.html
StylesComponents.html
StylesResponsive.html
```

Add:

```text
ReportService.gs
JsReports.html
Phase13Setup.gs
Phase13HealthCheck.gs
Phase13SmokeTest.gs
```

## Upgrade

Run once:

```javascript
upgradeToPhase13()
```

It sets:

```text
APP_VERSION = 0.13.0
SCHEMA_VERSION = 1.0.0
REPORT_CACHE_LOOKBACK_DAYS = 400
REPORT_DAILY_CACHE_MODE = REBUILDABLE_DERIVED_CACHE
REPORT_MONTHLY_CACHE_MODE = AGGREGATED_FROM_DAILY_CACHE
REPORT_WEEK_START = MONDAY
REPORT_EXPORT_FORMAT = CSV_UTF8_BOM
```

No Sheet is recreated.

## Validation

Run:

```javascript
runPhase13HealthCheck()
runPhase13SmokeTest()
```

Both validation suites are read-only.

They do **not**:
- rebuild caches;
- create targets;
- create Orders;
- create Expenses;
- create Marketing mappings.

## First production cache build

After Health + Smoke pass:

```javascript
rebuildReportMetricCaches()
```

This is the first intentional Phase 13 data mutation.

## Browser QA

1. Open Reports.
2. Verify date range defaults to current month.
3. Review role-appropriate Overview.
4. Change From / To and Apply.
5. Check Daily.
6. Check Weekly starts Monday.
7. Check Monthly fallback before cache rebuild.
8. As OWNER / ADMIN click Rebuild Cache.
9. Verify:
   - DAILY_METRICS populated;
   - MONTHLY_METRICS populated;
   - source tables unchanged.
10. Create a Target.
11. Check Target vs Actual.
12. Export Summary CSV.
13. Export Daily / Monthly.
14. Verify permission-specific export buttons.
15. Login as Production and confirm Finance columns are hidden.
16. Login as Marketing and confirm full P&L / operational columns are hidden.

## Next

**Phase 14 — Settings & Administration**
