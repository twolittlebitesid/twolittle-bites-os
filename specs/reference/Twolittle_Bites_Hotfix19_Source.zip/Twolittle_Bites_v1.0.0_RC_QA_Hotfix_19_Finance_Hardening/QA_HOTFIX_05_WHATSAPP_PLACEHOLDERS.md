# QA_HOTFIX_05_WHATSAPP_PLACEHOLDERS.md
# P0 — WhatsApp Invoice Placeholder Support

## Symptom

Saving a WhatsApp invoice template containing:

```text
{products}
{discount}
```

returned:

```text
Unknown WhatsApp placeholder: {products}
```

## Root cause

Phase 14 originally allowed only:

```text
{customer_name}
{business_name}
{invoice_number}
{total}
{remaining}
{due_at}
{invoice_url}
```

The validator and runtime message renderer did not yet include product lines or invoice discount.

## Fix

Supported placeholders are now:

```text
{customer_name}
{business_name}
{invoice_number}
{products}
{discount}
{total}
{remaining}
{due_at}
{invoice_url}
```

`{products}` renders from the invoice's Order Item snapshots.

Example:

```text
2x Classic Tiramisu — Rp180.000
1x Matcha Tiramisu — Rp95.000
```

`{discount}` renders the invoice-level discount:

```text
Rp25.000
```

The Settings real-time WhatsApp preview also renders both placeholders.

## Install

From QA Hotfix 04, replace:

```text
SettingsService.gs
WhatsAppService.gs
JsSettings.html
Phase16HealthCheck.gs
```

No schema migration and no upgrade function are required.

Then run:

```javascript
runPhase16HealthCheck()
```

Expected additional check:

```text
QA_HOTFIX_05_WA_PLACEHOLDERS = true
```

After that, save the WhatsApp template again.
