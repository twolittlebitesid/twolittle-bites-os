/**
 * Twolittle.bites OS — Phase 16 Production Release / v1.0
 *
 * This service manages release readiness metadata and final preflight.
 * It does NOT create or update Apps Script deployments automatically.
 */

function releaseReadUser_() {
  return requirePermission_(
    'SETTINGS_WRITE'
  );
}

function releaseOwnerUser_() {
  return requireRole_([
    TWB_ROLES.OWNER
  ]);
}

function releaseStatusSnapshot_() {
  return {
    releaseChannel:
      getConfig_(
        'RELEASE_CHANNEL'
      ) ||
      'PRODUCTION',
    releaseStatus:
      getConfig_(
        'RELEASE_STATUS'
      ) ||
      'PRE_RELEASE',
    releaseVersion:
      getConfig_(
        'RELEASE_VERSION'
      ) ||
      TWB_APP.APP_VERSION,
    featureFreeze:
      getConfig_(
        'RELEASE_FEATURE_FREEZE'
      ) !== false,
    releaseBackupFileId:
      getConfig_(
        'RELEASE_BACKUP_FILE_ID'
      ) ||
      '',
    releaseBackupCreatedAt:
      getConfig_(
        'RELEASE_BACKUP_CREATED_AT'
      ) ||
      '',
    productionReadyAt:
      getConfig_(
        'RELEASE_PRODUCTION_READY_AT'
      ) ||
      '',
    releasedAt:
      getConfig_(
        'RELEASED_AT'
      ) ||
      '',
    releasedBy:
      getConfig_(
        'RELEASED_BY'
      ) ||
      '',
    deploymentUrl:
      getConfig_(
        'RELEASE_DEPLOYMENT_URL'
      ) ||
      (
        typeof getWebAppBaseUrl_ ===
          'function'
          ? getWebAppBaseUrl_()
          : ''
      ),
    rollbackReason:
      getConfig_(
        'RELEASE_ROLLBACK_REASON'
      ) ||
      ''
  };
}

function releaseLatestCacheCalculatedAt_() {
  var latest = '';

  [
    'DAILY_METRICS',
    'MONTHLY_METRICS'
  ].forEach(function(sheetName) {
    listAllRecords_(
      sheetName
    ).forEach(function(row) {
      var value =
        String(
          row.calculated_at || ''
        );

      if (
        value > latest
      ) {
        latest = value;
      }
    });
  });

  return latest;
}

function releaseHoursSince_(isoValue) {
  if (!isoValue) return null;

  var timestamp =
    new Date(
      isoValue
    ).getTime();

  if (
    !isFinite(
      timestamp
    )
  ) {
    return null;
  }

  return (
    new Date().getTime() -
    timestamp
  ) /
  (
    60 *
    60 *
    1000
  );
}

function releaseLatestVerifiedBackup_() {
  var backups =
    listSystemBackups_();

  if (
    !backups.length
  ) {
    return null;
  }

  for (
    var i = 0;
    i < backups.length;
    i += 1
  ) {
    var row =
      backups[i];

    try {
      var verification =
        verifySystemBackupFile_(
          row.fileId
        );

      if (
        verification.ok
      ) {
        return Object.assign(
          {},
          row,
          {
            verified:
              true,
            verification:
              verification
          }
        );
      }
    } catch (ignore) {}
  }

  return null;
}

function releaseCheckRow_(
  key,
  label,
  ok,
  detail,
  blocking
) {
  return {
    key:
      key,
    label:
      label,
    ok:
      !!ok,
    blocking:
      blocking !== false,
    detail:
      String(
        detail == null
          ? ''
          : detail
      )
  };
}

function releaseWarningRow_(
  key,
  label,
  detail
) {
  return {
    key:
      key,
    label:
      label,
    detail:
      String(
        detail == null
          ? ''
          : detail
      )
  };
}

function buildPhase16Preflight_(
  options
) {
  options = options || {};

  var includeRegression =
    options.includeRegression !==
    false;

  var checks = [];
  var warnings = [];

  var schema = null;

  try {
    schema =
      validateDatabaseSchema();

    var valid =
      (
        schema.sheets ||
        []
      ).filter(function(row) {
        return row.ok === true;
      }).length;

    checks.push(
      releaseCheckRow_(
        'SCHEMA',
        'Canonical database schema',
        schema.ok === true &&
          schema.sheets.length === 33 &&
          valid === 33,
        valid +
          '/33 sheets valid',
        true
      )
    );
  } catch (e) {
    checks.push(
      releaseCheckRow_(
        'SCHEMA',
        'Canonical database schema',
        false,
        e.message ||
          String(e),
        true
      )
    );
  }

  checks.push(
    releaseCheckRow_(
      'APP_VERSION',
      'Application version',
      String(
        TWB_APP.APP_VERSION
      ) ===
        '1.0.0',
      'App ' +
        TWB_APP.APP_VERSION,
      true
    )
  );

  checks.push(
    releaseCheckRow_(
      'SCHEMA_VERSION',
      'Schema version',
      String(
        TWB_APP.SCHEMA_VERSION
      ) ===
        '1.0.0',
      'Schema ' +
        TWB_APP.SCHEMA_VERSION,
      true
    )
  );

  try {
    var integrity =
      systemIntegrityReport_();

    checks.push(
      releaseCheckRow_(
        'DATA_INTEGRITY',
        'Data integrity',
        integrity.ok === true,
        integrity.ok
          ? (
              'No integrity issue · ' +
              integrity.durationMs +
              ' ms'
            )
          : (
              integrity.totalIssues +
              ' issue(s) across ' +
              integrity.issueGroups +
              ' group(s)'
            ),
        true
      )
    );
  } catch (e) {
    checks.push(
      releaseCheckRow_(
        'DATA_INTEGRITY',
        'Data integrity',
        false,
        e.message ||
          String(e),
        true
      )
    );
  }

  try {
    var owners =
      activeOwnerCountPhase14_();

    checks.push(
      releaseCheckRow_(
        'ACTIVE_OWNER',
        'Active OWNER governance',
        owners >= 1,
        owners +
          ' active OWNER account(s)',
        true
      )
    );
  } catch (e) {
    checks.push(
      releaseCheckRow_(
        'ACTIVE_OWNER',
        'Active OWNER governance',
        false,
        e.message ||
          String(e),
        true
      )
    );
  }

  if (
    includeRegression
  ) {
    try {
      var regression =
        systemRegressionSuite_();

      checks.push(
        releaseCheckRow_(
          'REGRESSION',
          'Cross-module regression',
          regression.ok === true,
          regression.passed +
            '/' +
            regression.total +
            ' modules passed',
          true
        )
      );
    } catch (e) {
      checks.push(
        releaseCheckRow_(
          'REGRESSION',
          'Cross-module regression',
          false,
          e.message ||
            String(e),
          true
        )
      );
    }
  }

  var webAppUrl = '';

  try {
    webAppUrl =
      typeof getWebAppBaseUrl_ ===
        'function'
        ? getWebAppBaseUrl_()
        : '';

    checks.push(
      releaseCheckRow_(
        'WEB_APP',
        'Web App deployment URL',
        !!webAppUrl,
        webAppUrl ||
          'No deployed Web App URL available.',
        true
      )
    );
  } catch (e) {
    checks.push(
      releaseCheckRow_(
        'WEB_APP',
        'Web App deployment URL',
        false,
        e.message ||
          String(e),
        true
      )
    );
  }

  var backup = null;

  try {
    backup =
      releaseLatestVerifiedBackup_();

    var backupHours =
      backup
        ? releaseHoursSince_(
            backup.createdAt
          )
        : null;

    var maxBackupHours =
      Number(
        getConfig_(
          'RELEASE_PREFLIGHT_BACKUP_MAX_HOURS'
        ) ||
        24
      );

    var recent =
      !!backup &&
      backupHours !== null &&
      backupHours <=
        maxBackupHours;

    checks.push(
      releaseCheckRow_(
        'RECENT_BACKUP',
        'Recent verified database backup',
        recent,
        backup
          ? (
              backup.name +
              ' · ' +
              roundNumber_(
                backupHours,
                1
              ) +
              ' hour(s) old · max ' +
              maxBackupHours +
              'h'
            )
          : 'No verified backup found.',
        true
      )
    );
  } catch (e) {
    checks.push(
      releaseCheckRow_(
        'RECENT_BACKUP',
        'Recent verified database backup',
        false,
        e.message ||
          String(e),
        true
      )
    );
  }

  try {
    var cacheAt =
      releaseLatestCacheCalculatedAt_();

    var cacheHours =
      releaseHoursSince_(
        cacheAt
      );

    if (
      !cacheAt
    ) {
      warnings.push(
        releaseWarningRow_(
          'REPORT_CACHE_EMPTY',
          'Report cache',
          'DAILY_METRICS / MONTHLY_METRICS have not been built yet.'
        )
      );
    } else if (
      cacheHours !== null &&
      cacheHours > 48
    ) {
      warnings.push(
        releaseWarningRow_(
          'REPORT_CACHE_STALE',
          'Report cache',
          'Latest report cache is ' +
            roundNumber_(
              cacheHours,
              1
            ) +
            ' hour(s) old.'
        )
      );
    }
  } catch (e) {
    warnings.push(
      releaseWarningRow_(
        'REPORT_CACHE_CHECK',
        'Report cache',
        e.message ||
          String(e)
      )
    );
  }

  try {
    var maintenance =
      systemMaintenanceTriggerStatus_();

    if (
      !maintenance.configured
    ) {
      warnings.push(
        releaseWarningRow_(
          'MAINTENANCE_TRIGGER',
          'Scheduled maintenance',
          'Daily maintenance trigger is not configured.'
        )
      );
    }
  } catch (e) {
    warnings.push(
      releaseWarningRow_(
        'MAINTENANCE_TRIGGER',
        'Scheduled maintenance',
        e.message ||
          String(e)
      )
    );
  }

  try {
    var seriousErrors =
      systemRecentErrors_()
        .filter(function(row) {
          return (
            String(
              row.code || ''
            ) !==
            'UNKNOWN_API_ACTION'
          );
        });

    if (
      seriousErrors.length
    ) {
      warnings.push(
        releaseWarningRow_(
          'RECENT_ERRORS',
          'Recent server errors',
          seriousErrors.length +
            ' non-smoke RPC error(s) remain in the ring buffer.'
        )
      );
    }
  } catch (e) {}

  var blockingFailures =
    checks.filter(function(row) {
      return (
        row.blocking &&
        !row.ok
      );
    });

  return {
    ok:
      blockingFailures.length ===
      0,
    version:
      TWB_APP.APP_VERSION,
    schemaVersion:
      TWB_APP.SCHEMA_VERSION,
    generatedAt:
      nowIso_(),
    checks:
      checks,
    warnings:
      warnings,
    blockingFailures:
      blockingFailures.length,
    backup:
      backup,
    webAppUrl:
      webAppUrl
  };
}

function runPhase16ReleasePreflight() {
  releaseReadUser_();

  return buildPhase16Preflight_({
    includeRegression:
      true
  });
}

function createPhase16ReleaseBackup() {
  var user =
    releaseOwnerUser_();

  var backup =
    createSystemBackupPhase15();

  setConfig_(
    'RELEASE_BACKUP_FILE_ID',
    backup.fileId,
    'STRING',
    'Verified database backup associated with the v1.0 release.',
    user.user_id
  );

  setConfig_(
    'RELEASE_BACKUP_CREATED_AT',
    backup.createdAt,
    'STRING',
    'Timestamp of verified v1.0 release backup.',
    user.user_id
  );

  writeAuditLog_(
    'RELEASE_BACKUP',
    'SYSTEM',
    backup.fileId,
    null,
    {
      version:
        TWB_APP.APP_VERSION,
      name:
        backup.name,
      verified:
        backup.verified
    },
    'v1.0 release backup created.'
  );

  return backup;
}

function markPhase16ProductionReady() {
  var user =
    releaseOwnerUser_();

  var preflight =
    buildPhase16Preflight_({
      includeRegression:
        true
    });

  if (
    !preflight.ok
  ) {
    throw twbError_(
      'RELEASE_PREFLIGHT_FAILED',
      'Production readiness cannot be marked until all blocking release checks pass.',
      {
        blockingFailures:
          preflight.blockingFailures,
        checks:
          preflight.checks
      }
    );
  }

  var timestamp =
    nowIso_();

  setConfig_(
    'RELEASE_STATUS',
    'PRODUCTION_READY',
    'STRING',
    'Internal production release status.',
    user.user_id
  );

  setConfig_(
    'RELEASE_PRODUCTION_READY_AT',
    timestamp,
    'STRING',
    'Timestamp when v1.0 passed final release preflight.',
    user.user_id
  );

  if (
    preflight.backup &&
    preflight.backup.fileId
  ) {
    setConfig_(
      'RELEASE_BACKUP_FILE_ID',
      preflight.backup.fileId,
      'STRING',
      'Verified database backup associated with the v1.0 release.',
      user.user_id
    );
  }

  writeAuditLog_(
    'PRODUCTION_READY',
    'SYSTEM',
    TWB_APP.APP_VERSION,
    null,
    {
      timestamp:
        timestamp,
      warnings:
        preflight.warnings.length,
      backupFileId:
        preflight.backup
          ? preflight.backup.fileId
          : ''
    },
    'v1.0 passed final production readiness preflight.'
  );

  return {
    status:
      'PRODUCTION_READY',
    productionReadyAt:
      timestamp,
    warnings:
      preflight.warnings,
    deploymentInstruction:
      'Deploy a new Apps Script Web App version manually, then mark the release as RELEASED.'
  };
}

function markPhase16Released(
  payload
) {
  var user =
    releaseOwnerUser_();

  payload = payload || {};

  var preflight =
    buildPhase16Preflight_({
      includeRegression:
        true
    });

  if (
    !preflight.ok
  ) {
    throw twbError_(
      'RELEASE_PREFLIGHT_FAILED',
      'Release cannot be marked as RELEASED because blocking preflight checks remain.',
      {
        checks:
          preflight.checks
      }
    );
  }

  var deploymentUrl =
    normalizeText_(
      payload.deployment_url ||
      preflight.webAppUrl
    );

  if (!deploymentUrl) {
    throw twbError_(
      'RELEASE_DEPLOYMENT_URL_REQUIRED',
      'A deployed Web App URL is required.'
    );
  }

  var releaseNotes =
    normalizeText_(
      payload.release_notes
    );

  var timestamp =
    nowIso_();

  setConfig_(
    'RELEASE_STATUS',
    'RELEASED',
    'STRING',
    'Internal production release status.',
    user.user_id
  );

  setConfig_(
    'RELEASED_AT',
    timestamp,
    'STRING',
    'v1.0 production release timestamp.',
    user.user_id
  );

  setConfig_(
    'RELEASED_BY',
    user.email,
    'STRING',
    'OWNER who marked v1.0 released.',
    user.user_id
  );

  setConfig_(
    'RELEASE_DEPLOYMENT_URL',
    deploymentUrl,
    'STRING',
    'Production Apps Script Web App URL.',
    user.user_id
  );

  setConfig_(
    'RELEASE_NOTES',
    releaseNotes,
    'STRING',
    'Operator release notes for v1.0.',
    user.user_id
  );

  writeAuditLog_(
    'RELEASED',
    'SYSTEM',
    TWB_APP.APP_VERSION,
    null,
    {
      releasedAt:
        timestamp,
      releasedBy:
        user.email,
      deploymentUrl:
        deploymentUrl,
      releaseNotes:
        releaseNotes
    },
    'Twolittle.bites OS v1.0 marked RELEASED.'
  );

  return releaseStatusSnapshot_();
}

function markPhase16RollbackRequired(
  reason
) {
  var user =
    releaseOwnerUser_();

  var normalized =
    settingsText_(
      reason,
      'Rollback reason',
      3,
      500
    );

  setConfig_(
    'RELEASE_STATUS',
    'ROLLBACK_REQUIRED',
    'STRING',
    'Internal production release status.',
    user.user_id
  );

  setConfig_(
    'RELEASE_ROLLBACK_REASON',
    normalized,
    'STRING',
    'Reason rollback was requested.',
    user.user_id
  );

  writeAuditLog_(
    'ROLLBACK_REQUIRED',
    'SYSTEM',
    TWB_APP.APP_VERSION,
    null,
    {
      reason:
        normalized
    },
    'v1.0 rollback was requested.'
  );

  return releaseStatusSnapshot_();
}

function clearPhase16RollbackFlag() {
  var user =
    releaseOwnerUser_();

  setConfig_(
    'RELEASE_ROLLBACK_REASON',
    '',
    'STRING',
    'Reason rollback was requested.',
    user.user_id
  );

  setConfig_(
    'RELEASE_STATUS',
    'PRODUCTION_READY',
    'STRING',
    'Internal production release status.',
    user.user_id
  );

  return releaseStatusSnapshot_();
}

function releaseModuleBootstrap() {
  var user =
    releaseReadUser_();

  var status =
    releaseStatusSnapshot_();

  return {
    status:
      status,
    preflightSummary:
      buildPhase16Preflight_({
        includeRegression:
          false
      }),
    permissions: {
      canView:
        true,
      canManageRelease:
        user.role ===
          TWB_ROLES.OWNER
    },
    manualDeploymentRequired:
      true,
    deploymentNote:
      'Apps Script deployment versioning remains a manual Deploy > Manage deployments action.'
  };
}
