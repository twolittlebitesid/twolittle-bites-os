/**
 * Database/repository primitives.
 * Business rules belong in Services, not here.
 */
function getDatabaseSpreadsheet_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('TWB_SPREADSHEET_ID');
  if (id) return SpreadsheetApp.openById(id);

  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) {
    props.setProperty('TWB_SPREADSHEET_ID', active.getId());
    return active;
  }

  throw twbError_('DATABASE_NOT_INITIALIZED', 'Database is not initialized. Run setupTwolittleBitesPhase1().');
}

function getDbSheet_(sheetName) {
  getSheetSchema_(sheetName);
  const sheet = getDatabaseSpreadsheet_().getSheetByName(sheetName);
  if (!sheet) throw twbError_('MISSING_SHEET', 'Missing database sheet: ' + sheetName);
  return sheet;
}

function getHeaderMap_(sheetName) {
  const schema = getSheetSchema_(sheetName);
  const map = {};
  schema.headers.forEach(function(h, i) { map[h] = i; });
  return map;
}

function rowToObject_(headers, row) {
  const obj = {};
  headers.forEach(function(h, i) { obj[h] = row[i]; });
  return obj;
}

function objectToRow_(headers, record) {
  return headers.map(function(h) {
    return Object.prototype.hasOwnProperty.call(record, h) ? record[h] : '';
  });
}

function dbList(sheetName, options) {
  options = options || {};
  const schema = getSheetSchema_(sheetName);
  const sheet = getDbSheet_(sheetName);
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { items: [], total: 0, offset: 0, limit: 0 };

  const requestedLimit = Number(options.limit || getConfig_('DEFAULT_PAGE_SIZE') || 50);
  const maxLimit = Number(getConfig_('MAX_PAGE_SIZE') || 200);
  const limit = Math.max(1, Math.min(requestedLimit, maxLimit));
  const offset = Math.max(0, Number(options.offset || 0));
  const available = lastRow - 1;
  if (offset >= available) return { items: [], total: available, offset: offset, limit: limit };

  const numRows = Math.min(limit, available - offset);
  const values = sheet.getRange(2 + offset, 1, numRows, schema.headers.length).getValues();
  return {
    items: values.map(function(r) { return rowToObject_(schema.headers, r); }),
    total: available,
    offset: offset,
    limit: limit
  };
}

function dbFindById(sheetName, id) {
  const schema = getSheetSchema_(sheetName);
  if (!schema.primaryKey) throw twbError_('NO_PRIMARY_KEY', sheetName + ' does not have a configured primary key.');
  return dbFindOne(sheetName, schema.primaryKey, id);
}

function dbFindOne(sheetName, field, value) {
  const schema = getSheetSchema_(sheetName);
  const index = schema.headers.indexOf(field);
  if (index < 0) throw twbError_('UNKNOWN_FIELD', field + ' is not a field in ' + sheetName);

  const sheet = getDbSheet_(sheetName);
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return null;

  const values = sheet.getRange(2, 1, lastRow - 1, schema.headers.length).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][index]) === String(value)) {
      const obj = rowToObject_(schema.headers, values[i]);
      obj.__row = i + 2;
      return obj;
    }
  }
  return null;
}

function dbFindMany(sheetName, field, value) {
  const schema = getSheetSchema_(sheetName);
  const index = schema.headers.indexOf(field);
  if (index < 0) throw twbError_('UNKNOWN_FIELD', field + ' is not a field in ' + sheetName);

  const sheet = getDbSheet_(sheetName);
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return [];

  return sheet.getRange(2, 1, lastRow - 1, schema.headers.length).getValues()
    .filter(function(r) { return String(r[index]) === String(value); })
    .map(function(r) { return rowToObject_(schema.headers, r); });
}

function dbInsertRecord(sheetName, record, options) {
  options = options || {};
  const schema = getSheetSchema_(sheetName);
  const data = Object.assign({}, record);

  if (options.validate !== false) validateRecord_(sheetName, data, false);
  enforceUniqueFields_(sheetName, data, null);

  const row = objectToRow_(schema.headers, data);
  getDbSheet_(sheetName).appendRow(row);

  if (options.audit === true && sheetName !== 'ACTIVITY_LOG') {
    writeAuditLog_(options.action || 'CREATE', sheetName, schema.primaryKey ? data[schema.primaryKey] : '', null, data, options.notes || '');
  }
  return data;
}

function dbUpdateById(sheetName, id, patch, options) {
  options = options || {};
  const schema = getSheetSchema_(sheetName);
  if (!schema.primaryKey) throw twbError_('NO_PRIMARY_KEY', sheetName + ' does not have a primary key.');
  const current = dbFindById(sheetName, id);
  if (!current) throw twbError_('NOT_FOUND', sheetName + ' record not found: ' + id);

  const updated = {};
  schema.headers.forEach(function(h) {
    updated[h] = Object.prototype.hasOwnProperty.call(patch, h) ? patch[h] : current[h];
  });

  if (options.validate !== false) validateRecord_(sheetName, updated, true);
  enforceUniqueFields_(sheetName, updated, id);

  const row = current.__row;
  const values = objectToRow_(schema.headers, updated);
  getDbSheet_(sheetName).getRange(row, 1, 1, values.length).setValues([values]);

  if (options.audit === true && sheetName !== 'ACTIVITY_LOG') {
    const before = Object.assign({}, current);
    delete before.__row;
    writeAuditLog_(options.action || 'UPDATE', sheetName, id, before, updated, options.notes || '');
  }
  return updated;
}

function dbBulkInsert(sheetName, records, options) {
  options = options || {};
  if (!records || !records.length) return [];
  const schema = getSheetSchema_(sheetName);

  records.forEach(function(record) {
    if (options.validate !== false) validateRecord_(sheetName, record, false);
  });

  const rows = records.map(function(record) { return objectToRow_(schema.headers, record); });
  const sheet = getDbSheet_(sheetName);
  sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, schema.headers.length).setValues(rows);
  return records;
}
