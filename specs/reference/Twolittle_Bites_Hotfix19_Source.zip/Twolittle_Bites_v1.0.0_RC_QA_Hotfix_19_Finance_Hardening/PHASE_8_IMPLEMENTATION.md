# PHASE_8_IMPLEMENTATION.md
# Twolittle.bites OS — Purchasing Engine

**Phase:** 8  
**App Version:** 0.8.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Flow

```text
Active Production Requirement
+
Minimum Stock
-
Current Inventory
-
Outstanding Ordered Purchase
=
Recommended To Buy

↓
Supplier
↓
Purchase Draft
↓
ORDERED
↓
Partial / Full Receiving
↓
PURCHASE_RECEIPT Inventory Movement
↓
Current Stock
↓
Latest + Weighted Average Material Cost
↓
Product COGS refresh
```

## Purchasing recommendation

Phase 8 does not simply copy the old shortage snapshot.

Recommendation is calculated from current operational data:

```text
active unconsumed production requirement
+ minimum stock
- current stock
- incoming open purchases
```

This reduces duplicate purchasing when an ORDERED/PARTIAL supplier purchase is already incoming.

## Supplier Master

Supports:
- Supplier Name
- Contact Person
- WhatsApp
- Email
- Address
- Lead Time
- Minimum Order Value
- Status
- Notes

Supplier creation uses `PURCHASE_WRITE`.

## Purchase lifecycle

```text
DRAFT
├── ORDERED
└── CANCELLED

ORDERED
├── Receive Goods → PARTIAL
├── Receive Goods → RECEIVED
└── CANCELLED only if nothing has been received

PARTIAL
└── Receive Goods → RECEIVED

RECEIVED = terminal
CANCELLED = terminal
```

`PARTIAL` and `RECEIVED` are derived by receiving.

## Purchase Item snapshot

Each line stores:

```text
item_type
item_id
quantity
unit
quantity_base
unit_cost
total_cost
received_qty_base
```

A material can appear only once in one Purchase.

## Receiving

Goods receipt:
- validates remaining quantity;
- supports partial receipt;
- uses an idempotency receipt token;
- creates `PURCHASE_RECEIPT` rows in `INVENTORY_MOVEMENTS`;
- updates `INVENTORY.current_stock_base`;
- updates `PURCHASE_ITEMS.received_qty_base`;
- updates Purchase status;
- cannot receive more than ordered.

Movement reference:

```text
reference_type = PURCHASE_ITEM
reference_id   = <purchase_item_id>#<receipt_token>
```

## Material cost

On receiving:

```text
latest_cost_per_base_unit
= purchase line total / ordered base quantity
```

Weighted average:

```text
(old stock × old average + receipt qty × receipt cost)
/
(old stock + receipt qty)
```

The new weighted average updates:
- INGREDIENTS / PACKAGING
- INVENTORY

For active base recipes using the material, Product COGS is refreshed.

## Price History

No extra sheet is created.

Price history is derived from:

```text
PURCHASES
+
PURCHASE_ITEMS
+
SUPPLIERS
```

This preserves `Input once, reuse everywhere`.

## Delivery cost

Purchase-level delivery cost is tracked in `PURCHASES`.

Phase 8 does **not** allocate delivery cost into material landed cost yet.

## Supplier payment

`payment_status` starts at:

```text
UNPAID
```

Supplier payment posting is intentionally outside Phase 8.

No EXPENSE or TRANSACTION row is created by receiving goods.

## Permissions

Read:
```text
PURCHASE_READ
```

Create supplier / purchase / order purchase:
```text
PURCHASE_WRITE
```

Receive goods:
```text
PURCHASE_WRITE
+
INVENTORY_ADJUST
```

This means OWNER / ADMIN can execute receiving with the current role matrix.

## Install from Phase 7

Use:

```text
Twolittle_Bites_Phase_8_Delta.zip
```

Phase 8 also carries the Phase 7.0.2 RPC serialization/client-error improvements in:
- `ApiGateway.gs`
- `JsApiClient.html`

### Replace

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
Index.html
JsApp.html
JsApiClient.html
ComponentQuickActions.html
PagePurchasing.html
StylesComponents.html
StylesResponsive.html
```

### Add

```text
PurchasingService.gs
JsPurchasing.html
Phase8Setup.gs
Phase8HealthCheck.gs
Phase8SmokeTest.gs
```

## Upgrade

```javascript
upgradeToPhase8()
```

It changes configuration only:

```text
APP_VERSION = 0.8.0
SCHEMA_VERSION = 1.0.0
PURCHASE_RECEIPT_INVENTORY_MODE = MOVEMENT_LEDGER
PURCHASE_PAYMENT_MODE = TRACK_ONLY
```

No database table is recreated.

## Validation

```javascript
runPhase8HealthCheck()
runPhase8SmokeTest()
```

Tests are read-only against business transaction data.

## Browser QA

1. Create Supplier.
2. Open `To Buy`.
3. Create Purchase from recommendations.
4. Review estimated purchase-unit cost.
5. Save Draft.
6. Mark Ordered.
7. Receive only part of one line.
8. Verify:
   - Purchase = PARTIAL
   - Inventory Movement = PURCHASE_RECEIPT
   - Stock increased
   - Material cost changed
9. Receive remaining quantity.
10. Verify Purchase = RECEIVED.
11. Check Price History.
12. Verify Product COGS refresh for active base recipes.

## Next

**Phase 9 — Pre-Order & Capacity Engine**
