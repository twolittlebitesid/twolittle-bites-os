const TWB_ROLE_PERMISSIONS = Object.freeze({
  OWNER: ['*'],
  ADMIN: [
    'EXECUTIVE_READ','BUSINESS_READ','BUSINESS_UPDATE',
    'ORDER_READ','ORDER_WRITE','PREORDER_READ','PREORDER_WRITE',
    'CUSTOMER_READ','CUSTOMER_WRITE','PRODUCT_READ','PRODUCT_WRITE',
    'RECIPE_READ','RECIPE_WRITE','PRODUCTION_READ','PRODUCTION_WRITE',
    'INVENTORY_READ','INVENTORY_ADJUST','PURCHASE_READ','PURCHASE_WRITE',
    'INVOICE_READ','INVOICE_WRITE','PAYMENT_CREATE','EXPENSE_CREATE',
    'MARKETING_READ','MARKETING_WRITE','REPORT_MARKETING_READ',
    'REPORT_READ','SETTINGS_READ','SETTINGS_WRITE'
  ],
  PRODUCTION: [
    'BUSINESS_READ',
    'PRODUCT_READ','RECIPE_READ','RECIPE_WRITE',
    'ORDER_READ','PRODUCTION_READ','PRODUCTION_WRITE',
    'INVENTORY_READ','INVENTORY_ADJUST','PURCHASE_READ',
    'REPORT_OPERATIONAL_READ'
  ],
  MARKETING: [
    'BUSINESS_READ','CUSTOMER_READ_LIMITED','ORDER_READ',
    'MARKETING_READ','MARKETING_WRITE','EXPENSE_CREATE_MARKETING',
    'REPORT_MARKETING_READ'
  ],
  FINANCE: [
    'EXECUTIVE_READ','BUSINESS_READ','ORDER_READ','CUSTOMER_READ',
    'INVOICE_READ','INVOICE_WRITE','PAYMENT_READ','PAYMENT_WRITE',
    'TRANSACTION_READ','TRANSACTION_WRITE','EXPENSE_READ','EXPENSE_WRITE',
    'PURCHASE_READ','REPORT_READ','PNL_READ','SETTINGS_READ'
  ]
});

function hasPermission_(user, permission) {
  const perms = TWB_ROLE_PERMISSIONS[user.role] || [];
  return perms.indexOf('*') >= 0 || perms.indexOf(permission) >= 0;
}

function requirePermission_(permission) {
  const user = requireCurrentUser_();
  if (!hasPermission_(user, permission)) {
    throw twbError_('FORBIDDEN', 'Permission denied: ' + permission);
  }
  return user;
}

function requireRole_(roles) {
  const user = requireCurrentUser_();
  if (roles.indexOf(user.role) < 0) throw twbError_('FORBIDDEN', 'Role not allowed: ' + user.role);
  return user;
}
