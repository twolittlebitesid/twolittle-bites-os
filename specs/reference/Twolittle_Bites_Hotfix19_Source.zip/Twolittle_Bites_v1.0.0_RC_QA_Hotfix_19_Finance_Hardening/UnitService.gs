/**
 * Unit conversion / normalization.
 *
 * Canonical base units:
 * Weight = g
 * Volume = ml
 * Count  = pcs
 */

const TWB_STANDARD_UNIT_DEFINITIONS = Object.freeze({
  mg:    { dimension: 'WEIGHT', factorToCanonical: 0.001, canonical: 'g' },
  g:     { dimension: 'WEIGHT', factorToCanonical: 1, canonical: 'g' },
  kg:    { dimension: 'WEIGHT', factorToCanonical: 1000, canonical: 'g' },

  ml:    { dimension: 'VOLUME', factorToCanonical: 1, canonical: 'ml' },
  liter: { dimension: 'VOLUME', factorToCanonical: 1000, canonical: 'ml' },

  pcs:   { dimension: 'COUNT', factorToCanonical: 1, canonical: 'pcs' },
  dozen: { dimension: 'COUNT', factorToCanonical: 12, canonical: 'pcs' }
});

function canonicalUnit_(unit) {
  const raw = String(unit || '').trim().toLowerCase();
  const aliases = {
    milligram: 'mg', milligrams: 'mg',
    gram: 'g', grams: 'g', gr: 'g',
    kilogram: 'kg', kilograms: 'kg',
    milliliter: 'ml', milliliters: 'ml', millilitre: 'ml', millilitres: 'ml',
    l: 'liter', litre: 'liter', litres: 'liter', liters: 'liter',
    pc: 'pcs', piece: 'pcs', pieces: 'pcs',
    lusin: 'dozen',
    packs: 'pack', trays: 'tray', boxes: 'box', cartons: 'carton', cups: 'cup'
  };
  return aliases[raw] || raw;
}

function standardConversionFactor_(fromUnit, toUnit) {
  const from = canonicalUnit_(fromUnit);
  const to = canonicalUnit_(toUnit);
  if (from === to) return 1;

  const fromDef = TWB_STANDARD_UNIT_DEFINITIONS[from];
  const toDef = TWB_STANDARD_UNIT_DEFINITIONS[to];
  if (!fromDef || !toDef || fromDef.dimension !== toDef.dimension) return null;

  return fromDef.factorToCanonical / toDef.factorToCanonical;
}

function getMaterialByType_(itemType, itemId) {
  const type = String(itemType || '').toUpperCase();
  if (type === 'INGREDIENT') {
    const row = dbFindById('INGREDIENTS', itemId);
    if (!row) throw twbError_('NOT_FOUND', 'Ingredient not found: ' + itemId);
    return row;
  }
  if (type === 'PACKAGING') {
    const row = dbFindById('PACKAGING', itemId);
    if (!row) throw twbError_('NOT_FOUND', 'Packaging not found: ' + itemId);
    return row;
  }
  throw twbError_('VALIDATION_ITEM_TYPE', 'Item type must be INGREDIENT or PACKAGING.');
}

function findCustomConversionFactor_(itemType, itemId, fromUnit, toUnit) {
  const from = canonicalUnit_(fromUnit);
  const to = canonicalUnit_(toUnit);
  const rows = dbFindMany('UNIT_CONVERSIONS', 'item_id', itemId);

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (String(row.status).toUpperCase() !== 'ACTIVE') continue;
    if (String(row.scope).toUpperCase() !== 'ITEM') continue;
    if (String(row.item_type).toUpperCase() !== String(itemType).toUpperCase()) continue;

    const rowFrom = canonicalUnit_(row.from_unit);
    const rowTo = canonicalUnit_(row.to_unit);
    const factor = Number(row.factor);

    if (rowFrom === from && rowTo === to) return factor;
    if (rowFrom === to && rowTo === from && factor > 0) return 1 / factor;
  }
  return null;
}

function getItemConversionFactor_(itemType, itemId, fromUnit, toUnit) {
  const from = canonicalUnit_(fromUnit);
  const to = canonicalUnit_(toUnit);
  if (from === to) return 1;

  const standard = standardConversionFactor_(from, to);
  if (standard !== null) return standard;

  const material = getMaterialByType_(itemType, itemId);
  const base = canonicalUnit_(material.base_unit);
  const purchase = canonicalUnit_(material.purchase_unit);

  if (from === purchase && to === base) {
    return requirePositive_(material.purchase_to_base_factor, 'purchase_to_base_factor');
  }
  if (from === base && to === purchase) {
    return 1 / requirePositive_(material.purchase_to_base_factor, 'purchase_to_base_factor');
  }

  const custom = findCustomConversionFactor_(itemType, itemId, from, to);
  if (custom !== null) return custom;

  throw twbError_(
    'UNIT_CONVERSION_NOT_FOUND',
    'No conversion found for ' + from + ' → ' + to + ' on ' + itemId
  );
}

function convertItemUnit_(itemType, itemId, quantity, fromUnit, toUnit) {
  const qty = requireNonNegative_(quantity, 'quantity');
  const factor = getItemConversionFactor_(itemType, itemId, fromUnit, toUnit);
  return roundNumber_(qty * factor, 6);
}

function normalizeItemQuantity_(itemType, itemId, quantity, fromUnit) {
  const material = getMaterialByType_(itemType, itemId);
  return {
    quantityBase: convertItemUnit_(
      itemType,
      itemId,
      quantity,
      fromUnit,
      material.base_unit
    ),
    baseUnit: canonicalUnit_(material.base_unit)
  };
}

function createUnitConversion(payload) {
  const user = requireAnyPermission_(['PRODUCT_WRITE', 'RECIPE_WRITE']);
  payload = payload || {};

  const itemType = String(payload.item_type || '').toUpperCase();
  assertOneOf_(itemType, ['INGREDIENT', 'PACKAGING'], 'item_type');
  getMaterialByType_(itemType, payload.item_id);

  const factor = requirePositive_(payload.factor, 'factor');
  const record = stampCreate_(user, {
    conversion_id: nextBusinessId('UNIT_CONVERSION'),
    scope: 'ITEM',
    item_type: itemType,
    item_id: payload.item_id,
    from_unit: canonicalUnit_(payload.from_unit),
    to_unit: canonicalUnit_(payload.to_unit),
    factor: factor,
    status: 'ACTIVE'
  });

  return dbInsertRecord('UNIT_CONVERSIONS', record, {
    audit: true,
    action: 'CREATE'
  });
}
