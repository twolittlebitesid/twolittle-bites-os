# QA_HOTFIX_07_PUBLIC_INVOICE_POLISH.md
# Public Invoice — Visual & Date Cleanup

## Changes

### Invoice number

The public invoice number heading is smaller.

Example:

```text
INV-TLB-202610-000006
```

The heading now uses a compact responsive range instead of the previous large hero size.

### Timezone text removed

Public Invoice Date is now formatted server-side:

```text
06 Oct 2026
```

instead of allowing a raw JavaScript / Google Sheets Date representation such as:

```text
Mon Oct 05 2026 ... GMT+0700 (Waktu Indonesia Barat)
```

### Due date

Due date is now date-only:

```text
Due: 06 Oct 2026
```

The hour/minute is not shown on the public invoice.

The underlying `due_at` timestamp is not changed; this is display-only.

### Delivery label

```text
FULFILLMENT
```

is changed to:

```text
DELIVERY DETAILS
```

The stored fulfillment type remains unchanged.

### Delivery date

The displayed fulfillment date is also normalized to date-only format to prevent raw timezone strings.

### Closing block

A closing block is added inside the invoice card after Payment Status:

```text
See you for another little bite! 🤎

Instagram: @twolittle.bites | Order & inquiries: 0812 6794 8252
```

The Instagram handle and order/inquiry number are visually emphasized.

## Install from QA Hotfix 06

Replace:

```text
InvoiceService.gs
PublicInvoice.html
Phase16HealthCheck.gs
PRODUCTION_ACCEPTANCE_TEST.md
```

No schema migration.
No `upgradeToPhase16()` rerun.

Then:

```javascript
runPhase16HealthCheck()
```

Expected additional check:

```text
QA_HOTFIX_07_PUBLIC_INVOICE = true
```

Finally open a real public invoice link in a private browser and verify the date formatting visually.
