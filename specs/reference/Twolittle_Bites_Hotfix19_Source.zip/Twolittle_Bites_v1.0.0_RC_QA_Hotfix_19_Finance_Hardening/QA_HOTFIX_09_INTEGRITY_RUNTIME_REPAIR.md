# QA_HOTFIX_09_INTEGRITY_RUNTIME_REPAIR.md

# P0 — Integrity Runtime Repair

## Runtime symptom

```text
DERIVED_CACHE_COMPOSITE_KEYS = false
systemIntegrityKeyFields_ is not defined

DATA_INTEGRITY = false
5452 issue(s) across 2 group(s)
```

## Root cause

The deployed Apps Script runtime has a newer `Phase16HealthCheck.gs`, but an older
`SystemHardeningService.gs`.

`Phase16HealthCheck.gs` expects the composite-key integrity engine introduced in
QA Hotfix 03:

```text
DAILY_METRICS
metric_date + metric_key

MONTHLY_METRICS
month + metric_key
```

The old runtime hardening file still validates only:

```text
DAILY_METRICS → metric_date
MONTHLY_METRICS → month
```

which falsely reports thousands of duplicate keys.

The 5,452 issues are therefore consistent with the old checker and are not evidence
that 5,452 business records are corrupt.

## Fix

QA Hotfix 09 deliberately re-ships `SystemHardeningService.gs` so this dependency
cannot be missed by applying later deltas.

It also adds an explicit runtime marker:

```text
QA_HOTFIX_09_COMPOSITE_KEYS_V1
```

`DERIVED_CACHE_COMPOSITE_KEYS` only passes when both the marker and the correct
composite-key mapping are present.

## Install from QA Hotfix 08

Replace/add:

```text
REPLACE
SystemHardeningService.gs
Phase16HealthCheck.gs

ADD
QAHotfix09Setup.gs
```

No schema migration.
No data rewrite.
No `upgradeToPhase16()` rerun.

## Run

After Save:

```javascript
runQAHotfix09IntegrityRepairCheck()
```

Expected:

```text
engineVersion = QA_HOTFIX_09_COMPOSITE_KEYS_V1
dailyMetricKey = [metric_date, metric_key]
monthlyMetricKey = [month, metric_key]
integrityOk = true
totalIssues = 0
```

Then run:

```javascript
runPhase16HealthCheck()
```

Expected:

```text
DERIVED_CACHE_COMPOSITE_KEYS = true
DATA_INTEGRITY = true
```

If real integrity issues remain, `runQAHotfix09IntegrityRepairCheck()` returns the
exact remaining issue groups instead of hiding them.
