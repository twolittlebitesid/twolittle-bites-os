# QA_HOTFIX_14_THERMAL_PRINTING.md

# QA Hotfix 14 — Thermal Receipt Printing

## Scope

This hotfix adds browser-based thermal receipt printing without adding a local print bridge.

Supported in this phase:

- 58 mm receipt layout
- 80 mm receipt layout
- Print Receipt from Finance → Invoices
- Print Receipt from Order detail after payment exists
- optional auto-open print after successful payment
- configurable logo/customer/payment method visibility
- suggested copy count
- optional Kitchen Ticket browser print

Not included in this phase:

- silent / direct ESC/POS printing
- automatic printer selection
- USB device access from Apps Script
- QZ Tray / PrintNode / JSPrintManager integration

The operating system / browser print dialog remains responsible for choosing the physical printer and actual copy count.

## Settings

Open:

```text
Settings → Printing
```

Available controls:

```text
Print Mode: Browser Print
Paper Size: 58 mm / 80 mm
Suggested Copies: 1–3
Auto Open Print After Payment
Show Logo
Show Customer
Show Payment Method
Kitchen Ticket
```

## Receipt actions

### Finance → Invoices

Paid / partially-paid invoices expose a Print Receipt action.

### Orders

If the Order already has an Invoice with a paid amount, the Invoice strip exposes:

```text
Invoice
Receipt
WhatsApp
```

When Kitchen Ticket is enabled:

```text
Kitchen
```

is also available.

## Auto print after payment

When enabled, Record Payment pre-opens a blank browser window during the user submit action. After the payment is successfully stored, that window navigates to the receipt URL and calls `window.print()`.

This avoids most popup blockers, but browser policy can still block it. If blocked, the payment remains successfully saved and the user can use Print Receipt manually.

## Security

Receipt uses the same public invoice token model as Public Invoice.

Kitchen Ticket does **not** reuse the public invoice token. It uses an internal `invoice_id` route and calls the existing permission layer before rendering because Kitchen Ticket can contain `production_notes`.

## Printer setup

The printer must already be installed in the operating system.

Typical flow:

```text
Twolittle.bites OS
→ Print Receipt
→ Browser print dialog
→ Select thermal printer
→ Confirm 58/80 mm paper
→ Print
```

USB, LAN, or Wi-Fi printers can all work if the operating system exposes them to the browser print dialog.

## Apply from Hotfix 13

ADD:

```text
ReceiptService.gs
PublicReceipt.html
PublicKitchenTicket.html
QAHotfix14Setup.gs
```

REPLACE:

```text
Constants.gs
WebApp.gs
InvoiceService.gs
FinanceService.gs
OrderService.gs
SettingsService.gs
ApiGateway.gs
PageSettings.html
JsSettings.html
JsFinance.html
JsOrders.html
StylesComponents.html
Phase16HealthCheck.gs
Phase16SmokeTest.gs
PRODUCTION_ACCEPTANCE_TEST.md
README.md
```

No Sheet schema migration.
No data rewrite.

## Setup / runtime QA

Run once:

```javascript
upgradeToQAHotfix14()
```

Then test an existing Invoice:

```javascript
runQAHotfix14ReceiptSmoke('INV-TLB-202610-000006')
```

Expected:

```text
ok = true
receiptUrl = ...?receipt=...
printing.paperSize = 58 or 80
```

Then run:

```javascript
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
```
