function nowIso_() {
  return Utilities.formatDate(new Date(), TWB_APP.TIMEZONE, "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function todayIso_() {
  return Utilities.formatDate(new Date(), TWB_APP.TIMEZONE, 'yyyy-MM-dd');
}

function monthKey_() {
  return Utilities.formatDate(new Date(), TWB_APP.TIMEZONE, 'yyyyMM');
}

function twbError_(code, message, details) {
  const err = new Error(message || code);
  err.code = code;
  err.details = details || null;
  return err;
}

function normalizeEmail_(email) {
  return String(email || '').trim().toLowerCase();
}

function normalizeWhatsApp_(phone) {
  let value = String(phone || '').replace(/[^\d]/g, '');
  if (!value) return '';

  let countryCode = '62';

  try {
    const configured = String(
      getBusinessSetting_('whatsapp_country_code') || ''
    ).replace(/[^\d]/g, '');

    if (configured) countryCode = configured;
  } catch (ignore) {
    // Setup / early bootstrap fallback.
  }

  if (value.indexOf('0') === 0) {
    value = countryCode + value.substring(1);
  } else if (value.indexOf('8') === 0) {
    value = countryCode + value;
  }

  return value;
}

function stringifyCellValue_(value, valueType) {
  if (valueType === 'JSON') return JSON.stringify(value);
  if (valueType === 'BOOLEAN') return value ? 'TRUE' : 'FALSE';
  return String(value);
}

function parseConfigValue_(raw, type) {
  if (type === 'NUMBER') return Number(raw);
  if (type === 'BOOLEAN') return String(raw).toUpperCase() === 'TRUE';
  if (type === 'JSON') {
    try { return JSON.parse(raw); } catch (e) { return null; }
  }
  return raw;
}

function randomPublicToken_() {
  return Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '').substring(0, 12);
}

function safeJson_(value) {
  try { return JSON.stringify(value); } catch (e) { return JSON.stringify({ error: 'UNSERIALIZABLE' }); }
}

function displayNameFromEmail_(email) {
  const local = normalizeEmail_(email).split('@')[0] || 'Owner';
  return local
    .split(/[._-]/)
    .filter(Boolean)
    .map(function(s) { return s.charAt(0).toUpperCase() + s.substring(1); })
    .join(' ') || 'Owner';
}
