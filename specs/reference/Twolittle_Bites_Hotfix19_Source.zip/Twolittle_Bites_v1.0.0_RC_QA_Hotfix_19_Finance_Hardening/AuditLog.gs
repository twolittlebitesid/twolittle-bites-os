function writeAuditLog_(action, entityType, entityId, beforeValue, afterValue, notes) {
  let userId = 'SYSTEM';
  try {
    const email = resolveCurrentEmail_();
    const user = email ? dbFindOne('USERS', 'email', email) : null;
    if (user) userId = user.user_id;
  } catch (e) {}

  const record = {
    log_id: nextBusinessId('ACTIVITY_LOG'),
    timestamp: nowIso_(),
    user_id: userId,
    action: action,
    entity_type: entityType,
    entity_id: entityId || '',
    before_json: beforeValue === null || beforeValue === undefined ? '' : safeJson_(beforeValue),
    after_json: afterValue === null || afterValue === undefined ? '' : safeJson_(afterValue),
    source: 'WEB_APP',
    notes: notes || ''
  };

  // Direct repository insert with no recursive audit.
  return dbInsertRecord('ACTIVITY_LOG', record, { validate: true, audit: false });
}
