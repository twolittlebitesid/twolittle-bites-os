# RELEASE_CHECKLIST.md
# Twolittle.bites OS v1.0

Use this checklist in order.

## A. Install Phase 16

Replace/add files from:

```text
Twolittle_Bites_Phase_16_Delta.zip
```

Save the Apps Script project.

Confirm the function dropdown contains:

```text
upgradeToPhase16
runPhase16HealthCheck
runPhase16SmokeTest
runPhase15RegressionSuite
createPhase16ReleaseBackup
runPhase16ReleasePreflight
markPhase16ProductionReady
```

## B. Upgrade

Run:

```javascript
upgradeToPhase16()
```

Expected:
- App Version `1.0.0`
- Schema Version `1.0.0`
- 33 canonical sheets
- no schema migration.

## C. Baseline validation

Run:

```javascript
runPhase16HealthCheck()
```

Expected:

```text
ok = true
```

Then:

```javascript
runPhase16SmokeTest()
```

Expected:

```text
ok = true
```

## D. Cross-module regression

Run:

```javascript
runPhase15RegressionSuite()
```

Release target:

```text
13 / 13 modules passed
```

Do not release with a failed module.

## E. Browser / mobile QA

Complete `PRODUCTION_ACCEPTANCE_TEST.md`.

Minimum:
- desktop;
- mobile viewport;
- Orders;
- Invoice;
- Payment;
- Production;
- Inventory;
- Purchasing;
- Pre-Order;
- Finance;
- Customers;
- Marketing;
- Reports;
- Settings;
- public invoice.

## F. Fresh release backup

Run:

```javascript
createPhase16ReleaseBackup()
```

Open the backup and verify it is a Google Spreadsheet copy.

Release preflight requires a verified backup no older than 24 hours.

## G. Final preflight

Run:

```javascript
runPhase16ReleasePreflight()
```

Required:

```text
ok = true
blockingFailures = 0
```

Review warnings.

## H. Mark production ready

Run:

```javascript
markPhase16ProductionReady()
```

Expected:

```text
RELEASE_STATUS = PRODUCTION_READY
```

## I. Deploy Apps Script manually

Follow `DEPLOYMENT_GUIDE.md`.

Do not overwrite or change the production database ID during normal code deployment.

## J. Live acceptance

On the production `/exec` URL:
- login;
- open every core module;
- create one controlled test Order if appropriate;
- verify invoice/public invoice;
- verify no console/server blocking errors;
- verify responsive navigation.

## K. Mark released

From:

```text
Settings → Release → Mark Released
```

Record:
- production Web App URL;
- release notes.

Expected:

```text
RELEASE_STATUS = RELEASED
APP_VERSION = 1.0.0
```

## L. Post-release

Confirm:
- daily maintenance trigger configured, or document why not;
- backup folder accessible to OWNER;
- rollback guide accessible;
- operator guide shared with operating team.

Monitor the first production operating cycle for:
- failed RPCs;
- inventory mismatch;
- invoice/payment mismatch;
- report anomalies.

If a release-blocking issue appears:

```text
Settings → Release → Rollback Required
```

Then follow `ROLLBACK_PLAN.md`.
