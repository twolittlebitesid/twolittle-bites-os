/**
 * Twolittle.bites OS — Phase 5 Web App entry point.
 *
 * Internal app:
 *   /exec
 *
 * Public invoice:
 *   /exec?invoice=<public_token>
 */
function doGet(e) {
  const params =
    e && e.parameter
      ? e.parameter
      : {};

  const receiptToken = String(
    params.receipt || ''
  ).trim();

  const kitchenInvoiceId = String(
    params.kitchen_invoice || ''
  ).trim();

  const invoiceToken = String(
    params.invoice || ''
  ).trim();

  const autoPrint =
    String(
      params.autoprint || ''
    ) === '1';

  if (receiptToken) {
    return renderPublicReceipt_(
      receiptToken,
      autoPrint
    );
  }

  if (kitchenInvoiceId) {
    return renderKitchenTicket_(
      kitchenInvoiceId,
      autoPrint
    );
  }

  if (invoiceToken) {
    return renderPublicInvoice_(invoiceToken);
  }

  return HtmlService
    .createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Twolittle.bites OS')
    .addMetaTag(
      'viewport',
      'width=device-width, initial-scale=1, viewport-fit=cover'
    );
}

function doPost(e) {
  var contents =
    e && e.postData
      ? e.postData.contents || ''
      : '';

  var response =
    handleLocalBridgePost_(
      contents
    );

  return ContentService
    .createTextOutput(
      JSON.stringify(response)
    )
    .setMimeType(
      ContentService.MimeType.JSON
    );
}

function renderPublicInvoice_(token) {
  const data = getPublicInvoiceDataByToken_(token);

  if (!data) {
    const template = HtmlService.createTemplateFromFile(
      'PublicInvoiceNotFound'
    );
    return template
      .evaluate()
      .setTitle('Invoice not found')
      .addMetaTag(
        'viewport',
        'width=device-width, initial-scale=1, viewport-fit=cover'
      );
  }

  const template = HtmlService.createTemplateFromFile(
    'PublicInvoice'
  );
  template.invoice = data;

  return template
    .evaluate()
    .setTitle(data.invoiceNumber + ' · ' + data.businessName)
    .addMetaTag(
      'viewport',
      'width=device-width, initial-scale=1, viewport-fit=cover'
    );
}

function renderPublicReceipt_(
  token,
  autoPrint
) {
  const data =
    getPublicReceiptDataByToken_(
      token,
      {
        autoPrint:
          autoPrint === true
      }
    );

  if (!data) {
    const template =
      HtmlService
        .createTemplateFromFile(
          'PublicInvoiceNotFound'
        );

    return template
      .evaluate()
      .setTitle(
        'Receipt not found'
      )
      .addMetaTag(
        'viewport',
        'width=device-width, initial-scale=1, viewport-fit=cover'
      );
  }

  const template =
    HtmlService
      .createTemplateFromFile(
        'PublicReceipt'
      );

  template.receipt = data;

  return template
    .evaluate()
    .setTitle(
      data.invoiceNumber +
      ' · Receipt'
    )
    .addMetaTag(
      'viewport',
      'width=device-width, initial-scale=1, viewport-fit=cover'
    );
}

function renderKitchenTicket_(
  invoiceId,
  autoPrint
) {
  const data =
    getInternalKitchenTicketDataByInvoiceId_(
      invoiceId,
      {
        autoPrint:
          autoPrint === true
      }
    );

  if (!data) {
    const template =
      HtmlService
        .createTemplateFromFile(
          'PublicInvoiceNotFound'
        );

    return template
      .evaluate()
      .setTitle(
        'Kitchen ticket not found'
      )
      .addMetaTag(
        'viewport',
        'width=device-width, initial-scale=1, viewport-fit=cover'
      );
  }

  const template =
    HtmlService
      .createTemplateFromFile(
        'PublicKitchenTicket'
      );

  template.ticket = data;

  return template
    .evaluate()
    .setTitle(
      data.orderId +
      ' · Kitchen Ticket'
    )
    .addMetaTag(
      'viewport',
      'width=device-width, initial-scale=1, viewport-fit=cover'
    );
}

function include(filename) {
  return HtmlService
    .createHtmlOutputFromFile(filename)
    .getContent();
}
