/**
 * Twolittle.bites OS — Phase 9 upgrade.
 */
function upgradeToPhase9() {
  var user =
    requireRole_([TWB_ROLES.OWNER]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'PREORDER_ALMOST_FULL_RATIO',
    0.20,
    'NUMBER',
    'Campaign becomes ALMOST_FULL when remaining capacity is 20% or less.',
    user.user_id
  );

  setConfig_(
    'PREORDER_CAPACITY_SOURCE',
    'LINKED_NON_CANCELLED_ORDERS',
    'STRING',
    'Booked capacity is recalculated from linked non-cancelled Orders.',
    user.user_id
  );

  return runPhase9HealthCheck();
}
