# QA Hotfix 16 — WhatsApp Delivery Fee Placeholder

Adds `{delivery_fee}` to the WhatsApp invoice template system.

Mapping:

```text
{delivery_fee} → invoice.delivery_fee → formatIdrText_()
```

Example:

```text
Diskon: {discount}
Ongkir: {delivery_fee}
Total: {total}
```

renders as:

```text
Diskon: Rp25.000
Ongkir: Rp15.000
Total: Rp250.000
```

Changes:
- `WhatsAppService.gs`: renderer value map now includes `delivery_fee`.
- `SettingsService.gs`: `delivery_fee` is an allowed placeholder and included in the default template.
- `JsSettings.html`: live preview has a delivery-fee sample value.
- `QAHotfix16Setup.gs`: safe one-time helper fills only an existing blank `Ongkir:` line; it does not rewrite other custom templates.
- `Phase16HealthCheck.gs`: adds `QA_HOTFIX_16_WA_DELIVERY_FEE`.

No Sheet schema migration. No data rewrite.
