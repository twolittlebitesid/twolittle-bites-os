/**
 * Run once after adding Phase 3 files.
 * No schema migration is required.
 */
function upgradeToPhase3() {
  const user = requireRole_([TWB_ROLES.OWNER]);

  const schema = validateDatabaseSchema();
  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Phase 1 schema is not healthy. Resolve schema issues before Phase 3 upgrade.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'RECIPE_COST_BASIS',
    'LATEST_COST',
    'STRING',
    'Phase 3 recipe costing basis. Falls back to average cost when latest cost is zero.',
    user.user_id
  );

  return runPhase3HealthCheck();
}
