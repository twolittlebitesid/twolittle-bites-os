/**
 * Twolittle.bites OS — Phase 16 constants.
 * Schema version: 1.0.0
 */
const TWB_APP = Object.freeze({
  NAME: 'Twolittle.bites OS',
  PHASE: '16',
  APP_VERSION: '1.0.0',
  SCHEMA_VERSION: '1.0.0',
  TIMEZONE: 'Asia/Jakarta',
  CURRENCY: 'IDR',
  BRAND: Object.freeze({
    PRIMARY: '#DE5D3D',
    CREAM: '#F6F6D2',
    PINK: '#FDD3D7',
    BURNT: '#9E3B26',
    HEALTHY: '#2E7D32',
    ATTENTION: '#E65100',
    CRITICAL: '#C62828'
  })
});

const TWB_ROLES = Object.freeze({
  OWNER: 'OWNER',
  ADMIN: 'ADMIN',
  PRODUCTION: 'PRODUCTION',
  MARKETING: 'MARKETING',
  FINANCE: 'FINANCE'
});

const TWB_USER_STATUS = Object.freeze({
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE'
});

const TWB_ORDER_STATUS = Object.freeze({
  DRAFT: 'DRAFT',
  WAITING_PAYMENT: 'WAITING_PAYMENT',
  CONFIRMED: 'CONFIRMED',
  SCHEDULED: 'SCHEDULED',
  IN_PRODUCTION: 'IN_PRODUCTION',
  READY: 'READY',
  ON_DELIVERY: 'ON_DELIVERY',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED'
});

const TWB_PAYMENT_STATUS = Object.freeze({
  UNPAID: 'UNPAID',
  WAITING_PAYMENT: 'WAITING_PAYMENT',
  PARTIAL: 'PARTIAL',
  PAID: 'PAID',
  REFUNDED: 'REFUNDED',
  FAILED: 'FAILED'
});

const TWB_INVOICE_STATUS = Object.freeze({
  DRAFT: 'DRAFT',
  SENT: 'SENT',
  WAITING_PAYMENT: 'WAITING_PAYMENT',
  PARTIAL: 'PARTIAL',
  PAID: 'PAID',
  OVERDUE: 'OVERDUE',
  CANCELLED: 'CANCELLED',
  REFUNDED: 'REFUNDED'
});

const TWB_PAYMENT_EVENT_STATUS = Object.freeze({
  SUCCESS: 'SUCCESS',
  REFUND: 'REFUND',
  FAILED: 'FAILED'
});

const TWB_PREORDER_STATUS = Object.freeze({
  DRAFT: 'DRAFT',
  OPEN: 'OPEN',
  ALMOST_FULL: 'ALMOST_FULL',
  FULL: 'FULL',
  CLOSED: 'CLOSED',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED'
});

const TWB_PRODUCTION_PLAN_STATUS = Object.freeze({
  DRAFT: 'DRAFT',
  PLANNED: 'PLANNED',
  IN_PROGRESS: 'IN_PROGRESS',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED'
});

const TWB_PURCHASE_STATUS = Object.freeze({
  DRAFT: 'DRAFT',
  ORDERED: 'ORDERED',
  PARTIAL: 'PARTIAL',
  RECEIVED: 'RECEIVED',
  CANCELLED: 'CANCELLED'
});

const TWB_REQUIREMENT_STATUS = Object.freeze({
  SUFFICIENT: 'SUFFICIENT',
  LOW: 'LOW',
  SHORTAGE: 'SHORTAGE'
});

const TWB_BASE_UNITS = Object.freeze({
  WEIGHT: 'g',
  VOLUME: 'ml',
  COUNT: 'pcs'
});

const TWB_ID_DEFINITIONS = Object.freeze({
  USER: { prefix: 'USR', monthly: false },
  CUSTOMER: { prefix: 'CUS', monthly: false },
  PRODUCT: { prefix: 'PRD', monthly: false },
  VARIANT: { prefix: 'VAR', monthly: false },
  RECIPE: { prefix: 'RCP', monthly: false },
  RECIPE_ITEM: { prefix: 'RCI', monthly: false },
  INGREDIENT: { prefix: 'ING', monthly: false },
  PACKAGING: { prefix: 'PKG', monthly: false },
  UNIT_CONVERSION: { prefix: 'UCV', monthly: false },
  PREORDER: { prefix: 'PRE', monthly: true },
  ORDER: { prefix: 'ORD', monthly: true },
  ORDER_ITEM: { prefix: 'ORI', monthly: false },
  INVOICE: { prefix: 'INV', monthly: true },
  PAYMENT: { prefix: 'PAY', monthly: true },
  PRODUCTION_PLAN: { prefix: 'PPL', monthly: true },
  PRODUCTION_PLAN_ITEM: { prefix: 'PPI', monthly: false },
  REQUIREMENT: { prefix: 'REQ', monthly: false },
  PRODUCTION_BATCH: { prefix: 'BAT', monthly: true },
  INVENTORY: { prefix: 'STK', monthly: false },
  INVENTORY_MOVEMENT: { prefix: 'MOV', monthly: true },
  SUPPLIER: { prefix: 'SUP', monthly: false },
  PURCHASE: { prefix: 'PUR', monthly: true },
  PURCHASE_ITEM: { prefix: 'PUI', monthly: false },
  EXPENSE: { prefix: 'EXP', monthly: true },
  TRANSACTION: { prefix: 'TRX', monthly: true },
  TARGET: { prefix: 'TGT', monthly: false },
  MARKETING_CAMPAIGN: { prefix: 'MKT', monthly: true },
  CONTENT: { prefix: 'CNT', monthly: false },
  ACTIVITY_LOG: { prefix: 'LOG', monthly: true }
});

const TWB_CONFIG_DEFAULTS = Object.freeze({
  SCHEMA_VERSION: { value: TWB_APP.SCHEMA_VERSION, type: 'STRING', description: 'Current database schema version.' },
  APP_VERSION: { value: TWB_APP.APP_VERSION, type: 'STRING', description: 'Current application version.' },
  APP_NAME: { value: TWB_APP.NAME, type: 'STRING', description: 'Application name.' },
  TIMEZONE: { value: TWB_APP.TIMEZONE, type: 'STRING', description: 'Application timezone.' },
  CURRENCY: { value: TWB_APP.CURRENCY, type: 'STRING', description: 'Application currency.' },
  NEGATIVE_STOCK_ALLOWED: { value: false, type: 'BOOLEAN', description: 'Allow inventory balance below zero.' },
  ALLOW_ADMIN_PREORDER_OVERRIDE: { value: false, type: 'BOOLEAN', description: 'Allow ADMIN to override preorder cutoff/capacity.' },
  DEFAULT_PAGE_SIZE: { value: 50, type: 'NUMBER', description: 'Default list page size.' },
  MAX_PAGE_SIZE: { value: 200, type: 'NUMBER', description: 'Maximum list page size.' },
  SALES_CHANNELS: { value: ['WHATSAPP','INSTAGRAM','WEBSITE','OFFLINE','GOFOOD','GRABFOOD','SHOPEEFOOD','TOKOPEDIA','BAZAAR','OTHER'], type: 'JSON', description: 'Initial order source channels.' },
  EXPENSE_CATEGORIES: { value: ['INGREDIENTS','PACKAGING','SALARY','MARKETING','ADS','DELIVERY','RENT','UTILITIES','EQUIPMENT','MARKETPLACE_FEE','OTHER'], type: 'JSON', description: 'Initial expense categories.' },
  PAYMENT_METHODS: { value: ['CASH','BCA','MANDIRI','QRIS','TRANSFER','OTHER'], type: 'JSON', description: 'Initial payment methods.' },
  FULFILLMENT_TYPES: { value: ['PICKUP','OWN_DELIVERY','GOJEK','GRAB','LALAMOVE','OTHER'], type: 'JSON', description: 'Initial fulfillment types.' }
});

const TWB_BUSINESS_SETTING_DEFAULTS = Object.freeze([
  ['business_name', 'Twolittle.bites', 'STRING', 'BUSINESS', 'Business display name.'],
  ['brand_logo_url', '', 'STRING', 'BUSINESS', 'Public business logo URL shown on invoices.'],
  ['timezone', TWB_APP.TIMEZONE, 'STRING', 'BUSINESS', 'Business timezone.'],
  ['currency', TWB_APP.CURRENCY, 'STRING', 'BUSINESS', 'Business currency.'],
  ['invoice_prefix', 'INV-TLB', 'STRING', 'INVOICE', 'Invoice display prefix.'],
  ['invoice_due_hours', '24', 'NUMBER', 'INVOICE', 'Default invoice payment due time in hours.'],
  ['whatsapp_country_code', '62', 'STRING', 'WHATSAPP', 'Default country prefix for WhatsApp normalization.'],
  ['payment_methods', JSON.stringify(['CASH','BCA','MANDIRI','QRIS','TRANSFER','OTHER']), 'JSON', 'PAYMENT', 'Available payment methods.'],
  ['receipt_paper_size', '80', 'STRING', 'PRINTING', 'Browser thermal receipt paper size.'],
  ['receipt_copies', 1, 'NUMBER', 'PRINTING', 'Suggested receipt copy count.'],
  ['receipt_auto_print_after_payment', false, 'BOOLEAN', 'PRINTING', 'Open receipt print flow after successful payment.'],
  ['receipt_show_logo', true, 'BOOLEAN', 'PRINTING', 'Show business logo on receipt.'],
  ['receipt_show_customer', true, 'BOOLEAN', 'PRINTING', 'Show customer on receipt and kitchen ticket.'],
  ['receipt_show_payment_method', true, 'BOOLEAN', 'PRINTING', 'Show payment method on receipt.'],
  ['kitchen_ticket_enabled', false, 'BOOLEAN', 'PRINTING', 'Enable kitchen ticket print action.']
]);
