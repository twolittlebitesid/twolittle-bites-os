/**
 * Twolittle.bites OS — Phase 7 Inventory Engine
 *
 * Source of truth:
 * INVENTORY_MOVEMENTS is the stock ledger.
 * INVENTORY.current_stock_base is a materialized balance cache.
 */

const TWB_INVENTORY_OUT_TYPES = Object.freeze([
  'MANUAL_OUT',
  'ADJUSTMENT_OUT',
  'PRODUCTION_USAGE',
  'WASTE'
]);

const TWB_INVENTORY_IN_TYPES = Object.freeze([
  'OPENING_BALANCE',
  'MANUAL_IN',
  'ADJUSTMENT_IN',
  'RETURN_IN',
  'PURCHASE_RECEIPT'
]);

function getInventoryMaterialMaps_() {
  const ingredients = listAllRecords_('INGREDIENTS');
  const packaging = listAllRecords_('PACKAGING');

  const ingredientMap = {};
  ingredients.forEach(function(row) {
    ingredientMap[row.ingredient_id] = row;
  });

  const packagingMap = {};
  packaging.forEach(function(row) {
    packagingMap[row.packaging_id] = row;
  });

  return {
    ingredients: ingredients,
    packaging: packaging,
    ingredientMap: ingredientMap,
    packagingMap: packagingMap
  };
}

function getMaterialForInventory_(itemType, itemId) {
  return getMaterialByType_(itemType, itemId);
}

function getOrCreateInventoryRow_(itemType, itemId, actorUser) {
  const existing = dbFindOne(
    'INVENTORY',
    'item_id',
    itemId
  );

  if (existing) return existing;

  const material = getMaterialForInventory_(
    itemType,
    itemId
  );

  const row = {
    inventory_id: nextBusinessId('INVENTORY'),
    item_type: String(itemType).toUpperCase(),
    item_id: itemId,
    current_stock_base: 0,
    minimum_stock_base:
      Number(material.minimum_stock_base || 0),
    average_cost_per_base_unit:
      Number(material.average_cost_per_base_unit || 0),
    last_movement_at: '',
    updated_at: nowIso_()
  };

  return dbInsertRecord(
    'INVENTORY',
    row,
    { validate: true, audit: false }
  );
}

function movementDirection_(movementType) {
  const type = String(movementType || '').toUpperCase();

  if (TWB_INVENTORY_IN_TYPES.indexOf(type) >= 0) {
    return 'IN';
  }

  if (TWB_INVENTORY_OUT_TYPES.indexOf(type) >= 0) {
    return 'OUT';
  }

  throw twbError_(
    'INVENTORY_MOVEMENT_TYPE_INVALID',
    'Unknown inventory movement type: ' + type
  );
}

function inventoryStatus_(stock, minimum) {
  const current = Number(stock || 0);
  const min = Number(minimum || 0);

  if (current <= 0) return 'OUT_OF_STOCK';
  if (current < min) return 'LOW';
  return 'OK';
}

function calculateLedgerBalanceFromMovements_(movements) {
  return (movements || []).reduce(function(sum, movement) {
    return (
      sum +
      Number(movement.quantity_in_base || 0) -
      Number(movement.quantity_out_base || 0)
    );
  }, 0);
}

function inventoryReconciliationReport_() {
  const inventory = listAllRecords_('INVENTORY');
  const movements = listAllRecords_('INVENTORY_MOVEMENTS');

  const groups = {};
  movements.forEach(function(movement) {
    if (!groups[movement.item_id]) groups[movement.item_id] = [];
    groups[movement.item_id].push(movement);
  });

  return inventory.map(function(row) {
    const ledgerBalance =
      calculateLedgerBalanceFromMovements_(
        groups[row.item_id] || []
      );

    const cached =
      Number(row.current_stock_base || 0);

    return {
      inventoryId: row.inventory_id,
      itemType: row.item_type,
      itemId: row.item_id,
      cachedBalance: roundNumber_(cached, 6),
      ledgerBalance: roundNumber_(ledgerBalance, 6),
      difference: roundNumber_(
        cached - ledgerBalance,
        6
      ),
      ok:
        Math.abs(cached - ledgerBalance) <
        0.000001
    };
  });
}

function ensureOpeningInventoryLedgerPhase7_() {
  const user = requireCurrentUser_();
  const inventoryRows = listAllRecords_('INVENTORY');
  const movements = listAllRecords_('INVENTORY_MOVEMENTS');

  const movementCount = {};
  movements.forEach(function(row) {
    movementCount[row.item_id] =
      (movementCount[row.item_id] || 0) + 1;
  });

  const openingRows = [];

  inventoryRows.forEach(function(row) {
    const stock = Number(
      row.current_stock_base || 0
    );

    if (
      Math.abs(stock) < 0.000001 ||
      movementCount[row.item_id]
    ) {
      return;
    }

    const material = getMaterialForInventory_(
      row.item_type,
      row.item_id
    );

    openingRows.push({
      movement_id:
        nextBusinessId('INVENTORY_MOVEMENT'),
      movement_at: nowIso_(),
      item_type: row.item_type,
      item_id: row.item_id,
      movement_type: 'OPENING_BALANCE',
      quantity_in_base:
        stock > 0 ? stock : 0,
      quantity_out_base:
        stock < 0 ? Math.abs(stock) : 0,
      balance_after_base: stock,
      base_unit: material.base_unit,
      reference_type: 'PHASE7_UPGRADE',
      reference_id: row.inventory_id,
      notes:
        'Opening balance created from pre-Phase-7 materialized stock.',
      created_at: nowIso_(),
      created_by: user.user_id,
      updated_at: nowIso_(),
      updated_by: user.user_id
    });
  });

  if (openingRows.length) {
    dbBulkInsert(
      'INVENTORY_MOVEMENTS',
      openingRows,
      { validate: true }
    );
  }

  return {
    openingMovementCount: openingRows.length
  };
}

function ensureInventoryRowsPhase7_() {
  const user = requireCurrentUser_();
  const maps = getInventoryMaterialMaps_();
  const inventory = listAllRecords_('INVENTORY');

  const existing = {};
  inventory.forEach(function(row) {
    existing[row.item_id] = true;
  });

  let created = 0;

  maps.ingredients.forEach(function(row) {
    if (!existing[row.ingredient_id]) {
      getOrCreateInventoryRow_(
        'INGREDIENT',
        row.ingredient_id,
        user
      );
      created += 1;
    }
  });

  maps.packaging.forEach(function(row) {
    if (!existing[row.packaging_id]) {
      getOrCreateInventoryRow_(
        'PACKAGING',
        row.packaging_id,
        user
      );
      created += 1;
    }
  });

  return {
    createdInventoryRows: created
  };
}

function inventoryModuleBootstrap() {
  const user = requirePermission_('INVENTORY_READ');

  const maps = getInventoryMaterialMaps_();
  const inventory = listAllRecords_('INVENTORY');
  const movements = listAllRecords_('INVENTORY_MOVEMENTS');
  const plans = listAllRecords_('PRODUCTION_PLANS');
  const requirements = listAllRecords_('PRODUCTION_REQUIREMENTS');

  const movementGroups = {};
  movements.forEach(function(row) {
    if (!movementGroups[row.item_id]) {
      movementGroups[row.item_id] = [];
    }
    movementGroups[row.item_id].push(row);
  });

  const materials = inventory.map(function(row) {
    const type = String(row.item_type).toUpperCase();

    const material =
      type === 'INGREDIENT'
        ? maps.ingredientMap[row.item_id] || {}
        : maps.packagingMap[row.item_id] || {};

    const stock = Number(
      row.current_stock_base || 0
    );
    const min = Number(
      row.minimum_stock_base || 0
    );
    const avg = Number(
      row.average_cost_per_base_unit || 0
    );

    return Object.assign(
      {},
      stripInternalFields_(row),
      {
        item_name:
          type === 'INGREDIENT'
            ? material.ingredient_name || row.item_id
            : material.packaging_name || row.item_id,
        category: material.category || '',
        base_unit: material.base_unit || '',
        purchase_unit: material.purchase_unit || '',
        latest_cost_per_base_unit:
          Number(
            material.latest_cost_per_base_unit || 0
          ),
        valuation:
          Math.round(stock * avg),
        stock_status:
          inventoryStatus_(stock, min),
        movement_count:
          (movementGroups[row.item_id] || []).length
      }
    );
  });

  materials.sort(function(a, b) {
    const weight = {
      OUT_OF_STOCK: 1,
      LOW: 2,
      OK: 3
    };

    const statusCompare =
      (weight[a.stock_status] || 9) -
      (weight[b.stock_status] || 9);

    return statusCompare ||
      String(a.item_name).localeCompare(
        String(b.item_name)
      );
  });

  const movementRows = movements
    .map(function(row) {
      const type = String(row.item_type).toUpperCase();

      const material =
        type === 'INGREDIENT'
          ? maps.ingredientMap[row.item_id] || {}
          : maps.packagingMap[row.item_id] || {};

      return Object.assign(
        {},
        stripInternalFields_(row),
        {
          item_name:
            type === 'INGREDIENT'
              ? material.ingredient_name || row.item_id
              : material.packaging_name || row.item_id
        }
      );
    })
    .sort(function(a, b) {
      return String(b.movement_at || '').localeCompare(
        String(a.movement_at || '')
      );
    });

  const usageByPlan = {};
  movements.forEach(function(row) {
    if (
      String(row.movement_type).toUpperCase() ===
        'PRODUCTION_USAGE' &&
      String(row.reference_type).toUpperCase() ===
        'PRODUCTION_PLAN'
    ) {
      usageByPlan[row.reference_id] = true;
    }
  });

  const reqGroups = {};
  requirements.forEach(function(req) {
    if (!reqGroups[req.production_plan_id]) {
      reqGroups[req.production_plan_id] = [];
    }
    reqGroups[req.production_plan_id].push(req);
  });

  const productionPlans = plans
    .filter(function(plan) {
      return [
        'PLANNED',
        'IN_PROGRESS',
        'COMPLETED'
      ].indexOf(
        String(plan.status).toUpperCase()
      ) >= 0;
    })
    .map(function(plan) {
      const reqs =
        reqGroups[plan.production_plan_id] || [];

      return Object.assign(
        {},
        stripInternalFields_(plan),
        {
          requirement_count: reqs.length,
          required_item_count: reqs.length,
          usage_posted:
            !!usageByPlan[plan.production_plan_id],
          shortage_count:
            reqs.filter(function(req) {
              return String(req.status).toUpperCase() ===
                'SHORTAGE';
            }).length
        }
      );
    })
    .sort(function(a, b) {
      return String(b.production_date || '').localeCompare(
        String(a.production_date || '')
      );
    });

  const reconciliation =
    inventoryReconciliationReport_();

  return {
    materials: materials,
    movements: movementRows.slice(0, 500),
    productionPlans: productionPlans,
    reconciliation: reconciliation,
    permissions: {
      inventoryAdjust:
        hasPermission_(user, 'INVENTORY_ADJUST'),
      productionWrite:
        hasPermission_(user, 'PRODUCTION_WRITE')
    }
  };
}

function findMovementByReference_(
  referenceType,
  referenceId,
  movementType
) {
  const rows = dbFindMany(
    'INVENTORY_MOVEMENTS',
    'reference_id',
    referenceId
  );

  return rows.filter(function(row) {
    return (
      String(row.reference_type || '').toUpperCase() ===
        String(referenceType || '').toUpperCase() &&
      (
        !movementType ||
        String(row.movement_type || '').toUpperCase() ===
          String(movementType).toUpperCase()
      )
    );
  });
}

function recordInventoryMovement(payload) {
  const user = requirePermission_(
    'INVENTORY_ADJUST'
  );

  payload = payload || {};

  const itemType =
    String(payload.item_type || '').toUpperCase();

  assertOneOf_(
    itemType,
    ['INGREDIENT', 'PACKAGING'],
    'item_type'
  );

  const itemId = normalizeText_(payload.item_id);
  if (!itemId) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Inventory item is required.'
    );
  }

  const material =
    getMaterialForInventory_(
      itemType,
      itemId
    );

  const movementType =
    String(payload.movement_type || '').toUpperCase();

  const direction =
    movementDirection_(movementType);

  const enteredQty =
    requirePositive_(
      payload.quantity,
      'quantity'
    );

  const enteredUnit =
    canonicalUnit_(
      payload.unit ||
      material.base_unit
    );

  const quantityBase =
    convertItemUnit_(
      itemType,
      itemId,
      enteredQty,
      enteredUnit,
      material.base_unit
    );

  const referenceType =
    normalizeText_(payload.reference_type);

  const referenceId =
    normalizeText_(payload.reference_id);

  if (referenceId) {
    const duplicate = findMovementByReference_(
      referenceType,
      referenceId,
      movementType
    );

    if (duplicate.length) {
      throw twbError_(
        'INVENTORY_REFERENCE_DUPLICATE',
        'This inventory reference has already been posted.'
      );
    }
  }

  const ensuredInventory =
    getOrCreateInventoryRow_(
      itemType,
      itemId,
      user
    );

  const movementId =
    nextBusinessId('INVENTORY_MOVEMENT');

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let movement = null;

  try {
    const inventory =
      dbFindById(
        'INVENTORY',
        ensuredInventory.inventory_id
      );

    if (!inventory) {
      throw twbError_(
        'INVENTORY_ROW_MISSING',
        'Inventory row disappeared before movement posting.'
      );
    }

    const before =
      Number(
        inventory.current_stock_base || 0
      );

    const after =
      direction === 'IN'
        ? before + quantityBase
        : before - quantityBase;

    const negativeAllowed =
      getConfig_('NEGATIVE_STOCK_ALLOWED') === true;

    if (
      after < -0.000001 &&
      !negativeAllowed
    ) {
      throw twbError_(
        'NEGATIVE_STOCK_BLOCKED',
        'Movement would make stock negative.',
        {
          availableStock: before,
          requestedQuantity: quantityBase,
          resultingStock: after
        }
      );
    }

    const now = nowIso_();

    movement = {
      movement_id: movementId,
      movement_at:
        normalizeText_(payload.movement_at) ||
        now,
      item_type: itemType,
      item_id: itemId,
      movement_type: movementType,
      quantity_in_base:
        direction === 'IN'
          ? quantityBase
          : 0,
      quantity_out_base:
        direction === 'OUT'
          ? quantityBase
          : 0,
      balance_after_base:
        roundNumber_(after, 6),
      base_unit: material.base_unit,
      reference_type: referenceType,
      reference_id: referenceId,
      notes: normalizeText_(payload.notes),
      created_at: now,
      created_by: user.user_id,
      updated_at: now,
      updated_by: user.user_id
    };

    dbInsertRecord(
      'INVENTORY_MOVEMENTS',
      movement,
      { validate: true, audit: false }
    );

    dbUpdateById(
      'INVENTORY',
      inventory.inventory_id,
      {
        current_stock_base:
          roundNumber_(after, 6),
        last_movement_at:
          movement.movement_at,
        updated_at: now
      },
      { validate: true, audit: false }
    );
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'CREATE',
    'INVENTORY_MOVEMENTS',
    movementId,
    null,
    movement,
    'Inventory movement posted.'
  );

  return {
    movement: stripInternalFields_(movement),
    inventory:
      stripInternalFields_(
        dbFindOne(
          'INVENTORY',
          'item_id',
          itemId
        )
      )
  };
}

function adjustInventoryPhysicalCount(payload) {
  const user = requirePermission_(
    'INVENTORY_ADJUST'
  );

  payload = payload || {};

  const itemType =
    String(payload.item_type || '').toUpperCase();

  assertOneOf_(
    itemType,
    ['INGREDIENT', 'PACKAGING'],
    'item_type'
  );

  const itemId = normalizeText_(payload.item_id);

  const material =
    getMaterialForInventory_(
      itemType,
      itemId
    );

  const counted =
    requireNonNegative_(
      payload.counted_quantity,
      'counted_quantity'
    );

  const countedUnit =
    canonicalUnit_(
      payload.unit ||
      material.base_unit
    );

  const countedBase =
    convertItemUnit_(
      itemType,
      itemId,
      counted,
      countedUnit,
      material.base_unit
    );

  const inventory =
    getOrCreateInventoryRow_(
      itemType,
      itemId,
      user
    );

  const current =
    Number(
      inventory.current_stock_base || 0
    );

  const difference =
    roundNumber_(
      countedBase - current,
      6
    );

  if (
    Math.abs(difference) <
    0.000001
  ) {
    return {
      changed: false,
      inventory:
        stripInternalFields_(inventory)
    };
  }

  const result = recordInventoryMovement({
    item_type: itemType,
    item_id: itemId,
    movement_type:
      difference > 0
        ? 'ADJUSTMENT_IN'
        : 'ADJUSTMENT_OUT',
    quantity: Math.abs(difference),
    unit: material.base_unit,
    notes:
      normalizeText_(payload.notes) ||
      'Physical stock count adjustment.'
  });

  return {
    changed: true,
    differenceBase: difference,
    movement: result.movement,
    inventory: result.inventory
  };
}

function postProductionPlanUsage(planId) {
  const user = requirePermission_(
    'INVENTORY_ADJUST'
  );

  if (!hasPermission_(user, 'PRODUCTION_WRITE')) {
    throw twbError_(
      'FORBIDDEN',
      'PRODUCTION_WRITE permission is also required.'
    );
  }

  const plan = dbFindById(
    'PRODUCTION_PLANS',
    planId
  );

  if (!plan) {
    throw twbError_(
      'NOT_FOUND',
      'Production plan not found: ' + planId
    );
  }

  if (
    ['PLANNED', 'IN_PROGRESS', 'COMPLETED'].indexOf(
      String(plan.status).toUpperCase()
    ) < 0
  ) {
    throw twbError_(
      'PRODUCTION_USAGE_NOT_ALLOWED',
      'Production usage can only be posted from PLANNED, IN_PROGRESS, or COMPLETED plans.'
    );
  }

  const existing =
    findMovementByReference_(
      'PRODUCTION_PLAN',
      planId,
      'PRODUCTION_USAGE'
    );

  if (existing.length) {
    throw twbError_(
      'PRODUCTION_USAGE_ALREADY_POSTED',
      'Inventory usage has already been posted for this production plan.'
    );
  }

  const requirements =
    dbFindMany(
      'PRODUCTION_REQUIREMENTS',
      'production_plan_id',
      planId
    );

  if (!requirements.length) {
    throw twbError_(
      'PRODUCTION_REQUIREMENT_EMPTY',
      'Production plan has no material requirements.'
    );
  }

  const ensuredInventories =
    requirements.map(function(req) {
      return getOrCreateInventoryRow_(
        req.item_type,
        req.item_id,
        user
      );
    });

  const movementIds =
    requirements.map(function() {
      return nextBusinessId(
        'INVENTORY_MOVEMENT'
      );
    });

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  const inserted = [];

  try {
    const negativeAllowed =
      getConfig_('NEGATIVE_STOCK_ALLOWED') === true;

    const prepared = requirements.map(function(req, index) {
      const inventory =
        dbFindById(
          'INVENTORY',
          ensuredInventories[index].inventory_id
        );

      if (!inventory) {
        throw twbError_(
          'INVENTORY_ROW_MISSING',
          'Inventory row disappeared before production usage posting.'
        );
      }

      const before =
        Number(
          inventory.current_stock_base || 0
        );

      const quantity =
        Number(
          req.required_qty_base || 0
        );

      const after =
        before - quantity;

      if (
        after < -0.000001 &&
        !negativeAllowed
      ) {
        throw twbError_(
          'PRODUCTION_STOCK_SHORTAGE',
          'Insufficient stock for production usage.',
          {
            itemId: req.item_id,
            availableStock: before,
            requiredQuantity: quantity,
            shortage:
              Math.max(0, quantity - before)
          }
        );
      }

      return {
        requirement: req,
        inventory: inventory,
        before: before,
        after: after,
        movementId: movementIds[index]
      };
    });

    prepared.forEach(function(row) {
      const now = nowIso_();

      const movement = {
        movement_id: row.movementId,
        movement_at: now,
        item_type:
          row.requirement.item_type,
        item_id:
          row.requirement.item_id,
        movement_type:
          'PRODUCTION_USAGE',
        quantity_in_base: 0,
        quantity_out_base:
          Number(
            row.requirement.required_qty_base || 0
          ),
        balance_after_base:
          roundNumber_(row.after, 6),
        base_unit:
          row.requirement.base_unit,
        reference_type:
          'PRODUCTION_PLAN',
        reference_id: planId,
        notes:
          'Planned material consumption for ' +
          planId,
        created_at: now,
        created_by: user.user_id,
        updated_at: now,
        updated_by: user.user_id
      };

      dbInsertRecord(
        'INVENTORY_MOVEMENTS',
        movement,
        { validate: true, audit: false }
      );

      dbUpdateById(
        'INVENTORY',
        row.inventory.inventory_id,
        {
          current_stock_base:
            roundNumber_(row.after, 6),
          last_movement_at: now,
          updated_at: now
        },
        { validate: true, audit: false }
      );

      inserted.push(movement);
    });
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'CREATE',
    'INVENTORY_MOVEMENTS',
    planId,
    null,
    {
      movementCount: inserted.length,
      productionPlanId: planId
    },
    'Production usage posted to inventory.'
  );

  return {
    ok: true,
    productionPlanId: planId,
    movementCount: inserted.length,
    movements:
      inserted.map(
        stripInternalFields_
      )
  };
}

function rebuildInventoryBalancesFromLedger() {
  const user = requireRole_([
    TWB_ROLES.OWNER,
    TWB_ROLES.ADMIN
  ]);

  const inventoryRows =
    listAllRecords_('INVENTORY');

  const movements =
    listAllRecords_('INVENTORY_MOVEMENTS');

  const groups = {};
  movements.forEach(function(movement) {
    if (!groups[movement.item_id]) {
      groups[movement.item_id] = [];
    }

    groups[movement.item_id].push(
      movement
    );
  });

  let updated = 0;

  inventoryRows.forEach(function(row) {
    const itemMovements =
      groups[row.item_id] || [];

    const balance =
      calculateLedgerBalanceFromMovements_(
        itemMovements
      );

    const lastMovement =
      itemMovements
        .slice()
        .sort(function(a, b) {
          return String(b.movement_at || '').localeCompare(
            String(a.movement_at || '')
          );
        })[0] || null;

    dbUpdateById(
      'INVENTORY',
      row.inventory_id,
      {
        current_stock_base:
          roundNumber_(balance, 6),
        last_movement_at:
          lastMovement
            ? lastMovement.movement_at
            : '',
        updated_at: nowIso_()
      },
      { validate: true, audit: false }
    );

    updated += 1;
  });

  writeAuditLog_(
    'UPDATE',
    'INVENTORY',
    'REBUILD',
    null,
    {
      updatedRows: updated
    },
    'Inventory materialized balances rebuilt from movement ledger.'
  );

  return {
    ok: true,
    updatedRows: updated,
    reconciliation:
      inventoryReconciliationReport_()
  };
}
