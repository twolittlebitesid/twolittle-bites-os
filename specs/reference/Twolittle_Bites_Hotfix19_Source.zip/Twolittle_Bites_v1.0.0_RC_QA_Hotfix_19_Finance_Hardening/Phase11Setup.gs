/**
 * Twolittle.bites OS — Phase 11 upgrade.
 */
function upgradeToPhase11() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER
    ]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'CRM_DORMANT_DAYS',
    60,
    'NUMBER',
    'Customer is flagged dormant when days since last completed order exceed this threshold.',
    user.user_id
  );

  setConfig_(
    'CRM_PROFILE_ORDER_LIMIT',
    50,
    'NUMBER',
    'Maximum Order history rows returned in Customer Profile.',
    user.user_id
  );

  setConfig_(
    'CRM_RFM_METHOD',
    'RELATIVE_QUINTILE_STYLE',
    'STRING',
    'RFM-style scoring is derived relative to the current customer cohort.',
    user.user_id
  );

  return runPhase11HealthCheck();
}
