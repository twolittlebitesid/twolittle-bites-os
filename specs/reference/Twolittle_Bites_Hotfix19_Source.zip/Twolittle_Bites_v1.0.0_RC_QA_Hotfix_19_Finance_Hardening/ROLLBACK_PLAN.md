# ROLLBACK_PLAN.md
# Twolittle.bites OS v1.0

## Principle

Code rollback and data recovery are different operations.

Never restore an old database just because a code deployment failed.

## Scenario A — Code release is broken, data is healthy

Preferred rollback:

1. Flag:

```text
Settings → Release → Rollback Required
```

2. In Apps Script:
   - Deploy;
   - Manage deployments;
   - edit the production Web App deployment;
   - select the last known-good script version;
   - deploy.

3. Keep the current production database unchanged.

4. Re-run:
   - Health;
   - Regression;
   - critical acceptance tests.

This is the normal rollback path.

## Scenario B — Data corruption occurred after release

Do not immediately replace the production spreadsheet.

1. Stop the workflow causing additional corruption.
2. Create a fresh backup of the current damaged state for forensic comparison.
3. Identify the first bad transaction/event.
4. Open the v1.0 release backup.
5. Use:

```text
Settings → Diagnostics → Recovery Copy
```

to make a separate recovery spreadsheet.
6. Compare:
   - Orders;
   - Payments;
   - Transactions;
   - Inventory Movements;
   - Purchases;
   - Activity Log.
7. Decide whether targeted reconciliation is possible.

Prefer targeted repair/reconciliation over whole-database replacement.

## Scenario C — Whole database must be restored

This is a last-resort operator decision.

Before switching:
- preserve current production spreadsheet;
- preserve current spreadsheet ID;
- create a final copy;
- verify the recovery spreadsheet schema;
- verify business transaction cutoff;
- document transactions that occurred after the backup.

The application currently reads its database ID from:

```text
Script Property
TWB_SPREADSHEET_ID
```

Changing that property changes the production database connection.

Do not change it during routine rollback.

If a full database switchover is approved:
1. verify recovery spreadsheet;
2. record old production spreadsheet ID;
3. record new recovery spreadsheet ID;
4. update `TWB_SPREADSHEET_ID`;
5. run Health;
6. run Regression;
7. run Inventory reconciliation;
8. verify live Web App;
9. preserve both spreadsheets.

## After rollback

Record:
- cause;
- deployment version restored;
- whether database changed;
- time window affected;
- transactions reconciled;
- follow-up fix required.

Do not clear `ROLLBACK_REQUIRED` until the system is stable and the corrective release is ready.
