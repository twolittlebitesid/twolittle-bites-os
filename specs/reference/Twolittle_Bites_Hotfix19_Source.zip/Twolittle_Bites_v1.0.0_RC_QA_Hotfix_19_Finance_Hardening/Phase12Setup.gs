/**
 * Twolittle.bites OS — Phase 12 upgrade.
 */
function upgradeToPhase12() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER
    ]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'MARKETING_ATTRIBUTION_MODEL',
    'MANUAL_LAST_TOUCH',
    'STRING',
    'One active Campaign and optional Content mapping per Order. Latest attribution log wins.',
    user.user_id
  );

  setConfig_(
    'MARKETING_REVENUE_BASIS',
    'COMPLETED_ORDER_OPERATING_REVENUE',
    'STRING',
    'Attributed revenue uses completed Order grand total excluding tax.',
    user.user_id
  );

  setConfig_(
    'MARKETING_SPEND_SOURCE',
    'LINKED_ACTIVE_EXPENSES',
    'STRING',
    'Campaign spend is derived from active Finance Expenses linked in ACTIVITY_LOG.',
    user.user_id
  );

  setConfig_(
    'MARKETING_ATTRIBUTION_STORAGE',
    'ACTIVITY_LOG_LEDGER',
    'STRING',
    'Attribution mappings use ACTIVITY_LOG to preserve the 33-sheet schema.',
    user.user_id
  );

  return runPhase12HealthCheck();
}
