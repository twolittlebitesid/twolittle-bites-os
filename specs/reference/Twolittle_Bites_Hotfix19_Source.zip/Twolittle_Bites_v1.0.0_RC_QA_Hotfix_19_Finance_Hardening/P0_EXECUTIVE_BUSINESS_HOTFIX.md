# P0_EXECUTIVE_BUSINESS_HOTFIX.md
# Twolittle.bites OS v1.0 — Pre-release P0 Closure

## Finding

Manual QA correctly identified a release blocker:

```text
Executive = Phase 2 placeholder
Business  = shell / empty state
```

This was an implementation gap, not an installation mistake.

## Root cause

Three controls were missing:

1. `PageExecutive.html` was never replaced after Phase 2.
2. `PageBusiness.html` was never connected to a functional Business service.
3. Phase 15 cross-module regression did not include Executive or Business, so the missing engines could not fail the release gate.

The Production role also lacked `BUSINESS_READ`, despite the frozen permission matrix specifying Business health read access.

## Fix

Added:

```text
ExecutiveService.gs
BusinessService.gs
JsExecutive.html
JsBusiness.html
```

Replaced / updated:

```text
PageExecutive.html
PageBusiness.html
ApiGateway.gs
Index.html
JsApp.html
Permissions.gs
AppShellService.gs
SystemHardeningService.gs
Phase16HealthCheck.gs
Phase16SmokeTest.gs
StylesComponents.html
StylesResponsive.html
```

## Executive now shows

```text
Operating Revenue
Completed Orders
AOV
Net Cash
Operating Profit (OWNER / FINANCE only)
Order Pipeline
Due Today
Overdue Invoices
Production Plans
Production Shortages
Low / Out of Stock
Open Purchases
Customer Repeat / VIP / Dormant signals
Marketing Spend / Attributed Revenue / ROAS
Target progress
Recent Orders
```

ADMIN receives the Executive dashboard but does not receive the sensitive profit KPI payload.

## Business now shows

```text
Overview
Targets
Sales Channels
Operating Context
```

Role scope:

```text
OWNER      full
ADMIN      management / operational; no sensitive profit KPI
PRODUCTION operational Business health
MARKETING  marketing Business health
FINANCE    full financial Business health
```

Targets reuse `BUSINESS_TARGETS` and the existing Phase 13 target engine.

## Regression gate change

Before:

```text
11 modules
```

Now:

```text
13 modules
Executive
Business
Products
Customers
Orders
Finance
Production
Inventory
Purchasing
Pre-Orders
Marketing
Reports
Settings
```

## Install on current Phase 16 project

Do not rerun `upgradeToPhase16()` solely for this hotfix.

Replace all files supplied in the hotfix package and add the four new files.

Then run:

```javascript
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
```

Targets:

```text
EXECUTIVE_BUSINESS_ENGINES = PASS
RPC_EXECUTIVE_BUSINESS     = PASS
Regression                 = 13 / 13
```

Then manually QA Executive and Business using the updated `PRODUCTION_ACCEPTANCE_TEST.md`.

Do not continue to `PRODUCTION_READY` until this P0 is retested and closed.
