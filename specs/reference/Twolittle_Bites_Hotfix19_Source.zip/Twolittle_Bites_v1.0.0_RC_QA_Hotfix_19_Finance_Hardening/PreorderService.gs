/**
 * Twolittle.bites OS — Phase 9 Pre-Order & Capacity Engine
 *
 * Campaign capacity is derived from linked, non-cancelled Orders.
 * current_booked / remaining_capacity are materialized campaign fields.
 *
 * Capacity unit:
 * - ORDER / ORDERS: one order consumes one capacity unit.
 * - any other unit: sum of Order Item quantity consumes capacity.
 */

function preorderAlmostFullRatio_() {
  var configured = Number(
    getConfig_('PREORDER_ALMOST_FULL_RATIO')
  );

  if (
    configured > 0 &&
    configured < 1
  ) {
    return configured;
  }

  return 0.20;
}

function preorderDateMs_(value) {
  if (!value) return NaN;

  var parsed = new Date(value);
  return parsed.getTime();
}

function preorderCapacityUsageFromItems_(
  capacityUnit,
  items
) {
  var unit =
    String(capacityUnit || '')
      .trim()
      .toUpperCase();

  if (
    unit === 'ORDER' ||
    unit === 'ORDERS'
  ) {
    return (items && items.length) ? 1 : 0;
  }

  return (items || []).reduce(function(sum, item) {
    return sum + Number(item.quantity || 0);
  }, 0);
}

function calculatePreorderCapacityState_(
  maximumCapacity,
  currentBooked,
  storedStatus,
  startAt,
  cutoffAt,
  nowMs
) {
  var maximum =
    Number(maximumCapacity || 0);

  var booked =
    Math.max(
      0,
      Number(currentBooked || 0)
    );

  var remaining =
    Math.max(
      0,
      maximum - booked
    );

  var status =
    String(storedStatus || 'DRAFT')
      .toUpperCase();

  var now =
    Number(nowMs);

  if (!isFinite(now)) {
    now = new Date().getTime();
  }

  var startMs =
    preorderDateMs_(startAt);

  var cutoffMs =
    preorderDateMs_(cutoffAt);

  var terminal =
    ['COMPLETED', 'CANCELLED'].indexOf(status) >= 0;

  var effectiveStatus = status;
  var bookable = false;
  var reason = '';

  if (terminal) {
    reason = status;
  } else if (status === 'DRAFT') {
    reason = 'DRAFT';
  } else if (status === 'CLOSED') {
    effectiveStatus = 'CLOSED';
    reason = 'CLOSED';
  } else if (
    !isNaN(startMs) &&
    now < startMs
  ) {
    effectiveStatus = 'OPEN';
    reason = 'NOT_STARTED';
  } else if (
    !isNaN(cutoffMs) &&
    now > cutoffMs
  ) {
    effectiveStatus = 'CLOSED';
    reason = 'CUTOFF_PASSED';
  } else if (remaining <= 0) {
    effectiveStatus = 'FULL';
    reason = 'FULL';
  } else {
    var ratio =
      maximum > 0
        ? remaining / maximum
        : 0;

    effectiveStatus =
      ratio <= preorderAlmostFullRatio_()
        ? 'ALMOST_FULL'
        : 'OPEN';

    bookable = true;
    reason = '';
  }

  return {
    maximumCapacity:
      roundNumber_(maximum, 6),
    currentBooked:
      roundNumber_(booked, 6),
    remainingCapacity:
      roundNumber_(remaining, 6),
    effectiveStatus: effectiveStatus,
    bookable: bookable,
    blockReason: reason
  };
}

function preorderCampaignOrderData_(
  campaignId,
  orders,
  orderItems,
  capacityUnit
) {
  var linkedOrders = (orders || [])
    .filter(function(order) {
      return (
        String(order.preorder_campaign_id || '') ===
          String(campaignId) &&
        String(order.order_status || '').toUpperCase() !==
          'CANCELLED'
      );
    });

  var linkedMap = {};
  linkedOrders.forEach(function(order) {
    linkedMap[order.order_id] = true;
  });

  var linkedItems = (orderItems || [])
    .filter(function(item) {
      return !!linkedMap[item.order_id];
    });

  var booked =
    String(capacityUnit || '').toUpperCase() === 'ORDER' ||
    String(capacityUnit || '').toUpperCase() === 'ORDERS'
      ? linkedOrders.length
      : linkedItems.reduce(function(sum, item) {
          return sum + Number(item.quantity || 0);
        }, 0);

  return {
    orders: linkedOrders,
    items: linkedItems,
    booked:
      roundNumber_(booked, 6)
  };
}

function calculateLivePreorderCampaign_(
  campaign,
  orders,
  orderItems
) {
  var linked =
    preorderCampaignOrderData_(
      campaign.preorder_campaign_id,
      orders,
      orderItems,
      campaign.capacity_unit
    );

  var state =
    calculatePreorderCapacityState_(
      campaign.maximum_capacity,
      linked.booked,
      campaign.status,
      campaign.start_at,
      campaign.cutoff_at,
      new Date().getTime()
    );

  return Object.assign(
    {},
    stripInternalFields_(campaign),
    {
      current_booked:
        state.currentBooked,
      remaining_capacity:
        state.remainingCapacity,
      effective_status:
        state.effectiveStatus,
      bookable:
        state.bookable,
      block_reason:
        state.blockReason,
      linked_order_count:
        linked.orders.length
    }
  );
}

function syncPreorderCampaignCapacityUnlocked_(
  campaignId,
  actorUser
) {
  var campaign = dbFindById(
    'PREORDER_CAMPAIGNS',
    campaignId
  );

  if (!campaign) {
    throw twbError_(
      'NOT_FOUND',
      'Pre-order campaign not found: ' +
      campaignId
    );
  }

  var orders =
    listAllRecords_('ORDERS');

  var orderItems =
    listAllRecords_('ORDER_ITEMS');

  var live =
    calculateLivePreorderCampaign_(
      campaign,
      orders,
      orderItems
    );

  var storedStatus =
    String(campaign.status || '')
      .toUpperCase();

  var nextStatus = storedStatus;

  if (
    ['OPEN', 'ALMOST_FULL', 'FULL'].indexOf(
      storedStatus
    ) >= 0
  ) {
    nextStatus = live.effective_status;

    if (nextStatus === 'CLOSED') {
      nextStatus = 'CLOSED';
    }
  }

  dbUpdateById(
    'PREORDER_CAMPAIGNS',
    campaignId,
    stampUpdate_(
      actorUser,
      {
        current_booked:
          live.current_booked,
        remaining_capacity:
          live.remaining_capacity,
        status: nextStatus
      }
    ),
    {
      validate: true,
      audit: false
    }
  );

  return calculateLivePreorderCampaign_(
    dbFindById(
      'PREORDER_CAMPAIGNS',
      campaignId
    ),
    orders,
    orderItems
  );
}

function syncPreorderCampaignCapacity_(
  campaignId,
  actorUser
) {
  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    return syncPreorderCampaignCapacityUnlocked_(
      campaignId,
      actorUser || requireCurrentUser_()
    );
  } finally {
    lock.releaseLock();
  }
}

function canOverridePreorderCapacity_(
  user,
  requestedOverride
) {
  if (!requestedOverride) return false;

  if (user.role === TWB_ROLES.OWNER) {
    return true;
  }

  return (
    user.role === TWB_ROLES.ADMIN &&
    getConfig_(
      'ALLOW_ADMIN_PREORDER_OVERRIDE'
    ) === true
  );
}

function assertPreorderCapacityAvailableUnlocked_(
  campaignId,
  requestedUsage,
  actorUser,
  requestedOverride
) {
  var campaign = dbFindById(
    'PREORDER_CAMPAIGNS',
    campaignId
  );

  if (!campaign) {
    throw twbError_(
      'NOT_FOUND',
      'Pre-order campaign not found: ' +
      campaignId
    );
  }

  var live =
    calculateLivePreorderCampaign_(
      campaign,
      listAllRecords_('ORDERS'),
      listAllRecords_('ORDER_ITEMS')
    );

  var overrideAllowed =
    canOverridePreorderCapacity_(
      actorUser,
      requestedOverride
    );

  var now =
    new Date().getTime();

  var startMs =
    preorderDateMs_(campaign.start_at);

  var cutoffMs =
    preorderDateMs_(campaign.cutoff_at);

  if (
    String(campaign.status).toUpperCase() ===
      'DRAFT' &&
    !overrideAllowed
  ) {
    throw twbError_(
      'PREORDER_NOT_OPEN',
      'Pre-order campaign is still DRAFT.'
    );
  }

  if (
    ['CLOSED', 'COMPLETED', 'CANCELLED'].indexOf(
      String(campaign.status).toUpperCase()
    ) >= 0 &&
    !overrideAllowed
  ) {
    throw twbError_(
      'PREORDER_NOT_OPEN',
      'Pre-order campaign is not open.'
    );
  }

  if (
    !isNaN(startMs) &&
    now < startMs &&
    !overrideAllowed
  ) {
    throw twbError_(
      'PREORDER_NOT_STARTED',
      'Pre-order campaign has not started.'
    );
  }

  if (
    !isNaN(cutoffMs) &&
    now > cutoffMs &&
    !overrideAllowed
  ) {
    throw twbError_(
      'PREORDER_CUTOFF_PASSED',
      'Pre-order cutoff has passed.'
    );
  }

  var usage =
    requirePositive_(
      requestedUsage,
      'preorder capacity usage'
    );

  if (
    usage >
      Number(live.remaining_capacity || 0) +
      0.000001 &&
    !overrideAllowed
  ) {
    throw twbError_(
      'PREORDER_CAPACITY_EXCEEDED',
      'Requested pre-order exceeds remaining capacity.',
      {
        requestedUsage:
          usage,
        remainingCapacity:
          live.remaining_capacity,
        campaignId:
          campaignId
      }
    );
  }

  return {
    campaign: campaign,
    live: live,
    usage: usage,
    overrideApplied:
      overrideAllowed
  };
}

function preorderModuleBootstrap() {
  var user =
    requirePermission_('PREORDER_READ');

  var campaigns =
    listAllRecords_(
      'PREORDER_CAMPAIGNS'
    );

  var orders =
    listAllRecords_('ORDERS');

  var orderItems =
    listAllRecords_('ORDER_ITEMS');

  var customers =
    listAllRecords_('CUSTOMERS');

  var customerMap = {};
  customers.forEach(function(customer) {
    customerMap[customer.customer_id] =
      customer;
  });

  var campaignRows =
    campaigns.map(function(campaign) {
      return calculateLivePreorderCampaign_(
        campaign,
        orders,
        orderItems
      );
    });

  campaignRows.sort(function(a, b) {
    return String(b.created_at || '').localeCompare(
      String(a.created_at || '')
    );
  });

  var linkedOrders =
    orders
      .filter(function(order) {
        return !!order.preorder_campaign_id;
      })
      .map(function(order) {
        var customer =
          customerMap[order.customer_id] || {};

        return Object.assign(
          {},
          stripInternalFields_(order),
          {
            customer_name:
              customer.name ||
              order.customer_id
          }
        );
      })
      .sort(function(a, b) {
        return String(b.created_at || '').localeCompare(
          String(a.created_at || '')
        );
      });

  return {
    campaigns: campaignRows,
    orders: linkedOrders,
    permissions: {
      preorderWrite:
        hasPermission_(
          user,
          'PREORDER_WRITE'
        ),
      orderWrite:
        hasPermission_(
          user,
          'ORDER_WRITE'
        ),
      canOverride:
        user.role === TWB_ROLES.OWNER ||
        (
          user.role === TWB_ROLES.ADMIN &&
          getConfig_(
            'ALLOW_ADMIN_PREORDER_OVERRIDE'
          ) === true
        )
    }
  };
}

function validatePreorderCampaignPayload_(payload) {
  payload = payload || {};

  var name =
    normalizeText_(
      payload.campaign_name
    );

  if (!name) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Campaign name is required.'
    );
  }

  var startAt =
    normalizeText_(payload.start_at);

  var cutoffAt =
    normalizeText_(payload.cutoff_at);

  if (!startAt || !cutoffAt) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Start and cutoff time are required.'
    );
  }

  var startMs =
    preorderDateMs_(startAt);

  var cutoffMs =
    preorderDateMs_(cutoffAt);

  if (
    isNaN(startMs) ||
    isNaN(cutoffMs) ||
    cutoffMs <= startMs
  ) {
    throw twbError_(
      'PREORDER_DATE_INVALID',
      'Cutoff must be after campaign start.'
    );
  }

  var productionDate =
    normalizeDateKey_(
      payload.production_date
    );

  var fulfillmentDate =
    normalizeDateKey_(
      payload.fulfillment_date
    );

  if (
    !productionDate ||
    !fulfillmentDate
  ) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Production and fulfillment dates are required.'
    );
  }

  if (
    productionDate >
    fulfillmentDate
  ) {
    throw twbError_(
      'PREORDER_DATE_INVALID',
      'Production date cannot be after fulfillment date.'
    );
  }

  var maximumCapacity =
    requirePositive_(
      payload.maximum_capacity,
      'maximum_capacity'
    );

  var capacityUnit =
    normalizeText_(
      payload.capacity_unit
    );

  if (!capacityUnit) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Capacity unit is required.'
    );
  }

  return {
    campaignName: name,
    startAt: startAt,
    cutoffAt: cutoffAt,
    productionDate: productionDate,
    fulfillmentDate: fulfillmentDate,
    maximumCapacity:
      roundNumber_(
        maximumCapacity,
        6
      ),
    capacityUnit:
      capacityUnit
  };
}

function createPreorderCampaign(payload) {
  var user =
    requirePermission_(
      'PREORDER_WRITE'
    );

  var validated =
    validatePreorderCampaignPayload_(
      payload
    );

  var campaignId =
    nextBusinessId('PREORDER');

  var now = nowIso_();

  var record = {
    preorder_campaign_id:
      campaignId,
    campaign_name:
      validated.campaignName,
    start_at:
      validated.startAt,
    cutoff_at:
      validated.cutoffAt,
    production_date:
      validated.productionDate,
    fulfillment_date:
      validated.fulfillmentDate,
    maximum_capacity:
      validated.maximumCapacity,
    capacity_unit:
      validated.capacityUnit,
    current_booked: 0,
    remaining_capacity:
      validated.maximumCapacity,
    status: 'DRAFT',
    notes:
      normalizeText_(
        payload.notes
      ),
    created_at: now,
    created_by:
      user.user_id,
    updated_at: now,
    updated_by:
      user.user_id
  };

  dbInsertRecord(
    'PREORDER_CAMPAIGNS',
    record,
    {
      validate: true,
      audit: false
    }
  );

  writeAuditLog_(
    'CREATE',
    'PREORDER_CAMPAIGNS',
    campaignId,
    null,
    record,
    'Pre-order campaign created.'
  );

  return calculateLivePreorderCampaign_(
    dbFindById(
      'PREORDER_CAMPAIGNS',
      campaignId
    ),
    [],
    []
  );
}

function updatePreorderCampaign(
  campaignId,
  payload
) {
  var user =
    requirePermission_(
      'PREORDER_WRITE'
    );

  var current = dbFindById(
    'PREORDER_CAMPAIGNS',
    campaignId
  );

  if (!current) {
    throw twbError_(
      'NOT_FOUND',
      'Pre-order campaign not found: ' +
      campaignId
    );
  }

  if (
    String(current.status).toUpperCase() !==
    'DRAFT'
  ) {
    throw twbError_(
      'PREORDER_LOCKED',
      'Only DRAFT campaigns can be edited.'
    );
  }

  var merged =
    Object.assign(
      {},
      current,
      payload || {}
    );

  var validated =
    validatePreorderCampaignPayload_(
      merged
    );

  var updated =
    dbUpdateById(
      'PREORDER_CAMPAIGNS',
      campaignId,
      stampUpdate_(
        user,
        {
          campaign_name:
            validated.campaignName,
          start_at:
            validated.startAt,
          cutoff_at:
            validated.cutoffAt,
          production_date:
            validated.productionDate,
          fulfillment_date:
            validated.fulfillmentDate,
          maximum_capacity:
            validated.maximumCapacity,
          capacity_unit:
            validated.capacityUnit,
          current_booked: 0,
          remaining_capacity:
            validated.maximumCapacity,
          notes:
            normalizeText_(
              merged.notes
            )
        }
      ),
      {
        validate: true,
        audit: false
      }
    );

  writeAuditLog_(
    'UPDATE',
    'PREORDER_CAMPAIGNS',
    campaignId,
    stripInternalFields_(current),
    updated,
    'DRAFT pre-order campaign updated.'
  );

  return calculateLivePreorderCampaign_(
    updated,
    [],
    []
  );
}

function updatePreorderCampaignStatus(
  campaignId,
  targetStatus
) {
  var user =
    requirePermission_(
      'PREORDER_WRITE'
    );

  var campaign = dbFindById(
    'PREORDER_CAMPAIGNS',
    campaignId
  );

  if (!campaign) {
    throw twbError_(
      'NOT_FOUND',
      'Pre-order campaign not found: ' +
      campaignId
    );
  }

  var current =
    String(campaign.status || '')
      .toUpperCase();

  var target =
    String(targetStatus || '')
      .toUpperCase();

  var allowed = {
    DRAFT: [
      'OPEN',
      'CANCELLED'
    ],
    OPEN: [
      'CLOSED'
    ],
    ALMOST_FULL: [
      'CLOSED'
    ],
    FULL: [
      'CLOSED',
      'COMPLETED'
    ],
    CLOSED: [
      'COMPLETED'
    ],
    COMPLETED: [],
    CANCELLED: []
  };

  if (
    !allowed[current] ||
    allowed[current].indexOf(target) < 0
  ) {
    throw twbError_(
      'PREORDER_TRANSITION_INVALID',
      'Cannot move campaign from ' +
      current +
      ' to ' +
      target +
      '.'
    );
  }

  if (
    target === 'CANCELLED'
  ) {
    var live =
      calculateLivePreorderCampaign_(
        campaign,
        listAllRecords_('ORDERS'),
        listAllRecords_('ORDER_ITEMS')
      );

    if (
      Number(live.current_booked || 0) > 0
    ) {
      throw twbError_(
        'PREORDER_HAS_ORDERS',
        'Campaign with booked Orders cannot be cancelled. Close it or cancel linked Orders first.'
      );
    }
  }

  var before =
    stripInternalFields_(campaign);

  dbUpdateById(
    'PREORDER_CAMPAIGNS',
    campaignId,
    stampUpdate_(
      user,
      {
        status: target
      }
    ),
    {
      validate: true,
      audit: false
    }
  );

  var synced =
    syncPreorderCampaignCapacity_(
      campaignId,
      user
    );

  writeAuditLog_(
    'STATUS_CHANGE',
    'PREORDER_CAMPAIGNS',
    campaignId,
    before,
    synced,
    current + ' → ' + target
  );

  return synced;
}

function getPreorderCampaignDetail(
  campaignId
) {
  requirePermission_(
    'PREORDER_READ'
  );

  var campaign = dbFindById(
    'PREORDER_CAMPAIGNS',
    campaignId
  );

  if (!campaign) {
    throw twbError_(
      'NOT_FOUND',
      'Pre-order campaign not found: ' +
      campaignId
    );
  }

  var orders =
    listAllRecords_('ORDERS');

  var orderItems =
    listAllRecords_('ORDER_ITEMS');

  var customers =
    listAllRecords_('CUSTOMERS');

  var customerMap = {};
  customers.forEach(function(customer) {
    customerMap[customer.customer_id] =
      customer;
  });

  var live =
    calculateLivePreorderCampaign_(
      campaign,
      orders,
      orderItems
    );

  var linked =
    preorderCampaignOrderData_(
      campaignId,
      orders,
      orderItems,
      campaign.capacity_unit
    );

  var linkedOrders =
    linked.orders.map(function(order) {
      var customer =
        customerMap[order.customer_id] || {};

      var items =
        linked.items.filter(function(item) {
          return item.order_id ===
            order.order_id;
        });

      return {
        order_id:
          order.order_id,
        customer_name:
          customer.name ||
          order.customer_id,
        order_status:
          order.order_status,
        payment_status:
          order.payment_status,
        order_date:
          order.order_date,
        fulfillment_date:
          order.fulfillment_date,
        capacity_usage:
          preorderCapacityUsageFromItems_(
            campaign.capacity_unit,
            items
          ),
        grand_total:
          Number(
            order.grand_total || 0
          )
      };
    });

  return {
    campaign: live,
    orders: linkedOrders
  };
}
