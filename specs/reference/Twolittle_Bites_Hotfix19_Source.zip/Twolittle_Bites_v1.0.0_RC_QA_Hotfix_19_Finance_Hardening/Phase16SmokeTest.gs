/**
 * Phase 16 smoke test.
 *
 * Does not create a backup, mark a release status,
 * change a deployment, or modify business records.
 */
function runPhase16SmokeTest() {
  var tests = [];

  function addTest_(name, ok, detail) {
    var row = {};
    row.test = name;
    row.ok = !!ok;
    row.detail = String(
      detail == null
        ? ''
        : detail
    );
    tests.push(row);
  }

  try {
    var envelope =
      apiCall(
        'release.bootstrap',
        {}
      );

    addTest_(
      'RPC_RELEASE_BOOTSTRAP',
      envelope &&
        envelope.ok === true &&
        envelope.data &&
        envelope.data.status &&
        envelope.data.permissions,
      envelope &&
      envelope.ok
        ? envelope.data.status.releaseStatus
        : (
            envelope &&
            envelope.error
              ? envelope.error.message
              : 'RPC failed'
          )
    );
  } catch (e) {
    addTest_(
      'RPC_RELEASE_BOOTSTRAP',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var executive =
      apiCall(
        'executive.bootstrap',
        {}
      );

    var business =
      apiCall(
        'business.bootstrap',
        {}
      );

    addTest_(
      'RPC_EXECUTIVE_BUSINESS',
      executive &&
        executive.ok === true &&
        executive.data &&
        executive.data.pipeline &&
        business &&
        business.ok === true &&
        business.data &&
        Array.isArray(
          business.data.channels
        ),
      executive && executive.ok && business && business.ok
        ? 'Executive + Business engines available'
        : 'Executive or Business RPC failed'
    );
  } catch (e) {
    addTest_(
      'RPC_EXECUTIVE_BUSINESS',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var status =
      releaseStatusSnapshot_();

    addTest_(
      'V1_VERSION_STATE',
      status.releaseVersion ===
        '1.0.0' &&
        status.releaseChannel ===
          'PRODUCTION',
      status.releaseVersion +
        ' · ' +
        status.releaseChannel
    );
  } catch (e) {
    addTest_(
      'V1_VERSION_STATE',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var preview =
      buildPhase16Preflight_({
        includeRegression:
          false
      });

    addTest_(
      'PREFLIGHT_PREVIEW',
      Array.isArray(
        preview.checks
      ) &&
        typeof preview.ok ===
          'boolean',
      preview.blockingFailures +
        ' current blocking condition(s)'
    );
  } catch (e) {
    addTest_(
      'PREFLIGHT_PREVIEW',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var html =
      HtmlService
        .createTemplateFromFile(
          'Index'
        )
        .evaluate()
        .getContent();

    addTest_(
      'RELEASE_UI_RENDER',
      html.indexOf(
        'data-settings-panel="release"'
      ) >= 0 &&
        html.indexOf(
          'data-release-backup'
        ) >= 0 &&
        html.indexOf(
          'Mark Production Ready'
        ) >= 0 &&
        html.indexOf(
          'id="exec-revenue-chart"'
        ) >= 0 &&
        html.indexOf(
          'id="business-trend-primary"'
        ) >= 0 &&
        html.indexOf(
          'data-global-whatsapp'
        ) >= 0 &&
        html.indexOf(
          'Business Operating System'
        ) < 0 &&
        html.indexOf(
          'Order + Pre-Order Engine'
        ) < 0 &&
        html.indexOf(
          'Business engine comes next'
        ) < 0,
      'Release UI + production-facing cleanup + charts + active WhatsApp rendered'
    );
  } catch (e) {
    addTest_(
      'RELEASE_UI_RENDER',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var routerJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsRouter'
        )
        .getContent();

    var orderJs =
      HtmlService
        .createHtmlOutputFromFile(
          'JsOrders'
        )
        .getContent();

    addTest_(
      'CLIENT_ROUTE_CACHE_AND_SEARCH',
      routerJs.indexOf(
        'routeNodes: new Map()'
      ) >= 0 &&
        routerJs.indexOf(
          'firstVisit'
        ) >= 0 &&
        orderJs.indexOf(
          'bindCustomerSearch'
        ) >= 0,
      'Visited routes stay mounted; Order customer search is available'
    );
  } catch (e) {
    addTest_(
      'CLIENT_ROUTE_CACHE_AND_SEARCH',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var unknown =
      apiCall(
        'phase16.does.not.exist',
        {}
      );

    addTest_(
      'RPC_ERROR_ENVELOPE_REGRESSION',
      unknown &&
        unknown.ok === false &&
        unknown.error &&
        unknown.error.code ===
          'UNKNOWN_API_ACTION',
      unknown &&
      unknown.error
        ? unknown.error.code
        : 'No error envelope'
    );
  } catch (e) {
    addTest_(
      'RPC_ERROR_ENVELOPE_REGRESSION',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var ui12 =
      HtmlService
        .createTemplateFromFile(
          'Index'
        )
        .evaluate()
        .getContent();

    addTest_(
      'QA_HOTFIX_12_SEARCH_IMAGE_UI',
      ui12.indexOf(
        'data-experience-slot="executive"'
      ) >= 0 &&
        ui12.indexOf(
          'data-experience-slot="settings"'
        ) >= 0 &&
        ui12.indexOf(
          'TWB.setImageSource'
        ) >= 0 &&
        ui12.indexOf(
          'data-exp-page-search'
        ) >= 0,
      'Universal search layer + versioned image reload helpers render in release UI'
    );
  } catch (e) {
    addTest_(
      'QA_HOTFIX_12_SEARCH_IMAGE_UI',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var ui13 =
      HtmlService
        .createTemplateFromFile(
          'Index'
        )
        .evaluate()
        .getContent();

    addTest_(
      'QA_HOTFIX_13_NAV_PAYMENT_IMAGE',
      ui13.indexOf(
        'Operating System Active'
      ) < 0 &&
        ui13.indexOf(
          'data-global-invoices'
        ) >= 0 &&
        ui13.indexOf(
          'data-order-payment'
        ) >= 0 &&
        ui13.indexOf(
          'data-invoice-payment'
        ) >= 0 &&
        ui13.indexOf(
          'resolveImageDataUrl'
        ) >= 0,
      'Invoice quick action + payment shortcuts + server-assisted image fallback render in release UI'
    );
  } catch (e) {
    addTest_(
      'QA_HOTFIX_13_NAV_PAYMENT_IMAGE',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var receiptSmoke14 =
      HtmlService
        .createHtmlOutputFromFile(
          'PublicReceipt'
        )
        .getContent();

    var kitchenSmoke14 =
      HtmlService
        .createHtmlOutputFromFile(
          'PublicKitchenTicket'
        )
        .getContent();

    var settingsSmoke14 =
      HtmlService
        .createHtmlOutputFromFile(
          'PageSettings'
        )
        .getContent();

    addTest_(
      'QA_HOTFIX_14_PRINT_UI',
      receiptSmoke14.indexOf(
        'Print Receipt'
      ) >= 0 &&
        receiptSmoke14.indexOf(
          '@page'
        ) >= 0 &&
        kitchenSmoke14.indexOf(
          'Print Kitchen Ticket'
        ) >= 0 &&
        settingsSmoke14.indexOf(
          'Paper Size'
        ) >= 0 &&
        settingsSmoke14.indexOf(
          'Auto Open Print After Payment'
        ) >= 0,
      'Thermal receipt/kitchen templates and Printing settings UI render'
    );
  } catch (e) {
    addTest_(
      'QA_HOTFIX_14_PRINT_UI',
      false,
      e.message || String(e)
    );
  }

  try {
    var localUi15 =
      HtmlService
        .createTemplateFromFile(
          'Index'
        )
        .evaluate()
        .getContent();

    addTest_(
      'QA_HOTFIX_15_LOCAL_RUNTIME_UI',
      localUi15.indexOf(
        'local-runtime-status'
      ) >= 0 &&
        localUi15.indexOf(
          'twb:runtime-status'
        ) >= 0 &&
        localUi15.indexOf(
          'indexedDB.open'
        ) >= 0,
      'Dual-runtime API client + local runtime indicator are included without changing Apps Script mode'
    );
  } catch (e) {
    addTest_(
      'QA_HOTFIX_15_LOCAL_RUNTIME_UI',
      false,
      e.message ||
        String(e)
    );
  }

  try {
    var bulkUi17 =
      HtmlService
        .createTemplateFromFile(
          'Index'
        )
        .evaluate()
        .getContent();

    addTest_(
      'QA_HOTFIX_17_BULK_PROGRESS_UI',
      bulkUi17.indexOf(
        'Bulk Progress'
      ) >= 0 &&
        bulkUi17.indexOf(
          'Advance Next Step'
        ) >= 0 &&
        bulkUi17.indexOf(
          'data-order-select-visible'
        ) >= 0 &&
        bulkUi17.indexOf(
          'applyBulkProgress'
        ) >= 0,
      'Orders bulk selection and Bulk Progress controls render in the release UI'
    );
  } catch (e) {
    addTest_(
      'QA_HOTFIX_17_BULK_PROGRESS_UI',
      false,
      e.message || String(e)
    );
  }

  var result = {};
  result.ok =
    tests.every(function(test) {
      return test.ok;
    });
  result.phase = 16;
  result.appVersion =
    TWB_APP.APP_VERSION;
  result.schemaVersion =
    TWB_APP.SCHEMA_VERSION;
  result.tests =
    tests;

  console.log(
    JSON.stringify(
      result,
      null,
      2
    )
  );

  return result;
}
