/**
 * QA Hotfix 14 — printing setup / smoke helpers.
 */

function upgradeToQAHotfix14() {
  var user = requirePermission_(
    'SETTINGS_WRITE'
  );

  var defaults = [
    ['receipt_paper_size', '80', 'STRING', 'Browser thermal receipt paper size.'],
    ['receipt_copies', 1, 'NUMBER', 'Suggested receipt copy count.'],
    ['receipt_auto_print_after_payment', false, 'BOOLEAN', 'Open receipt print flow after successful payment.'],
    ['receipt_show_logo', true, 'BOOLEAN', 'Show business logo on receipt.'],
    ['receipt_show_customer', true, 'BOOLEAN', 'Show customer on receipt and kitchen ticket.'],
    ['receipt_show_payment_method', true, 'BOOLEAN', 'Show payment method on receipt.'],
    ['kitchen_ticket_enabled', false, 'BOOLEAN', 'Enable kitchen ticket print action.']
  ];

  var created = [];

  defaults.forEach(function(row) {
    var key = row[0];
    var current = getBusinessSetting_(
      key
    );

    if (
      current === null ||
      typeof current === 'undefined'
    ) {
      setBusinessSetting_(
        key,
        row[1],
        row[2],
        'PRINTING',
        row[3],
        user.user_id
      );
      created.push(key);
    }
  });

  return {
    ok: true,
    created: created,
    printing: receiptPrintingSettings_(),
    health: runPhase16HealthCheck()
  };
}

function runQAHotfix14ReceiptSmoke(
  invoiceIdentifier
) {
  requirePermission_(
    'INVOICE_READ'
  );

  var key = String(
    invoiceIdentifier || ''
  ).trim();

  var invoice = dbFindById(
    'INVOICES',
    key
  );

  if (!invoice) {
    invoice = dbFindOne(
      'INVOICES',
      'invoice_number',
      key
    );
  }

  if (!invoice) {
    throw twbError_(
      'NOT_FOUND',
      'Invoice not found: ' + key
    );
  }

  var receipt =
    getPublicReceiptDataByToken_(
      invoice.public_token,
      { autoPrint: false }
    );

  var urls = getReceiptUrl(
    invoice.invoice_id,
    false
  );

  return {
    ok: !!(
      receipt &&
      receipt.items &&
      receipt.items.length >= 0 &&
      urls.receipt_url
    ),
    invoiceId: invoice.invoice_id,
    invoiceNumber: invoice.invoice_number,
    receiptUrl: urls.receipt_url,
    kitchenTicketUrl: urls.kitchen_ticket_url,
    printing: urls.printing,
    itemCount: receipt
      ? receipt.items.length
      : 0,
    paidAmountText: receipt
      ? receipt.paidAmountText
      : '',
    remainingAmountText: receipt
      ? receipt.remainingAmountText
      : ''
  };
}
