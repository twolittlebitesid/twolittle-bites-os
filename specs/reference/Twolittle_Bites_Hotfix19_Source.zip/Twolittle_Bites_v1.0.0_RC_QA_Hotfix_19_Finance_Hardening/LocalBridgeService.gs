/**
 * QA Hotfix 15 — signed localhost bridge for hybrid runtime.
 *
 * The browser never receives the shared secret. A local Node server signs
 * each request and forwards it to doPost(). The Apps Script request context
 * then resolves the configured actor through the existing USERS/permission
 * layer.
 */

var TWB_REQUEST_CONTEXT = null;

function localBridgeSecretKey_() {
  return 'TWB_LOCAL_BRIDGE_SECRET_V1';
}

function localBridgeActorKey_() {
  return 'TWB_LOCAL_BRIDGE_ACTOR_EMAIL_V1';
}

function localBridgeEnabledKey_() {
  return 'TWB_LOCAL_BRIDGE_ENABLED_V1';
}

function localBridgeNormalizeActor_(value) {
  return normalizeEmail_(value);
}

function localBridgeRandomSecret_() {
  return [
    Utilities.getUuid(),
    Utilities.getUuid(),
    Utilities.getUuid(),
    Utilities.getUuid()
  ].join('').replace(/-/g, '');
}

function localBridgeHex_(bytes) {
  return (bytes || []).map(function(value) {
    var normalized = value < 0
      ? value + 256
      : value;
    return ('0' + normalized.toString(16)).slice(-2);
  }).join('');
}

function localBridgeSignature_(
  secret,
  actorEmail,
  timestamp,
  nonce,
  action,
  payloadBase64
) {
  var canonical = [
    localBridgeNormalizeActor_(actorEmail),
    String(timestamp || ''),
    String(nonce || ''),
    String(action || ''),
    String(payloadBase64 || '')
  ].join('\n');

  return localBridgeHex_(
    Utilities.computeHmacSha256Signature(
      canonical,
      secret,
      Utilities.Charset.UTF_8
    )
  );
}

function localBridgeSecureEqual_(a, b) {
  a = String(a || '');
  b = String(b || '');

  if (a.length !== b.length) {
    return false;
  }

  var diff = 0;
  for (var i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }

  return diff === 0;
}

function localBridgeValidateEnvelope_(envelope) {
  envelope = envelope || {};

  if (Number(envelope.bridgeVersion || 0) !== 1) {
    throw twbError_(
      'LOCAL_BRIDGE_VERSION_UNSUPPORTED',
      'Unsupported localhost bridge version.'
    );
  }

  var props = PropertiesService.getScriptProperties();
  var enabled = props.getProperty(
    localBridgeEnabledKey_()
  ) === 'TRUE';

  if (!enabled) {
    throw twbError_(
      'LOCAL_BRIDGE_DISABLED',
      'Localhost bridge is disabled. Run setupLocalhostBridge() as OWNER.'
    );
  }

  var secret = props.getProperty(
    localBridgeSecretKey_()
  ) || '';

  var configuredActor =
    localBridgeNormalizeActor_(
      props.getProperty(
        localBridgeActorKey_()
      ) || ''
    );

  var actor =
    localBridgeNormalizeActor_(
      envelope.actorEmail
    );

  if (!secret || !configuredActor) {
    throw twbError_(
      'LOCAL_BRIDGE_NOT_CONFIGURED',
      'Localhost bridge secret/actor is not configured.'
    );
  }

  if (
    !actor ||
    actor !== configuredActor
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_ACTOR_DENIED',
      'This localhost actor is not authorized for the configured bridge.'
    );
  }

  var timestamp = Number(
    envelope.timestamp || 0
  );

  var now = new Date().getTime();
  var maxSkewMs = 5 * 60 * 1000;

  if (
    !isFinite(timestamp) ||
    Math.abs(now - timestamp) > maxSkewMs
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_REQUEST_EXPIRED',
      'Localhost bridge request timestamp is outside the allowed window.'
    );
  }

  var nonce = String(
    envelope.nonce || ''
  ).trim();

  if (
    !/^[A-Za-z0-9._-]{12,128}$/.test(nonce)
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_NONCE_INVALID',
      'Localhost bridge nonce is invalid.'
    );
  }

  var nonceCache =
    CacheService.getScriptCache();
  var nonceKey =
    'TWB_LOCAL_NONCE_' + nonce;

  if (
    nonceCache.get(nonceKey)
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_REPLAY_REJECTED',
      'This localhost bridge request has already been used.'
    );
  }

  var action = String(
    envelope.action || ''
  ).trim();

  if (!action) {
    throw twbError_(
      'LOCAL_BRIDGE_ACTION_REQUIRED',
      'Localhost bridge action is required.'
    );
  }

  var payloadBase64 = String(
    envelope.payloadBase64 || ''
  );

  var standardPayloadLimit = 1500000;
  var proofPayloadLimit = 16000000;
  var oversized = payloadBase64.length > standardPayloadLimit;
  if (
    (oversized && action !== 'payments.record') ||
    payloadBase64.length > proofPayloadLimit
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_PAYLOAD_TOO_LARGE',
      'Localhost bridge payload is too large.'
    );
  }

  var expected =
    localBridgeSignature_(
      secret,
      actor,
      timestamp,
      nonce,
      action,
      payloadBase64
    );

  if (
    !localBridgeSecureEqual_(
      expected,
      envelope.signature
    )
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_SIGNATURE_INVALID',
      'Localhost bridge signature is invalid.'
    );
  }

  var payload = {};

  if (payloadBase64) {
    try {
      var decoded = Utilities.newBlob(
        Utilities.base64Decode(
          payloadBase64
        )
      ).getDataAsString(
        'UTF-8'
      );

      payload = decoded
        ? JSON.parse(decoded)
        : {};
    } catch (e) {
      throw twbError_(
        'LOCAL_BRIDGE_PAYLOAD_INVALID',
        'Localhost bridge payload could not be decoded.'
      );
    }
  }

  if (oversized) {
    var proof =
      payload && payload.proof_upload;
    var maxProofEncoded =
      Math.ceil(TWB_PAYMENT_PROOF_MAX_BYTES / 3) * 4 + 8;
    if (
      !proof ||
      typeof proof.base64 !== 'string' ||
      proof.base64.length > maxProofEncoded
    ) {
      throw twbError_(
        'LOCAL_BRIDGE_PAYLOAD_TOO_LARGE',
        'Large localhost requests are allowed only for valid payment proof uploads.'
      );
    }
  }

  nonceCache.put(
    nonceKey,
    '1',
    600
  );

  return {
    actorEmail: actor,
    action: action,
    payload: payload
  };
}

function withLocalBridgeContext_(
  context,
  callback
) {
  var previous =
    TWB_REQUEST_CONTEXT;

  TWB_REQUEST_CONTEXT = {
    trustedLocalBridge: true,
    actorEmail:
      localBridgeNormalizeActor_(
        context.actorEmail
      )
  };

  try {
    return callback();
  } finally {
    TWB_REQUEST_CONTEXT = previous;
  }
}

function handleLocalBridgePost_(contents) {
  var envelope;

  try {
    envelope = JSON.parse(
      String(contents || '{}')
    );
  } catch (e) {
    return clientSafeResponse_({
      ok: false,
      error: {
        code: 'LOCAL_BRIDGE_JSON_INVALID',
        message: 'Localhost bridge request body must be valid JSON.'
      },
      meta: {
        appVersion: TWB_APP.APP_VERSION
      }
    });
  }

  try {
    var context =
      localBridgeValidateEnvelope_(
        envelope
      );

    return withLocalBridgeContext_(
      context,
      function() {
        return apiCall(
          context.action,
          context.payload
        );
      }
    );
  } catch (err) {
    return clientSafeResponse_({
      ok: false,
      error: {
        code:
          err && err.code
            ? err.code
            : 'LOCAL_BRIDGE_ERROR',
        message:
          err && err.message
            ? err.message
            : 'Localhost bridge request failed.',
        details:
          err && err.details
            ? err.details
            : null
      },
      meta: {
        appVersion: TWB_APP.APP_VERSION
      }
    });
  }
}

function setupLocalhostBridge(actorEmail) {
  var owner = requireRole_([
    TWB_ROLES.OWNER
  ]);

  var actor =
    localBridgeNormalizeActor_(
      actorEmail || owner.email
    );

  var actorUser = dbFindOne(
    'USERS',
    'email',
    actor
  );

  if (
    !actorUser ||
    actorUser.status !==
      TWB_USER_STATUS.ACTIVE
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_ACTOR_NOT_ACTIVE',
      'The localhost bridge actor must be an active USERS record.'
    );
  }

  var secret =
    localBridgeRandomSecret_();

  var props =
    PropertiesService.getScriptProperties();

  props.setProperty(
    localBridgeSecretKey_(),
    secret
  );
  props.setProperty(
    localBridgeActorKey_(),
    actor
  );
  props.setProperty(
    localBridgeEnabledKey_(),
    'TRUE'
  );

  writeAuditLog_(
    'UPDATE',
    'SYSTEM',
    'LOCALHOST_BRIDGE',
    null,
    {
      actorEmail: actor,
      enabled: true
    },
    'Localhost bridge secret rotated/configured.'
  );

  return {
    ok: true,
    actorEmail: actor,
    localApiSecret: secret,
    webAppUrl:
      typeof getWebAppBaseUrl_ ===
        'function'
        ? getWebAppBaseUrl_()
        : '',
    note:
      'Copy localApiSecret to .env.local now. It is not shown by status calls.'
  };
}

function disableLocalhostBridge() {
  requireRole_([
    TWB_ROLES.OWNER
  ]);

  var props =
    PropertiesService.getScriptProperties();

  props.deleteProperty(
    localBridgeSecretKey_()
  );
  props.setProperty(
    localBridgeEnabledKey_(),
    'FALSE'
  );

  return {
    ok: true,
    enabled: false
  };
}

function getLocalhostBridgeStatus() {
  requireRole_([
    TWB_ROLES.OWNER
  ]);

  var props =
    PropertiesService.getScriptProperties();

  return {
    enabled:
      props.getProperty(
        localBridgeEnabledKey_()
      ) === 'TRUE',
    actorEmail:
      props.getProperty(
        localBridgeActorKey_()
      ) || '',
    secretConfigured:
      !!props.getProperty(
        localBridgeSecretKey_()
      ),
    webAppUrl:
      typeof getWebAppBaseUrl_ ===
        'function'
        ? getWebAppBaseUrl_()
        : ''
  };
}
