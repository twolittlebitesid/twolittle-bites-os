/**
 * Phase 3 recipe/product economics.
 */

function getItemCostPerBaseUnit_(itemType, itemId) {
  const item = getMaterialByType_(itemType, itemId);
  const latest = Number(item.latest_cost_per_base_unit || 0);
  const average = Number(item.average_cost_per_base_unit || 0);

  // Phase 3 uses latest known material cost first.
  return latest > 0 ? latest : average;
}

function calculateRecipeEconomicsFromRows_(recipe, items) {
  const baseYield = requirePositive_(recipe.base_yield, 'base_yield');
  let total = 0;

  const lines = (items || []).map(function(item) {
    const baseQty = requireNonNegative_(item.quantity_base, 'quantity_base');
    const wastePct = requireNonNegative_(item.waste_allowance_pct || 0, 'waste_allowance_pct');
    const qtyWithWaste = baseQty * (1 + wastePct / 100);
    const unitCost = getItemCostPerBaseUnit_(item.item_type, item.item_id);
    const lineCost = qtyWithWaste * unitCost;
    total += lineCost;

    const material = getMaterialByType_(item.item_type, item.item_id);
    return {
      recipeItemId: item.recipe_item_id,
      itemType: item.item_type,
      itemId: item.item_id,
      itemName: item.item_type === 'INGREDIENT'
        ? material.ingredient_name
        : material.packaging_name,
      baseQuantity: roundNumber_(baseQty, 6),
      wasteAllowancePct: roundNumber_(wastePct, 4),
      costQuantityBase: roundNumber_(qtyWithWaste, 6),
      baseUnit: canonicalUnit_(material.base_unit),
      costPerBaseUnit: roundNumber_(unitCost, 6),
      lineCost: Math.round(lineCost)
    };
  });

  const batchCogs = Math.round(total);
  const unitCogs = Math.round(batchCogs / baseYield);

  return {
    batchCogs: batchCogs,
    unitCogs: unitCogs,
    baseYield: Number(recipe.base_yield),
    yieldUnit: recipe.yield_unit,
    lines: lines
  };
}

function getRecipeEconomics_(recipeId) {
  const recipe = dbFindById('RECIPES', recipeId);
  if (!recipe) throw twbError_('NOT_FOUND', 'Recipe not found: ' + recipeId);
  const items = dbFindMany('RECIPE_ITEMS', 'recipe_id', recipeId);
  return calculateRecipeEconomicsFromRows_(recipe, items);
}

function recalculateProductEconomics_(productId, recipeId, actorUser) {
  const product = dbFindById('PRODUCTS', productId);
  if (!product) throw twbError_('NOT_FOUND', 'Product not found: ' + productId);

  const economics = getRecipeEconomics_(recipeId);
  const sellingPrice = requireNonNegative_(product.selling_price, 'selling_price');
  const grossProfit = Math.round(sellingPrice - economics.unitCogs);
  const grossMargin = sellingPrice > 0
    ? roundNumber_((grossProfit / sellingPrice) * 100, 2)
    : 0;

  return dbUpdateById(
    'PRODUCTS',
    productId,
    stampUpdate_(actorUser, {
      base_recipe_id: recipeId,
      current_cogs: economics.unitCogs,
      gross_profit: grossProfit,
      gross_margin_pct: grossMargin
    }),
    { audit: false }
  );
}
