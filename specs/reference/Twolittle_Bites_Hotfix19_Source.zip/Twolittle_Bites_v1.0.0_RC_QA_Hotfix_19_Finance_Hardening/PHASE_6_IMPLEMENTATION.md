# PHASE_6_IMPLEMENTATION.md
# Twolittle.bites OS — Production Planning + Material Requirement

**Phase:** 6  
**App Version:** 0.6.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

---

## Phase 6 flow

```text
CONFIRMED / SCHEDULED ORDERS
↓
Select Fulfillment Date
↓
Exclude Orders already present in a live Production Plan
↓
Aggregate Product + Variant quantity
↓
Resolve ACTIVE Recipe version
↓
Auto Recipe Scaling
↓
Freeze Production Plan Items
↓
Aggregate Ingredient + Packaging Requirement
↓
Read current Inventory
↓
SUFFICIENT / LOW / SHORTAGE snapshot
```

---

## Production source snapshot

Every plan stores exact Order IDs in:

```text
PRODUCTION_PLANS.source_type = ORDER_SET
PRODUCTION_PLANS.source_id   = ORD-...|ORD-...|ORD-...
```

This means:
- one Order cannot enter two live production plans;
- a late Order can be placed in a supplemental plan;
- cancelling a plan makes its source Orders eligible again;
- the historical source set remains traceable.

---

## Plan status

```text
DRAFT
├── PLANNED
└── CANCELLED

PLANNED
├── IN_PROGRESS
└── CANCELLED

IN_PROGRESS
└── COMPLETED

COMPLETED = terminal
CANCELLED = terminal
```

Phase 6 does not automatically change Order operational status.

---

## Recipe scaling snapshot

For each aggregated Product / Variant target, the plan stores:

```text
recipe_id
recipe_version
target_quantity
target_unit
scaling_mode
multiplier
required_batches
expected_output
expected_surplus
```

Changing a Recipe later does not rewrite an existing Production Plan.

---

## Material Requirement snapshot

Requirements aggregate all active BOM items across the plan.

Both are supported:

```text
INGREDIENT
PACKAGING
```

Each requirement stores:

```text
required_qty_base
available_stock_base
shortage_qty_base
base_unit
status
calculated_at
```

Status logic:

```text
required > available
→ SHORTAGE

required <= available
but projected stock < minimum stock
→ LOW

otherwise
→ SUFFICIENT
```

`Recheck Stock` updates availability/shortage for DRAFT or PLANNED plans without changing the required quantity snapshot.

---

## Important phase boundary

Phase 6 **does not**:

```text
deduct stock
create inventory movements
reserve physical stock
create supplier purchases
consume ingredients
record actual yield
record waste
```

Those remain separate so planning does not mutate inventory before execution.

Next:
- Phase 7 = Inventory Engine
- Phase 8 = Purchasing / Shortage fulfillment

---

## Installation from Phase 5

Use:

```text
Twolittle_Bites_Phase_6_Delta.zip
```

### Replace

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
Index.html
JsApp.html
PageProduction.html
StylesComponents.html
StylesResponsive.html
```

### Add

```text
ProductionPlanningService.gs
JsProduction.html
Phase6Setup.gs
Phase6HealthCheck.gs
Phase6SmokeTest.gs
```

The Delta also contains the Phase 5.0.1 runtime recovery files:

```text
FinanceService.gs
InvoiceService.gs
PaymentService.gs
WhatsAppService.gs
```

If they already exist and are the Phase 5.0.1 versions, replacing them is safe.

---

## One-time upgrade

Run:

```javascript
upgradeToPhase6()
```

It updates:

```text
APP_VERSION = 0.6.0
SCHEMA_VERSION = 1.0.0

PRODUCTION_ELIGIBLE_ORDER_STATUSES
= ["CONFIRMED","SCHEDULED"]

PRODUCTION_PLAN_SOURCE_MODE
= ORDER_SET
```

No sheet is recreated.

---

## Verification

Run:

```javascript
runPhase6HealthCheck()
```

Then:

```javascript
runPhase6SmokeTest()
```

Both are read-only against business transaction data.

Expected:

```text
ok: true
phase: 6
appVersion: 0.6.0
schemaVersion: 1.0.0
```

---

## Browser test

1. Update Web App deployment.
2. Ensure you have:
   - an ACTIVE Product;
   - an ACTIVE Recipe;
   - a CONFIRMED or SCHEDULED Order;
   - Order fulfillment date filled.
3. Open Production.
4. Open `Plan Orders`.
5. Select the Order fulfillment date.
6. Preview Demand.
7. Review:
   - source Orders;
   - aggregated Product targets;
   - scaling;
   - ingredient requirement;
   - packaging requirement;
   - shortages.
8. Set Production Date.
9. Create Production Plan.
10. Open Production Plans.
11. Open the plan.
12. Recheck Stock.
13. Finalize Plan.
14. Start Production.
15. Complete Plan.

No automated test creates a real Production Plan.

---

## Validation file cleanup

Phase 6 validation is self-contained.

After Phase 6 health + smoke both pass, old phase-specific validation files are not required:

```text
Phase2HealthCheck.gs
Phase2SmokeTest.gs
Phase3HealthCheck.gs
Phase3SmokeTest.gs
Phase4HealthCheck.gs
Phase4SmokeTest.gs
Phase5HealthCheck.gs
Phase5SmokeTest.gs
```

Keep:

```text
Phase6HealthCheck.gs
Phase6SmokeTest.gs
```
