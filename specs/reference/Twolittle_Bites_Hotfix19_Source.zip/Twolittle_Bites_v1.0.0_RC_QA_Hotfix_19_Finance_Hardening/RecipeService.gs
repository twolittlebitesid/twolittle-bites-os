/**
 * Recipe / BOM versioning and activation.
 */

function getNextRecipeVersion_(productId, variantId) {
  const recipes = dbFindMany('RECIPES', 'product_id', productId);
  let maxVersion = 0;
  recipes.forEach(function(recipe) {
    const sameVariant = String(recipe.variant_id || '') === String(variantId || '');
    if (sameVariant) maxVersion = Math.max(maxVersion, Number(recipe.version || 0));
  });
  return maxVersion + 1;
}

function validateRecipeTarget_(productId, variantId) {
  const product = dbFindById('PRODUCTS', productId);
  if (!product) throw twbError_('NOT_FOUND', 'Product not found: ' + productId);

  if (variantId) {
    const variant = dbFindById('PRODUCT_VARIANTS', variantId);
    if (!variant) throw twbError_('NOT_FOUND', 'Variant not found: ' + variantId);
    if (String(variant.product_id) !== String(productId)) {
      throw twbError_('VALIDATION_RELATION', 'Variant does not belong to the selected product.');
    }
  }

  return product;
}

function createRecipe(payload) {
  const user = requirePermission_('RECIPE_WRITE');
  payload = payload || {};

  const productId = normalizeText_(payload.product_id);
  const variantId = normalizeText_(payload.variant_id);
  validateRecipeTarget_(productId, variantId);

  const recipeName = normalizeText_(payload.recipe_name);
  const baseYield = requirePositive_(payload.base_yield, 'base_yield');
  const yieldUnit = canonicalUnit_(payload.yield_unit);
  const scalingMode = String(payload.scaling_mode || 'EXACT').toUpperCase();
  assertOneOf_(scalingMode, ['EXACT', 'FULL_BATCH'], 'scaling_mode');

  if (!recipeName) throw twbError_('VALIDATION_REQUIRED', 'Recipe name is required.');
  if (!yieldUnit) throw twbError_('VALIDATION_REQUIRED', 'Yield unit is required.');

  const inputItems = Array.isArray(payload.items) ? payload.items : [];
  if (!inputItems.length) {
    throw twbError_('VALIDATION_REQUIRED', 'Recipe must contain at least one item.');
  }

  const recipeId = nextBusinessId('RECIPE');
  const version = getNextRecipeVersion_(productId, variantId);
  const recipe = stampCreate_(user, {
    recipe_id: recipeId,
    product_id: productId,
    variant_id: variantId,
    recipe_name: recipeName,
    base_yield: baseYield,
    yield_unit: yieldUnit,
    scaling_mode: scalingMode,
    version: version,
    status: 'DRAFT',
    effective_from: '',
    notes: normalizeText_(payload.notes)
  });

  const items = inputItems.map(function(input, index) {
    const itemType = String(input.item_type || '').toUpperCase();
    assertOneOf_(itemType, ['INGREDIENT', 'PACKAGING'], 'item_type');

    const itemId = normalizeText_(input.item_id);
    const qty = requirePositive_(input.quantity, 'quantity');
    const unit = canonicalUnit_(input.unit);
    const wastePct = requireNonNegative_(input.waste_allowance_pct || 0, 'waste_allowance_pct');

    if (!itemId) throw twbError_('VALIDATION_REQUIRED', 'Recipe item is required.');
    if (!unit) throw twbError_('VALIDATION_REQUIRED', 'Recipe item unit is required.');

    const normalized = normalizeItemQuantity_(itemType, itemId, qty, unit);

    return stampCreate_(user, {
      recipe_item_id: nextBusinessId('RECIPE_ITEM'),
      recipe_id: recipeId,
      item_type: itemType,
      item_id: itemId,
      quantity: qty,
      unit: unit,
      quantity_base: normalized.quantityBase,
      waste_allowance_pct: wastePct,
      sort_order: index + 1,
      notes: normalizeText_(input.notes)
    });
  });

  dbInsertRecord('RECIPES', recipe, { validate: true, audit: false });
  dbBulkInsert('RECIPE_ITEMS', items, { validate: true });

  writeAuditLog_(
    'CREATE',
    'RECIPES',
    recipeId,
    null,
    {
      recipe: recipe,
      itemCount: items.length
    },
    'Recipe/BOM created as DRAFT.'
  );

  return getRecipeDetail(recipeId);
}

function getRecipeDetail(recipeId) {
  requireAnyPermission_(['RECIPE_READ', 'PRODUCT_READ']);
  return getRecipeDetail_(recipeId);
}

function getRecipeDetail_(recipeId) {
  const recipe = dbFindById('RECIPES', recipeId);
  if (!recipe) throw twbError_('NOT_FOUND', 'Recipe not found: ' + recipeId);

  const product = dbFindById('PRODUCTS', recipe.product_id);
  const variant = recipe.variant_id
    ? dbFindById('PRODUCT_VARIANTS', recipe.variant_id)
    : null;
  const items = dbFindMany('RECIPE_ITEMS', 'recipe_id', recipeId);
  const economics = calculateRecipeEconomicsFromRows_(recipe, items);

  const enrichedItems = items.map(function(item) {
    const material = getMaterialByType_(item.item_type, item.item_id);
    return Object.assign({}, stripInternalFields_(item), {
      item_name: item.item_type === 'INGREDIENT'
        ? material.ingredient_name
        : material.packaging_name,
      base_unit: material.base_unit,
      cost_per_base_unit: getItemCostPerBaseUnit_(item.item_type, item.item_id)
    });
  });

  return {
    recipe: stripInternalFields_(recipe),
    product: product ? stripInternalFields_(product) : null,
    variant: variant ? stripInternalFields_(variant) : null,
    items: enrichedItems,
    economics: economics
  };
}

function activateRecipe(recipeId) {
  const user = requirePermission_('RECIPE_WRITE');
  const recipe = dbFindById('RECIPES', recipeId);
  if (!recipe) throw twbError_('NOT_FOUND', 'Recipe not found: ' + recipeId);

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let beforeRecipe = null;
  try {
    const related = dbFindMany('RECIPES', 'product_id', recipe.product_id);
    related.forEach(function(other) {
      const sameVariant =
        String(other.variant_id || '') === String(recipe.variant_id || '');
      if (
        sameVariant &&
        other.recipe_id !== recipeId &&
        String(other.status).toUpperCase() === 'ACTIVE'
      ) {
        dbUpdateById(
          'RECIPES',
          other.recipe_id,
          stampUpdate_(user, { status: 'INACTIVE' }),
          { validate: true, audit: false }
        );
      }
    });

    beforeRecipe = stripInternalFields_(recipe);

    dbUpdateById(
      'RECIPES',
      recipeId,
      stampUpdate_(user, {
        status: 'ACTIVE',
        effective_from: todayIso_()
      }),
      { validate: true, audit: false }
    );

    if (recipe.variant_id) {
      dbUpdateById(
        'PRODUCT_VARIANTS',
        recipe.variant_id,
        stampUpdate_(user, { recipe_id: recipeId }),
        { validate: true, audit: false }
      );
    } else {
      recalculateProductEconomics_(recipe.product_id, recipeId, user);
    }
  } finally {
    lock.releaseLock();
  }

  const detail = getRecipeDetail_(recipeId);

  writeAuditLog_(
    'STATUS_CHANGE',
    'RECIPES',
    recipeId,
    beforeRecipe,
    detail.recipe,
    'Recipe activated.'
  );

  return detail;
}
