/**
 * One-time Phase 4 upgrade.
 * Existing 33-sheet schema remains unchanged.
 */
function upgradeToPhase4() {
  const user = requireRole_([TWB_ROLES.OWNER]);

  const schema = validateDatabaseSchema();
  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy. Resolve schema issues first.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'ORDER_DEFAULT_STATUS',
    'WAITING_PAYMENT',
    'STRING',
    'Default order status for new operational orders.',
    user.user_id
  );

  return runPhase4HealthCheck();
}
