# QA Hotfix 18 — Payment Proof Upload and Drive Naming

## User flow

1. Open Finance → Invoices → Record Payment, or use the payment shortcut in Orders.
2. Enter amount, method, and optional reference.
3. Choose one:
   - upload JPG/JPEG, PNG, WebP, PDF (maximum 8 MiB), or
   - paste an existing HTTPS proof URL.
4. Click Record Payment.
5. Payment is recorded using the existing PAYMENTS and TRANSACTIONS workflow.
6. Uploaded proof URL is saved in `PAYMENTS.proof_url` and appears as
   **View proof** in Finance → Payments and Invoice → Payment Events.

## Drive organization

`Twolittle.bites OS / Payment Proofs / 2026 / 10`

Example:

`2026-10-28_Ayu_Putri_PAY-202610-000123.jpg`

- Date is the payment event date in `Asia/Jakarta`.
- Customer name comes from the canonical CUSTOMERS row linked to the invoice.
- Payment ID is included to keep multiple DP/final proofs distinct.
- No original user-supplied file name is trusted or retained.
- New files use Drive's default permissions; do not mark them
  `ANYONE_WITH_LINK` because they may reveal financial information.
- If a Drive file is created but the PAYMENTS insert fails, the unlinked
  file is moved to Trash automatically.

## Acceptance checklist (in an authorized Apps Script deployment)

- [ ] JPG/PNG/WebP/PDF proof uploads and opens for an authorized Drive user.
- [ ] Name contains the correct payment date, Customer name, and Payment ID.
- [ ] File is under the correct year/month folder.
- [ ] New proof URL exists in the matching PAYMENTS row and both UI locations.
- [ ] A second partial payment receives a distinct filename and URL.
- [ ] A payment with no proof still works.
- [ ] Existing Proof URL continues to work.
- [ ] Selecting a file and entering a Proof URL together is rejected.
- [ ] Files above 8 MiB and unsupported/mismatched file types are rejected.
- [ ] Overpayment fails without uploading a Drive file.
- [ ] User without PAYMENT_CREATE or PAYMENT_WRITE cannot upload.
- [ ] File is **not** publicly viewable by anonymous users.
- [ ] Existing invoice PDF/receipt/auto-print behavior is unchanged.

## Deployment

Add the new `PaymentProofService.gs` file, and update
`PaymentService.gs`, `JsFinance.html`, `PageFinance.html`,
and `StylesComponents.html` in the Apps Script project.
Create a new deployment version and test with a real, non-sensitive
payment proof. Existing spreadsheet schema remains unchanged.

This package has been statically checked but has not performed live
Google Drive/App Script write testing.
