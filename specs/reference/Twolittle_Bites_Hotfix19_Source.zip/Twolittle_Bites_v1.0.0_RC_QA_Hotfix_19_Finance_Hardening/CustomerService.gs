/**
 * Twolittle.bites OS — Phase 11 Customer Service
 */

function customerModuleBootstrap() {
  if (
    typeof crmIntelligenceBootstrap ===
    'function'
  ) {
    return crmIntelligenceBootstrap();
  }

  requireAnyPermission_([
    'CUSTOMER_READ',
    'CUSTOMER_READ_LIMITED',
    'ORDER_READ'
  ]);

  var customers =
    listAllRecords_(
      'CUSTOMERS'
    )
      .map(
        stripInternalFields_
      )
      .sort(function(a, b) {
        return String(
          a.name || ''
        ).localeCompare(
          String(
            b.name || ''
          )
        );
      });

  return {
    customers: customers,
    count: customers.length
  };
}

function findCustomerDuplicateCandidate_(whatsapp) {
  const normalized = normalizeWhatsApp_(whatsapp);
  if (!normalized) return null;

  const customers = listAllRecords_('CUSTOMERS');
  for (let i = 0; i < customers.length; i++) {
    if (normalizeWhatsApp_(customers[i].whatsapp) === normalized) {
      return customers[i];
    }
  }
  return null;
}

function createCustomer(payload) {
  const user = requirePermission_('CUSTOMER_WRITE');
  payload = payload || {};

  const name = normalizeText_(payload.name);
  const whatsapp = normalizeWhatsApp_(payload.whatsapp);
  const email = normalizeEmail_(payload.email || '');

  if (!name) {
    throw twbError_('VALIDATION_REQUIRED', 'Customer name is required.');
  }
  if (!whatsapp) {
    throw twbError_('VALIDATION_REQUIRED', 'WhatsApp number is required.');
  }

  const duplicate = findCustomerDuplicateCandidate_(whatsapp);
  if (duplicate) {
    throw twbError_(
      'CUSTOMER_DUPLICATE_WHATSAPP',
      'A customer already uses this WhatsApp number: ' + duplicate.name,
      { customerId: duplicate.customer_id }
    );
  }

  const record = stampCreate_(user, {
    customer_id: nextBusinessId('CUSTOMER'),
    name: name,
    whatsapp: whatsapp,
    email: email,
    default_address: normalizeText_(payload.default_address),
    segment: 'NEW',
    first_order_date: '',
    last_order_date: '',
    total_orders: 0,
    total_spend: 0,
    average_order_value: 0,
    favorite_product_id: '',
    notes: normalizeText_(payload.notes),
    status: 'ACTIVE'
  });

  return dbInsertRecord('CUSTOMERS', record, {
    audit: true,
    action: 'CREATE'
  });
}

function updateCustomer(customerId, payload) {
  const user = requirePermission_('CUSTOMER_WRITE');
  const current = dbFindById('CUSTOMERS', customerId);
  if (!current) {
    throw twbError_('NOT_FOUND', 'Customer not found: ' + customerId);
  }

  payload = payload || {};
  const patch = {};

  if (Object.prototype.hasOwnProperty.call(payload, 'name')) {
    patch.name = normalizeText_(payload.name);
    if (!patch.name) {
      throw twbError_('VALIDATION_REQUIRED', 'Customer name is required.');
    }
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'whatsapp')) {
    const whatsapp = normalizeWhatsApp_(payload.whatsapp);
    if (!whatsapp) {
      throw twbError_('VALIDATION_REQUIRED', 'WhatsApp number is required.');
    }

    const duplicate = findCustomerDuplicateCandidate_(whatsapp);
    if (
      duplicate &&
      String(duplicate.customer_id) !== String(customerId)
    ) {
      throw twbError_(
        'CUSTOMER_DUPLICATE_WHATSAPP',
        'Another customer already uses this WhatsApp number.',
        { customerId: duplicate.customer_id }
      );
    }
    patch.whatsapp = whatsapp;
  }

  if (Object.prototype.hasOwnProperty.call(payload, 'email')) {
    patch.email = normalizeEmail_(payload.email);
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'default_address')) {
    patch.default_address = normalizeText_(payload.default_address);
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'notes')) {
    patch.notes = normalizeText_(payload.notes);
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'status')) {
    patch.status = String(payload.status || '').toUpperCase();
    assertOneOf_(patch.status, ['ACTIVE', 'ARCHIVED'], 'status');
  }

  return dbUpdateById(
    'CUSTOMERS',
    customerId,
    stampUpdate_(user, patch),
    { audit: true, action: 'UPDATE' }
  );
}

function recalculateCustomerMetrics_(customerId, actorUser) {
  const customer = dbFindById('CUSTOMERS', customerId);
  if (!customer) return null;

  const orders = dbFindMany('ORDERS', 'customer_id', customerId)
    .filter(function(order) {
      return String(order.order_status).toUpperCase() === 'COMPLETED';
    });

  let totalSpend = 0;
  let firstOrder = '';
  let lastOrder = '';
  const productCounts = {};

  orders.forEach(function(order) {
    totalSpend += Number(order.grand_total || 0);

    const date =
      typeof crmOrderDateKey_ === 'function'
        ? crmOrderDateKey_(order)
        : String(
            order.fulfillment_date ||
            order.order_date ||
            ''
          );

    if (!firstOrder || date < firstOrder) firstOrder = date;
    if (!lastOrder || date > lastOrder) lastOrder = date;

    dbFindMany('ORDER_ITEMS', 'order_id', order.order_id).forEach(function(item) {
      const key = item.product_id;
      productCounts[key] = (productCounts[key] || 0) + Number(item.quantity || 0);
    });
  });

  let favoriteProductId = '';
  let favoriteQty = -1;
  Object.keys(productCounts).forEach(function(productId) {
    if (productCounts[productId] > favoriteQty) {
      favoriteQty = productCounts[productId];
      favoriteProductId = productId;
    }
  });

  let segment = 'NEW';
  if (orders.length >= 2) segment = 'REPEAT';

  const patch = {
    first_order_date: firstOrder,
    last_order_date: lastOrder,
    total_orders: orders.length,
    total_spend: Math.round(totalSpend),
    average_order_value: orders.length
      ? Math.round(totalSpend / orders.length)
      : 0,
    favorite_product_id: favoriteProductId,
    segment: segment
  };

  if (actorUser) {
    Object.assign(patch, stampUpdate_(actorUser, {}));
  } else {
    patch.updated_at = nowIso_();
    patch.updated_by = customer.updated_by || customer.created_by;
  }

  return dbUpdateById(
    'CUSTOMERS',
    customerId,
    patch,
    { validate: true, audit: false }
  );
}
