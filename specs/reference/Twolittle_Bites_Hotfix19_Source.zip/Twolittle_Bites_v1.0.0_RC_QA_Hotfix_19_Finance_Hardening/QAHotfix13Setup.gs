/**
 * QA Hotfix 13 — runtime diagnostics.
 */

function runQAHotfix13ImagePreviewSmoke(url) {
  var result = resolveProductImagePreview({
    url: url
  });

  return {
    ok: !!(
      result &&
      result.data_url &&
      result.mime_type &&
      result.byte_size > 0
    ),
    source: result.source,
    file_id: result.file_id,
    file_name: result.file_name,
    mime_type: result.mime_type,
    byte_size: result.byte_size,
    data_url_prefix: String(
      result.data_url || ''
    ).slice(0, 48)
  };
}
