/**
 * QA Hotfix 15 — localhost bridge diagnostics.
 */

function runQAHotfix15LocalBridgeSelfTest() {
  requireRole_([
    TWB_ROLES.OWNER
  ]);

  var props =
    PropertiesService.getScriptProperties();

  var secret = props.getProperty(
    localBridgeSecretKey_()
  ) || '';

  var actor = props.getProperty(
    localBridgeActorKey_()
  ) || '';

  var enabled = props.getProperty(
    localBridgeEnabledKey_()
  ) === 'TRUE';

  if (
    !enabled ||
    !secret ||
    !actor
  ) {
    throw twbError_(
      'LOCAL_BRIDGE_NOT_CONFIGURED',
      'Run setupLocalhostBridge() before the localhost bridge self-test.'
    );
  }

  var timestamp =
    new Date().getTime();

  var nonce =
    'SELFTEST-' +
    Utilities.getUuid();

  var action =
    'app.ping';

  var payloadBase64 =
    Utilities.base64Encode(
      JSON.stringify({
        qa: 'hotfix15'
      })
    );

  var envelope = {
    bridgeVersion: 1,
    actorEmail: actor,
    timestamp: timestamp,
    nonce: nonce,
    action: action,
    payloadBase64:
      payloadBase64,
    signature:
      localBridgeSignature_(
        secret,
        actor,
        timestamp,
        nonce,
        action,
        payloadBase64
      )
  };

  var response =
    handleLocalBridgePost_(
      JSON.stringify(
        envelope
      )
    );

  return {
    ok:
      response &&
      response.ok === true,
    actorEmail: actor,
    bridgeEnabled: enabled,
    action: action,
    appVersion:
      response &&
      response.meta
        ? response.meta.appVersion || ''
        : '',
    error:
      response &&
      response.error
        ? response.error
        : null
  };
}
