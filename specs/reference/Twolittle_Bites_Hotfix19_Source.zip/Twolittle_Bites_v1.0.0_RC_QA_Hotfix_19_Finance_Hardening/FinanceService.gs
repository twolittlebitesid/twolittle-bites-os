/**
 * Twolittle.bites OS — Phase 10 Finance Module Bootstrap
 */

function financeModuleBootstrap(options) {
  options = options || {};

  const user = requireAnyPermission_([
    'INVOICE_READ',
    'PAYMENT_READ',
    'PAYMENT_CREATE',
    'TRANSACTION_READ',
    'PNL_READ'
  ]);

  if (options.refreshOverdue !== false) {
    refreshOverdueInvoices_();
  }

  const invoices = listAllRecords_('INVOICES')
    .map(stripInternalFields_);

  const customers = listAllRecords_('CUSTOMERS')
    .map(stripInternalFields_);

  const orders = listAllRecords_('ORDERS')
    .map(stripInternalFields_);

  const canReadPayments =
    hasPermission_(user, 'PAYMENT_READ') ||
    hasPermission_(user, 'PAYMENT_CREATE') ||
    hasPermission_(user, 'PAYMENT_WRITE');

  const payments = canReadPayments
    ? listAllRecords_('PAYMENTS').map(stripInternalFields_)
    : [];

  const transactions = hasPermission_(
    user,
    'TRANSACTION_READ'
  )
    ? listAllRecords_('TRANSACTIONS').map(stripInternalFields_)
    : [];

  const customerMap = {};
  customers.forEach(function(row) {
    customerMap[row.customer_id] = row;
  });

  const orderMap = {};
  orders.forEach(function(row) {
    orderMap[row.order_id] = row;
  });

  const invoiceRows = invoices.map(function(invoice) {
    const customer = customerMap[invoice.customer_id] || {};
    const order = orderMap[invoice.order_id] || {};

    return Object.assign({}, invoice, {
      customer_name: customer.name || invoice.customer_id,
      customer_whatsapp: customer.whatsapp || '',
      order_status: order.order_status || '',
      payment_status: order.payment_status || '',
      public_url: buildPublicInvoiceUrl_(invoice.public_token),
      receipt_url:
        typeof buildPublicReceiptUrl_ === 'function'
          ? buildPublicReceiptUrl_(
              invoice.public_token,
              false
            )
          : '',
      kitchen_ticket_url:
        typeof buildKitchenTicketUrl_ === 'function'
          ? buildKitchenTicketUrl_(
              invoice.invoice_id,
              false
            )
          : ''
    });
  });

  invoiceRows.sort(function(a, b) {
    return String(b.created_at || '').localeCompare(
      String(a.created_at || '')
    );
  });

  payments.sort(function(a, b) {
    return String(b.payment_at || '').localeCompare(
      String(a.payment_at || '')
    );
  });

  transactions.sort(function(a, b) {
    return String(b.transaction_at || '').localeCompare(
      String(a.transaction_at || '')
    );
  });

  const canReadExpenses =
    typeof expenseReadPermission_ === 'function'
      ? expenseReadPermission_(user)
      : false;

  const canCreateExpense =
    typeof expenseCreatePermission_ === 'function'
      ? expenseCreatePermission_(user)
      : false;

  const expenses = canReadExpenses
    ? listAllRecords_('EXPENSES')
        .map(stripInternalFields_)
        .sort(function(a, b) {
          return String(b.expense_date || '').localeCompare(
            String(a.expense_date || '')
          );
        })
    : [];

  const canReadPnl =
    hasPermission_(user, 'PNL_READ') ||
    hasPermission_(user, 'REPORT_READ');

  const analytics = canReadPnl &&
    typeof buildFinanceAnalytics_ === 'function'
      ? buildFinanceAnalytics_({})
      : null;

  return {
    invoices: invoiceRows,
    payments: payments,
    transactions: transactions,
    expenses: expenses,
    analytics: analytics,
    expenseCategories:
      typeof getExpenseCategories_ === 'function'
        ? getExpenseCategories_()
        : [],
    paymentMethods: getPaymentMethods_(),
    printing:
      typeof receiptPrintingSettings_ === 'function'
        ? receiptPrintingSettings_()
        : null,
    permissions: {
      invoiceWrite: hasPermission_(user, 'INVOICE_WRITE'),
      paymentCreate:
        hasPermission_(user, 'PAYMENT_CREATE') ||
        hasPermission_(user, 'PAYMENT_WRITE'),
      refund: hasPermission_(user, 'PAYMENT_WRITE'),
      transactionRead: hasPermission_(user, 'TRANSACTION_READ'),
      pnlRead: canReadPnl,
      expenseRead: canReadExpenses,
      expenseCreate: canCreateExpense,
      expenseWrite: hasPermission_(user, 'EXPENSE_WRITE'),
      cogsBackfill: hasPermission_(user, 'TRANSACTION_WRITE')
    }
  };
}
