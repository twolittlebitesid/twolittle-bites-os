# QA_HOTFIX_12_STATIC_QA.md

## Comprehensive static QA

- Search utility physically appears before the first card on all 12 pages: PASS
- All server `.gs` syntax: PASS
- All client `Js*.html` syntax: PASS
- Index include resolution: PASS
- Search utility slot on all 12 pages: PASS
- No duplicate DOM IDs inside page templates: PASS
- No duplicate Page template IDs: PASS
- Duplicate Experience KPI/card layer removed: PASS
- Universal/native search engine present: PASS
- Image fallback candidate engine present: PASS
- Product image cache-bust uses Product updated_at: PASS
- New Order image cache-bust uses Product updated_at: PASS
- Visited-route cache still active: PASS
- Reduced-motion accessibility preserved: PASS
- Phase 16 Hotfix 12 health guard: PASS
- Phase 16 Hotfix 12 smoke guard: PASS
- Prior QA health guards preserved: PASS
- Canonical sheet schema unchanged (33/33): PASS
- Permissions unchanged from Hotfix 11: PASS

- Missing includes: none
- Duplicate page IDs: none
- Duplicate template IDs: none
- Canonical sheets: 33/33
- Schema migration required: NO
- Data rewrite required: NO
- Permission change required: NO
- External animation library: NO

## Runtime boundaries

Static QA cannot prove that a third-party image host or Google Drive sharing policy permits the browser to fetch an image. Manual QA must open at least one direct URL and one Drive image URL in the deployed webapp.

Runtime/manual acceptance also remains required for search behavior after tab switches, mobile overflow, role permissions, route caching, and real Apps Script RPC latency.
