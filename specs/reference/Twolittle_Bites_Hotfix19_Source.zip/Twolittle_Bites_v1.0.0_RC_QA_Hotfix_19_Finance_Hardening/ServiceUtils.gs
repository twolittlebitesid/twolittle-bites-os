/**
 * Shared helpers for Phase 3 business services.
 */

function requireAnyPermission_(permissions) {
  const user = requireCurrentUser_();
  const allowed = (permissions || []).some(function(permission) {
    return hasPermission_(user, permission);
  });
  if (!allowed) {
    throw twbError_(
      'FORBIDDEN',
      'Permission denied. Required one of: ' + (permissions || []).join(', ')
    );
  }
  return user;
}

function listAllRecords_(sheetName) {
  const schema = getSheetSchema_(sheetName);
  const sheet = getDbSheet_(sheetName);
  const lastRow = sheet.getLastRow();

  if (lastRow <= 1) return [];

  return sheet
    .getRange(
      2,
      1,
      lastRow - 1,
      schema.headers.length
    )
    .getValues()
    .map(function(row) {
      return rowToObject_(
        schema.headers,
        row
      );
    });
}

function stripInternalFields_(record) {
  if (!record) return record;
  const clean = Object.assign({}, record);
  Object.keys(clean).forEach(function(key) {
    if (key.indexOf('__') === 0) delete clean[key];
  });
  return clean;
}

function stampCreate_(user, payload) {
  const now = nowIso_();
  return Object.assign({}, payload, {
    created_at: now,
    created_by: user.user_id,
    updated_at: now,
    updated_by: user.user_id
  });
}

function stampUpdate_(user, payload) {
  return Object.assign({}, payload, {
    updated_at: nowIso_(),
    updated_by: user.user_id
  });
}

function assertOneOf_(value, allowed, fieldName) {
  if (allowed.indexOf(value) < 0) {
    throw twbError_(
      'VALIDATION_ENUM',
      (fieldName || 'value') + ' must be one of: ' + allowed.join(', ')
    );
  }
  return value;
}

function numberOrZero_(value) {
  const n = Number(value);
  return isNaN(n) ? 0 : n;
}

function optionalNumber_(value) {
  if (value === '' || value === null || value === undefined) return '';
  const n = Number(value);
  if (isNaN(n)) throw twbError_('VALIDATION_NUMBER', 'Expected a valid number.');
  return n;
}

function roundNumber_(value, decimals) {
  const power = Math.pow(10, decimals === undefined ? 2 : decimals);
  return Math.round((Number(value) + Number.EPSILON) * power) / power;
}

function normalizeSku_(value) {
  return String(value || '').trim().toUpperCase();
}

function normalizeText_(value) {
  return String(value || '').trim();
}

function activeLikeStatus_(status) {
  return ['ACTIVE', 'SEASONAL', 'DRAFT'].indexOf(String(status || '').toUpperCase()) >= 0;
}
