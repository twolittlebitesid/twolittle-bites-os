/**
 * Twolittle.bites OS — Business health, targets, channels and operating context.
 * Added as v1.0 pre-release P0 closure because PageBusiness remained a shell.
 */

function businessModuleBootstrap(payload) {
  var user = requirePermission_('BUSINESS_READ');
  var period = normalizeReportPeriod_(payload || {});
  var report = reportModuleBootstrap({
    period_start: period.start,
    period_end: period.end
  });

  var orders = listAllRecords_('ORDERS');
  var sourceChannels = getConfig_('SALES_CHANNELS') || [];
  var fulfillmentTypes = getConfig_('FULFILLMENT_TYPES') || [];
  var paymentMethods = getConfig_('PAYMENT_METHODS') || [];

  var canSeeRevenue =
    user.role !== TWB_ROLES.PRODUCTION;

  var canSeeProfit =
    user.role === TWB_ROLES.OWNER ||
    hasPermission_(user, 'PNL_READ');

  var channels = {};
  sourceChannels.forEach(function(channel) {
    channels[channel] = {
      channel: channel,
      orders: 0,
      completedOrders: 0,
      operatingRevenue: 0
    };
  });

  orders.forEach(function(order) {
    var status = String(order.order_status || '').toUpperCase();
    if (status === 'CANCELLED') return;

    var orderDate = reportDateKey_(order.order_date || order.created_at);
    var fulfillmentDate = reportDateKey_(order.fulfillment_date || order.order_date);
    var orderInPeriod = !!orderDate && orderDate >= period.start && orderDate <= period.end;
    var completedInPeriod =
      status === 'COMPLETED' &&
      !!fulfillmentDate &&
      fulfillmentDate >= period.start &&
      fulfillmentDate <= period.end;

    if (!orderInPeriod && !completedInPeriod) return;

    var channel = String(order.source_channel || 'UNSPECIFIED').toUpperCase();
    if (!channels[channel]) {
      channels[channel] = {
        channel: channel,
        orders: 0,
        completedOrders: 0,
        operatingRevenue: 0
      };
    }

    if (orderInPeriod) channels[channel].orders += 1;

    if (completedInPeriod) {
      channels[channel].completedOrders += 1;
      channels[channel].operatingRevenue += marketingOperatingRevenue_(order);
    }
  });

  var channelRows = Object.keys(channels)
    .map(function(key) {
      var row = channels[key];
      return {
        channel: row.channel,
        orders: row.orders,
        completedOrders: row.completedOrders,
        operatingRevenue: canSeeRevenue ? Math.round(row.operatingRevenue) : null
      };
    })
    .filter(function(row) {
      return row.orders > 0 || sourceChannels.indexOf(row.channel) >= 0;
    })
    .sort(function(a, b) {
      return b.orders - a.orders;
    });

  var targets = (report.targets || []).filter(function(target) {
    if (canSeeProfit) return true;
    return ['OPERATING_PROFIT', 'GROSS_MARGIN_PCT'].indexOf(target.metric_key) < 0;
  });

  var targetMetricKeys = (report.targetMetricKeys || []).filter(function(key) {
    if (canSeeProfit) return true;
    return ['OPERATING_PROFIT', 'GROSS_MARGIN_PCT'].indexOf(key) < 0;
  });

  var finance = report.finance
    ? {
        completedOrders: Number(report.finance.completedOrders || 0),
        operatingRevenue: canSeeRevenue ? Number(report.finance.operatingRevenue || 0) : null,
        netCash: canSeeRevenue ? Number(report.finance.netCash || 0) : null,
        grossMarginPct: canSeeProfit ? Number(report.finance.grossMarginPct || 0) : null,
        operatingProfit: canSeeProfit ? Number(report.finance.operatingProfit || 0) : null
      }
    : null;

  var healthCards = [];

  if (report.finance) {
    healthCards.push({ key: 'COMPLETED_ORDERS', label: 'Completed Orders', value: report.finance.completedOrders, unit: 'COUNT' });
    healthCards.push({ key: 'OPERATING_REVENUE', label: 'Operating Revenue', value: report.finance.operatingRevenue, unit: 'IDR' });
    if (canSeeProfit) {
      healthCards.push({ key: 'GROSS_MARGIN_PCT', label: 'Gross Margin', value: report.finance.grossMarginPct, unit: 'PERCENT' });
      healthCards.push({ key: 'OPERATING_PROFIT', label: 'Operating Profit', value: report.finance.operatingProfit, unit: 'IDR' });
    } else {
      healthCards.push({ key: 'NET_CASH', label: 'Net Cash Movement', value: report.finance.netCash, unit: 'IDR' });
    }
  } else if (report.marketing) {
    healthCards.push({ key: 'MARKETING_SPEND', label: 'Marketing Spend', value: report.marketing.spend, unit: 'IDR' });
    healthCards.push({ key: 'ATTRIBUTED_REVENUE', label: 'Attributed Revenue', value: report.marketing.attributedRevenue, unit: 'IDR' });
    healthCards.push({ key: 'ATTRIBUTED_ORDERS', label: 'Attributed Orders', value: report.marketing.attributedOrders, unit: 'COUNT' });
    healthCards.push({ key: 'ATTRIBUTION_COVERAGE_PCT', label: 'Attribution Coverage', value: report.marketing.attributionCoveragePct, unit: 'PERCENT' });
  } else if (report.operational) {
    healthCards.push({ key: 'PRODUCTION_PLANS', label: 'Production Plans', value: report.operational.productionPlans, unit: 'COUNT' });
    healthCards.push({ key: 'PRODUCTION_COMPLETED_PLANS', label: 'Completed Plans', value: report.operational.completedProductionPlans, unit: 'COUNT' });
    healthCards.push({ key: 'PRODUCTION_COMPLETION_RATE_PCT', label: 'Completion Rate', value: report.operational.productionCompletionRatePct, unit: 'PERCENT' });
    healthCards.push({ key: 'SHORTAGE_REQUIREMENTS', label: 'Shortage Signals', value: report.operational.shortageRequirements, unit: 'COUNT' });
  }

  return {
    period: period,
    healthCards: healthCards,
    finance: finance,
    operational: report.operational || null,
    marketing: report.marketing || null,
    trend: report.daily || [],
    targets: targets,
    targetMetricKeys: targetMetricKeys,
    channels: channelRows,
    context: {
      businessName: getBusinessSetting_('business_name') || TWB_APP.NAME,
      salesChannels: sourceChannels,
      fulfillmentTypes: fulfillmentTypes,
      paymentMethods: paymentMethods,
      timezone: TWB_APP.TIMEZONE,
      currency: TWB_APP.CURRENCY
    },
    permissions: {
      canWriteTargets: hasPermission_(user, 'BUSINESS_UPDATE'),
      canSeeRevenue: canSeeRevenue,
      canSeeProfit: canSeeProfit
    }
  };
}

function createBusinessTarget(payload) {
  requirePermission_('BUSINESS_UPDATE');
  return createBusinessTargetPhase13(payload || {});
}

function updateBusinessTargetStatus(targetId, status) {
  requirePermission_('BUSINESS_UPDATE');
  return updateBusinessTargetStatusPhase13(targetId, status);
}
