/**
 * Twolittle.bites OS — Phase 15 upgrade.
 *
 * Does not create scheduled triggers automatically.
 * OWNER must explicitly run configurePhase15MaintenanceAutomation().
 */
function upgradeToPhase15() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER
    ]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'SYSTEM_HARDENING_MODE',
    'PHASE15',
    'STRING',
    'System diagnostics, exact backups, non-destructive recovery, and maintenance automation are available.',
    user.user_id
  );

  setConfig_(
    'SYSTEM_BACKUP_RETENTION_DAYS',
    Number(
      getConfig_(
        'SYSTEM_BACKUP_RETENTION_DAYS'
      ) || 30
    ),
    'NUMBER',
    'Days to retain automatic database spreadsheet backups.',
    user.user_id
  );

  if (
    getConfig_(
      'SYSTEM_BACKUP_ENABLED'
    ) === null
  ) {
    setConfig_(
      'SYSTEM_BACKUP_ENABLED',
      true,
      'BOOLEAN',
      'Create database backup during scheduled Phase 15 maintenance.',
      user.user_id
    );
  }

  if (
    getConfig_(
      'SYSTEM_REPORT_CACHE_REBUILD_ENABLED'
    ) === null
  ) {
    setConfig_(
      'SYSTEM_REPORT_CACHE_REBUILD_ENABLED',
      true,
      'BOOLEAN',
      'Rebuild report cache during scheduled Phase 15 maintenance.',
      user.user_id
    );
  }

  setConfig_(
    'SYSTEM_INTERNAL_READ_MODE',
    'SINGLE_RANGE_FULL_SHEET',
    'STRING',
    'Internal listAllRecords_ uses one range read per sheet instead of pagination.',
    user.user_id
  );

  setConfig_(
    'SYSTEM_CONFIG_CACHE_TTL_SECONDS',
    300,
    'NUMBER',
    'Script cache TTL for CONFIG and BUSINESS_SETTINGS reads.',
    user.user_id
  );

  return runPhase15HealthCheck();
}
