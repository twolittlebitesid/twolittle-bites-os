/**
 * QA Hotfix 18 — Private payment proof uploads.
 *
 * Files are stored inside the existing Twolittle.bites OS Drive root.
 * No public sharing permission is applied to sensitive payment evidence.
 */

const TWB_PAYMENT_PROOF_MAX_BYTES = 8 * 1024 * 1024;
const TWB_PAYMENT_PROOF_TYPES = Object.freeze({
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'application/pdf': '.pdf'
});

function paymentProofDate_(paymentAt) {
  const value = String(paymentAt || '');
  const match = value.match(/^(\d{4}-\d{2}-\d{2})(?:T|$)/);

  if (match) {
    const parsed = new Date(match[1] + 'T12:00:00+07:00');
    if (
      !isNaN(parsed.getTime()) &&
      Utilities.formatDate(parsed, TWB_APP.TIMEZONE, 'yyyy-MM-dd') === match[1]
    ) {
      return match[1];
    }
  }

  return todayIso_();
}

function paymentProofCustomerName_(invoice) {
  const customer = invoice && invoice.customer_id
    ? dbFindById('CUSTOMERS', invoice.customer_id)
    : null;

  return (customer && normalizeText_(customer.name)) ||
    normalizeText_(invoice && invoice.customer_id) ||
    'Customer';
}

function paymentProofSafeName_(name) {
  return String(name || 'Customer')
    .replace(/[\\\/:*?"<>|\u0000-\u001f\u007f]+/g, ' ')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^[._\s-]+|[._\s-]+$/g, '')
    .slice(0, 64) || 'Customer';
}

function paymentProofFileName_(paymentAt, customerName, paymentId, mimeType) {
  return paymentProofDate_(paymentAt) + '_' +
    paymentProofSafeName_(customerName) + '_' +
    paymentProofSafeName_(paymentId) +
    TWB_PAYMENT_PROOF_TYPES[mimeType];
}

function paymentProofDecode_(upload) {
  if (!upload || typeof upload !== 'object' || Array.isArray(upload)) {
    throw twbError_('PAYMENT_PROOF_INVALID', 'Choose a valid proof file.');
  }

  const mime = String(upload.mime_type || '').toLowerCase().trim();
  const encoded = upload.base64;
  if (!Object.prototype.hasOwnProperty.call(TWB_PAYMENT_PROOF_TYPES, mime)) {
    throw twbError_(
      'PAYMENT_PROOF_TYPE',
      'Payment proof must be JPG, PNG, WebP, or PDF.'
    );
  }
  if (
    typeof encoded !== 'string' ||
    !encoded ||
    encoded.length > Math.ceil(TWB_PAYMENT_PROOF_MAX_BYTES / 3) * 4 + 8 ||
    !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)
  ) {
    throw twbError_(
      'PAYMENT_PROOF_INVALID',
      'Payment proof data is invalid or exceeds 8 MB.'
    );
  }

  let bytes;
  try {
    bytes = Utilities.base64Decode(encoded);
  } catch (e) {
    throw twbError_('PAYMENT_PROOF_INVALID', 'Payment proof cannot be decoded.');
  }

  if (!bytes.length || bytes.length > TWB_PAYMENT_PROOF_MAX_BYTES) {
    throw twbError_('PAYMENT_PROOF_SIZE', 'Payment proof must be 8 MB or smaller.');
  }

  const b = index => (bytes[index] || 0) & 255;
  const signatureOk =
    (mime === 'image/jpeg' &&
      b(0) === 255 && b(1) === 216 && b(2) === 255) ||
    (mime === 'image/png' &&
      b(0) === 137 && b(1) === 80 && b(2) === 78 &&
      b(3) === 71 && b(4) === 13 && b(5) === 10 &&
      b(6) === 26 && b(7) === 10) ||
    (mime === 'image/webp' &&
      String.fromCharCode(b(0), b(1), b(2), b(3)) === 'RIFF' &&
      String.fromCharCode(b(8), b(9), b(10), b(11)) === 'WEBP') ||
    (mime === 'application/pdf' &&
      String.fromCharCode(b(0), b(1), b(2), b(3), b(4)) === '%PDF-');

  if (!signatureOk) {
    throw twbError_(
      'PAYMENT_PROOF_CONTENT',
      'The proof file content does not match its file type.'
    );
  }

  return { bytes: bytes, mimeType: mime };
}

function paymentProofFolder_(paymentAt) {
  const date = paymentProofDate_(paymentAt);
  const year = date.substring(0, 4);
  const month = date.substring(5, 7);
  const root = invoicePdfRootFolder_();
  const proofs = invoicePdfChildFolder_(
    root, 'PAYMENT_PROOFS', 'Payment Proofs'
  );
  const yearFolder = invoicePdfChildFolder_(
    proofs, 'PAYMENT_PROOFS_YEAR_' + year, year
  );

  return invoicePdfChildFolder_(
    yearFolder, 'PAYMENT_PROOFS_MONTH_' + year + '_' + month, month
  );
}

function paymentProofCreate_(upload, invoice, paymentId, paymentAt) {
  const validated = paymentProofDecode_(upload);
  const fileName = paymentProofFileName_(
    paymentAt,
    paymentProofCustomerName_(invoice),
    paymentId,
    validated.mimeType
  );
  const blob = Utilities.newBlob(
    validated.bytes,
    validated.mimeType,
    fileName
  );
  const file = paymentProofFolder_(paymentAt).createFile(blob);

  // A Drive link does not imply public access. Keep Drive's default permissions.
  return {
    fileId: file.getId(),
    url: 'https://drive.google.com/file/d/' +
      encodeURIComponent(file.getId()) + '/view',
    name: fileName
  };
}

function paymentProofDiscardUnsaved_(proof) {
  if (!proof || !proof.fileId) return;
  try {
    DriveApp.getFileById(proof.fileId).setTrashed(true);
  } catch (ignored) {}
}
