# PRODUCTION_ACCEPTANCE_TEST.md
# Twolittle.bites OS v1.0

Use a controlled test customer/order where business policy allows.

## 1. App shell

Desktop:
- app loads without server-request failure;
- header/navigation renders;
- route changes work;
- revisiting a previously opened menu does not refetch/reload the module unless Refresh is clicked;
- More menu works;
- logo is non-clickable and no “Business Operating System” subtitle is shown;
- Data Foundation status is a small bottom-right indicator;
- no stray `\` text artifact appears at the lower-left.

Mobile:
- navigation remains usable;
- forms do not overflow;
- modal actions remain accessible;
- tables are scrollable/readable.

## 2. Executive

- Executive loads live data, not Phase 2 readiness placeholders.
- Operating Revenue / Completed Orders / Net Cash match Reports for the same period.
- OWNER / FINANCE can see profit metrics; ADMIN does not receive sensitive profit KPIs.
- Order Pipeline counts reflect live Order statuses.
- Attention panel surfaces overdue invoice / stock / shortage / purchase exceptions.
- Customer and Marketing summaries load.
- Target progress and Recent Orders load.
- Revenue and Completed Orders growth charts render for the selected period.
- New Order / Refresh actions sit at the lower-right of the Executive banner/card.

## 3. Business

- Business loads live health cards, not a shell/empty state.
- Overview is role-aware.
- Targets come from BUSINESS_TARGETS and Target vs Actual works.
- OWNER / ADMIN can create/archive targets.
- PRODUCTION can open Business and sees operational scope only.
- MARKETING sees marketing scope only.
- Finance/Owner receive full business reporting scope.
- Channel table loads live source-channel order counts.
- Production does not receive restricted revenue/profit values.
- Operating Context matches configured Sales Channels, Fulfillment Types, and Payment Methods.
- role-appropriate growth charts render and update with the selected period.

## 4. Products & Recipes

- Products page loads.
- Recipe/BOM data loads.
- EXACT scaling works.
- FULL_BATCH scaling works.
- Product pricing remains available to Order creation.

## 5. Customers & Orders

- Customers page loads.
- Customer profile loads.
- New Order form loads.
- Customer can be searched by name / WhatsApp / email; selecting from a very large customer list does not require scrolling one-by-one.
- Product snapshot pricing is correct.
- Orders page spacing between KPI, growth, and table cards is visually consistent.
- Orders Created and Booked Value growth charts render.
- Fulfillment fields behave correctly.
- Order status flow remains valid.

## 6. Invoice / Payment / WhatsApp

- Invoice is created for a controlled test Order when configured.
- Public invoice URL opens.
- WhatsApp quick action opens an active unpaid/partial Order queue instead of an “inactive workflow” message.
- WhatsApp link contains the configured template.
- Partial payment updates invoice balance.
- Full payment updates payment state.
- Auto-confirm behavior follows Settings.

## 7. Production

- eligible Orders appear;
- production plan can be generated;
- recipe requirements are snapshotted;
- stock recheck works;
- production usage guard prevents duplicate posting.

## 8. Inventory

- Inventory page loads.
- Ledger balance and cached balance reconcile.
- manual movement works on a controlled material;
- physical-count adjustment works if tested;
- negative stock setting is respected.

## 9. Purchasing

- Suppliers load.
- Purchase creation works.
- Receiving posts PURCHASE_RECEIPT movement.
- duplicate receipt protection remains active.
- weighted average inventory cost updates as expected.

## 10. Pre-Order

- campaign loads;
- cutoff/capacity state is correct;
- quota status is correct;
- campaign-created Orders flow into normal Orders.

## 11. Finance

- invoices load;
- payments load;
- expenses load;
- Transactions load;
- managerial P&L renders;
- cash movement remains separate from non-cash COGS.

## 12. CRM

- repeat rate loads;
- customer segments load;
- profile affinity/channel mix loads;
- dormant/reactivation list loads;
- limited-access masking works for a limited role if available.

## 13. Marketing

- Campaigns load.
- Content loads.
- linked Marketing Expenses contribute to spend.
- attributed Orders show.
- completed attributed revenue contributes to ROAS.

## 14. Reports

- current-period report loads;
- Daily / Weekly / Monthly tabs load;
- target table loads;
- CSV export downloads;
- role-aware column visibility works.

## 15. Settings

OWNER:
- Settings write works;
- Public Invoice Title / Public Invoice Note / WhatsApp template can be edited;
- Public Invoice and WhatsApp live previews update while typing;
- Users tab appears;
- Diagnostics tab appears;
- Release tab appears.

ADMIN:
- Settings write works;
- Users tab hidden;
- Diagnostics / Release view available.

FINANCE:
- Settings read-only.

## 16. Diagnostics

- Integrity = Healthy.
- Cross-module Regression = 13/13.
- recent errors contain no unexplained production error.
- verified backup is visible.

## 17. Public invoice

Open a public invoice in an unauthenticated browser/private window:
- invoice renders;
- wrong token returns not-found page;
- no private admin UI appears.

## 18. Final release gate

Required:

```text
runPhase16ReleasePreflight()
ok = true
blockingFailures = 0
```

If any critical item fails, do not mark RELEASED.


## 17. Global header consistency

- Desktop header is visually consistent on every route.
- Active menu state remains clear.
- Header does not overflow around tablet breakpoint.
- Mobile header uses the drawer without horizontal overflow.
- Every module banner uses consistent icon size, spacing, title scale, and content height.


### Drive PDF / clickable contact QA

- `@twolittle.bites` opens `instagram.com/twolittle.bites/` in a new tab.
- `0812 6794 8252` opens WhatsApp chat to `6281267948252`.
- A real Invoice automatically has a PDF archive after creation.
- PDF path follows `Twolittle.bites OS / Invoices / YYYY / MM Month`.
- PDF file name matches the Invoice Number.
- PDF file is `Anyone with the link — Viewer`.
- Open the PDF download URL in an incognito browser with no Google login; it must not ask for Drive access.
- Record a partial payment; PDF is regenerated and Remaining is updated.
- Record/refund payment; PDF is regenerated again.
- Edit Order fulfillment details; PDF is regenerated with the latest Delivery Details.
- Public Invoice shows `Download PDF` when a public PDF archive exists.
- WhatsApp template accepts `{invoice_pdf_url}`.
- For a no-Apps-Script-link WhatsApp flow, use `{invoice_pdf_url}` instead of `{invoice_url}`.


### QA Hotfix 09 — integrity runtime

- `runQAHotfix09IntegrityRepairCheck()` returns `QA_HOTFIX_09_COMPOSITE_KEYS_V1`.
- DAILY_METRICS integrity key is `metric_date + metric_key`.
- MONTHLY_METRICS integrity key is `month + metric_key`.
- `DATA_INTEGRITY` is no longer failing only because multiple metric keys share one date/month.
- If `DATA_INTEGRITY` remains false, inspect the returned real issue groups before release.

### QA Hotfix 10 — public invoice layout + logo

- Settings → Business shows `Brand Logo URL` field and live preview.
- Saving `brand_logo_url` persists successfully.
- Public invoice header renders logo when `brand_logo_url` is populated.
- When no logo is set, invoice falls back to business-name text.
- Public web preview retains CTA buttons.
- Generated PDF hides CTA buttons and remains visually aligned with the preview.
- Small invoices (for example 1–4 lines) render on one PDF page.


## Experience Upgrade 11 — decision utility & motion

### Global motion
- Route changes use a short fade + 6px rise and do not trigger data reload.
- Buttons compress slightly on press.
- Modals animate opacity/translate/scale once on open.
- Cards only lift on hover-capable pointer devices.
- KPI/chart reveal runs once per render.
- `prefers-reduced-motion: reduce` disables visible motion.
- No external animation library is loaded.

### Orders
- Pipeline strip reflects Waiting Payment → Confirmed → Production → Ready → Delivery → Completed.
- Search matches Order ID, customer, WhatsApp, item summary, channel, or fulfillment.
- Date / Channel / Fulfillment / Customer filters combine with Status and existing view tabs.
- Needs Attention summarizes payment/final-fulfillment risk.

### Customers
- New This Month is based on customer created date.
- Directory search matches name, WhatsApp, email, favorite product, or CRM segment.
- CRM Segment filter works without changing source data.

### Products
- Active Product / Variant / Avg Gross Margin / Recipe-Margin Attention cards render.
- Product search filters Product Master by name, SKU, category, and status.
- Existing Product → Variant hierarchy remains intact.

### Production
- Today Plans, In Progress, Today Target, and Today Shortage render from live production plans.

### Inventory
- Need Restock prioritizes LOW and OUT_OF_STOCK materials.
- Search, Stock Status, and Material Type filters work together.

### Purchasing
- Suggested To Buy, Open Purchases, Awaiting Delivery, and Delivery Risk render from purchasing data.

### Finance
- Cash In/Out are based on TRANSACTIONS amount_in / amount_out.
- Overdue invoice and refund signals are visible.

### Marketing
- Best Channel uses operating revenue.
- Best Campaign, Attribution Coverage, and Unattributed Order attention render.

### Reports
- Previous-period comparison uses the same-length period immediately before the selected period.
- Revenue, Completed Orders, Marketing Spend, and Attribution Coverage delta render.
- Previous-period data is cached client-side for the active session.


### QA Hotfix 12 — full UI consistency

- Every page displays Search / Filter utility above its KPI/card area.
- Experience Upgrade does not render a second duplicated KPI card grid.
- Route switching remains cached and does not bootstrap/reload the previous route again.
- Product Master image loads after initial page open.
- Edit a Product image URL and save; the thumbnail refreshes without hard-refreshing the webapp.
- Re-save/replace an image behind the same URL, then update the Product; the `updated_at` cache key forces a fresh browser request.
- Google Drive image links try thumbnail then `uc?export=view` fallback.
- New Order selected Product thumbnail matches the current Product image.
- Search does not reveal permission-hidden controls.
- Search reset restores the full rendered record list.
- Mobile Search / Filter controls stack without horizontal overflow.
- `prefers-reduced-motion` still disables nonessential motion.


### QA Hotfix 13 — invoice/payment/image

- Bottom quick bar does not show `Operating System Active`.
- Bottom quick bar shows `Invoice`; click opens Finance → Invoices.
- Orders with remaining payment show a `+` beside Payment status.
- Order Payment `+` opens the correct Invoice and Record Payment flow.
- Finance → Invoices shows a `+` for invoices with remaining balance.
- Fully paid / cancelled / refunded records do not show an inappropriate Record Payment shortcut.
- Product Edit preview displays a saved Google Drive image without requiring a hard browser refresh when the Apps Script owner can read the Drive file.
- Product table and New Order thumbnail use the same image fallback path.
- Settings → Business logo preview uses the resilient image loader.
- Public Invoice / PDF renders a configured Drive logo through server-side data URL resolution when direct Drive embedding is unavailable.
- `runQAHotfix13ImagePreviewSmoke(<drive-link>)` returns `ok=true` for the actual Drive image used in QA.
- Executive users without `PNL_READ` do not receive OPERATING_PROFIT or GROSS_MARGIN_PCT target rows.


### QA Hotfix 14 — thermal printing

- Settings → Printing loads and saves 58/80 mm options.
- Paid/partial Invoice shows Print Receipt.
- Order detail shows Receipt after a payment exists.
- Receipt browser page matches the selected 58/80 mm width and opens the browser print dialog with `autoprint=1`.
- Auto Open Print After Payment opens receipt after a successful payment and never rolls back or duplicates the payment if a popup is blocked.
- Kitchen Ticket is hidden when disabled and available when enabled.
- Kitchen Ticket requires internal app permission and does not reuse the public invoice token.
- Receipt logo respects Show Logo and uses the configured Business logo.
- Show Customer and Show Payment Method toggles affect receipt output.
- Existing invoice/payment/order source-of-truth behavior remains unchanged.


### QA Hotfix 15 — localhost hybrid

- Apps Script mode still loads through `google.script.run` when `TWB_RUNTIME_CONFIG.mode` is not LOCAL.
- Localhost package loads at `127.0.0.1:5173` and does not contain the bridge secret.
- `setupLocalhostBridge()` binds exactly one active USERS actor and rotates a long secret.
- `runQAHotfix15LocalBridgeSelfTest()` returns `ok=true` after setup.
- Invalid signature, expired timestamp, wrong actor, and reused nonce are rejected by the local bridge.
- `Auth.gs` does not use `Session.getEffectiveUser()` as an application identity fallback.
- Local read modules can render from IndexedDB when a cached response exists.
- Background revalidation updates IndexedDB and runtime status without turning an unavailable cloud write into a success.
- Mutations remain server-authoritative and clear stale read cache only after successful mutation.
- `images.resolve` and other non-mutating uncached calls do not clear the entire local cache.
- Local runtime indicator shows Synced / Cached / Syncing / Offline / Sync issue states.
- Hotfix 14 Receipt printing remains available.
- Local Kitchen Ticket uses signed `receipts.kitchenData`; production notes are not exposed through an anonymous public-token route.
- Existing role permissions are still enforced server-side using the bridge actor.
- Canonical sheet count remains 33 and no schema migration is required.


### QA Hotfix 16 — WhatsApp delivery fee

- Settings → Invoice & WhatsApp lists `{delivery_fee}`.
- Template containing `Ongkir: {delivery_fee}` saves without unknown-placeholder error.
- Live preview renders a Rupiah delivery fee sample.
- Real Invoice WhatsApp message renders `{delivery_fee}` from `invoice.delivery_fee`.
- Zero delivery fee renders `Rp0` consistently with other IDR placeholders.
- Existing placeholders remain supported.


### QA Hotfix 17 — Bulk Order Progress

- Orders table shows a selection checkbox for non-terminal Orders when the user has `ORDER_WRITE`.
- `Select all visible Orders` only selects currently filtered non-terminal Orders.
- `COMPLETED` and `CANCELLED` Orders cannot be selected for Bulk Progress.
- Selecting one or more Orders reveals the Bulk Progress bar and selected count.
- `Advance Next Step` follows the existing transition graph per Order.
- READY + DELIVERY advances to ON_DELIVERY; READY + non-DELIVERY advances to COMPLETED.
- Manual target status preflight rejects the entire batch before the first mutation when any selected Order cannot transition to that target.
- Bulk cancellation is not available; cancellation still requires per-Order payment/refund validation.
- Bulk operation is limited to 100 Orders per request.
- Unexpected runtime failures are returned per Order as `UPDATED` / `FAILED` results and surfaced to the operator.
- Search/filter/tab behavior remains intact and `Select visible` follows the current filtered set.
- Localhost runtime invalidates cached reads after `orders.bulkProgress`.
