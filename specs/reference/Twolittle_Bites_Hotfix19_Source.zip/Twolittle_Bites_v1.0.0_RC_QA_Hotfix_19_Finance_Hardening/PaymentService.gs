/**
 * Twolittle.bites OS — Phase 5 Payment Service
 *
 * Multiple SUCCESS payment rows represent DP/partial payments.
 * REFUND rows reduce net paid amount.
 */

function getPaymentMethods_() {
  const configured = getConfig_('PAYMENT_METHODS');
  if (Array.isArray(configured) && configured.length) {
    return configured;
  }

  const businessMethods =
    getBusinessSetting_('payment_methods');

  return Array.isArray(businessMethods)
    ? businessMethods
    : ['CASH', 'BCA', 'MANDIRI', 'QRIS', 'TRANSFER', 'OTHER'];
}

function summarizeInvoicePayments_(invoiceId) {
  const payments = dbFindMany(
    'PAYMENTS',
    'invoice_id',
    invoiceId
  );

  let successful = 0;
  let refunded = 0;
  let lastMethod = '';
  let latestPaymentAt = -Infinity;
  let latestPaymentId = '';

  payments.forEach(function(payment) {
    const status = String(payment.status || '').toUpperCase();
    const amount = Number(payment.amount || 0);

    if (status === 'SUCCESS') {
      successful += amount;
      const parsedAt = new Date(payment.payment_at || '').getTime();
      const at = isFinite(parsedAt) ? parsedAt : 0;
      const id = String(payment.payment_id || '');
      if (
        at > latestPaymentAt ||
        (at === latestPaymentAt && id > latestPaymentId)
      ) {
        latestPaymentAt = at;
        latestPaymentId = id;
        lastMethod = payment.payment_method;
      }
    } else if (status === 'REFUND') {
      refunded += amount;
    }
  });

  const netPaid = Math.max(0, successful - refunded);

  return {
    successfulAmount: successful,
    refundedAmount: refunded,
    netPaidAmount: netPaid,
    lastPaymentMethod: lastMethod,
    payments: payments
  };
}

function deriveInvoicePaymentStatus_(invoice, paymentSummary) {
  const grandTotal = Number(invoice.grand_total || 0);
  const paid = Number(paymentSummary.netPaidAmount || 0);
  const refunded = Number(paymentSummary.refundedAmount || 0);

  if (refunded > 0 && paid === 0) return 'REFUNDED';
  if (paid >= grandTotal && grandTotal >= 0) return 'PAID';
  if (paid > 0) return 'PARTIAL';

  const dueMs = invoice.due_at
    ? new Date(invoice.due_at).getTime()
    : NaN;

  if (
    invoice.sent_at &&
    !isNaN(dueMs) &&
    dueMs < new Date().getTime()
  ) {
    return 'OVERDUE';
  }

  if (invoice.sent_at) return 'WAITING_PAYMENT';
  return 'DRAFT';
}

function deriveOrderPaymentStatus_(invoice, paymentSummary) {
  const grandTotal = Number(invoice.grand_total || 0);
  const paid = Number(paymentSummary.netPaidAmount || 0);
  const refunded = Number(paymentSummary.refundedAmount || 0);

  if (refunded > 0 && paid === 0) return 'REFUNDED';
  if (paid >= grandTotal && grandTotal >= 0) return 'PAID';
  if (paid > 0) return 'PARTIAL';
  return 'UNPAID';
}

function recalculateInvoicePaymentState_(invoiceId, actorUser) {
  const invoice = dbFindById('INVOICES', invoiceId);
  if (!invoice) {
    throw twbError_('NOT_FOUND', 'Invoice not found: ' + invoiceId);
  }

  const summary = summarizeInvoicePayments_(invoiceId);
  const paid = Math.round(summary.netPaidAmount);

  const invoiceStatus = deriveInvoicePaymentStatus_(
    invoice,
    summary
  );

  const remaining = invoiceStatus === 'REFUNDED'
    ? 0
    : Math.max(
        0,
        Math.round(Number(invoice.grand_total || 0) - paid)
      );

  const orderPaymentStatus = deriveOrderPaymentStatus_(
    invoice,
    summary
  );

  const user = actorUser || requireCurrentUser_();

  dbUpdateById(
    'INVOICES',
    invoiceId,
    stampUpdate_(user, {
      paid_amount: paid,
      remaining_amount: remaining,
      status: invoiceStatus,
      last_payment_method: summary.lastPaymentMethod || ''
    }),
    { validate: true, audit: false }
  );

  const order = dbFindById('ORDERS', invoice.order_id);
  if (order) {
    const orderPatch = {
      payment_status: orderPaymentStatus,
      invoice_status: invoiceStatus
    };

    const autoConfirm =
      getConfig_('AUTO_CONFIRM_ON_PAID') !== false;

    if (
      autoConfirm &&
      orderPaymentStatus === 'PAID' &&
      String(order.order_status).toUpperCase() === 'WAITING_PAYMENT'
    ) {
      orderPatch.order_status = 'CONFIRMED';
    }

    dbUpdateById(
      'ORDERS',
      order.order_id,
      stampUpdate_(user, orderPatch),
      { validate: true, audit: false }
    );
  }

  return getInvoiceDetail_(invoiceId);
}

function findPaymentByReference_(referenceNo) {
  const ref = normalizeText_(referenceNo);
  if (!ref) return null;
  return dbFindOne('PAYMENTS', 'reference_no', ref);
}

function buildPaymentTransactionRecord_(
  transactionId,
  payment,
  isRefund,
  actorUser
) {
  const now = nowIso_();
  return {
    transaction_id: transactionId,
    transaction_at: payment.payment_at,
    transaction_type: isRefund ? 'REFUND' : 'INCOME',
    category: isRefund ? 'SALES_REFUND' : 'SALES',
    reference_type: 'PAYMENT',
    reference_id: payment.payment_id,
    amount_in: isRefund ? 0 : Number(payment.amount || 0),
    amount_out: isRefund ? Number(payment.amount || 0) : 0,
    payment_method: payment.payment_method,
    notes:
      (isRefund ? 'Refund' : 'Payment') +
      ' for invoice ' + payment.invoice_id,
    created_at: now,
    created_by: actorUser.user_id,
    updated_at: now,
    updated_by: actorUser.user_id
  };
}

function ensureTransactionForPayment_(payment, actorUser) {
  const existing = dbFindOne(
    'TRANSACTIONS',
    'reference_id',
    payment.payment_id
  );

  if (existing) return stripInternalFields_(existing);

  const transactionId = nextBusinessId('TRANSACTION');
  const isRefund =
    String(payment.status).toUpperCase() === 'REFUND';

  return dbInsertRecord(
    'TRANSACTIONS',
    buildPaymentTransactionRecord_(
      transactionId,
      payment,
      isRefund,
      actorUser
    ),
    { validate: true, audit: false }
  );
}

function recordInvoicePayment(payload) {
  const user = requireAnyPermission_([
    'PAYMENT_WRITE',
    'PAYMENT_CREATE'
  ]);

  payload = payload || {};
  const invoiceId = normalizeText_(payload.invoice_id);
  const amount = requirePositive_(payload.amount, 'amount');
  const method = String(payload.payment_method || '').toUpperCase();
  const allowedMethods = getPaymentMethods_();
  const hasProofUpload = payload.proof_upload != null;

  if (hasProofUpload && normalizeText_(payload.proof_url)) {
    throw twbError_(
      'PAYMENT_PROOF_CONFLICT',
      'Use either a proof file upload or an existing proof URL.'
    );
  }

  if (!invoiceId) {
    throw twbError_('VALIDATION_REQUIRED', 'Invoice is required.');
  }
  if (!method) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Payment method is required.'
    );
  }
  if (
    allowedMethods.length &&
    allowedMethods.indexOf(method) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Unknown payment method: ' + method
    );
  }

  const referenceNo =
    normalizeText_(payload.reference_no) ||
    ('MANUAL-' + Utilities.getUuid());

  const paymentId = nextBusinessId('PAYMENT');
  const transactionId = nextBusinessId('TRANSACTION');
  const now = nowIso_();

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let payment = null;
  let uploadedProof = null;
  let paymentSaved = false;
  let repeatedPayment = null;

  try {
    const invoice = dbFindById('INVOICES', invoiceId);
    if (!invoice) {
      throw twbError_('NOT_FOUND', 'Invoice not found: ' + invoiceId);
    }

    // The reference check shares the same lock as the insert. A retry is
    // idempotent only when its financial details genuinely match.
    const duplicate = findPaymentByReference_(referenceNo);
    if (duplicate) {
      if (
        String(duplicate.invoice_id) !== String(invoiceId) ||
        String(duplicate.status || '').toUpperCase() !== 'SUCCESS' ||
        Number(duplicate.amount || 0) !== Math.round(amount) ||
        String(duplicate.payment_method || '').toUpperCase() !== method ||
        (normalizeText_(payload.proof_url) &&
          normalizeText_(payload.proof_url) !== normalizeText_(duplicate.proof_url))
      ) {
        throw twbError_(
          'PAYMENT_REFERENCE_CONFLICT',
          'This reference already belongs to a different payment. Use a new reference.'
        );
      }
      repeatedPayment = duplicate;
    } else {
    if (
      ['CANCELLED', 'REFUNDED'].indexOf(
        String(invoice.status).toUpperCase()
      ) >= 0
    ) {
      throw twbError_(
        'INVOICE_NOT_PAYABLE',
        'This invoice cannot accept payment.'
      );
    }

    const currentSummary = summarizeInvoicePayments_(invoiceId);
    const remaining = Math.max(
      0,
      Number(invoice.grand_total || 0) -
        Number(currentSummary.netPaidAmount || 0)
    );

    if (amount > remaining) {
      throw twbError_(
        'PAYMENT_OVERPAYMENT',
        'Payment amount exceeds remaining invoice balance.',
        {
          remainingAmount: remaining,
          attemptedAmount: amount
        }
      );
    }

    const paymentAt = normalizeText_(payload.payment_at) || now;
    if (hasProofUpload) {
      uploadedProof = paymentProofCreate_(
        payload.proof_upload,
        invoice,
        paymentId,
        paymentAt
      );
    }

    payment = {
      payment_id: paymentId,
      invoice_id: invoiceId,
      order_id: invoice.order_id,
      payment_at: paymentAt,
      amount: Math.round(amount),
      payment_method: method,
      reference_no: referenceNo,
      status: 'SUCCESS',
      proof_url: uploadedProof
        ? uploadedProof.url
        : normalizeText_(payload.proof_url),
      notes: normalizeText_(payload.notes),
      created_at: now,
      created_by: user.user_id,
      updated_at: now,
      updated_by: user.user_id
    };

    dbInsertRecord(
      'PAYMENTS',
      payment,
      { validate: true, audit: false }
    );
    paymentSaved = true;

    dbInsertRecord(
      'TRANSACTIONS',
      buildPaymentTransactionRecord_(
        transactionId,
        payment,
        false,
        user
      ),
      { validate: true, audit: false }
    );

    recalculateInvoicePaymentState_(
      invoiceId,
      user
    );
    }
  } catch (e) {
    // Don't leave an orphan Drive file when the payment row was not saved.
    if (!paymentSaved) paymentProofDiscardUnsaved_(uploadedProof);
    throw e;
  } finally {
    lock.releaseLock();
  }

  if (repeatedPayment) {
    // These may allocate IDs and must run after the script lock is released.
    ensureTransactionForPayment_(repeatedPayment, user);
    recalculateInvoicePaymentState_(invoiceId, user);
    if (typeof syncInvoicePdfArchiveSafely_ === 'function') {
      syncInvoicePdfArchiveSafely_(invoiceId, 'PAYMENT_RECALCULATED');
    }
    const detail = getInvoiceDetail_(invoiceId);
    detail.already_recorded = true;
    return detail;
  }

  writeAuditLog_(
    'CREATE',
    'PAYMENTS',
    paymentId,
    null,
    payment,
    'Invoice payment recorded.'
  );

  if (
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    syncInvoicePdfArchiveSafely_(
      invoiceId,
      'PAYMENT_RECORDED'
    );
  }

  return getInvoiceDetail_(invoiceId);
}

function refundInvoicePayment(payload) {
  const user = requirePermission_('PAYMENT_WRITE');
  payload = payload || {};

  const invoiceId = normalizeText_(payload.invoice_id);
  const amount = requirePositive_(payload.amount, 'amount');
  const reason = normalizeText_(payload.reason);

  if (!reason) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Refund reason is required.'
    );
  }

  const paymentId = nextBusinessId('PAYMENT');
  const transactionId = nextBusinessId('TRANSACTION');
  const now = nowIso_();
  const referenceNo = normalizeText_(payload.reference_no) ||
    ('REFUND-' + Utilities.getUuid());

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let refund = null;
  let repeatedRefund = null;

  try {
    const invoice = dbFindById('INVOICES', invoiceId);
    if (!invoice) {
      throw twbError_('NOT_FOUND', 'Invoice not found: ' + invoiceId);
    }

    const duplicate = findPaymentByReference_(referenceNo);
    const method = String(
      payload.payment_method ||
      (duplicate && String(duplicate.status || '').toUpperCase() === 'REFUND'
        ? duplicate.payment_method
        : '') ||
      invoice.last_payment_method ||
      'OTHER'
    ).toUpperCase();

    if (duplicate) {
      if (
        String(duplicate.invoice_id) !== String(invoiceId) ||
        String(duplicate.status || '').toUpperCase() !== 'REFUND' ||
        Number(duplicate.amount || 0) !== Math.round(amount) ||
        String(duplicate.payment_method || '').toUpperCase() !== method ||
        normalizeText_(duplicate.notes) !== reason
      ) {
        throw twbError_(
          'REFUND_REFERENCE_CONFLICT',
          'This reference already belongs to a different payment/refund.'
        );
      }
      repeatedRefund = duplicate;
    } else {
      // The available paid balance MUST be evaluated under the insert lock.
      const summary = summarizeInvoicePayments_(invoiceId);
      if (amount > Number(summary.netPaidAmount || 0)) {
        throw twbError_(
          'REFUND_EXCEEDS_PAID',
          'Refund amount exceeds the current net paid amount.'
        );
      }

      refund = {
        payment_id: paymentId,
        invoice_id: invoiceId,
        order_id: invoice.order_id,
        payment_at: normalizeText_(payload.payment_at) || now,
        amount: Math.round(amount),
        payment_method: method,
        reference_no: referenceNo,
        status: 'REFUND',
        proof_url: normalizeText_(payload.proof_url),
        notes: reason,
        created_at: now,
        created_by: user.user_id,
        updated_at: now,
        updated_by: user.user_id
      };

      dbInsertRecord(
        'PAYMENTS',
        refund,
        { validate: true, audit: false }
      );

      dbInsertRecord(
        'TRANSACTIONS',
        buildPaymentTransactionRecord_(
          transactionId, refund, true, user
        ),
        { validate: true, audit: false }
      );
      recalculateInvoicePaymentState_(invoiceId, user);
    }
  } finally {
    lock.releaseLock();
  }

  if (repeatedRefund) {
    ensureTransactionForPayment_(repeatedRefund, user);
    recalculateInvoicePaymentState_(invoiceId, user);
    if (typeof syncInvoicePdfArchiveSafely_ === 'function') {
      syncInvoicePdfArchiveSafely_(invoiceId, 'PAYMENT_REFUND_RECALCULATED');
    }
    const detail = getInvoiceDetail_(invoiceId);
    detail.already_recorded = true;
    return detail;
  }

  writeAuditLog_(
    'CREATE',
    'PAYMENTS',
    paymentId,
    null,
    refund,
    'Refund recorded: ' + reason
  );

  if (
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    syncInvoicePdfArchiveSafely_(
      invoiceId,
      'PAYMENT_REFUND'
    );
  }

  return getInvoiceDetail_(invoiceId);
}
