# QA_HOTFIX_17_BULK_ORDER_PROGRESS.md

# QA Hotfix 17 — Bulk Order Progress

## Purpose

Update operational progress for multiple Orders from the Orders page without opening each Order one by one.

## UI

Each eligible Order row now has a checkbox. The table header contains `Select all visible Orders`.

After at least one Order is selected, a Bulk Progress bar appears with:

```text
N selected   Clear
Bulk Progress [Advance Next Step ▼] [Apply Progress]
```

Available actions:

```text
Advance Next Step
Move to CONFIRMED
Move to SCHEDULED
Move to IN_PRODUCTION
Move to READY
Move to ON_DELIVERY
Move to COMPLETED
```

Bulk cancellation is intentionally excluded.

## Advance Next Step mapping

```text
DRAFT           → WAITING_PAYMENT
WAITING_PAYMENT → CONFIRMED
CONFIRMED       → SCHEDULED
SCHEDULED       → IN_PRODUCTION
IN_PRODUCTION   → READY
READY + DELIVERY→ ON_DELIVERY
READY + other   → COMPLETED
ON_DELIVERY     → COMPLETED
```

`COMPLETED` and `CANCELLED` are terminal and cannot be selected.

## Safety

The server remains authoritative.

For manual TARGET mode the service loads every selected Order and runs the existing `validateOrderTransition_()` for all rows before applying the first mutation. If one Order cannot make the requested transition, the request is rejected before status mutations start.

For NEXT mode each Order receives its own next valid target based on current status and fulfillment type.

Maximum batch size: 100 Orders.

Unexpected runtime errors after preflight are returned per Order as `UPDATED` / `FAILED`. This is important because Order status changes may trigger existing downstream side effects such as customer metric refresh, COGS transaction generation, or preorder capacity sync.

## Permissions

Requires existing:

```text
ORDER_WRITE
```

No new role or permission is introduced.

## Localhost

`orders.bulkProgress` is added to the localhost mutation action set so IndexedDB read caches are invalidated after a successful bulk mutation.

## Apply from Hotfix 16

Replace:

```text
OrderService.gs
ApiGateway.gs
PageOrders.html
JsOrders.html
JsApiClient.html
StylesComponents.html
StylesResponsive.html
Phase16HealthCheck.gs
Phase16SmokeTest.gs
PRODUCTION_ACCEPTANCE_TEST.md
README.md
```

Add:

```text
QA_HOTFIX_17_BULK_ORDER_PROGRESS.md
QA_HOTFIX_17_STATIC_QA.md
qa_hotfix_17_manifest.json
```

No Sheet schema migration.
No data rewrite.

## Runtime QA

Run:

```javascript
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
```

Expected new checks:

```text
QA_HOTFIX_17_BULK_ORDER_PROGRESS = true
QA_HOTFIX_17_BULK_PROGRESS_UI = true
```

Manual workflow test:

1. Filter Orders so 2–3 non-terminal Orders are visible.
2. Use Select Visible.
3. Choose Advance Next Step.
4. Apply and confirm.
5. Verify each row moved exactly one valid step.
6. Mix Orders from incompatible statuses and choose a manual target that is invalid for one row; confirm the whole request is rejected before any row changes.
7. Verify Completed/Cancelled rows are not selectable.
