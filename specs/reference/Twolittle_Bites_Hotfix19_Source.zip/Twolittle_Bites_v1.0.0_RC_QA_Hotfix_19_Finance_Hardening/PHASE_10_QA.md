# PHASE_10_QA.md

Static QA:

- Server `.gs` syntax: PASS
- Client `Js*.html` syntax: PASS
- HTML include references: PASS
- Existing finance schema compatibility: PASS
- COGS completion hook: PASS
- RPC client-safe bridge retained: PASS
- Previous validation cleanup: PASS
- Schema migration required: NO
- App Version: 0.10.0
- Schema Version: 1.0.0

Finance safeguards:
- COMPLETED-order revenue recognition
- tax excluded from operating revenue
- delivery revenue shown separately
- Order-level discount allocated proportionally to Product revenue
- COGS snapshotted per Order Item on completion
- historical COGS fallback explicitly marked estimate
- COGS excluded from cash movement
- Expense write creates matching cash-out Transaction
- Expense VOID creates reversal, not delete
- no purchase receipt treated as operating expense
- no silent historical-cost reconstruction
