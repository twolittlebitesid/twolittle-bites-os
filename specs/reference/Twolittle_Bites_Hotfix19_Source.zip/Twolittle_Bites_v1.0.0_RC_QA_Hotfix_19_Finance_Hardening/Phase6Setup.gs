/**
 * Twolittle.bites OS — Phase 6 upgrade.
 * Existing 33-sheet schema remains unchanged.
 */
function upgradeToPhase6() {
  const user = requireRole_([TWB_ROLES.OWNER]);

  const schema = validateDatabaseSchema();
  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy. Resolve schema issues first.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'PRODUCTION_ELIGIBLE_ORDER_STATUSES',
    ['CONFIRMED', 'SCHEDULED'],
    'JSON',
    'Order statuses eligible to enter a production plan.',
    user.user_id
  );

  setConfig_(
    'PRODUCTION_PLAN_SOURCE_MODE',
    'ORDER_SET',
    'STRING',
    'Production plans snapshot exact Order IDs to prevent double planning.',
    user.user_id
  );

  return runPhase6HealthCheck();
}
