# PHASE_5_IMPLEMENTATION.md
# Twolittle.bites OS — Invoice + Payment + WhatsApp

**Phase:** 5  
**App Version:** 0.5.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

---

## Activated

### Invoice Engine
- Auto invoice for new Phase 5 Orders
- Manual Generate Invoice for older orders
- Unique invoice number
- Public token
- Public invoice URL
- Due time
- Invoice status
- Paid / remaining balance
- Mark Sent
- Cancel unpaid invoice

### Public Invoice
Web App route:

```text
?invoice=<public_token>
```

The public page contains:
- invoice number
- customer
- order item snapshots
- totals
- fulfillment information
- invoice status
- paid amount
- remaining amount

The page reads the current invoice state, so partial payment / Paid status is reflected on refresh.

### WhatsApp
MVP remains a deep-link:

```text
wa.me/<customer>?text=<invoice message>
```

It does **not** auto-send WhatsApp messages.

The message includes:
- customer name
- invoice number
- total
- remaining balance
- due time
- public invoice link

The user still presses **Send** manually in WhatsApp.

### Payment Engine
Supports multiple payment events:

```text
Invoice Rp100,000

Payment 1  Rp30,000
→ PARTIAL
→ remaining Rp70,000

Payment 2  Rp70,000
→ PAID
→ remaining Rp0
```

When fully paid:
- Invoice → PAID
- Order payment_status → PAID
- WAITING_PAYMENT Order → CONFIRMED automatically

### Refund
FINANCE / OWNER can record refunds.

A refund creates:
- PAYMENTS row with `REFUND`
- TRANSACTIONS amount-out

A full refund changes:
- Invoice → REFUNDED
- Order payment status → REFUNDED

Order operational status is not automatically cancelled.

### Finance Transactions
SUCCESS payment:
```text
transaction_type = INCOME
category = SALES
amount_in = payment amount
```

REFUND:
```text
transaction_type = REFUND
category = SALES_REFUND
amount_out = refund amount
```

---

## Source-of-truth rules

Do not manually edit:
```text
INVOICES.paid_amount
INVOICES.remaining_amount
ORDERS.payment_status
```

They are derived from Payment events.

Order item pricing remains snapshotted in `ORDER_ITEMS`.

---

## Install from Phase 4

Use:

```text
Twolittle_Bites_Phase_5_Delta.zip
```

### Replace

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
WebApp.gs
OrderService.gs
Index.html
JsApp.html
JsOrders.html
PageFinance.html
StylesComponents.html
StylesResponsive.html
```

### Add

```text
InvoiceService.gs
PaymentService.gs
WhatsAppService.gs
FinanceService.gs
Phase5Setup.gs
Phase5HealthCheck.gs
Phase5SmokeTest.gs
JsFinance.html
PublicInvoice.html
PublicInvoiceNotFound.html
```

Do not add:

```text
phase5_manifest.json
```

to Apps Script.

---

## One-time upgrade

Run:

```javascript
upgradeToPhase5()
```

It does not create or clear business rows.

It updates:
```text
APP_VERSION = 0.5.0
SCHEMA_VERSION = 1.0.0
AUTO_INVOICE_ON_ORDER = TRUE
AUTO_CONFIRM_ON_PAID = TRUE
WHATSAPP_INVOICE_MODE = DEEPLINK
```

Existing Phase 4 orders are **not** automatically invoiced during upgrade.

For existing orders:
- generate from Order Detail individually; or
- explicitly run `backfillMissingInvoicesPhase5()` if you want invoices for every non-cancelled historical order.

---

## Verification

```javascript
runPhase5HealthCheck()
runPhase5SmokeTest()
```

Both should return:

```text
ok: true
phase: 5
appVersion: 0.5.0
schemaVersion: 1.0.0
```

---

## Web App deployment

After the checks pass, update the Web App deployment.

The invoice link uses the currently deployed Web App URL.

Important:
A public invoice URL can only be opened by a customer if the Apps Script deployment access setting permits that customer to access the Web App. Apps Script deployment access rules cannot be bypassed by application code.

---

## Recommended live browser test

1. Update deployment.
2. Create a Customer.
3. Create a new Order.
4. Open Order Detail.
5. Confirm Invoice exists automatically.
6. Click Invoice.
7. Open Public Invoice.
8. Click WhatsApp.
9. Press Send manually in WhatsApp.
10. Mark Invoice Sent.
11. Record partial payment.
12. Verify PARTIAL + remaining balance.
13. Record final payment.
14. Verify:
   - Invoice PAID
   - Order payment status PAID
   - Order status CONFIRMED if it was WAITING_PAYMENT
15. Create another test order and test refund.

No automated health/smoke test inserts customer, invoice, payment, or transaction business rows.


---

## Cancellation consistency

After Phase 5 is installed:

```text
UNPAID order
→ may be cancelled
→ unpaid invoice is also cancelled

PARTIAL / PAID order
→ cannot be cancelled directly
→ refund is required first
```

A fully refunded order may then be cancelled operationally.

Health and smoke checks call Finance bootstrap in read-only mode, so automated verification does not change overdue statuses.
