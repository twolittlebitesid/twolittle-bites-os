/**
 * Twolittle.bites OS — Phase 16 API Gateway
 */

/**
 * Convert Apps Script service results into values that are always safe
 * to cross the google.script.run bridge.
 *
 * Google Sheets can return Date objects. google.script.run only accepts
 * JSON-like values. JSON serialization converts Date -> ISO string and
 * removes unsupported/undefined values.
 */
function clientSafeResponse_(value) {
  if (value === null || value === undefined) {
    return value === undefined ? null : value;
  }

  try {
    return JSON.parse(
      JSON.stringify(
        value,
        function(key, current) {
          if (current instanceof Date) {
            return current.toISOString();
          }

          if (typeof current === 'undefined') {
            return null;
          }

          if (
            typeof current === 'number' &&
            !isFinite(current)
          ) {
            return null;
          }

          return current;
        }
      )
    );
  } catch (err) {
    throw twbError_(
      'RPC_SERIALIZATION_FAILED',
      'Server response could not be serialized for the browser.',
      {
        message:
          err && err.message
            ? err.message
            : String(err)
      }
    );
  }
}

function apiCall(action, payload) {
  const requestId = 'RPC-' + Utilities.getUuid();
  const started = new Date().getTime();

  try {
    const data = dispatchApiAction_(
      String(action || ''),
      payload || {}
    );

    return clientSafeResponse_({
      ok: true,
      data: data,
      meta: {
        requestId: requestId,
        durationMs: new Date().getTime() - started,
        appVersion: TWB_APP.APP_VERSION
      }
    });
  } catch (err) {
    const code =
      err && err.code
        ? err.code
        : 'INTERNAL_ERROR';

    const message =
      err && err.message
        ? err.message
        : 'Unexpected server error.';

    console.error(JSON.stringify({
      requestId: requestId,
      action: action,
      code: code,
      message: message,
      stack:
        err && err.stack
          ? err.stack
          : ''
    }));

    try {
      if (
        typeof recordSystemError_ ===
        'function'
      ) {
        recordSystemError_({
          requestId: requestId,
          action: action,
          code: code,
          message: message,
          stack:
            err && err.stack
              ? err.stack
              : ''
        });
      }
    } catch (ignoreLogError) {}

    return clientSafeResponse_({
      ok: false,
      error: {
        code: code,
        message: message,
        details:
          err && err.details
            ? err.details
            : null
      },
      meta: {
        requestId: requestId,
        durationMs: new Date().getTime() - started,
        appVersion: TWB_APP.APP_VERSION
      }
    });
  }
}

function dispatchApiAction_(action, payload) {
  switch (action) {
    case 'app.bootstrap':
      return getAppBootstrap_();

    case 'app.ping':
      return getAppPing_();

    case 'images.resolve':
      return resolveProductImagePreview(
        payload
      );

    case 'products.bootstrap':
      return productModuleBootstrap();

    case 'products.create':
      return createProduct(payload);

    case 'products.update':
      return updateProduct(
        payload.product_id,
        payload
      );

    case 'variants.create':
      return createProductVariant(payload);

    case 'variants.update':
      return updateProductVariant(
        payload.variant_id,
        payload
      );

    case 'materials.create':
      return createMaterial(
        payload.item_type,
        payload
      );

    case 'materials.update':
      return updateMaterial(
        payload.item_type,
        payload.item_id,
        payload
      );

    case 'units.createConversion':
      return createUnitConversion(payload);

    case 'recipes.create':
      return createRecipe(payload);

    case 'recipes.detail':
      return getRecipeDetail(payload.recipe_id);

    case 'recipes.activate':
      return activateRecipe(payload.recipe_id);

    case 'recipes.scale':
      return scaleRecipe(
        payload.recipe_id,
        payload.target_quantity,
        payload.scaling_mode || ''
      );

    case 'customers.bootstrap':
      return customerModuleBootstrap();

    case 'customers.create':
      return createCustomer(payload);

    case 'customers.update':
      return updateCustomer(
        payload.customer_id,
        payload
      );

    case 'customers.profile':
      return getCustomerProfile(
        payload.customer_id
      );

    case 'customers.rebuildMetrics':
      return rebuildCustomerMetricsPhase11();

    case 'marketing.bootstrap':
      return marketingModuleBootstrap();

    case 'marketing.campaign.create':
      return createMarketingCampaign(payload);

    case 'marketing.campaign.update':
      return updateMarketingCampaign(
        payload.marketing_campaign_id,
        payload
      );

    case 'marketing.campaign.status':
      return updateMarketingCampaignStatus(
        payload.marketing_campaign_id,
        payload.status
      );

    case 'marketing.content.create':
      return createMarketingContent(payload);

    case 'marketing.content.update':
      return updateMarketingContent(
        payload.content_id,
        payload
      );

    case 'marketing.attribution.set':
      return setMarketingAttribution(payload);

    case 'marketing.attribution.clear':
      return clearMarketingAttribution(
        payload.order_id
      );

    case 'marketing.spend.create':
      return createMarketingSpend(payload);

    case 'marketing.rebuild':
      return rebuildMarketingAggregatesPhase12();

    case 'executive.bootstrap':
      return executiveModuleBootstrap(payload);

    case 'business.bootstrap':
      return businessModuleBootstrap(payload);

    case 'business.target.create':
      return createBusinessTarget(payload);

    case 'business.target.status':
      return updateBusinessTargetStatus(
        payload.target_id,
        payload.status
      );

    case 'reports.bootstrap':
      return reportModuleBootstrap(payload);

    case 'reports.cache.rebuild':
      return rebuildReportMetricCaches(payload);

    case 'reports.target.create':
      return createBusinessTargetPhase13(payload);

    case 'reports.target.status':
      return updateBusinessTargetStatusPhase13(
        payload.target_id,
        payload.status
      );

    case 'reports.export':
      return reportExportCsv(payload);

    case 'settings.bootstrap':
      return settingsModuleBootstrap();

    case 'settings.business.update':
      return updateBusinessSettingsPhase14(payload);

    case 'settings.commerce.update':
      return updateCommerceSettingsPhase14(payload);

    case 'settings.invoice.update':
      return updateInvoiceSettingsPhase14(payload);

    case 'settings.printing.update':
      return updatePrintingSettingsPhase14(payload);

    case 'receipts.url':
      return getReceiptUrl(
        payload.invoice_id,
        payload.auto_print === true
      );

    case 'receipts.kitchenData':
      return getInternalKitchenTicketDataByInvoiceId_(
        payload.invoice_id,
        {
          autoPrint: false
        }
      );

    case 'settings.automation.update':
      return updateAutomationSettingsPhase14(payload);

    case 'settings.user.create':
      return createUserPhase14(payload);

    case 'settings.user.update':
      return updateUserPhase14(
        payload.user_id,
        payload
      );

    case 'system.diagnostics':
      return systemDiagnosticsBootstrap();

    case 'system.regression':
      return systemRegressionSuite_();

    case 'system.errors.clear':
      return clearSystemErrorsPhase15();

    case 'system.backup.create':
      return createSystemBackupPhase15();

    case 'system.backup.recoveryCopy':
      return createRecoveryCopyFromBackupPhase15(
        payload.backup_file_id
      );

    case 'system.automation.configure':
      return configurePhase15MaintenanceAutomation();

    case 'system.automation.remove':
      return removePhase15MaintenanceAutomation();

    case 'system.maintenance.runNow':
      return runPhase15MaintenanceNow();

    case 'release.bootstrap':
      return releaseModuleBootstrap();

    case 'release.preflight':
      return runPhase16ReleasePreflight();

    case 'release.backup':
      return createPhase16ReleaseBackup();

    case 'release.productionReady':
      return markPhase16ProductionReady();

    case 'release.markReleased':
      return markPhase16Released(payload);

    case 'release.rollbackRequired':
      return markPhase16RollbackRequired(
        payload.reason
      );

    case 'release.rollbackClear':
      return clearPhase16RollbackFlag();

    case 'orders.bootstrap':
      return orderModuleBootstrap();

    case 'orders.create':
      return createOrder(payload);

    case 'orders.detail':
      return getOrderDetail(payload.order_id);

    case 'orders.status':
      return updateOrderStatus(
        payload.order_id,
        payload.target_status,
        payload.notes || ''
      );

    case 'orders.bulkProgress':
      return bulkProgressOrders(payload);

    case 'orders.cancel':
      return cancelOrder(
        payload.order_id,
        payload.reason
      );

    case 'orders.fulfillment':
      return updateOrderFulfillment(
        payload.order_id,
        payload
      );

    case 'finance.bootstrap':
      return financeModuleBootstrap({
        refreshOverdue:
          payload.refresh_overdue !== false
      });

    case 'invoices.createForOrder':
      return createInvoiceForOrder(
        payload.order_id
      );

    case 'invoices.detail':
      return getInvoiceDetail(
        payload.invoice_id
      );

    case 'invoices.markSent':
      return markInvoiceSent(
        payload.invoice_id
      );

    case 'invoices.cancel':
      return cancelInvoice(
        payload.invoice_id,
        payload.reason
      );

    case 'invoices.whatsapp':
      return getInvoiceWhatsAppLink(
        payload.invoice_id
      );

    case 'invoices.pdf':
      return getInvoicePdfArchive(
        payload.invoice_id
      );

    case 'invoices.pdfRegenerate':
      return regenerateInvoicePdf(
        payload.invoice_id
      );

    case 'payments.record':
      return recordInvoicePayment(payload);

    case 'payments.refund':
      return refundInvoicePayment(payload);

    case 'production.bootstrap':
      return productionModuleBootstrap();

    case 'production.preview':
      return previewProductionPlan(payload);

    case 'production.create':
      return createProductionPlan(payload);

    case 'production.detail':
      return getProductionPlanDetail(
        payload.production_plan_id
      );

    case 'production.refreshStock':
      return refreshProductionRequirementAvailability(
        payload.production_plan_id
      );

    case 'production.status':
      return updateProductionPlanStatus(
        payload.production_plan_id,
        payload.target_status
      );

    case 'inventory.bootstrap':
      return inventoryModuleBootstrap();

    case 'inventory.movement':
      return recordInventoryMovement(payload);

    case 'inventory.adjustCount':
      return adjustInventoryPhysicalCount(payload);

    case 'inventory.postProductionUsage':
      return postProductionPlanUsage(
        payload.production_plan_id
      );

    case 'inventory.rebuild':
      return rebuildInventoryBalancesFromLedger();

    case 'purchasing.bootstrap':
      return purchasingModuleBootstrap();

    case 'suppliers.create':
      return createSupplier(payload);

    case 'suppliers.update':
      return updateSupplier(
        payload.supplier_id,
        payload
      );

    case 'purchases.create':
      return createPurchase(payload);

    case 'purchases.detail':
      return getPurchaseDetail(
        payload.purchase_id
      );

    case 'purchases.status':
      return updatePurchaseStatus(
        payload.purchase_id,
        payload.target_status,
        payload.notes || ''
      );

    case 'purchases.receive':
      return receivePurchase(payload);

    case 'preorders.bootstrap':
      return preorderModuleBootstrap();

    case 'preorders.create':
      return createPreorderCampaign(payload);

    case 'preorders.update':
      return updatePreorderCampaign(
        payload.preorder_campaign_id,
        payload
      );

    case 'preorders.status':
      return updatePreorderCampaignStatus(
        payload.preorder_campaign_id,
        payload.target_status
      );

    case 'preorders.detail':
      return getPreorderCampaignDetail(
        payload.preorder_campaign_id
      );

    case 'finance.analytics':
      return financeAnalytics(payload);

    case 'expenses.create':
      return createExpense(payload);

    case 'expenses.void':
      return voidExpense(
        payload.expense_id,
        payload.reason
      );

    case 'finance.backfillCogs':
      return backfillCompletedOrderCogsPhase10();

    default:
      throw twbError_(
        'UNKNOWN_API_ACTION',
        'Unknown API action: ' + action
      );
  }
}
