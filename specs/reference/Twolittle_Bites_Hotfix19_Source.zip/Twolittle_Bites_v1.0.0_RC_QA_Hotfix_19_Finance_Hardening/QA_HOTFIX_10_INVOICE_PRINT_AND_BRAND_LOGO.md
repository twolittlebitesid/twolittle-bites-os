# QA_HOTFIX_10_INVOICE_PRINT_AND_BRAND_LOGO.md

# QA Hotfix 10 — Public Invoice Print Layout + Brand Logo

## Reported issue

1. Public invoice preview looked different from the generated/printed PDF.
2. Small invoices could still spill into 2 pages.
3. The public invoice header still rendered the business name as text instead of a logo.
4. Settings did not provide a visible placement for the public brand logo.

## Root cause

The public invoice template relied on modern browser styling that is not rendered consistently by the Apps Script HTML-to-PDF engine.
This caused color blocks, spacing, and layout proportions to diverge between on-screen preview and the PDF output.

The print/PDF view also kept web-only CTA actions, and the layout did not explicitly optimize compact invoices for single-page output.

## Fix

### Public invoice template
- Reworked `PublicInvoice.html` with more PDF-safe CSS.
- Replaced variable-heavy styling with explicit color values.
- Added print-safe A4 page settings.
- Added compact invoice layout behavior for short orders.
- Hid web CTA buttons in print/PDF mode to preserve space.

### Brand logo support
- Added `brand_logo_url` as a Business setting.
- Public invoice now renders the logo when `brand_logo_url` is filled.
- Falls back to text business name when no logo is configured.

### Settings UI
- Added **Brand Logo URL** field in Business Settings.
- Added live preview block so the logo placement is visible inside the web app.
- Accepts either:
  - direct `http(s)` image URLs, or
  - `data:image/...;base64,...` strings (large values supported).

## Files changed

### Replace
- `Constants.gs`
- `SettingsService.gs`
- `JsSettings.html`
- `PageSettings.html`
- `StylesComponents.html`
- `InvoiceService.gs`
- `InvoicePdfService.gs`
- `PublicInvoice.html`

## Expected result

- Preview and generated PDF match much more closely.
- Small invoices fit on 1 page.
- Invoice header shows the business logo when configured.
- Logo placement is visible in the Settings web UI.

## Setup after deploy

Open **Settings → Business** and fill **Brand Logo URL**.

If you already have a public image URL, paste it directly.
If not, you can also paste a `data:image` base64 string.
