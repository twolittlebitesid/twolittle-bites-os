# PHASE_8_QA.md

Static QA:

- Server `.gs` syntax: PASS
- Client `Js*.html` syntax: PASS
- Index includes: PASS
- Required schema sheets: PASS
- Phase 7.0.2 RPC bridge retained: PASS
- Previous validation cleanup: PASS
- Schema migration required: NO
- App Version: 0.8.0
- Schema Version: 1.0.0

Safeguards:
- current stock + incoming purchase deducted from recommendation
- purchase material duplicate guard
- purchase status machine
- receipt cannot exceed remaining quantity
- receipt token idempotency
- partial receiving supported
- PURCHASE_RECEIPT inventory movement
- latest material cost update
- weighted-average material cost update
- base Product COGS refresh
- no supplier payment transaction mutation

Runtime:
```javascript
upgradeToPhase8()
runPhase8HealthCheck()
runPhase8SmokeTest()
```
