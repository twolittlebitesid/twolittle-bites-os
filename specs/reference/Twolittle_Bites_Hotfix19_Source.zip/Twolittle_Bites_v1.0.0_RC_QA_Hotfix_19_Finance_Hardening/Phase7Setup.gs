/**
 * Twolittle.bites OS — Phase 7 upgrade.
 */
function upgradeToPhase7() {
  const user = requireRole_([TWB_ROLES.OWNER]);

  const schema = validateDatabaseSchema();
  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'INVENTORY_SOURCE_OF_TRUTH',
    'INVENTORY_MOVEMENTS',
    'STRING',
    'Inventory balances are derived from stock movements.',
    user.user_id
  );

  setConfig_(
    'PRODUCTION_USAGE_BASIS',
    'PLANNED_REQUIREMENT',
    'STRING',
    'Phase 7 production usage posts planned material requirement.',
    user.user_id
  );

  const inventoryRows =
    ensureInventoryRowsPhase7_();

  const opening =
    ensureOpeningInventoryLedgerPhase7_();

  return {
    upgrade: {
      inventoryRows: inventoryRows,
      openingBalances: opening
    },
    health: runPhase7HealthCheck()
  };
}
