# PHASE_9_IMPLEMENTATION.md
# Twolittle.bites OS — Pre-Order & Capacity Engine

**Phase:** 9  
**App Version:** 0.9.0  
**Schema Version:** 1.0.0  
**Schema Migration:** Not required

## Flow

```text
Pre-Order Campaign
→ start / cutoff / quota
→ New Pre-Order
→ ScriptLock
→ live capacity recheck
→ ORDERS + ORDER_ITEMS
→ campaign booked capacity sync
→ Invoice / Payment
→ Production
```

A Pre-Order is a normal `ORDERS` row with `preorder_campaign_id`.

## Capacity source of truth

Booked capacity is derived from linked non-cancelled Orders, then materialized into `PREORDER_CAMPAIGNS.current_booked` and `remaining_capacity`.

### Quantity mode

For capacity units such as `pcs`, `box`, `tray`, or `jar`:

```text
capacity usage = sum(Order Item quantity)
```

### Order mode

Set:

```text
capacity_unit = ORDER
```

Each linked Order consumes one capacity unit.

## Anti-overselling

The final check runs inside the same Apps Script `ScriptLock` used to write the Order:

```text
read live linked Orders
→ calculate booked
→ validate incoming usage
→ insert Order + Items
→ recalculate capacity
```

This prevents two simultaneous requests from both consuming the last available capacity.

## Campaign status

```text
DRAFT → OPEN
DRAFT → CANCELLED (only with zero booked Orders)

OPEN / ALMOST_FULL / FULL → CLOSED
FULL / CLOSED → COMPLETED
```

Runtime also derives:
- `ALMOST_FULL` at <=20% remaining;
- `FULL` at zero remaining;
- `CLOSED` after cutoff;
- not bookable before `start_at`.

## Capacity release

Cancelled Orders are excluded from booked capacity.

Paid/partial Orders still use the refund-first cancellation guard from Phase 5.

## Fulfillment

Campaign Orders inherit `campaign.fulfillment_date` automatically.

## Orders UI

Pre-Orders live inside Orders:

```text
Orders
├── All Orders
├── Today
├── Upcoming
├── Need Attention
└── Pre-Orders
```

## Install from Phase 8

Replace:

```text
Constants.gs
AppShellService.gs
ApiGateway.gs
OrderService.gs
PageOrders.html
JsOrders.html
StylesComponents.html
StylesResponsive.html
```

Add:

```text
PreorderService.gs
Phase9Setup.gs
Phase9HealthCheck.gs
Phase9SmokeTest.gs
```

## Upgrade

```javascript
upgradeToPhase9()
```

Sets:

```text
APP_VERSION = 0.9.0
SCHEMA_VERSION = 1.0.0
PREORDER_ALMOST_FULL_RATIO = 0.20
PREORDER_CAPACITY_SOURCE = LINKED_NON_CANCELLED_ORDERS
```

## Validate

```javascript
runPhase9HealthCheck()
runPhase9SmokeTest()
```

Both are read-only against business transaction data.

## Browser QA

1. Orders → Pre-Orders.
2. Create Campaign, capacity `10 pcs`.
3. Open Campaign.
4. Create Pre-Order qty 6.
5. Confirm remaining = 4.
6. Create Pre-Order qty 4.
7. Confirm FULL.
8. Attempt qty 1 → blocked.
9. Cancel one unpaid linked Order.
10. Confirm released capacity.
11. Close Campaign.
12. Confirm further booking is blocked.

## Next

**Phase 10 — Finance & Profitability**
