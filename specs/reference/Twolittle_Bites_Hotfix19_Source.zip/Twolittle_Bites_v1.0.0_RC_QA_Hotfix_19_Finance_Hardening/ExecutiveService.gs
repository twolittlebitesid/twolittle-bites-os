/**
 * Twolittle.bites OS — Executive command center.
 * Added as v1.0 pre-release P0 closure because PageExecutive remained a Phase 2 shell.
 */

function executiveModuleBootstrap(payload) {
  var user = requirePermission_('EXECUTIVE_READ');
  var period = normalizeReportPeriod_(payload || {});
  var report = reportModuleBootstrap({
    period_start: period.start,
    period_end: period.end
  });

  var orders = listAllRecords_('ORDERS');
  var customers = listAllRecords_('CUSTOMERS');
  var invoices = listAllRecords_('INVOICES');
  var plans = listAllRecords_('PRODUCTION_PLANS');
  var requirements = listAllRecords_('PRODUCTION_REQUIREMENTS');
  var inventory = listAllRecords_('INVENTORY');
  var purchases = listAllRecords_('PURCHASES');

  var customerMap = {};
  customers.forEach(function(row) {
    customerMap[row.customer_id] = row;
  });

  var today = reportTodayKey_();
  var terminal = { COMPLETED: true, CANCELLED: true };
  var pipeline = {
    draft: 0,
    waitingPayment: 0,
    confirmed: 0,
    scheduled: 0,
    inProduction: 0,
    ready: 0,
    onDelivery: 0,
    dueToday: 0
  };

  orders.forEach(function(order) {
    var status = String(order.order_status || '').toUpperCase();
    if (status === 'DRAFT') pipeline.draft += 1;
    if (status === 'WAITING_PAYMENT') pipeline.waitingPayment += 1;
    if (status === 'CONFIRMED') pipeline.confirmed += 1;
    if (status === 'SCHEDULED') pipeline.scheduled += 1;
    if (status === 'IN_PRODUCTION') pipeline.inProduction += 1;
    if (status === 'READY') pipeline.ready += 1;
    if (status === 'ON_DELIVERY') pipeline.onDelivery += 1;

    if (!terminal[status] && reportDateKey_(order.fulfillment_date) === today) {
      pipeline.dueToday += 1;
    }
  });

  var overdueCount = 0;
  var overdueAmount = 0;
  var nowMs = new Date().getTime();
  invoices.forEach(function(invoice) {
    var status = String(invoice.status || '').toUpperCase();
    var remaining = Number(invoice.remaining_amount || 0);
    var dueMs = invoice.due_at ? new Date(invoice.due_at).getTime() : NaN;
    var isClosed = ['PAID', 'CANCELLED', 'REFUNDED'].indexOf(status) >= 0;
    var isOverdue =
      status === 'OVERDUE' ||
      (!isClosed && remaining > 0 && isFinite(dueMs) && dueMs < nowMs);

    if (isOverdue) {
      overdueCount += 1;
      overdueAmount += remaining;
    }
  });

  var planMap = {};
  plans.forEach(function(plan) {
    planMap[plan.production_plan_id] = plan;
  });

  var activeShortages = 0;
  requirements.forEach(function(req) {
    var plan = planMap[req.production_plan_id];
    if (!plan) return;
    if (String(plan.status || '').toUpperCase() === 'CANCELLED') return;
    if (
      String(req.status || '').toUpperCase() === 'SHORTAGE' ||
      Number(req.shortage_qty_base || 0) > 0
    ) {
      activeShortages += 1;
    }
  });

  var lowStock = 0;
  var outOfStock = 0;
  inventory.forEach(function(row) {
    var current = Number(row.current_stock_base || 0);
    var minimum = Number(row.minimum_stock_base || 0);
    if (current <= 0) outOfStock += 1;
    else if (current < minimum) lowStock += 1;
  });

  var openPurchases = purchases.filter(function(row) {
    return ['RECEIVED', 'CANCELLED'].indexOf(String(row.status || '').toUpperCase()) < 0;
  }).length;

  var activePlans = plans.filter(function(plan) {
    return ['PLANNED', 'IN_PROGRESS'].indexOf(String(plan.status || '').toUpperCase()) >= 0;
  }).length;

  var crm = null;
  try {
    crm = crmIntelligenceBootstrap();
  } catch (ignore) {}

  var canSeeProfit =
    user.role === TWB_ROLES.OWNER ||
    hasPermission_(user, 'PNL_READ');

  var finance = report.finance || {};
  var sanitizedFinance = {
    completedOrders: Number(finance.completedOrders || 0),
    operatingRevenue: Number(finance.operatingRevenue || 0),
    cashIn: Number(finance.cashIn || 0),
    cashOut: Number(finance.cashOut || 0),
    netCash: Number(finance.netCash || 0),
    grossProfit: canSeeProfit ? Number(finance.grossProfit || 0) : null,
    grossMarginPct: canSeeProfit ? Number(finance.grossMarginPct || 0) : null,
    operatingExpenses: canSeeProfit ? Number(finance.operatingExpenses || 0) : null,
    operatingProfit: canSeeProfit ? Number(finance.operatingProfit || 0) : null,
    operatingMarginPct: canSeeProfit ? Number(finance.operatingMarginPct || 0) : null,
    canSeeProfit: canSeeProfit
  };

  var recentOrders = orders
    .slice()
    .sort(function(a, b) {
      return String(b.created_at || '').localeCompare(String(a.created_at || ''));
    })
    .slice(0, 8)
    .map(function(order) {
      var customer = customerMap[order.customer_id] || {};
      return {
        order_id: order.order_id,
        order_date: order.order_date,
        fulfillment_date: order.fulfillment_date,
        customer_name: customer.name || order.customer_id,
        order_status: order.order_status,
        payment_status: order.payment_status,
        grand_total: Number(order.grand_total || 0),
        source_channel: order.source_channel || ''
      };
    });

  var attention = [];
  if (overdueCount) attention.push({ level: 'critical', label: 'Overdue invoices', value: overdueCount, detail: overdueAmount });
  if (outOfStock) attention.push({ level: 'critical', label: 'Out of stock materials', value: outOfStock, detail: 0 });
  if (activeShortages) attention.push({ level: 'critical', label: 'Production shortage lines', value: activeShortages, detail: 0 });
  if (lowStock) attention.push({ level: 'attention', label: 'Low stock materials', value: lowStock, detail: 0 });
  if (pipeline.waitingPayment) attention.push({ level: 'attention', label: 'Orders waiting payment', value: pipeline.waitingPayment, detail: 0 });
  if (openPurchases) attention.push({ level: 'attention', label: 'Open purchases', value: openPurchases, detail: 0 });

  var executiveTargets =
    (report.targets || [])
      .filter(function(target) {
        if (canSeeProfit) {
          return true;
        }

        return [
          'OPERATING_PROFIT',
          'GROSS_MARGIN_PCT'
        ].indexOf(
          String(
            target.metric_key || ''
          ).toUpperCase()
        ) < 0;
      })
      .slice(0, 8);

  return {
    period: period,
    finance: sanitizedFinance,
    operational: report.operational || null,
    marketing: report.marketing || null,
    trend: report.daily || [],
    customers: crm ? crm.summary : null,
    targets: executiveTargets,
    pipeline: pipeline,
    attention: attention,
    health: {
      overdueInvoices: overdueCount,
      overdueAmount: Math.round(overdueAmount),
      activeProductionPlans: activePlans,
      activeShortageLines: activeShortages,
      lowStockMaterials: lowStock,
      outOfStockMaterials: outOfStock,
      openPurchases: openPurchases
    },
    recentOrders: recentOrders,
    permissions: {
      canSeeProfit: canSeeProfit,
      canCreateOrder: hasPermission_(user, 'ORDER_WRITE'),
      canOpenReports: hasPermission_(user, 'REPORT_READ')
    }
  };
}
