# QA_HOTFIX_13_STATIC_QA.md

Full-package static QA:

- Server `.gs` syntax: PASS (60 files)
- Client `Js*.html` syntax: PASS (18 files)
- Index include references: PASS
- Duplicate DOM IDs inside Page templates: PASS
- 12-page top Search/Filter slot contract: PASS
- Route cache / no-menu-reload contract: PASS
- Lightweight motion + reduced-motion contract: PASS
- Bottom `Operating System Active` removed: PASS
- Bottom Invoice shortcut present: PASS
- Order Payment `+` shortcut: PASS
- Finance Invoice Payment `+` shortcut: PASS
- Payment shortcut permission fields: PASS
- Google Drive resource-key browser fallback: PASS
- Server-assisted Google Drive image preview fallback: PASS
- Product preview debounce: PASS
- Product/New Order forced `no-referrer` removed: PASS
- Settings Business logo uses resilient loader + forced preview retry: PASS
- Public Invoice/PDF Drive logo server resolution: PASS
- Executive profit-sensitive target filtering: PASS
- Phase 16 Hotfix 13 health guard: PASS
- Phase 16 Hotfix 13 smoke guard: PASS
- Canonical sheet count unchanged: PASS (33/33)
- Sheet schema migration required: NO
- Data rewrite required: NO
- App Version: 1.0.0
- Schema Version: 1.0.0

Runtime/manual boundary:

Static QA cannot prove that the Google account executing Apps Script can read the exact Drive image supplied by the user. Run:

```javascript
runQAHotfix13ImagePreviewSmoke('PASTE_THE_ACTUAL_DRIVE_IMAGE_LINK')
```

Then run:

```javascript
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
```
