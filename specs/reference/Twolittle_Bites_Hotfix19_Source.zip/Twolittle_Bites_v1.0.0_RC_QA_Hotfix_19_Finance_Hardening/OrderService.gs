/**
 * Twolittle.bites OS — Phase 9 Order + Pre-Order Engine
 *
 * Scope:
 * - order/customer bootstrap
 * - pricing snapshots
 * - create order + items
 * - status transitions
 * - cancellation
 * - order details
 *
 * Invoice / Payment posting is intentionally deferred to the next phase.
 */

const TWB_ORDER_TRANSITIONS = Object.freeze({
  DRAFT: ['WAITING_PAYMENT', 'CONFIRMED', 'CANCELLED'],
  WAITING_PAYMENT: ['CONFIRMED', 'CANCELLED'],
  CONFIRMED: ['SCHEDULED', 'IN_PRODUCTION', 'CANCELLED'],
  SCHEDULED: ['IN_PRODUCTION', 'CANCELLED'],
  IN_PRODUCTION: ['READY', 'CANCELLED'],
  READY: ['ON_DELIVERY', 'COMPLETED', 'CANCELLED'],
  ON_DELIVERY: ['COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: []
});

function orderModuleBootstrap() {
  requirePermission_('ORDER_READ');

  const customers = listAllRecords_('CUSTOMERS').map(stripInternalFields_);
  const products = listAllRecords_('PRODUCTS').map(stripInternalFields_);
  const variants = listAllRecords_('PRODUCT_VARIANTS').map(stripInternalFields_);
  const orders = listAllRecords_('ORDERS').map(stripInternalFields_);
  const orderItems = listAllRecords_('ORDER_ITEMS').map(stripInternalFields_);

  const customerMap = {};
  customers.forEach(function(row) {
    customerMap[row.customer_id] = row;
  });

  const itemGroups = {};
  orderItems.forEach(function(item) {
    if (!itemGroups[item.order_id]) itemGroups[item.order_id] = [];
    itemGroups[item.order_id].push(item);
  });

  const orderRows = orders.map(function(order) {
    const customer = customerMap[order.customer_id] || null;
    const items = itemGroups[order.order_id] || [];

    return Object.assign({}, order, {
      customer_name: customer ? customer.name : order.customer_id,
      customer_whatsapp: customer ? customer.whatsapp : '',
      item_count: items.length,
      total_quantity: items.reduce(function(sum, item) {
        return sum + Number(item.quantity || 0);
      }, 0),
      item_summary: items
        .slice(0, 3)
        .map(function(item) {
          return item.product_name_snapshot + ' × ' + Number(item.quantity || 0);
        })
        .join(', ')
    });
  });

  orderRows.sort(function(a, b) {
    return String(b.created_at || '').localeCompare(String(a.created_at || ''));
  });

  const sourceChannels = getConfig_('SALES_CHANNELS') || [];
  const fulfillmentTypes = getConfig_('FULFILLMENT_TYPES') || [];

  return {
    orders: orderRows,
    customers: customers.filter(function(c) {
      return String(c.status).toUpperCase() === 'ACTIVE';
    }),
    products: products.filter(function(p) {
      return ['ACTIVE', 'SEASONAL'].indexOf(
        String(p.status).toUpperCase()
      ) >= 0;
    }),
    variants: variants.filter(function(v) {
      return String(v.status).toUpperCase() === 'ACTIVE';
    }),
    sourceChannels: sourceChannels,
    fulfillmentTypes: fulfillmentTypes,
    orderStatuses: Object.keys(TWB_ORDER_TRANSITIONS),
    printing:
      typeof receiptPrintingSettings_ === 'function'
        ? receiptPrintingSettings_()
        : null,
    permissions: {
      orderWrite: hasPermission_(requireCurrentUser_(), 'ORDER_WRITE'),
      customerWrite: hasPermission_(requireCurrentUser_(), 'CUSTOMER_WRITE'),
      preorderRead: hasPermission_(requireCurrentUser_(), 'PREORDER_READ'),
      preorderWrite: hasPermission_(requireCurrentUser_(), 'PREORDER_WRITE'),
      invoiceWrite: hasPermission_(requireCurrentUser_(), 'INVOICE_WRITE'),
      paymentCreate: hasPermission_(requireCurrentUser_(), 'PAYMENT_CREATE')
    }
  };
}

function getOrderDetail(orderId) {
  requirePermission_('ORDER_READ');
  return getOrderDetail_(orderId);
}

function getOrderDetail_(orderId) {
  const order = dbFindById('ORDERS', orderId);
  if (!order) {
    throw twbError_('NOT_FOUND', 'Order not found: ' + orderId);
  }

  const customer = dbFindById('CUSTOMERS', order.customer_id);
  const items = dbFindMany('ORDER_ITEMS', 'order_id', orderId)
    .map(stripInternalFields_);

  const invoice = typeof getInvoiceByOrderId_ === 'function'
    ? getInvoiceByOrderId_(orderId)
    : null;

  const cleanInvoice = invoice
    ? stripInternalFields_(invoice)
    : null;

  if (cleanInvoice && typeof buildPublicInvoiceUrl_ === 'function') {
    cleanInvoice.public_url = buildPublicInvoiceUrl_(
      cleanInvoice.public_token
    );
  }

  if (
    cleanInvoice &&
    typeof buildPublicReceiptUrl_ === 'function'
  ) {
    cleanInvoice.receipt_url =
      buildPublicReceiptUrl_(
        cleanInvoice.public_token,
        false
      );
  }

  if (
    cleanInvoice &&
    typeof buildKitchenTicketUrl_ === 'function'
  ) {
    cleanInvoice.kitchen_ticket_url =
      buildKitchenTicketUrl_(
        cleanInvoice.invoice_id,
        false
      );
  }

  return {
    order: stripInternalFields_(order),
    customer: customer ? stripInternalFields_(customer) : null,
    items: items,
    invoice: cleanInvoice,
    allowedTransitions:
      TWB_ORDER_TRANSITIONS[String(order.order_status).toUpperCase()] || []
  };
}

function resolveOrderItemSnapshot_(input) {
  const product = dbFindById('PRODUCTS', input.product_id);
  if (!product) {
    throw twbError_('NOT_FOUND', 'Product not found: ' + input.product_id);
  }

  const productStatus = String(product.status).toUpperCase();
  if (['ACTIVE', 'SEASONAL'].indexOf(productStatus) < 0) {
    throw twbError_(
      'PRODUCT_NOT_SELLABLE',
      product.product_name + ' is not currently sellable.'
    );
  }

  let variant = null;
  if (input.variant_id) {
    variant = dbFindById('PRODUCT_VARIANTS', input.variant_id);
    if (!variant) {
      throw twbError_('NOT_FOUND', 'Variant not found: ' + input.variant_id);
    }
    if (String(variant.product_id) !== String(product.product_id)) {
      throw twbError_(
        'VALIDATION_RELATION',
        'Variant does not belong to the selected product.'
      );
    }
    if (String(variant.status).toUpperCase() !== 'ACTIVE') {
      throw twbError_(
        'VARIANT_NOT_SELLABLE',
        variant.variant_name + ' is not active.'
      );
    }
  }

  const quantity = requirePositive_(input.quantity, 'quantity');
  const price = variant && variant.selling_price_override !== ''
    ? requireNonNegative_(
        variant.selling_price_override,
        'selling_price_override'
      )
    : requireNonNegative_(product.selling_price, 'selling_price');

  const lineDiscount = requireNonNegative_(
    input.line_discount || 0,
    'line_discount'
  );

  const gross = price * quantity;
  if (lineDiscount > gross) {
    throw twbError_(
      'ORDER_LINE_DISCOUNT_TOO_HIGH',
      'Line discount cannot exceed line gross value.'
    );
  }

  return {
    product: product,
    variant: variant,
    quantity: quantity,
    unitPrice: Math.round(price),
    lineDiscount: Math.round(lineDiscount),
    lineTotal: Math.round(gross - lineDiscount)
  };
}

function calculateOrderTotals_(resolvedItems, orderDiscount, deliveryFee, tax) {
  const subtotal = (resolvedItems || []).reduce(function(sum, item) {
    return sum + Number(item.lineTotal || 0);
  }, 0);

  const discount = requireNonNegative_(orderDiscount || 0, 'discount');
  const delivery = requireNonNegative_(deliveryFee || 0, 'delivery_fee');
  const taxValue = requireNonNegative_(tax || 0, 'tax');

  if (discount > subtotal) {
    throw twbError_(
      'ORDER_DISCOUNT_TOO_HIGH',
      'Order discount cannot exceed subtotal.'
    );
  }

  return {
    subtotal: Math.round(subtotal),
    discount: Math.round(discount),
    deliveryFee: Math.round(delivery),
    tax: Math.round(taxValue),
    grandTotal: Math.round(subtotal - discount + delivery + taxValue)
  };
}

function validateOrderFulfillment_(payload) {
  const fulfillmentType = String(payload.fulfillment_type || '').toUpperCase();
  const allowed = getConfig_('FULFILLMENT_TYPES') || [];

  if (!fulfillmentType) {
    throw twbError_('VALIDATION_REQUIRED', 'Fulfillment type is required.');
  }

  if (
    allowed.length &&
    allowed.indexOf(fulfillmentType) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Unknown fulfillment type: ' + fulfillmentType
    );
  }

  if (
    fulfillmentType !== 'PICKUP' &&
    !normalizeText_(payload.delivery_address)
  ) {
    throw twbError_(
      'VALIDATION_REQUIRED',
      'Delivery address is required for delivery orders.'
    );
  }

  return fulfillmentType;
}

function createOrder(payload) {
  const user = requirePermission_('ORDER_WRITE');
  payload = payload || {};

  const customerId = normalizeText_(payload.customer_id);
  const customer = dbFindById('CUSTOMERS', customerId);
  if (!customer) {
    throw twbError_('NOT_FOUND', 'Customer not found: ' + customerId);
  }
  if (String(customer.status).toUpperCase() !== 'ACTIVE') {
    throw twbError_('CUSTOMER_INACTIVE', 'Selected customer is not active.');
  }

  const itemsInput = Array.isArray(payload.items) ? payload.items : [];
  if (!itemsInput.length) {
    throw twbError_('VALIDATION_REQUIRED', 'Order must contain at least one item.');
  }

  const sourceChannel = String(payload.source_channel || '').toUpperCase();
  const allowedChannels = getConfig_('SALES_CHANNELS') || [];
  if (!sourceChannel) {
    throw twbError_('VALIDATION_REQUIRED', 'Order source is required.');
  }
  if (
    allowedChannels.length &&
    allowedChannels.indexOf(sourceChannel) < 0
  ) {
    throw twbError_('VALIDATION_ENUM', 'Unknown order source: ' + sourceChannel);
  }

  const preorderCampaignId =
    normalizeText_(payload.preorder_campaign_id);

  let preorderCampaign = null;

  if (preorderCampaignId) {
    if (typeof assertPreorderCapacityAvailableUnlocked_ !== 'function') {
      throw twbError_(
        'PREORDER_ENGINE_UNAVAILABLE',
        'Pre-order engine is not loaded.'
      );
    }

    preorderCampaign = dbFindById(
      'PREORDER_CAMPAIGNS',
      preorderCampaignId
    );

    if (!preorderCampaign) {
      throw twbError_(
        'NOT_FOUND',
        'Pre-order campaign not found: ' +
        preorderCampaignId
      );
    }
  }

  const fulfillmentPayload =
    preorderCampaign
      ? Object.assign(
          {},
          payload,
          {
            fulfillment_date:
              preorderCampaign.fulfillment_date
          }
        )
      : payload;

  const fulfillmentType =
    validateOrderFulfillment_(
      fulfillmentPayload
    );

  // Resolve all products/variants/prices before any write.
  const resolvedItems = itemsInput.map(resolveOrderItemSnapshot_);
  const totals = calculateOrderTotals_(
    resolvedItems,
    payload.discount,
    payload.delivery_fee,
    payload.tax
  );

  const preorderCapacityUsage =
    preorderCampaign
      ? preorderCapacityUsageFromItems_(
          preorderCampaign.capacity_unit,
          resolvedItems.map(function(item) {
            return {
              quantity: item.quantity
            };
          })
        )
      : 0;

  const requestedStatus = String(
    payload.order_status || 'WAITING_PAYMENT'
  ).toUpperCase();

  assertOneOf_(
    requestedStatus,
    ['DRAFT', 'WAITING_PAYMENT', 'CONFIRMED'],
    'order_status'
  );

  const orderId = nextBusinessId('ORDER');
  const now = nowIso_();

  const order = {
    order_id: orderId,
    order_date: normalizeText_(payload.order_date) || todayIso_(),
    customer_id: customerId,
    source_channel: sourceChannel,
    preorder_campaign_id:
      preorderCampaignId || '',
    order_status: requestedStatus,
    payment_status: 'UNPAID',
    invoice_status: 'DRAFT',
    fulfillment_type: fulfillmentType,
    fulfillment_date:
      preorderCampaign
        ? preorderCampaign.fulfillment_date
        : normalizeText_(payload.fulfillment_date),
    fulfillment_time_start: normalizeText_(payload.fulfillment_time_start),
    fulfillment_time_end: normalizeText_(payload.fulfillment_time_end),
    delivery_address:
      fulfillmentType === 'PICKUP'
        ? normalizeText_(payload.delivery_address || customer.default_address)
        : normalizeText_(payload.delivery_address),
    subtotal: totals.subtotal,
    discount: totals.discount,
    delivery_fee: totals.deliveryFee,
    tax: totals.tax,
    grand_total: totals.grandTotal,
    notes: normalizeText_(payload.notes),
    created_at: now,
    created_by: user.user_id,
    updated_at: now,
    updated_by: user.user_id
  };

  const orderItems = resolvedItems.map(function(resolved) {
    return {
      order_item_id: nextBusinessId('ORDER_ITEM'),
      order_id: orderId,
      product_id: resolved.product.product_id,
      variant_id: resolved.variant ? resolved.variant.variant_id : '',
      product_name_snapshot:
        resolved.product.product_name +
        (resolved.variant ? ' · ' + resolved.variant.variant_name : ''),
      sku_snapshot:
        resolved.variant
          ? resolved.variant.sku
          : resolved.product.sku,
      quantity: resolved.quantity,
      unit_price: resolved.unitPrice,
      line_discount: resolved.lineDiscount,
      line_total: resolved.lineTotal,
      production_notes: normalizeText_(
        itemsInput[resolvedItems.indexOf(resolved)].production_notes
      ),
      created_at: now,
      created_by: user.user_id,
      updated_at: now,
      updated_by: user.user_id
    };
  });

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  let orderInserted = false;
  try {
    if (preorderCampaignId) {
      assertPreorderCapacityAvailableUnlocked_(
        preorderCampaignId,
        preorderCapacityUsage,
        user,
        payload.preorder_override === true
      );
    }

    dbInsertRecord(
      'ORDERS',
      order,
      { validate: true, audit: false }
    );
    orderInserted = true;

    dbBulkInsert(
      'ORDER_ITEMS',
      orderItems,
      { validate: true }
    );

    if (preorderCampaignId) {
      syncPreorderCampaignCapacityUnlocked_(
        preorderCampaignId,
        user
      );
    }
  } catch (e) {
    if (orderInserted) {
      try {
        dbUpdateById(
          'ORDERS',
          orderId,
          {
            order_status: 'CANCELLED',
            notes:
              normalizeText_(order.notes) +
              (order.notes ? '\n' : '') +
              '[SYSTEM] Creation failed after header write: ' +
              (e.message || e),
            updated_at: nowIso_(),
            updated_by: user.user_id
          },
          { validate: true, audit: false }
        );
      } catch (ignore) {}
    }
    throw e;
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'CREATE',
    'ORDERS',
    orderId,
    null,
    {
      order: order,
      itemCount: orderItems.length
    },
    'Order created with pricing snapshot.'
  );

  const autoInvoice =
    typeof getConfig_ === 'function'
      ? getConfig_('AUTO_INVOICE_ON_ORDER') !== false
      : true;

  if (
    autoInvoice &&
    typeof ensureInvoiceForOrder_ === 'function'
  ) {
    try {
      ensureInvoiceForOrder_(orderId, user);
    } catch (invoiceError) {
      console.error(
        'AUTO_INVOICE_FAILED ' +
        orderId +
        ': ' +
        (invoiceError.message || invoiceError)
      );
    }
  }

  return getOrderDetail_(orderId);
}

function validateOrderTransition_(fromStatus, toStatus) {
  const from = String(fromStatus || '').toUpperCase();
  const to = String(toStatus || '').toUpperCase();

  if (!TWB_ORDER_TRANSITIONS[from]) {
    throw twbError_('ORDER_STATUS_INVALID', 'Unknown current order status: ' + from);
  }

  if (TWB_ORDER_TRANSITIONS[from].indexOf(to) < 0) {
    throw twbError_(
      'ORDER_STATUS_TRANSITION_INVALID',
      'Cannot move order from ' + from + ' to ' + to + '.',
      {
        from: from,
        to: to,
        allowed: TWB_ORDER_TRANSITIONS[from]
      }
    );
  }

  return true;
}

function updateOrderStatus(orderId, targetStatus, notes) {
  const user = requirePermission_('ORDER_WRITE');
  const order = dbFindById('ORDERS', orderId);
  if (!order) {
    throw twbError_('NOT_FOUND', 'Order not found: ' + orderId);
  }

  const fromStatus = String(order.order_status).toUpperCase();
  const toStatus = String(targetStatus || '').toUpperCase();

  validateOrderTransition_(fromStatus, toStatus);

  const before = stripInternalFields_(order);
  const updated = dbUpdateById(
    'ORDERS',
    orderId,
    stampUpdate_(user, {
      order_status: toStatus,
      notes:
        normalizeText_(notes) ||
        normalizeText_(order.notes)
    }),
    { validate: true, audit: false }
  );

  writeAuditLog_(
    'STATUS_CHANGE',
    'ORDERS',
    orderId,
    before,
    updated,
    fromStatus + ' → ' + toStatus
  );

  if (toStatus === 'COMPLETED' || fromStatus === 'COMPLETED') {
    recalculateCustomerMetrics_(order.customer_id, user);
  }

  if (
    toStatus === 'COMPLETED' &&
    typeof ensureOrderCogsTransactions_ === 'function'
  ) {
    ensureOrderCogsTransactions_(
      orderId,
      user,
      false
    );
  }

  if (
    toStatus === 'CANCELLED' &&
    order.preorder_campaign_id &&
    typeof syncPreorderCampaignCapacity_ === 'function'
  ) {
    syncPreorderCampaignCapacity_(
      order.preorder_campaign_id,
      user
    );
  }

  return getOrderDetail_(orderId);
}

function getOrderNextProgressStatus_(order) {
  const current = String(
    order && order.order_status || ''
  ).toUpperCase();

  switch (current) {
    case 'DRAFT':
      return 'WAITING_PAYMENT';
    case 'WAITING_PAYMENT':
      return 'CONFIRMED';
    case 'CONFIRMED':
      return 'SCHEDULED';
    case 'SCHEDULED':
      return 'IN_PRODUCTION';
    case 'IN_PRODUCTION':
      return 'READY';
    case 'READY':
      return String(
        order.fulfillment_type || ''
      ).toUpperCase() === 'DELIVERY'
        ? 'ON_DELIVERY'
        : 'COMPLETED';
    case 'ON_DELIVERY':
      return 'COMPLETED';
    default:
      return '';
  }
}

function bulkProgressOrders(payload) {
  requirePermission_('ORDER_WRITE');
  payload = payload || {};

  const rawIds = Array.isArray(payload.order_ids)
    ? payload.order_ids
    : [];

  const orderIds = [...new Set(
    rawIds
      .map(function(value) {
        return String(value || '').trim();
      })
      .filter(Boolean)
  )];

  if (!orderIds.length) {
    throw twbError_(
      'ORDER_BULK_EMPTY',
      'Select at least one Order.'
    );
  }

  if (orderIds.length > 100) {
    throw twbError_(
      'ORDER_BULK_LIMIT',
      'Bulk Progress supports up to 100 Orders at a time.'
    );
  }

  const mode = String(
    payload.mode || 'NEXT'
  ).toUpperCase();

  if (['NEXT', 'TARGET'].indexOf(mode) < 0) {
    throw twbError_(
      'ORDER_BULK_MODE_INVALID',
      'Bulk Progress mode must be NEXT or TARGET.'
    );
  }

  const requestedTarget = String(
    payload.target_status || ''
  ).toUpperCase();

  if (
    mode === 'TARGET' &&
    !requestedTarget
  ) {
    throw twbError_(
      'ORDER_BULK_TARGET_REQUIRED',
      'Choose a target Order status.'
    );
  }

  if (requestedTarget === 'CANCELLED') {
    throw twbError_(
      'ORDER_BULK_CANCEL_NOT_ALLOWED',
      'Bulk cancellation is not available. Cancellation requires payment/refund checks per Order.'
    );
  }

  const plan = orderIds.map(function(orderId) {
    const order = dbFindById(
      'ORDERS',
      orderId
    );

    if (!order) {
      throw twbError_(
        'NOT_FOUND',
        'Order not found: ' + orderId
      );
    }

    const fromStatus = String(
      order.order_status || ''
    ).toUpperCase();

    const targetStatus =
      mode === 'NEXT'
        ? getOrderNextProgressStatus_(order)
        : requestedTarget;

    if (!targetStatus) {
      throw twbError_(
        'ORDER_BULK_NO_NEXT_STATUS',
        orderId + ' is already ' + fromStatus + ' and has no next progress status.'
      );
    }

    validateOrderTransition_(
      fromStatus,
      targetStatus
    );

    return {
      order_id: orderId,
      from_status: fromStatus,
      target_status: targetStatus
    };
  });

  const results = [];

  plan.forEach(function(item) {
    try {
      const detail = updateOrderStatus(
        item.order_id,
        item.target_status,
        payload.notes || ''
      );

      results.push({
        order_id: item.order_id,
        from_status: item.from_status,
        target_status: item.target_status,
        status: 'UPDATED',
        final_status:
          detail && detail.order
            ? detail.order.order_status
            : item.target_status
      });
    } catch (error) {
      results.push({
        order_id: item.order_id,
        from_status: item.from_status,
        target_status: item.target_status,
        status: 'FAILED',
        error:
          error && error.message
            ? error.message
            : String(error)
      });
    }
  });

  const updatedCount = results.filter(function(row) {
    return row.status === 'UPDATED';
  }).length;

  const failedCount = results.length - updatedCount;

  return {
    ok: failedCount === 0,
    mode: mode,
    selected_count: orderIds.length,
    updated_count: updatedCount,
    failed_count: failedCount,
    results: results
  };
}

function cancelOrder(orderId, reason) {
  const reasonText = normalizeText_(reason);
  if (!reasonText) {
    throw twbError_('VALIDATION_REQUIRED', 'Cancellation reason is required.');
  }

  const detail = getOrderDetail_(orderId);
  const currentStatus = String(detail.order.order_status).toUpperCase();
  const paymentStatus = String(detail.order.payment_status || '').toUpperCase();

  if (currentStatus === 'COMPLETED') {
    throw twbError_(
      'ORDER_CANCEL_COMPLETED',
      'Completed orders cannot be cancelled. A refund/reversal flow is required.'
    );
  }

  if (currentStatus === 'CANCELLED') {
    return detail;
  }

  if (['PARTIAL', 'PAID'].indexOf(paymentStatus) >= 0) {
    throw twbError_(
      'ORDER_HAS_PAYMENT_REFUND_REQUIRED',
      'This order already has payment. Refund the payment before cancelling the order.'
    );
  }

  updateOrderStatus(
    orderId,
    'CANCELLED',
    (detail.order.notes ? detail.order.notes + '\n' : '') +
    '[CANCELLED] ' + reasonText
  );

  const invoice =
    typeof getInvoiceByOrderId_ === 'function'
      ? getInvoiceByOrderId_(orderId)
      : null;

  if (
    invoice &&
    ['CANCELLED', 'REFUNDED'].indexOf(
      String(invoice.status).toUpperCase()
    ) < 0 &&
    Number(invoice.paid_amount || 0) === 0 &&
    typeof cancelInvoice === 'function'
  ) {
    cancelInvoice(
      invoice.invoice_id,
      'Order cancelled: ' + reasonText
    );
  }

  return getOrderDetail_(orderId);
}

function updateOrderFulfillment(orderId, payload) {
  const user = requirePermission_('ORDER_WRITE');
  const order = dbFindById('ORDERS', orderId);
  if (!order) throw twbError_('NOT_FOUND', 'Order not found: ' + orderId);

  if (['COMPLETED', 'CANCELLED'].indexOf(String(order.order_status).toUpperCase()) >= 0) {
    throw twbError_(
      'ORDER_LOCKED',
      'Completed or cancelled orders cannot change fulfillment details.'
    );
  }

  payload = payload || {};
  const fulfillmentType = validateOrderFulfillment_(
    Object.assign({}, order, payload)
  );

  const patch = stampUpdate_(user, {
    fulfillment_type: fulfillmentType,
    fulfillment_date: Object.prototype.hasOwnProperty.call(payload, 'fulfillment_date')
      ? normalizeText_(payload.fulfillment_date)
      : order.fulfillment_date,
    fulfillment_time_start: Object.prototype.hasOwnProperty.call(payload, 'fulfillment_time_start')
      ? normalizeText_(payload.fulfillment_time_start)
      : order.fulfillment_time_start,
    fulfillment_time_end: Object.prototype.hasOwnProperty.call(payload, 'fulfillment_time_end')
      ? normalizeText_(payload.fulfillment_time_end)
      : order.fulfillment_time_end,
    delivery_address: fulfillmentType === 'PICKUP'
      ? normalizeText_(
          Object.prototype.hasOwnProperty.call(payload, 'delivery_address')
            ? payload.delivery_address
            : order.delivery_address
        )
      : normalizeText_(
          Object.prototype.hasOwnProperty.call(payload, 'delivery_address')
            ? payload.delivery_address
            : order.delivery_address
        )
  });

  dbUpdateById(
    'ORDERS',
    orderId,
    patch,
    { audit: true, action: 'UPDATE' }
  );

  if (
    typeof getInvoiceByOrderId_ ===
      'function' &&
    typeof syncInvoicePdfArchiveSafely_ ===
      'function'
  ) {
    const invoice =
      getInvoiceByOrderId_(
        orderId
      );

    if (invoice) {
      syncInvoicePdfArchiveSafely_(
        invoice.invoice_id,
        'FULFILLMENT_UPDATED'
      );
    }
  }

  return getOrderDetail_(orderId);
}
