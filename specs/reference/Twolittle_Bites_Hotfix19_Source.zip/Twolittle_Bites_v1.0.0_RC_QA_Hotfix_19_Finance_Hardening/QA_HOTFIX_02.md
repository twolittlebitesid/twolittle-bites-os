# QA Hotfix 02 — Navigation, WhatsApp, UI Cleanup, Charts, Order Search, Invoice Preview

**Release Candidate:** Twolittle.bites OS v1.0.0  
**Purpose:** Close P0/P1 issues found during manual pre-release QA.  
**Schema migration:** None.

## Closed issues

### P0 — Returning to a previous menu reloads the module

Root cause:

```text
Router navigation
→ clone page template again
→ module.init()
→ bootstrap API again
```

Fix:

```text
First visit
→ create route DOM
→ init + fetch once
→ keep route mounted

Return visit
→ show cached route DOM
→ no module bootstrap request
```

Data refresh is now explicit through each module's Refresh action.

### P0 — WhatsApp Workflow inactive

The bottom WhatsApp action is no longer a future placeholder.

It opens an active **WhatsApp Queue** containing unpaid/partial Orders. Opening an Order exposes the existing live invoice WhatsApp action.

### P0 — Data Foundation status placement

The large top strip is removed from the top chrome.

Data Foundation now appears as a compact bottom-right system-status indicator:

```text
Data Foundation · 33/33 sheets valid · App 1.0.0 · Schema 1.0.0
```

### P0 — stray `\` artifact

A safe UI cleanup removes standalone backslash text nodes outside SCRIPT / STYLE / TEXTAREA / PRE / CODE elements.

### P0 — production UI contains technical Phase/Engine labels

Removed production-facing implementation labels such as:

```text
Executive Command Center · v1.0
Order + Pre-Order Engine · Phase 9
CRM & Customer Intelligence · Phase 11
Inventory Engine · Phase 7
...
```

Legacy explanatory copy referring to old phased limitations was also rewritten to describe the current live behavior.

### P0 — growth charts missing

Added lightweight native SVG / DOM charts without an external chart library.

Added to:

```text
Executive
- Operating Revenue growth
- Completed Orders growth

Business
- role-aware primary growth metric
- role-aware secondary growth metric

Orders
- Orders Created, last 14 days
- Booked Value, last 14 days

Reports
- role-aware primary trend
- role-aware secondary trend
```

### P0 — logo opens a link

The Twolittle.bites brand is now a non-clickable identity element.

### P0 — customer selection does not scale

New Order now uses a searchable customer combobox.

Search fields:

```text
Name
WhatsApp
Email
```

Results are capped to a short result set rather than requiring scrolling through the full customer list.

### P0 — Invoice / WhatsApp template has no real preview

Settings → Invoice & WhatsApp now supports:

```text
Invoice Prefix
Payment Due Hours
Public Invoice Title
Public Invoice Note
WhatsApp Invoice Template
```

Two live previews are rendered while typing:

```text
Public Invoice Preview
WhatsApp Message Preview
```

The Public Invoice Title and Note are also used by the real public invoice page.

### P1 — “BUSINESS OPERATING SYSTEM” subtitle

Removed from the header.

### P1 — Executive action placement

New Order and Refresh remain inside the Executive banner but are aligned to its lower-right corner.

### P1 — Orders card spacing

Orders KPI, Growth, and Table sections now have consistent vertical spacing.

## Files changed

Core:

```text
ComponentHeader.html
ComponentQuickActions.html
Index.html
JsApp.html
JsRouter.html
JsCharts.html
StylesTokens.html
StylesComponents.html
StylesResponsive.html
```

Executive / Business / Reports:

```text
ExecutiveService.gs
BusinessService.gs
JsExecutive.html
JsBusiness.html
JsReports.html
PageExecutive.html
PageBusiness.html
PageReports.html
```

Orders / WhatsApp:

```text
JsOrders.html
PageOrders.html
```

Invoice / Settings:

```text
SettingsService.gs
InvoiceService.gs
PublicInvoice.html
JsSettings.html
PageSettings.html
```

Production-facing copy cleanup also changes module Page HTML files.

Validation:

```text
Phase16HealthCheck.gs
Phase16SmokeTest.gs
PRODUCTION_ACCEPTANCE_TEST.md
```

## Install

Apply the Delta ZIP over the current **v1.0.0 RC P0 Executive/Business Fixed** Apps Script project.

No upgrade function is required for this hotfix.

Save all files, create a new test deployment version if your QA URL uses versioned deployment, then hard refresh once.

## Runtime validation

Run:

```javascript
runPhase16HealthCheck()
```

Expected additional check:

```text
QA_HOTFIX_02_UI ✅
```

Then:

```javascript
runPhase16SmokeTest()
```

Expected additional test:

```text
CLIENT_ROUTE_CACHE_AND_SEARCH ✅
```

Then:

```javascript
runPhase15RegressionSuite()
```

Target remains:

```text
13 / 13 modules passed
```

## Manual retest focus

1. Open Executive → Orders → Business → Executive.
   - Executive should appear immediately on return without its loading/bootstrap cycle.
2. Explicit Refresh must still refetch.
3. Click WhatsApp bottom action.
   - WhatsApp Queue opens.
4. Verify bottom-right Data Foundation status.
5. Verify no Phase/Engine labels remain in normal module UI.
6. Create New Order and search customer by partial name / WhatsApp / email.
7. Settings → Invoice & WhatsApp:
   - edit title/note/template;
   - confirm both previews update live;
   - save;
   - open a real public invoice and verify title/note.
8. Verify Executive, Business, Orders, and Reports charts render.
9. Verify Executive actions sit lower-right.
10. Verify Orders vertical card spacing.
