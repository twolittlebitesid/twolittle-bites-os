# EXPERIENCE_UPGRADE_11.md

# Experience Upgrade 11 — Decision Utility + Lightweight Motion

This build applies the previously proposed page usefulness and motion improvements without creating duplicate cards where an equivalent already existed.

## Global motion system

Uses only CSS `transform` and `opacity` for the primary animations:
- page enter: 260ms fade + 6px rise;
- card hover: 2px lift on pointer devices;
- button press: 0.97 scale;
- modal backdrop + modal enter;
- tab / status transitions;
- toast reveal;
- KPI and chart reveal;
- `prefers-reduced-motion` fallback.

No animation library is added.

## Orders
- operational pipeline strip;
- Needs Attention summary;
- search across order/customer/WhatsApp/item;
- date filter;
- channel filter;
- fulfillment filter;
- customer filter;
- filters combine with existing All / Today / Upcoming / Need Attention / Status views.

## Customers
- New This Month;
- Repeat Rate / VIP / Dormant decision cards;
- searchable Directory;
- CRM Segment filter.

## Products & Recipes
- Active Products;
- Variants;
- average Gross Margin;
- products without active recipe + low-margin attention count;
- Product/SKU/Category search;
- existing Product → Variant hierarchy, COGS, Recipe Calculator, EXACT/FULL_BATCH remain canonical.

## Production
- Today Plans;
- In Progress;
- Today Target;
- Today Shortage.

## Inventory
- Need Restock priority list;
- material search;
- stock-status filter;
- Ingredient/Packaging type filter.

## Purchasing
- Suggested To Buy;
- Open Purchases;
- Awaiting Delivery;
- Delivery Risk.

Existing shortage-based purchase recommendations remain the primary purchasing engine.

## Finance
- Cash In;
- Cash Out;
- Overdue Invoice attention;
- Refund signals.

Existing P&L, expense category, profitability, invoices, payments, and transactions remain unchanged.

## Marketing
- Best Channel;
- Best Campaign;
- Attribution Coverage;
- Unattributed Order attention.

Existing campaign/channel attribution remains canonical.

## Reports
- same-length previous-period comparison for Revenue, Orders, Marketing Spend, and Attribution Coverage;
- comparison is fetched from the existing `reports.bootstrap` endpoint and cached client-side for the period.

## Existing pages intentionally not duplicated

Executive already contains financial snapshot, pipeline, Needs Attention, operating health, customer health, marketing, targets, growth, and recent orders.
Business already contains health cards, targets, channels, role-aware trend, and operating context.
Settings already contains Business, Commerce, Invoice/WhatsApp, Automation, Users, Diagnostics, Release, and System sections.

## Schema / source of truth

No Sheet schema migration. No source-of-truth changes.
All new decision cards derive from existing module bootstrap data.
