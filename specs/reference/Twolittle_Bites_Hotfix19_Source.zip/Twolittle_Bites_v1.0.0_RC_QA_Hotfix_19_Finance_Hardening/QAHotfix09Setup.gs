/**
 * QA Hotfix 09 — Integrity Runtime Repair
 *
 * Use after replacing SystemHardeningService.gs + Phase16HealthCheck.gs.
 */

function runQAHotfix09IntegrityRepairCheck() {
  requirePermission_(
    'SETTINGS_WRITE'
  );

  var dailyKeys =
    systemIntegrityKeyFields_(
      'DAILY_METRICS',
      getSheetSchema_(
        'DAILY_METRICS'
      )
    );

  var monthlyKeys =
    systemIntegrityKeyFields_(
      'MONTHLY_METRICS',
      getSheetSchema_(
        'MONTHLY_METRICS'
      )
    );

  var integrity =
    systemIntegrityReport_();

  return {
    ok:
      systemIntegrityEngineVersion_() ===
        'QA_HOTFIX_09_COMPOSITE_KEYS_V1' &&
      dailyKeys.join('|') ===
        'metric_date|metric_key' &&
      monthlyKeys.join('|') ===
        'month|metric_key' &&
      integrity.ok,
    engineVersion:
      systemIntegrityEngineVersion_(),
    dailyMetricKey:
      dailyKeys,
    monthlyMetricKey:
      monthlyKeys,
    integrityOk:
      integrity.ok,
    issueGroups:
      integrity.issueGroups,
    totalIssues:
      integrity.totalIssues,
    issues:
      integrity.issues
  };
}
