# QA_HOTFIX_13_NAV_PAYMENT_IMAGE.md

# QA Hotfix 13 — Invoice Access, Payment Shortcut & Image Preview Repair

## Requested changes

1. Remove `Operating System Active` from the bottom quick bar.
2. Add a clear Invoice shortcut and a `+` action when a payment needs to be recorded.
3. Repair image previews that still fail even though an image link is already saved.
4. Re-run cross-module QA so the patch does not break route cache, search/filter, permissions, invoice/PDF, or prior hotfixes.

## Bottom quick bar

Removed:

```text
Operating System Active
```

Added:

```text
Invoice
```

The Invoice shortcut opens:

```text
Finance → Invoices
```

without creating a second Invoice module or another source of truth.

## Payment `+` shortcut

### Orders

For an unpaid / partial Order, the Payment cell now shows:

```text
[PAYMENT STATUS] [+]
```

The `+` action:

1. resolves the Order's Invoice;
2. creates the Invoice first when it does not exist and the current role has `INVOICE_WRITE`;
3. routes to `Finance → Invoices`;
4. opens the Invoice and immediately opens `Record Payment`.

It does **not** manually edit `payment_status`. Payment status continues to be derived from immutable Payment events.

### Finance → Invoices

Unpaid / partial Invoices also show a `+` action next to the normal Open action.

The `+` opens `Record Payment` directly.

## Image preview repair

The existing browser image chain remains first:

```text
Direct URL
→ Google Drive thumbnail
→ Google Drive uc?export=view
→ Dropbox raw URL
```

QA Hotfix 13 adds a final Google Drive fallback:

```text
Browser candidate failed
→ Apps Script reads the Drive file with the script owner's access
→ validates image MIME type
→ returns a data:image base64 preview
```

This fixes the common case where the Drive file is readable by the Apps Script owner but Google Drive refuses direct `<img>` embedding.

Additional repairs:
- Google Drive `resourcekey` is preserved in browser candidates.
- `referrerPolicy="no-referrer"` was removed from Product/New Order images so it cannot break hosts that require a referrer.
- Product Edit image preview is debounced while typing.
- Product list continues to use `updated_at` as its cache-busting version.
- Settings → Business logo preview now uses the same resilient image loader.
- Public Invoice / PDF resolves a Drive-based brand logo server-side to a `data:image` URL before rendering.

Server-assisted preview is capped at **4.5 MB** per image.

## Permission / security QA fix

While cross-checking access control, the Executive target list was found to still expose profit-sensitive target rows to roles without `PNL_READ`.

QA Hotfix 13 filters these target metrics when `canSeeProfit = false`:

```text
OPERATING_PROFIT
GROSS_MARGIN_PCT
```

Finance profit cards were already masked; now target rows follow the same rule.

## Runtime checks

Run:

```javascript
runPhase16HealthCheck()
runPhase16SmokeTest()
runPhase15RegressionSuite()
```

Expected new checks:

```text
QA_HOTFIX_13_INVOICE_PAYMENT_IMAGE = true
QA_HOTFIX_13_NAV_PAYMENT_IMAGE = true
```

For the exact Drive image link that currently fails, run:

```javascript
runQAHotfix13ImagePreviewSmoke('PASTE_GOOGLE_DRIVE_IMAGE_LINK_HERE')
```

Expected:

```text
ok = true
source = GOOGLE_DRIVE_SERVER_FALLBACK
mime_type = image/...
byte_size > 0
```

If this fails with `IMAGE_DRIVE_ACCESS_FAILED`, the file is not readable by the Google account that owns/runs the Apps Script project.

## Install from QA Hotfix 12

### ADD

```text
ImagePreviewService.gs
QAHotfix13Setup.gs
```

### REPLACE

```text
ApiGateway.gs
ComponentQuickActions.html
StylesComponents.html
StylesResponsive.html
JsApp.html
JsProducts.html
JsOrders.html
JsFinance.html
JsSettings.html
PageSettings.html
OrderService.gs
InvoiceService.gs
ExecutiveService.gs
Phase16HealthCheck.gs
Phase16SmokeTest.gs
PRODUCTION_ACCEPTANCE_TEST.md
README.md
```

No Sheet schema migration.
No data rewrite.
No `upgradeToPhase16()` rerun.
