# PHASE_11_QA.md

Static QA:

- Server `.gs` syntax: PASS
- Client `Js*.html` syntax: PASS
- HTML include references: PASS
- Existing CRM source schema compatibility: PASS
- Customer Profile API: PASS
- Limited-access privacy masking: PASS
- RPC client-safe bridge retained: PASS
- Previous validation cleanup: PASS
- Schema migration required: NO
- App Version: 0.11.0
- Schema Version: 1.0.0

CRM safeguards:
- intelligence uses completed Orders
- repeat-rate denominator is customers with 1+ completed Order
- historical customer value is not presented as predicted CLV
- RFM-style score is relative to current cohort
- dormant segment overrides value tier after inactivity threshold
- CUSTOMER_READ_LIMITED masks WhatsApp/email and hides address/notes
- no automatic reactivation message sending
- no duplicate CRM table
- stored base customer metrics remain compatible
