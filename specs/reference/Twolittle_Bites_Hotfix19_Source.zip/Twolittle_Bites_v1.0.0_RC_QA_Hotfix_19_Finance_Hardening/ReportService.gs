/**
 * Twolittle.bites OS — Phase 13 Reports, Metrics Cache & Export
 *
 * Sources of truth stay in operational sheets.
 * DAILY_METRICS and MONTHLY_METRICS are rebuildable derived caches.
 */

function reportAccess_() {
  var user = requireCurrentUser_();

  var full =
    hasPermission_(user, 'REPORT_READ');

  var operational =
    full ||
    hasPermission_(
      user,
      'REPORT_OPERATIONAL_READ'
    );

  var marketing =
    full ||
    hasPermission_(
      user,
      'REPORT_MARKETING_READ'
    );

  if (
    !full &&
    !operational &&
    !marketing
  ) {
    throw twbError_(
      'FORBIDDEN',
      'Report permission is required.'
    );
  }

  return {
    user: user,
    full: full,
    operational: operational,
    marketing: marketing,
    canRebuildCache:
      user.role === TWB_ROLES.OWNER ||
      user.role === TWB_ROLES.ADMIN,
    canWriteTarget:
      user.role === TWB_ROLES.OWNER ||
      hasPermission_(
        user,
        'BUSINESS_UPDATE'
      )
  };
}

function reportMetricDefinitions_() {
  return {
    ORDERS_CREATED: {
      label: 'Orders Created',
      unit: 'COUNT',
      scope: 'MARKETING',
      additive: true
    },
    COMPLETED_ORDERS: {
      label: 'Completed Orders',
      unit: 'COUNT',
      scope: 'FULL',
      additive: true
    },
    OPERATING_REVENUE: {
      label: 'Operating Revenue',
      unit: 'IDR',
      scope: 'FULL',
      additive: true
    },
    EXPENSES: {
      label: 'Operating Expenses',
      unit: 'IDR',
      scope: 'FULL',
      additive: true
    },
    CASH_IN: {
      label: 'Cash In',
      unit: 'IDR',
      scope: 'FULL',
      additive: true
    },
    CASH_OUT: {
      label: 'Cash Out',
      unit: 'IDR',
      scope: 'FULL',
      additive: true
    },
    NEW_CUSTOMERS: {
      label: 'New Customers',
      unit: 'COUNT',
      scope: 'MARKETING',
      additive: true
    },
    MARKETING_SPEND: {
      label: 'Marketing Spend',
      unit: 'IDR',
      scope: 'MARKETING',
      additive: true
    },
    ATTRIBUTED_ORDERS: {
      label: 'Attributed Orders',
      unit: 'COUNT',
      scope: 'MARKETING',
      additive: true
    },
    ATTRIBUTED_REVENUE: {
      label: 'Attributed Revenue',
      unit: 'IDR',
      scope: 'MARKETING',
      additive: true
    },
    PRODUCTION_PLANS: {
      label: 'Production Plans',
      unit: 'COUNT',
      scope: 'OPERATIONAL',
      additive: true
    },
    PRODUCTION_COMPLETED_PLANS: {
      label: 'Completed Production Plans',
      unit: 'COUNT',
      scope: 'OPERATIONAL',
      additive: true
    },
    SHORTAGE_REQUIREMENTS: {
      label: 'Shortage Requirements',
      unit: 'COUNT',
      scope: 'OPERATIONAL',
      additive: true
    },
    WASTE_QTY: {
      label: 'Waste Quantity',
      unit: 'QTY',
      scope: 'OPERATIONAL',
      additive: true
    },
    AOV: {
      label: 'Average Order Value',
      unit: 'IDR',
      scope: 'FULL',
      additive: false
    },
    CASH_NET: {
      label: 'Net Cash Movement',
      unit: 'IDR',
      scope: 'FULL',
      additive: false
    },
    ROAS: {
      label: 'ROAS',
      unit: 'RATIO',
      scope: 'MARKETING',
      additive: false
    },
    ATTRIBUTION_COVERAGE_PCT: {
      label: 'Attribution Coverage',
      unit: 'PERCENT',
      scope: 'MARKETING',
      additive: false
    },
    PRODUCTION_COMPLETION_RATE_PCT: {
      label: 'Production Completion Rate',
      unit: 'PERCENT',
      scope: 'OPERATIONAL',
      additive: false
    }
  };
}

function reportTargetMetricKeys_() {
  return [
    'OPERATING_REVENUE',
    'COMPLETED_ORDERS',
    'OPERATING_PROFIT',
    'GROSS_MARGIN_PCT',
    'ATTRIBUTED_REVENUE',
    'ATTRIBUTED_ORDERS',
    'NEW_CUSTOMERS',
    'PRODUCTION_COMPLETED_PLANS'
  ];
}

function reportTargetMetricDefinition_(
  metricKey
) {
  var defs = {
    OPERATING_REVENUE: {
      label: 'Operating Revenue',
      unit: 'IDR'
    },
    COMPLETED_ORDERS: {
      label: 'Completed Orders',
      unit: 'COUNT'
    },
    OPERATING_PROFIT: {
      label: 'Operating Profit',
      unit: 'IDR'
    },
    GROSS_MARGIN_PCT: {
      label: 'Gross Margin',
      unit: 'PERCENT'
    },
    ATTRIBUTED_REVENUE: {
      label: 'Attributed Revenue',
      unit: 'IDR'
    },
    ATTRIBUTED_ORDERS: {
      label: 'Attributed Orders',
      unit: 'COUNT'
    },
    NEW_CUSTOMERS: {
      label: 'New Customers',
      unit: 'COUNT'
    },
    PRODUCTION_COMPLETED_PLANS: {
      label: 'Completed Production Plans',
      unit: 'COUNT'
    }
  };

  return defs[
    metricKey
  ] || null;
}

function reportDateKey_(value) {
  return financeDateKey_(value);
}

function reportTodayKey_() {
  return Utilities.formatDate(
    new Date(),
    TWB_APP.TIMEZONE,
    'yyyy-MM-dd'
  );
}

function reportMonthKey_(value) {
  var key =
    reportDateKey_(value);

  return key
    ? key.slice(0, 7)
    : '';
}

function reportDefaultPeriod_() {
  var now = new Date();

  var start =
    Utilities.formatDate(
      new Date(
        now.getFullYear(),
        now.getMonth(),
        1
      ),
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );

  var end =
    Utilities.formatDate(
      new Date(
        now.getFullYear(),
        now.getMonth() + 1,
        0
      ),
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );

  return {
    start: start,
    end: end
  };
}

function normalizeReportPeriod_(payload) {
  payload = payload || {};

  var defaults =
    reportDefaultPeriod_();

  var start =
    reportDateKey_(
      payload.period_start
    ) || defaults.start;

  var end =
    reportDateKey_(
      payload.period_end
    ) || defaults.end;

  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(start) ||
    !/^\d{4}-\d{2}-\d{2}$/.test(end)
  ) {
    throw twbError_(
      'REPORT_PERIOD_INVALID',
      'Report period requires valid start/end dates.'
    );
  }

  if (start > end) {
    throw twbError_(
      'REPORT_PERIOD_INVALID',
      'Report start cannot be after report end.'
    );
  }

  var startMs =
    new Date(
      start + 'T12:00:00'
    ).getTime();

  var endMs =
    new Date(
      end + 'T12:00:00'
    ).getTime();

  var days =
    Math.round(
      (
        endMs -
        startMs
      ) /
      (
        24 *
        60 *
        60 *
        1000
      )
    ) + 1;

  if (days > 732) {
    throw twbError_(
      'REPORT_PERIOD_TOO_LARGE',
      'Interactive report range is limited to 732 days.'
    );
  }

  return {
    start: start,
    end: end,
    days: days
  };
}

function reportDateRangeKeys_(
  start,
  end
) {
  var keys = [];

  var cursor =
    new Date(
      start + 'T12:00:00'
    );

  var last =
    new Date(
      end + 'T12:00:00'
    );

  while (
    cursor.getTime() <=
    last.getTime()
  ) {
    keys.push(
      Utilities.formatDate(
        cursor,
        TWB_APP.TIMEZONE,
        'yyyy-MM-dd'
      )
    );

    cursor.setDate(
      cursor.getDate() + 1
    );
  }

  return keys;
}

function reportValueInPeriod_(
  value,
  period
) {
  var key =
    reportDateKey_(value);

  return (
    !!key &&
    key >= period.start &&
    key <= period.end
  );
}

function visibleReportMetricKeys_(
  access
) {
  var defs =
    reportMetricDefinitions_();

  return Object.keys(defs)
    .filter(function(key) {
      var scope =
        defs[key].scope;

      if (
        access.full
      ) {
        return true;
      }

      if (
        scope ===
          'OPERATIONAL' &&
        access.operational
      ) {
        return true;
      }

      if (
        scope ===
          'MARKETING' &&
        access.marketing
      ) {
        return true;
      }

      return false;
    });
}

function reportInitialDailyBucket_(
  dateKey
) {
  return {
    metric_date:
      dateKey,
    ORDERS_CREATED: 0,
    COMPLETED_ORDERS: 0,
    OPERATING_REVENUE: 0,
    EXPENSES: 0,
    CASH_IN: 0,
    CASH_OUT: 0,
    NEW_CUSTOMERS: 0,
    MARKETING_SPEND: 0,
    ATTRIBUTED_ORDERS: 0,
    ATTRIBUTED_REVENUE: 0,
    PRODUCTION_PLANS: 0,
    PRODUCTION_COMPLETED_PLANS: 0,
    SHORTAGE_REQUIREMENTS: 0,
    WASTE_QTY: 0
  };
}

function buildDailyMetricBuckets_(
  period
) {
  var buckets = {};

  reportDateRangeKeys_(
    period.start,
    period.end
  ).forEach(function(key) {
    buckets[key] =
      reportInitialDailyBucket_(
        key
      );
  });

  var orders =
    listAllRecords_(
      'ORDERS'
    );

  var expenses =
    listAllRecords_(
      'EXPENSES'
    );

  var transactions =
    listAllRecords_(
      'TRANSACTIONS'
    );

  var productionPlans =
    listAllRecords_(
      'PRODUCTION_PLANS'
    );

  var requirements =
    listAllRecords_(
      'PRODUCTION_REQUIREMENTS'
    );

  var batches =
    listAllRecords_(
      'PRODUCTION_BATCHES'
    );

  var logs =
    listAllRecords_(
      'ACTIVITY_LOG'
    );

  var attributionMap =
    typeof marketingAttributionMap_ ===
      'function'
      ? marketingAttributionMap_(
          logs
        )
      : {};

  var expenseLinkMap =
    typeof marketingExpenseLinkMap_ ===
      'function'
      ? marketingExpenseLinkMap_(
          logs
        )
      : {};

  var firstOrders =
    typeof marketingFirstOrderByCustomer_ ===
      'function'
      ? marketingFirstOrderByCustomer_(
          orders
        )
      : {};

  var planDateMap = {};

  productionPlans
    .forEach(function(plan) {
      var date =
        reportDateKey_(
          plan.production_date
        );

      if (
        String(
          plan.status || ''
        ).toUpperCase() ===
          'CANCELLED'
      ) {
        return;
      }

      planDateMap[
        plan.production_plan_id
      ] = date;

      if (
        !buckets[date]
      ) {
        return;
      }

      buckets[date]
        .PRODUCTION_PLANS += 1;

      if (
        String(
          plan.status || ''
        ).toUpperCase() ===
        'COMPLETED'
      ) {
        buckets[date]
          .PRODUCTION_COMPLETED_PLANS +=
          1;
      }
    });

  requirements
    .forEach(function(row) {
      var date =
        planDateMap[
          row.production_plan_id
        ];

      if (!buckets[date]) {
        return;
      }

      if (
        String(
          row.status || ''
        ).toUpperCase() ===
          'SHORTAGE' ||
        Number(
          row.shortage_qty_base || 0
        ) > 0
      ) {
        buckets[date]
          .SHORTAGE_REQUIREMENTS += 1;
      }
    });

  batches
    .forEach(function(batch) {
      var date =
        reportDateKey_(
          batch.completed_at ||
          batch.started_at ||
          batch.created_at
        );

      if (!buckets[date]) {
        return;
      }

      buckets[date]
        .WASTE_QTY +=
        Number(
          batch.waste_qty || 0
        );
    });

  orders
    .forEach(function(order) {
      var status =
        String(
          order.order_status || ''
        ).toUpperCase();

      if (
        status ===
        'CANCELLED'
      ) {
        return;
      }

      var orderDate =
        reportDateKey_(
          order.order_date ||
          order.created_at
        );

      if (
        buckets[
          orderDate
        ]
      ) {
        buckets[
          orderDate
        ].ORDERS_CREATED += 1;

        if (
          attributionMap[
            order.order_id
          ]
        ) {
          buckets[
            orderDate
          ].ATTRIBUTED_ORDERS += 1;
        }

        var first =
          firstOrders[
            order.customer_id
          ];

        if (
          first &&
          String(
            first.orderId
          ) ===
          String(
            order.order_id
          )
        ) {
          buckets[
            orderDate
          ].NEW_CUSTOMERS += 1;
        }
      }

      if (
        status ===
        'COMPLETED'
      ) {
        var revenueDate =
          reportDateKey_(
            order.fulfillment_date ||
            order.order_date
          );

        if (
          buckets[
            revenueDate
          ]
        ) {
          buckets[
            revenueDate
          ].COMPLETED_ORDERS += 1;

          var operatingRevenue =
            typeof marketingOperatingRevenue_ ===
              'function'
              ? marketingOperatingRevenue_(
                  order
                )
              : Math.max(
                  0,
                  Math.round(
                    Number(
                      order.grand_total || 0
                    ) -
                    Number(
                      order.tax || 0
                    )
                  )
                );

          buckets[
            revenueDate
          ].OPERATING_REVENUE +=
            operatingRevenue;

          if (
            attributionMap[
              order.order_id
            ]
          ) {
            buckets[
              revenueDate
            ].ATTRIBUTED_REVENUE +=
              operatingRevenue;
          }
        }
      }
    });

  expenses
    .forEach(function(expense) {
      if (
        String(
          expense.status || ''
        ).toUpperCase() ===
        'VOID'
      ) {
        return;
      }

      var date =
        reportDateKey_(
          expense.expense_date
        );

      if (!buckets[date]) {
        return;
      }

      var amount =
        Number(
          expense.amount || 0
        );

      buckets[date]
        .EXPENSES +=
        amount;

      if (
        expenseLinkMap[
          expense.expense_id
        ]
      ) {
        buckets[date]
          .MARKETING_SPEND +=
          amount;
      }
    });

  transactions
    .forEach(function(row) {
      if (
        String(
          row.transaction_type || ''
        ).toUpperCase() ===
        'COGS'
      ) {
        return;
      }

      var date =
        reportDateKey_(
          row.transaction_at
        );

      if (!buckets[date]) {
        return;
      }

      buckets[date]
        .CASH_IN +=
        Number(
          row.amount_in || 0
        );

      buckets[date]
        .CASH_OUT +=
        Number(
          row.amount_out || 0
        );
    });

  return buckets;
}

function dailyBucketsToMetricRows_(
  buckets
) {
  var defs =
    reportMetricDefinitions_();

  var additiveKeys =
    Object.keys(defs)
      .filter(function(key) {
        return (
          defs[key].additive ===
          true
        );
      });

  var calculatedAt =
    nowIso_();

  var rows = [];

  Object.keys(buckets)
    .sort()
    .forEach(function(dateKey) {
      additiveKeys
        .forEach(function(metricKey) {
          rows.push({
            metric_date:
              dateKey,
            metric_key:
              metricKey,
            metric_value:
              roundNumber_(
                Number(
                  buckets[
                    dateKey
                  ][
                    metricKey
                  ] || 0
                ),
                6
              ),
            unit:
              defs[
                metricKey
              ].unit,
            calculated_at:
              calculatedAt
          });
        });
    });

  return rows;
}

function buildDailyMetricRows_(
  period
) {
  return dailyBucketsToMetricRows_(
    buildDailyMetricBuckets_(
      period
    )
  );
}

function aggregateMonthlyMetricRows_(
  dailyRows
) {
  var defs =
    reportMetricDefinitions_();

  var months = {};

  (dailyRows || [])
    .forEach(function(row) {
      var month =
        String(
          row.metric_date || ''
        ).slice(0, 7);

      if (!month) return;

      if (!months[month]) {
        months[month] = {};
      }

      var key =
        row.metric_key;

      months[month][key] =
        (
          months[month][key] ||
          0
        ) +
        Number(
          row.metric_value || 0
        );
    });

  var calculatedAt =
    nowIso_();

  var rows = [];

  Object.keys(months)
    .sort()
    .forEach(function(month) {
      var values =
        months[month];

      Object.keys(values)
        .forEach(function(key) {
          if (
            !defs[key] ||
            defs[key].additive !==
              true
          ) {
            return;
          }

          rows.push({
            month: month,
            metric_key: key,
            metric_value:
              roundNumber_(
                values[key],
                6
              ),
            unit:
              defs[key].unit,
            calculated_at:
              calculatedAt
          });
        });

      var completed =
        Number(
          values.COMPLETED_ORDERS || 0
        );

      var revenue =
        Number(
          values.OPERATING_REVENUE || 0
        );

      var cashIn =
        Number(
          values.CASH_IN || 0
        );

      var cashOut =
        Number(
          values.CASH_OUT || 0
        );

      var spend =
        Number(
          values.MARKETING_SPEND || 0
        );

      var attributedRevenue =
        Number(
          values.ATTRIBUTED_REVENUE || 0
        );

      var ordersCreated =
        Number(
          values.ORDERS_CREATED || 0
        );

      var attributedOrders =
        Number(
          values.ATTRIBUTED_ORDERS || 0
        );

      var plans =
        Number(
          values.PRODUCTION_PLANS || 0
        );

      var completedPlans =
        Number(
          values.PRODUCTION_COMPLETED_PLANS || 0
        );

      var derived = [
        {
          key: 'AOV',
          value:
            completed > 0
              ? revenue / completed
              : 0
        },
        {
          key: 'CASH_NET',
          value:
            cashIn -
            cashOut
        },
        {
          key: 'ROAS',
          value:
            spend > 0
              ? attributedRevenue /
                spend
              : 0
        },
        {
          key:
            'ATTRIBUTION_COVERAGE_PCT',
          value:
            ordersCreated > 0
              ? (
                  attributedOrders /
                  ordersCreated
                ) * 100
              : 0
        },
        {
          key:
            'PRODUCTION_COMPLETION_RATE_PCT',
          value:
            plans > 0
              ? (
                  completedPlans /
                  plans
                ) * 100
              : 0
        }
      ];

      derived.forEach(function(item) {
        rows.push({
          month: month,
          metric_key:
            item.key,
          metric_value:
            roundNumber_(
              item.value,
              6
            ),
          unit:
            defs[
              item.key
            ].unit,
          calculated_at:
            calculatedAt
        });
      });
    });

  return rows;
}

function reportWriteCacheSheet_(
  sheetName,
  rows
) {
  var schema =
    getSheetSchema_(
      sheetName
    );

  var sheet =
    getDbSheet_(
      sheetName
    );

  var lastRow =
    sheet.getLastRow();

  if (lastRow > 1) {
    sheet
      .getRange(
        2,
        1,
        lastRow - 1,
        schema.headers.length
      )
      .clearContent();
  }

  if (!rows.length) {
    return 0;
  }

  var values =
    rows.map(function(row) {
      return objectToRow_(
        schema.headers,
        row
      );
    });

  sheet
    .getRange(
      2,
      1,
      values.length,
      schema.headers.length
    )
    .setValues(
      values
    );

  return rows.length;
}

function rebuildReportMetricCaches(
  payload
) {
  var access =
    reportAccess_();

  if (
    !access.canRebuildCache
  ) {
    throw twbError_(
      'FORBIDDEN',
      'Only OWNER or ADMIN can rebuild report caches.'
    );
  }

  payload = payload || {};

  var lookback =
    Number(
      payload.lookback_days ||
      getConfig_(
        'REPORT_CACHE_LOOKBACK_DAYS'
      ) ||
      400
    );

  lookback =
    Math.max(
      30,
      Math.min(
        1460,
        Math.round(
          lookback
        )
      )
    );

  var end =
    reportTodayKey_();

  var endDate =
    new Date(
      end + 'T12:00:00'
    );

  var startDate =
    new Date(
      endDate.getTime()
    );

  startDate.setDate(
    startDate.getDate() -
    (
      lookback - 1
    )
  );

  var start =
    Utilities.formatDate(
      startDate,
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd'
    );

  var period = {
    start: start,
    end: end,
    days: lookback
  };

  var daily =
    buildDailyMetricRows_(
      period
    );

  var monthly =
    aggregateMonthlyMetricRows_(
      daily
    );

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    reportWriteCacheSheet_(
      'DAILY_METRICS',
      daily
    );

    reportWriteCacheSheet_(
      'MONTHLY_METRICS',
      monthly
    );
  } finally {
    lock.releaseLock();
  }

  writeAuditLog_(
    'REBUILD',
    'DAILY_METRICS',
    start + ':' + end,
    null,
    {
      dailyRows:
        daily.length,
      monthlyRows:
        monthly.length,
      lookbackDays:
        lookback
    },
    'Report metric caches rebuilt.'
  );

  return {
    period: period,
    dailyRows:
      daily.length,
    monthlyRows:
      monthly.length,
    calculatedAt:
      nowIso_()
  };
}

function reportListAllCacheRows_(
  sheetName
) {
  return listAllRecords_(
    sheetName
  ).map(
    stripInternalFields_
  );
}

function reportFilterMetricRowsByAccess_(
  rows,
  access
) {
  var visible =
    visibleReportMetricKeys_(
      access
    );

  var map = {};

  visible.forEach(function(key) {
    map[key] = true;
  });

  return (rows || [])
    .filter(function(row) {
      return !!map[
        row.metric_key
      ];
    });
}

function reportPivotDailyRows_(
  rows
) {
  var map = {};

  (rows || [])
    .forEach(function(row) {
      var date =
        row.metric_date;

      if (!map[date]) {
        map[date] = {
          date: date
        };
      }

      map[date][
        row.metric_key
      ] =
        Number(
          row.metric_value || 0
        );
    });

  return Object.keys(map)
    .sort()
    .map(function(key) {
      return map[key];
    });
}

function reportWeekStartKey_(
  dateKey
) {
  var date =
    new Date(
      dateKey + 'T12:00:00'
    );

  var day =
    date.getDay();

  var delta =
    day === 0
      ? -6
      : 1 - day;

  date.setDate(
    date.getDate() +
    delta
  );

  return Utilities.formatDate(
    date,
    TWB_APP.TIMEZONE,
    'yyyy-MM-dd'
  );
}

function reportAggregateWeekly_(
  dailySeries
) {
  var weeks = {};

  (dailySeries || [])
    .forEach(function(row) {
      var week =
        reportWeekStartKey_(
          row.date
        );

      if (!weeks[week]) {
        weeks[week] = {
          week_start:
            week
        };
      }

      Object.keys(row)
        .forEach(function(key) {
          if (
            key === 'date'
          ) {
            return;
          }

          weeks[week][key] =
            (
              weeks[week][key] ||
              0
            ) +
            Number(
              row[key] || 0
            );
        });
    });

  return Object.keys(weeks)
    .sort()
    .map(function(key) {
      return weeks[key];
    });
}

function reportPivotMonthlyRows_(
  rows
) {
  var map = {};

  (rows || [])
    .forEach(function(row) {
      var month =
        row.month;

      if (!map[month]) {
        map[month] = {
          month: month
        };
      }

      map[month][
        row.metric_key
      ] =
        Number(
          row.metric_value || 0
        );
    });

  return Object.keys(map)
    .sort()
    .map(function(key) {
      return map[key];
    });
}

function reportOperationalSummary_(
  dailySeries
) {
  var summary = {
    productionPlans: 0,
    completedProductionPlans: 0,
    shortageRequirements: 0,
    wasteQty: 0,
    productionCompletionRatePct: 0
  };

  (dailySeries || [])
    .forEach(function(row) {
      summary.productionPlans +=
        Number(
          row.PRODUCTION_PLANS || 0
        );

      summary.completedProductionPlans +=
        Number(
          row.PRODUCTION_COMPLETED_PLANS || 0
        );

      summary.shortageRequirements +=
        Number(
          row.SHORTAGE_REQUIREMENTS || 0
        );

      summary.wasteQty +=
        Number(
          row.WASTE_QTY || 0
        );
    });

  summary.productionCompletionRatePct =
    summary.productionPlans > 0
      ? roundNumber_(
          (
            summary.completedProductionPlans /
            summary.productionPlans
          ) * 100,
          2
        )
      : 0;

  summary.wasteQty =
    roundNumber_(
      summary.wasteQty,
      3
    );

  return summary;
}

function reportMarketingSummary_(
  dailySeries
) {
  var summary = {
    spend: 0,
    attributedRevenue: 0,
    attributedOrders: 0,
    newCustomers: 0,
    ordersCreated: 0,
    roas: null,
    attributionCoveragePct: 0
  };

  (dailySeries || [])
    .forEach(function(row) {
      summary.spend +=
        Number(
          row.MARKETING_SPEND || 0
        );

      summary.attributedRevenue +=
        Number(
          row.ATTRIBUTED_REVENUE || 0
        );

      summary.attributedOrders +=
        Number(
          row.ATTRIBUTED_ORDERS || 0
        );

      summary.newCustomers +=
        Number(
          row.NEW_CUSTOMERS || 0
        );

      summary.ordersCreated +=
        Number(
          row.ORDERS_CREATED || 0
        );
    });

  summary.spend =
    Math.round(
      summary.spend
    );

  summary.attributedRevenue =
    Math.round(
      summary.attributedRevenue
    );

  summary.roas =
    summary.spend > 0
      ? roundNumber_(
          summary.attributedRevenue /
          summary.spend,
          2
        )
      : null;

  summary.attributionCoveragePct =
    summary.ordersCreated > 0
      ? roundNumber_(
          (
            summary.attributedOrders /
            summary.ordersCreated
          ) * 100,
          2
        )
      : 0;

  return summary;
}

function reportFinanceSummary_(
  period
) {
  var analytics =
    buildFinanceAnalytics_({
      period_start:
        period.start,
      period_end:
        period.end
    });

  return {
    completedOrders:
      analytics.pnl.completedOrders,
    productSales:
      analytics.pnl.productSales,
    deliveryRevenue:
      analytics.pnl.deliveryRevenue,
    operatingRevenue:
      analytics.pnl.operatingRevenue,
    cogs:
      analytics.pnl.cogs,
    grossProfit:
      analytics.pnl.grossProfit,
    grossMarginPct:
      analytics.pnl.grossMarginPct,
    operatingExpenses:
      analytics.pnl.operatingExpenses,
    operatingProfit:
      analytics.pnl.operatingProfit,
    operatingMarginPct:
      analytics.pnl.operatingMarginPct,
    estimatedCogs:
      analytics.pnl.estimatedCogs,
    cashIn:
      analytics.cash.cashIn,
    cashOut:
      analytics.cash.cashOut,
    netCash:
      analytics.cash.netCash
  };
}

function reportTargetActualMap_(
  report
) {
  var map = {};

  if (report.finance) {
    map.OPERATING_REVENUE =
      report.finance.operatingRevenue;

    map.COMPLETED_ORDERS =
      report.finance.completedOrders;

    map.OPERATING_PROFIT =
      report.finance.operatingProfit;

    map.GROSS_MARGIN_PCT =
      report.finance.grossMarginPct;
  }

  if (report.marketing) {
    map.ATTRIBUTED_REVENUE =
      report.marketing.attributedRevenue;

    map.ATTRIBUTED_ORDERS =
      report.marketing.attributedOrders;

    map.NEW_CUSTOMERS =
      report.marketing.newCustomers;
  }

  if (report.operational) {
    map.PRODUCTION_COMPLETED_PLANS =
      report.operational.completedProductionPlans;
  }

  return map;
}

function buildReportTargets_(
  period,
  access,
  report
) {
  var targets =
    listAllRecords_(
      'BUSINESS_TARGETS'
    )
      .filter(function(target) {
        return (
          String(
            target.status || ''
          ).toUpperCase() ===
            'ACTIVE' &&
          String(
            target.period_end || ''
          ) >=
            period.start &&
          String(
            target.period_start || ''
          ) <=
            period.end
        );
      });

  var actualMap =
    reportTargetActualMap_(
      report
    );

  return targets
    .map(function(target) {
      var def =
        reportTargetMetricDefinition_(
          target.metric_key
        );

      if (!def) {
        return null;
      }

      var visible = false;

      if (
        access.full
      ) {
        visible = true;
      } else if (
        access.marketing &&
        [
          'ATTRIBUTED_REVENUE',
          'ATTRIBUTED_ORDERS',
          'NEW_CUSTOMERS'
        ].indexOf(
          target.metric_key
        ) >= 0
      ) {
        visible = true;
      } else if (
        access.operational &&
        target.metric_key ===
          'PRODUCTION_COMPLETED_PLANS'
      ) {
        visible = true;
      }

      if (!visible) {
        return null;
      }

      var actual =
        Object.prototype.hasOwnProperty.call(
          actualMap,
          target.metric_key
        )
          ? Number(
              actualMap[
                target.metric_key
              ] || 0
            )
          : null;

      var targetValue =
        Number(
          target.target_value || 0
        );

      return Object.assign(
        {},
        stripInternalFields_(
          target
        ),
        {
          metric_label:
            def.label,
          actual_value:
            actual,
          variance:
            actual == null
              ? null
              : roundNumber_(
                  actual -
                  targetValue,
                  4
                ),
          achievement_pct:
            actual == null ||
            targetValue === 0
              ? null
              : roundNumber_(
                  (
                    actual /
                    targetValue
                  ) * 100,
                  2
                )
        }
      );
    })
    .filter(Boolean);
}

function createBusinessTargetPhase13(
  payload
) {
  var access =
    reportAccess_();

  if (
    !access.canWriteTarget
  ) {
    throw twbError_(
      'FORBIDDEN',
      'Business update permission is required to create targets.'
    );
  }

  payload = payload || {};

  var metricKey =
    String(
      payload.metric_key || ''
    ).toUpperCase();

  var def =
    reportTargetMetricDefinition_(
      metricKey
    );

  if (!def) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Unsupported target metric: ' +
      metricKey
    );
  }

  var periodType =
    String(
      payload.period_type ||
      'MONTHLY'
    ).toUpperCase();

  if (
    [
      'DAILY',
      'WEEKLY',
      'MONTHLY',
      'CUSTOM'
    ].indexOf(
      periodType
    ) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Invalid target period type.'
    );
  }

  var start =
    reportDateKey_(
      payload.period_start
    );

  var end =
    reportDateKey_(
      payload.period_end
    );

  if (
    !start ||
    !end ||
    start > end
  ) {
    throw twbError_(
      'REPORT_TARGET_PERIOD_INVALID',
      'Target requires a valid period.'
    );
  }

  var targetValue =
    requireNonNegative_(
      payload.target_value,
      'target_value'
    );

  var id =
    nextBusinessId(
      'TARGET'
    );

  var now =
    nowIso_();

  var record = {
    target_id:
      id,
    period_type:
      periodType,
    period_start:
      start,
    period_end:
      end,
    metric_key:
      metricKey,
    target_value:
      targetValue,
    unit:
      def.unit,
    status:
      'ACTIVE',
    created_at:
      now,
    created_by:
      access.user.user_id,
    updated_at:
      now,
    updated_by:
      access.user.user_id
  };

  dbInsertRecord(
    'BUSINESS_TARGETS',
    record,
    {
      validate: true,
      audit: false
    }
  );

  writeAuditLog_(
    'CREATE',
    'BUSINESS_TARGETS',
    id,
    null,
    record,
    'Business target created from Reports.'
  );

  return stripInternalFields_(
    record
  );
}

function updateBusinessTargetStatusPhase13(
  targetId,
  status
) {
  var access =
    reportAccess_();

  if (
    !access.canWriteTarget
  ) {
    throw twbError_(
      'FORBIDDEN',
      'Business update permission is required to update targets.'
    );
  }

  var target =
    dbFindById(
      'BUSINESS_TARGETS',
      targetId
    );

  if (!target) {
    throw twbError_(
      'NOT_FOUND',
      'Business target not found: ' +
      targetId
    );
  }

  var normalized =
    String(
      status || ''
    ).toUpperCase();

  if (
    [
      'ACTIVE',
      'ARCHIVED',
      'CANCELLED'
    ].indexOf(
      normalized
    ) < 0
  ) {
    throw twbError_(
      'VALIDATION_ENUM',
      'Invalid target status.'
    );
  }

  return dbUpdateById(
    'BUSINESS_TARGETS',
    targetId,
    stampUpdate_(
      access.user,
      {
        status:
          normalized
      }
    ),
    {
      validate: true,
      audit: true,
      action:
        'STATUS_CHANGE'
    }
  );
}

function reportCacheStatus_() {
  var daily =
    reportListAllCacheRows_(
      'DAILY_METRICS'
    );

  var monthly =
    reportListAllCacheRows_(
      'MONTHLY_METRICS'
    );

  var latest = '';

  daily
    .concat(
      monthly
    )
    .forEach(function(row) {
      if (
        String(
          row.calculated_at || ''
        ) > latest
      ) {
        latest =
          String(
            row.calculated_at || ''
          );
      }
    });

  return {
    dailyRows:
      daily.length,
    monthlyRows:
      monthly.length,
    calculatedAt:
      latest
  };
}

function reportModuleBootstrap(
  payload
) {
  var access =
    reportAccess_();

  var period =
    normalizeReportPeriod_(
      payload
    );

  var liveDailyRows =
    buildDailyMetricRows_(
      period
    );

  var visibleDailyRows =
    reportFilterMetricRowsByAccess_(
      liveDailyRows,
      access
    );

  var dailySeries =
    reportPivotDailyRows_(
      visibleDailyRows
    );

  var report = {
    period: period,
    access: {
      full:
        access.full,
      operational:
        access.operational,
      marketing:
        access.marketing,
      canRebuildCache:
        access.canRebuildCache,
      canWriteTarget:
        access.canWriteTarget
    },
    finance:
      access.full
        ? reportFinanceSummary_(
            period
          )
        : null,
    operational:
      access.operational
        ? reportOperationalSummary_(
            dailySeries
          )
        : null,
    marketing:
      access.marketing
        ? reportMarketingSummary_(
            dailySeries
          )
        : null,
    daily:
      dailySeries,
    weekly:
      reportAggregateWeekly_(
        dailySeries
      ),
    monthly:
      [],
    targets: [],
    cache:
      reportCacheStatus_(),
    metricDefinitions:
      reportMetricDefinitions_(),
    targetMetricKeys:
      reportTargetMetricKeys_()
  };

  var monthlyRows =
    reportFilterMetricRowsByAccess_(
      reportListAllCacheRows_(
        'MONTHLY_METRICS'
      ),
      access
    );

  if (!monthlyRows.length) {
    monthlyRows =
      reportFilterMetricRowsByAccess_(
        aggregateMonthlyMetricRows_(
          liveDailyRows
        ),
        access
      );
  }

  report.monthly =
    reportPivotMonthlyRows_(
      monthlyRows
    )
      .slice(-18);

  report.targets =
    buildReportTargets_(
      period,
      access,
      report
    );

  return report;
}

function csvEscapeReportValue_(value) {
  if (
    value === null ||
    value === undefined
  ) {
    return '';
  }

  var text =
    String(value);

  if (
    text.indexOf('"') >= 0
  ) {
    text =
      text.replace(
        /"/g,
        '""'
      );
  }

  if (
    /[",\n\r]/.test(
      text
    )
  ) {
    return '"' +
      text +
      '"';
  }

  return text;
}

function reportObjectsToCsv_(
  rows,
  headers
) {
  var lines = [];

  lines.push(
    headers
      .map(
        csvEscapeReportValue_
      )
      .join(',')
  );

  (rows || [])
    .forEach(function(row) {
      lines.push(
        headers
          .map(function(header) {
            return csvEscapeReportValue_(
              row[header]
            );
          })
          .join(',')
      );
    });

  return lines.join(
    '\r\n'
  );
}

function reportSummaryExportRows_(
  report
) {
  var rows = [];

  if (report.finance) {
    [
      ['COMPLETED_ORDERS', report.finance.completedOrders, 'COUNT'],
      ['OPERATING_REVENUE', report.finance.operatingRevenue, 'IDR'],
      ['COGS', report.finance.cogs, 'IDR'],
      ['GROSS_PROFIT', report.finance.grossProfit, 'IDR'],
      ['GROSS_MARGIN_PCT', report.finance.grossMarginPct, 'PERCENT'],
      ['OPERATING_EXPENSES', report.finance.operatingExpenses, 'IDR'],
      ['OPERATING_PROFIT', report.finance.operatingProfit, 'IDR'],
      ['OPERATING_MARGIN_PCT', report.finance.operatingMarginPct, 'PERCENT'],
      ['CASH_IN', report.finance.cashIn, 'IDR'],
      ['CASH_OUT', report.finance.cashOut, 'IDR'],
      ['NET_CASH', report.finance.netCash, 'IDR']
    ].forEach(function(item) {
      rows.push({
        metric_key:
          item[0],
        metric_value:
          item[1],
        unit:
          item[2]
      });
    });
  }

  if (report.operational) {
    [
      ['PRODUCTION_PLANS', report.operational.productionPlans, 'COUNT'],
      ['PRODUCTION_COMPLETED_PLANS', report.operational.completedProductionPlans, 'COUNT'],
      ['PRODUCTION_COMPLETION_RATE_PCT', report.operational.productionCompletionRatePct, 'PERCENT'],
      ['SHORTAGE_REQUIREMENTS', report.operational.shortageRequirements, 'COUNT'],
      ['WASTE_QTY', report.operational.wasteQty, 'QTY']
    ].forEach(function(item) {
      rows.push({
        metric_key:
          item[0],
        metric_value:
          item[1],
        unit:
          item[2]
      });
    });
  }

  if (report.marketing) {
    [
      ['MARKETING_SPEND', report.marketing.spend, 'IDR'],
      ['ATTRIBUTED_REVENUE', report.marketing.attributedRevenue, 'IDR'],
      ['ATTRIBUTED_ORDERS', report.marketing.attributedOrders, 'COUNT'],
      ['NEW_CUSTOMERS', report.marketing.newCustomers, 'COUNT'],
      ['ROAS', report.marketing.roas, 'RATIO'],
      ['ATTRIBUTION_COVERAGE_PCT', report.marketing.attributionCoveragePct, 'PERCENT']
    ].forEach(function(item) {
      rows.push({
        metric_key:
          item[0],
        metric_value:
          item[1],
        unit:
          item[2]
      });
    });
  }

  return rows;
}

function reportExportCsv(
  payload
) {
  var access =
    reportAccess_();

  payload = payload || {};

  var type =
    String(
      payload.export_type ||
      'SUMMARY'
    ).toUpperCase();

  var report =
    reportModuleBootstrap(
      payload
    );

  var rows = [];
  var headers = [];
  var suffix =
    report.period.start +
    '_' +
    report.period.end;

  if (
    type === 'SUMMARY'
  ) {
    rows =
      reportSummaryExportRows_(
        report
      );

    headers = [
      'metric_key',
      'metric_value',
      'unit'
    ];
  } else if (
    type === 'DAILY'
  ) {
    rows =
      report.daily;

    headers =
      Object.keys(
        rows[0] || {
          date: ''
        }
      );
  } else if (
    type === 'WEEKLY'
  ) {
    rows =
      report.weekly;

    headers =
      Object.keys(
        rows[0] || {
          week_start: ''
        }
      );
  } else if (
    type === 'MONTHLY'
  ) {
    rows =
      report.monthly;

    headers =
      Object.keys(
        rows[0] || {
          month: ''
        }
      );
  } else if (
    type === 'TARGETS'
  ) {
    rows =
      report.targets;

    headers = [
      'target_id',
      'period_type',
      'period_start',
      'period_end',
      'metric_key',
      'metric_label',
      'target_value',
      'actual_value',
      'variance',
      'achievement_pct',
      'unit',
      'status'
    ];
  } else if (
    type ===
      'MARKETING_ATTRIBUTION'
  ) {
    if (!access.marketing) {
      throw twbError_(
        'FORBIDDEN',
        'Marketing report access is required.'
      );
    }

    rows =
      buildMarketingAnalytics_()
        .attributedOrders;

    headers = [
      'order_id',
      'order_date',
      'customer_id',
      'customer_name',
      'source_channel',
      'order_status',
      'payment_status',
      'grand_total',
      'operating_revenue',
      'marketing_campaign_id',
      'content_id',
      'attribution_model',
      'new_customer'
    ];
  } else if (
    type ===
      'FINANCE_TRANSACTIONS'
  ) {
    if (!access.full) {
      throw twbError_(
        'FORBIDDEN',
        'Full report access is required.'
      );
    }

    rows =
      listAllRecords_(
        'TRANSACTIONS'
      )
        .filter(function(row) {
          return reportValueInPeriod_(
            row.transaction_at,
            report.period
          );
        })
        .map(
          stripInternalFields_
        );

    headers =
      getSheetSchema_(
        'TRANSACTIONS'
      ).headers;
  } else if (
    type ===
      'PRODUCTION_PLANS'
  ) {
    if (!access.operational) {
      throw twbError_(
        'FORBIDDEN',
        'Operational report access is required.'
      );
    }

    rows =
      listAllRecords_(
        'PRODUCTION_PLANS'
      )
        .filter(function(row) {
          return reportValueInPeriod_(
            row.production_date,
            report.period
          );
        })
        .map(
          stripInternalFields_
        );

    headers =
      getSheetSchema_(
        'PRODUCTION_PLANS'
      ).headers;
  } else {
    throw twbError_(
      'REPORT_EXPORT_TYPE_INVALID',
      'Unsupported export type: ' +
      type
    );
  }

  var filename =
    'twolittle-bites_' +
    type.toLowerCase() +
    '_' +
    suffix +
    '.csv';

  return {
    filename:
      filename,
    mimeType:
      'text/csv;charset=utf-8',
    csv:
      reportObjectsToCsv_(
        rows,
        headers
      ),
    rowCount:
      rows.length
  };
}
