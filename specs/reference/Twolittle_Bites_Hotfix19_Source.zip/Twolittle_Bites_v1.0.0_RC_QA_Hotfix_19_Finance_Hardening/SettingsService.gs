/**
 * Twolittle.bites OS — Phase 14 Settings & Administration
 *
 * Configuration writes are whitelist-based.
 * USERS are never deleted; OWNER-only governance protects lockout.
 */

function settingsReadUser_() {
  return requirePermission_(
    'SETTINGS_READ'
  );
}

function settingsWriteUser_() {
  return requirePermission_(
    'SETTINGS_WRITE'
  );
}

function settingsOwnerUser_() {
  return requireRole_([
    TWB_ROLES.OWNER
  ]);
}

function settingsRoles_() {
  return Object.keys(
    TWB_ROLES
  ).map(function(key) {
    return TWB_ROLES[key];
  });
}

function settingsNormalizeToken_(
  value
) {
  return String(
    value || ''
  )
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function settingsNormalizeList_(
  value,
  options
) {
  options = options || {};

  var raw = [];

  if (Array.isArray(value)) {
    raw = value;
  } else {
    raw =
      String(
        value || ''
      )
        .split(
          /[\n,;]+/
        );
  }

  var seen = {};
  var rows = [];

  raw.forEach(function(item) {
    var token =
      settingsNormalizeToken_(
        item
      );

    if (!token) return;

    if (
      !seen[token]
    ) {
      seen[token] = true;
      rows.push(token);
    }
  });

  var min =
    Number(
      options.min || 1
    );

  var max =
    Number(
      options.max || 40
    );

  if (
    rows.length < min
  ) {
    throw twbError_(
      'SETTINGS_LIST_REQUIRED',
      (
        options.label ||
        'Setting list'
      ) +
      ' requires at least ' +
      min +
      ' value(s).'
    );
  }

  if (
    rows.length > max
  ) {
    throw twbError_(
      'SETTINGS_LIST_TOO_LARGE',
      (
        options.label ||
        'Setting list'
      ) +
      ' cannot exceed ' +
      max +
      ' values.'
    );
  }

  (options.requiredTokens || [])
    .forEach(function(required) {
      if (
        rows.indexOf(
          required
        ) < 0
      ) {
        throw twbError_(
          'SETTINGS_REQUIRED_TOKEN',
          (
            options.label ||
            'Setting list'
          ) +
          ' must include ' +
          required +
          '.'
        );
      }
    });

  return rows;
}

function settingsBoolean_(
  value
) {
  if (
    value === true ||
    value === false
  ) {
    return value;
  }

  var normalized =
    String(
      value || ''
    ).toUpperCase();

  return (
    normalized === 'TRUE' ||
    normalized === '1' ||
    normalized === 'YES' ||
    normalized === 'ON'
  );
}

function settingsNumberInRange_(
  value,
  field,
  min,
  max
) {
  var numeric =
    Number(value);

  if (
    !isFinite(numeric) ||
    numeric < min ||
    numeric > max
  ) {
    throw twbError_(
      'SETTINGS_NUMBER_RANGE',
      field +
      ' must be between ' +
      min +
      ' and ' +
      max +
      '.'
    );
  }

  return numeric;
}

function settingsText_(
  value,
  field,
  minLength,
  maxLength
) {
  var text =
    normalizeText_(
      value
    );

  if (
    text.length <
      minLength ||
    text.length >
      maxLength
  ) {
    throw twbError_(
      'SETTINGS_TEXT_LENGTH',
      field +
      ' must be ' +
      minLength +
      '–' +
      maxLength +
      ' characters.'
    );
  }

  return text;
}

function settingsReceiptPaperSize_(value) {
  var size = String(
    value || ''
  ).trim();

  if (
    ['58', '80'].indexOf(size) < 0
  ) {
    throw twbError_(
      'SETTINGS_RECEIPT_PAPER_INVALID',
      'Receipt paper size must be 58 or 80 mm.'
    );
  }

  return size;
}

function settingsInvoicePrefix_(
  value
) {
  var prefix =
    String(
      value || ''
    )
      .trim()
      .toUpperCase();

  if (
    !/^[A-Z0-9][A-Z0-9-]{1,19}$/.test(
      prefix
    )
  ) {
    throw twbError_(
      'SETTINGS_INVOICE_PREFIX_INVALID',
      'Invoice prefix must be 2–20 characters using A–Z, 0–9, or hyphen.'
    );
  }

  return prefix;
}

function settingsCountryCode_(
  value
) {
  var code =
    String(
      value || ''
    )
      .replace(
        /[^\d]/g,
        ''
      );

  if (
    !/^\d{1,4}$/.test(
      code
    )
  ) {
    throw twbError_(
      'SETTINGS_COUNTRY_CODE_INVALID',
      'WhatsApp country code must contain 1–4 digits.'
    );
  }

  return code;
}


function settingsUrlOrBlank_(
  value,
  field,
  maxLength
) {
  var text = normalizeText_(
    value
  );

  if (!text) {
    return '';
  }

  if (
    text.length > maxLength
  ) {
    throw twbError_(
      'SETTINGS_URL_LENGTH',
      field +
      ' cannot exceed ' +
      maxLength +
      ' characters.'
    );
  }

  var isHttp =
    /^https?:\/\/\S+$/i.test(
      text
    );

  var isDataImage =
    /^data:image\/[a-z0-9.+-]+;base64,[a-z0-9+/=\s]+$/i.test(
      text
    );

  if (
    !isHttp &&
    !isDataImage
  ) {
    throw twbError_(
      'SETTINGS_URL_INVALID',
      field +
      ' must be a valid http(s) image URL or a data:image base64 string.'
    );
  }

  return text;
}

function settingsDefaultInvoiceWhatsAppTemplate_() {
  return [
    'Hi {customer_name} 👋',
    '',
    'Berikut invoice dari {business_name}:',
    '{invoice_number}',
    'Diskon: {discount}',
    'Ongkir: {delivery_fee}',
    'Total: {total}',
    'Sisa pembayaran: {remaining}',
    'Jatuh tempo: {due_at}',
    '',
    'Lihat invoice:',
    '{invoice_pdf_url}',
    '',
    'Terima kasih 🤎'
  ].join('\n');
}


function settingsDefaultInvoicePublicTitle_() {
  return 'Invoice';
}

function settingsDefaultInvoicePublicNote_() {
  return 'Please follow the payment instructions shared directly by the seller.';
}

function settingsValidateInvoicePublicTitle_(value) {
  return settingsText_(
    value,
    'Public invoice title',
    2,
    60
  );
}

function settingsValidateInvoicePublicNote_(value) {
  var text =
    normalizeText_(
      value
    );

  if (
    text.length > 500
  ) {
    throw twbError_(
      'SETTINGS_INVOICE_NOTE_LENGTH',
      'Public invoice note cannot exceed 500 characters.'
    );
  }

  return text;
}

function settingsAllowedWhatsAppPlaceholders_() {
  return [
    'customer_name',
    'business_name',
    'invoice_number',
    'products',
    'discount',
    'delivery_fee',
    'total',
    'remaining',
    'due_at',
    'invoice_url',
    'invoice_pdf_url'
  ];
}

function settingsValidateWhatsAppTemplate_(
  value
) {
  var template =
    String(
      value || ''
    );

  if (
    template.length < 10 ||
    template.length > 2000
  ) {
    throw twbError_(
      'SETTINGS_WA_TEMPLATE_LENGTH',
      'WhatsApp invoice template must be 10–2000 characters.'
    );
  }

  var allowed = {};
  settingsAllowedWhatsAppPlaceholders_()
    .forEach(function(key) {
      allowed[key] = true;
    });

  var matches =
    template.match(
      /\{[a-z_]+\}/g
    ) || [];

  matches.forEach(function(match) {
    var key =
      match
        .replace(
          /^\{|\}$/g,
          ''
        );

    if (
      !allowed[key]
    ) {
      throw twbError_(
        'SETTINGS_WA_TEMPLATE_PLACEHOLDER',
        'Unknown WhatsApp placeholder: ' +
        match
      );
    }
  });

  if (
    template.indexOf(
      '{invoice_number}'
    ) < 0 ||
    (
      template.indexOf(
        '{invoice_url}'
      ) < 0 &&
      template.indexOf(
        '{invoice_pdf_url}'
      ) < 0
    )
  ) {
    throw twbError_(
      'SETTINGS_WA_TEMPLATE_REQUIRED_PLACEHOLDER',
      'WhatsApp template must include {invoice_number} and at least one of {invoice_url} or {invoice_pdf_url}.'
    );
  }

  return template;
}

function renderSettingsTemplate_(
  template,
  values
) {
  values = values || {};

  return String(
    template || ''
  ).replace(
    /\{([a-z_]+)\}/g,
    function(match, key) {
      return Object.prototype.hasOwnProperty.call(
        values,
        key
      )
        ? String(
            values[key] == null
              ? ''
              : values[key]
          )
        : match;
    }
  );
}

function settingsSnapshot_() {
  return {
    business: {
      business_name:
        getBusinessSetting_(
          'business_name'
        ) ||
        'Twolittle.bites',
      brand_logo_url:
        getBusinessSetting_(
          'brand_logo_url'
        ) ||
        '',
      timezone:
        getBusinessSetting_(
          'timezone'
        ) ||
        TWB_APP.TIMEZONE,
      currency:
        getBusinessSetting_(
          'currency'
        ) ||
        TWB_APP.CURRENCY,
      whatsapp_country_code:
        getBusinessSetting_(
          'whatsapp_country_code'
        ) ||
        '62'
    },
    commerce: {
      sales_channels:
        getConfig_(
          'SALES_CHANNELS'
        ) || [],
      fulfillment_types:
        getConfig_(
          'FULFILLMENT_TYPES'
        ) || [],
      payment_methods:
        getConfig_(
          'PAYMENT_METHODS'
        ) || [],
      expense_categories:
        getConfig_(
          'EXPENSE_CATEGORIES'
        ) || []
    },
    printing:
      typeof receiptPrintingSettings_ ===
        'function'
        ? receiptPrintingSettings_()
        : {
            printMode: 'BROWSER',
            paperSize: '80',
            paperWidthMm: 80,
            contentWidthMm: 72,
            copies: 1,
            autoPrintAfterPayment: false,
            showLogo: true,
            showCustomer: true,
            showPaymentMethod: true,
            kitchenTicketEnabled: false
          },
    invoice: {
      invoice_prefix:
        getBusinessSetting_(
          'invoice_prefix'
        ) ||
        'INV-TLB',
      invoice_due_hours:
        Number(
          getBusinessSetting_(
            'invoice_due_hours'
          ) ||
          24
        ),
      invoice_public_title:
        getBusinessSetting_(
          'invoice_public_title'
        ) ||
        settingsDefaultInvoicePublicTitle_(),
      invoice_public_note:
        getBusinessSetting_(
          'invoice_public_note'
        ) ||
        settingsDefaultInvoicePublicNote_(),
      invoice_whatsapp_template:
        getBusinessSetting_(
          'invoice_whatsapp_template'
        ) ||
        settingsDefaultInvoiceWhatsAppTemplate_()
    },
    automation: {
      auto_invoice_on_order:
        getConfig_(
          'AUTO_INVOICE_ON_ORDER'
        ) !== false,
      auto_confirm_on_paid:
        getConfig_(
          'AUTO_CONFIRM_ON_PAID'
        ) !== false,
      negative_stock_allowed:
        getConfig_(
          'NEGATIVE_STOCK_ALLOWED'
        ) === true,
      allow_admin_preorder_override:
        getConfig_(
          'ALLOW_ADMIN_PREORDER_OVERRIDE'
        ) === true,
      preorder_almost_full_ratio:
        Number(
          getConfig_(
            'PREORDER_ALMOST_FULL_RATIO'
          ) ||
          0.20
        ),
      crm_dormant_days:
        Number(
          getConfig_(
            'CRM_DORMANT_DAYS'
          ) ||
          60
        ),
      report_cache_lookback_days:
        Number(
          getConfig_(
            'REPORT_CACHE_LOOKBACK_DAYS'
          ) ||
          400
        )
    }
  };
}

function settingsUsersForOwner_() {
  var user =
    requireCurrentUser_();

  if (
    user.role !==
    TWB_ROLES.OWNER
  ) {
    return [];
  }

  return listAllRecords_(
    'USERS'
  )
    .map(
      sanitizeUser_
    )
    .sort(function(a, b) {
      if (
        a.status !==
        b.status
      ) {
        return String(
          a.status
        ).localeCompare(
          String(
            b.status
          )
        );
      }

      return String(
        a.display_name || ''
      ).localeCompare(
        String(
          b.display_name || ''
        )
      );
    });
}

function settingsModuleBootstrap() {
  var user =
    settingsReadUser_();

  var schema =
    validateDatabaseSchema();

  return {
    settings:
      settingsSnapshot_(),
    users:
      user.role ===
        TWB_ROLES.OWNER
        ? settingsUsersForOwner_()
        : [],
    roles:
      settingsRoles_(),
    permissions: {
      canWriteSettings:
        hasPermission_(
          user,
          'SETTINGS_WRITE'
        ),
      canManageUsers:
        user.role ===
          TWB_ROLES.OWNER,
      canRunDiagnostics:
        hasPermission_(
          user,
          'SETTINGS_WRITE'
        ),
      canManageSystem:
        user.role ===
          TWB_ROLES.OWNER,
      canViewRelease:
        hasPermission_(
          user,
          'SETTINGS_WRITE'
        ),
      canManageRelease:
        user.role ===
          TWB_ROLES.OWNER
    },
    system: {
      appVersion:
        TWB_APP.APP_VERSION,
      schemaVersion:
        TWB_APP.SCHEMA_VERSION,
      phase:
        Number(
          TWB_APP.PHASE
        ),
      timezone:
        TWB_APP.TIMEZONE,
      currency:
        TWB_APP.CURRENCY,
      schemaOk:
        schema.ok,
      validSheets:
        schema.sheets.filter(
          function(row) {
            return row.ok;
          }
        ).length,
      expectedSheets:
        schema.sheets.length,
      webAppUrl:
        typeof getWebAppBaseUrl_ ===
          'function'
          ? getWebAppBaseUrl_()
          : ''
    },
    placeholders:
      settingsAllowedWhatsAppPlaceholders_()
  };
}

function updateBusinessSettingsPhase14(
  payload
) {
  var user =
    settingsWriteUser_();

  payload = payload || {};

  var businessName =
    settingsText_(
      payload.business_name,
      'Business name',
      2,
      100
    );

  var countryCode =
    settingsCountryCode_(
      payload.whatsapp_country_code
    );

  var brandLogoUrl =
    settingsUrlOrBlank_(
      payload.brand_logo_url,
      'Brand logo URL',
      120000
    );

  var before =
    settingsSnapshot_()
      .business;

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    setBusinessSetting_(
      'business_name',
      businessName,
      'STRING',
      'BUSINESS',
      'Business display name.',
      user.user_id
    );

    setBusinessSetting_(
      'whatsapp_country_code',
      countryCode,
      'STRING',
      'WHATSAPP',
      'Default country prefix for WhatsApp normalization.',
      user.user_id
    );

    setBusinessSetting_(
      'brand_logo_url',
      brandLogoUrl,
      'STRING',
      'BUSINESS',
      'Public business logo URL shown on invoices.',
      user.user_id
    );
  } finally {
    lock.releaseLock();
  }

  var after =
    settingsSnapshot_()
      .business;

  writeAuditLog_(
    'UPDATE',
    'BUSINESS_SETTINGS',
    'BUSINESS_PROFILE',
    before,
    after,
    'Business settings updated.'
  );

  return after;
}

function updateCommerceSettingsPhase14(
  payload
) {
  var user =
    settingsWriteUser_();

  payload = payload || {};

  var salesChannels =
    settingsNormalizeList_(
      payload.sales_channels,
      {
        label:
          'Sales channels',
        min: 1,
        max: 30
      }
    );

  var fulfillmentTypes =
    settingsNormalizeList_(
      payload.fulfillment_types,
      {
        label:
          'Fulfillment types',
        min: 1,
        max: 20
      }
    );

  var paymentMethods =
    settingsNormalizeList_(
      payload.payment_methods,
      {
        label:
          'Payment methods',
        min: 1,
        max: 20
      }
    );

  var expenseCategories =
    settingsNormalizeList_(
      payload.expense_categories,
      {
        label:
          'Expense categories',
        min: 2,
        max: 40,
        requiredTokens: [
          'MARKETING',
          'ADS'
        ]
      }
    );

  var before =
    settingsSnapshot_()
      .commerce;

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    setConfig_(
      'SALES_CHANNELS',
      salesChannels,
      'JSON',
      'Allowed order source channels.',
      user.user_id
    );

    setConfig_(
      'FULFILLMENT_TYPES',
      fulfillmentTypes,
      'JSON',
      'Allowed fulfillment types.',
      user.user_id
    );

    setConfig_(
      'PAYMENT_METHODS',
      paymentMethods,
      'JSON',
      'Available payment methods.',
      user.user_id
    );

    setBusinessSetting_(
      'payment_methods',
      paymentMethods,
      'JSON',
      'PAYMENT',
      'Available payment methods.',
      user.user_id
    );

    setConfig_(
      'EXPENSE_CATEGORIES',
      expenseCategories,
      'JSON',
      'Allowed expense categories.',
      user.user_id
    );
  } finally {
    lock.releaseLock();
  }

  var after =
    settingsSnapshot_()
      .commerce;

  writeAuditLog_(
    'UPDATE',
    'CONFIG',
    'COMMERCE_SETTINGS',
    before,
    after,
    'Commerce configuration updated.'
  );

  return after;
}

function updateInvoiceSettingsPhase14(
  payload
) {
  var user =
    settingsWriteUser_();

  payload = payload || {};

  var prefix =
    settingsInvoicePrefix_(
      payload.invoice_prefix
    );

  var dueHours =
    settingsNumberInRange_(
      payload.invoice_due_hours,
      'Invoice due hours',
      1,
      720
    );

  var publicTitle =
    settingsValidateInvoicePublicTitle_(
      payload.invoice_public_title ||
      settingsDefaultInvoicePublicTitle_()
    );

  var publicNote =
    settingsValidateInvoicePublicNote_(
      payload.invoice_public_note
    );

  var template =
    settingsValidateWhatsAppTemplate_(
      payload.invoice_whatsapp_template
    );

  var before =
    settingsSnapshot_()
      .invoice;

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    setBusinessSetting_(
      'invoice_prefix',
      prefix,
      'STRING',
      'INVOICE',
      'Invoice display prefix.',
      user.user_id
    );

    setBusinessSetting_(
      'invoice_due_hours',
      dueHours,
      'NUMBER',
      'INVOICE',
      'Default invoice payment due time in hours.',
      user.user_id
    );

    setBusinessSetting_(
      'invoice_public_title',
      publicTitle,
      'STRING',
      'INVOICE',
      'Public invoice heading shown above the invoice number.',
      user.user_id
    );

    setBusinessSetting_(
      'invoice_public_note',
      publicNote,
      'STRING',
      'INVOICE',
      'Public invoice note shown in the footer.',
      user.user_id
    );

    setBusinessSetting_(
      'invoice_whatsapp_template',
      template,
      'STRING',
      'WHATSAPP',
      'Invoice WhatsApp deep-link message template.',
      user.user_id
    );
  } finally {
    lock.releaseLock();
  }

  var after =
    settingsSnapshot_()
      .invoice;

  writeAuditLog_(
    'UPDATE',
    'BUSINESS_SETTINGS',
    'INVOICE_WHATSAPP_SETTINGS',
    before,
    after,
    'Invoice and WhatsApp settings updated.'
  );

  return after;
}

function updatePrintingSettingsPhase14(payload) {
  var user =
    settingsWriteUser_();

  payload = payload || {};

  var values = {
    paperSize:
      settingsReceiptPaperSize_(
        payload.receipt_paper_size
      ),
    copies:
      Math.round(
        settingsNumberInRange_(
          payload.receipt_copies,
          'Receipt copies',
          1,
          3
        )
      ),
    autoPrintAfterPayment:
      settingsBoolean_(
        payload.receipt_auto_print_after_payment
      ),
    showLogo:
      settingsBoolean_(
        payload.receipt_show_logo
      ),
    showCustomer:
      settingsBoolean_(
        payload.receipt_show_customer
      ),
    showPaymentMethod:
      settingsBoolean_(
        payload.receipt_show_payment_method
      ),
    kitchenTicketEnabled:
      settingsBoolean_(
        payload.kitchen_ticket_enabled
      )
  };

  var before =
    settingsSnapshot_()
      .printing;

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    setBusinessSetting_(
      'receipt_paper_size',
      values.paperSize,
      'STRING',
      'PRINTING',
      'Browser thermal receipt paper size in millimeters.',
      user.user_id
    );

    setBusinessSetting_(
      'receipt_copies',
      values.copies,
      'NUMBER',
      'PRINTING',
      'Suggested receipt copy count. Browser print dialog controls actual copies.',
      user.user_id
    );

    setBusinessSetting_(
      'receipt_auto_print_after_payment',
      values.autoPrintAfterPayment,
      'BOOLEAN',
      'PRINTING',
      'Open the browser receipt print flow after a payment is recorded.',
      user.user_id
    );

    setBusinessSetting_(
      'receipt_show_logo',
      values.showLogo,
      'BOOLEAN',
      'PRINTING',
      'Show the configured business logo on receipt.',
      user.user_id
    );

    setBusinessSetting_(
      'receipt_show_customer',
      values.showCustomer,
      'BOOLEAN',
      'PRINTING',
      'Show customer identity on receipt and kitchen ticket.',
      user.user_id
    );

    setBusinessSetting_(
      'receipt_show_payment_method',
      values.showPaymentMethod,
      'BOOLEAN',
      'PRINTING',
      'Show the latest successful payment method on receipt.',
      user.user_id
    );

    setBusinessSetting_(
      'kitchen_ticket_enabled',
      values.kitchenTicketEnabled,
      'BOOLEAN',
      'PRINTING',
      'Enable browser-print kitchen ticket action.',
      user.user_id
    );
  } finally {
    lock.releaseLock();
  }

  var after =
    settingsSnapshot_()
      .printing;

  writeAuditLog_(
    'UPDATE',
    'BUSINESS_SETTINGS',
    'PRINTING_SETTINGS',
    before,
    after,
    'Receipt and kitchen printing settings updated.'
  );

  return after;
}

function updateAutomationSettingsPhase14(
  payload
) {
  var user =
    settingsWriteUser_();

  payload = payload || {};

  var values = {
    auto_invoice_on_order:
      settingsBoolean_(
        payload.auto_invoice_on_order
      ),
    auto_confirm_on_paid:
      settingsBoolean_(
        payload.auto_confirm_on_paid
      ),
    negative_stock_allowed:
      settingsBoolean_(
        payload.negative_stock_allowed
      ),
    allow_admin_preorder_override:
      settingsBoolean_(
        payload.allow_admin_preorder_override
      ),
    preorder_almost_full_ratio:
      settingsNumberInRange_(
        payload.preorder_almost_full_ratio,
        'Pre-order almost-full ratio',
        0.05,
        0.50
      ),
    crm_dormant_days:
      Math.round(
        settingsNumberInRange_(
          payload.crm_dormant_days,
          'CRM dormant days',
          7,
          3650
        )
      ),
    report_cache_lookback_days:
      Math.round(
        settingsNumberInRange_(
          payload.report_cache_lookback_days,
          'Report cache lookback days',
          30,
          1460
        )
      )
  };

  var before =
    settingsSnapshot_()
      .automation;

  var lock =
    LockService.getScriptLock();

  lock.waitLock(30000);

  try {
    setConfig_(
      'AUTO_INVOICE_ON_ORDER',
      values.auto_invoice_on_order,
      'BOOLEAN',
      'Automatically create invoice after new Order.',
      user.user_id
    );

    setConfig_(
      'AUTO_CONFIRM_ON_PAID',
      values.auto_confirm_on_paid,
      'BOOLEAN',
      'Move WAITING_PAYMENT Order to CONFIRMED when fully paid.',
      user.user_id
    );

    setConfig_(
      'NEGATIVE_STOCK_ALLOWED',
      values.negative_stock_allowed,
      'BOOLEAN',
      'Allow inventory balance below zero.',
      user.user_id
    );

    setConfig_(
      'ALLOW_ADMIN_PREORDER_OVERRIDE',
      values.allow_admin_preorder_override,
      'BOOLEAN',
      'Allow ADMIN pre-order capacity/cutoff override.',
      user.user_id
    );

    setConfig_(
      'PREORDER_ALMOST_FULL_RATIO',
      values.preorder_almost_full_ratio,
      'NUMBER',
      'Remaining-capacity ratio used for ALMOST_FULL.',
      user.user_id
    );

    setConfig_(
      'CRM_DORMANT_DAYS',
      values.crm_dormant_days,
      'NUMBER',
      'Days since last completed Order before Dormant signal.',
      user.user_id
    );

    setConfig_(
      'REPORT_CACHE_LOOKBACK_DAYS',
      values.report_cache_lookback_days,
      'NUMBER',
      'Default lookback days for report cache rebuild.',
      user.user_id
    );
  } finally {
    lock.releaseLock();
  }

  var after =
    settingsSnapshot_()
      .automation;

  writeAuditLog_(
    'UPDATE',
    'CONFIG',
    'AUTOMATION_SETTINGS',
    before,
    after,
    'Automation and governance configuration updated.'
  );

  return after;
}

function activeOwnerCountPhase14_() {
  return listAllRecords_(
    'USERS'
  ).filter(function(user) {
    return (
      String(
        user.role || ''
      ).toUpperCase() ===
        TWB_ROLES.OWNER &&
      String(
        user.status || ''
      ).toUpperCase() ===
        TWB_USER_STATUS.ACTIVE
    );
  }).length;
}

function createUserPhase14(
  payload
) {
  var actor =
    settingsOwnerUser_();

  payload = payload || {};

  var email =
    normalizeEmail_(
      payload.email
    );

  if (
    !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(
      email
    )
  ) {
    throw twbError_(
      'USER_EMAIL_INVALID',
      'A valid Google account email is required.'
    );
  }

  var existing =
    dbFindOne(
      'USERS',
      'email',
      email
    );

  if (existing) {
    throw twbError_(
      'UNIQUE_VIOLATION',
      'A user already exists for ' +
      email
    );
  }

  var displayName =
    settingsText_(
      payload.display_name ||
      displayNameFromEmail_(
        email
      ),
      'Display name',
      2,
      100
    );

  var role =
    String(
      payload.role || ''
    ).toUpperCase();

  if (
    settingsRoles_().indexOf(
      role
    ) < 0
  ) {
    throw twbError_(
      'USER_ROLE_INVALID',
      'Invalid role: ' +
      role
    );
  }

  var now =
    nowIso_();

  var id =
    nextBusinessId(
      'USER'
    );

  var record = {
    user_id:
      id,
    email:
      email,
    display_name:
      displayName,
    role:
      role,
    status:
      TWB_USER_STATUS.ACTIVE,
    last_login_at: '',
    created_at:
      now,
    created_by:
      actor.user_id,
    updated_at:
      now,
    updated_by:
      actor.user_id
  };

  dbInsertRecord(
    'USERS',
    record,
    {
      validate: true,
      audit: false
    }
  );

  writeAuditLog_(
    'CREATE',
    'USERS',
    id,
    null,
    record,
    'Application user created.'
  );

  return sanitizeUser_(
    record
  );
}

function updateUserPhase14(
  userId,
  payload
) {
  var actor =
    settingsOwnerUser_();

  payload = payload || {};

  var target =
    dbFindById(
      'USERS',
      userId
    );

  if (!target) {
    throw twbError_(
      'NOT_FOUND',
      'User not found: ' +
      userId
    );
  }

  var displayName =
    settingsText_(
      Object.prototype.hasOwnProperty.call(
        payload,
        'display_name'
      )
        ? payload.display_name
        : target.display_name,
      'Display name',
      2,
      100
    );

  var role =
    String(
      Object.prototype.hasOwnProperty.call(
        payload,
        'role'
      )
        ? payload.role
        : target.role
    ).toUpperCase();

  var status =
    String(
      Object.prototype.hasOwnProperty.call(
        payload,
        'status'
      )
        ? payload.status
        : target.status
    ).toUpperCase();

  if (
    settingsRoles_().indexOf(
      role
    ) < 0
  ) {
    throw twbError_(
      'USER_ROLE_INVALID',
      'Invalid role: ' +
      role
    );
  }

  if (
    [
      TWB_USER_STATUS.ACTIVE,
      TWB_USER_STATUS.INACTIVE
    ].indexOf(
      status
    ) < 0
  ) {
    throw twbError_(
      'USER_STATUS_INVALID',
      'Invalid user status.'
    );
  }

  var targetIsActiveOwner =
    String(
      target.role || ''
    ).toUpperCase() ===
      TWB_ROLES.OWNER &&
    String(
      target.status || ''
    ).toUpperCase() ===
      TWB_USER_STATUS.ACTIVE;

  var removesOwner =
    targetIsActiveOwner &&
    (
      role !==
        TWB_ROLES.OWNER ||
      status !==
        TWB_USER_STATUS.ACTIVE
    );

  if (
    String(
      target.user_id
    ) ===
      String(
        actor.user_id
      ) &&
    removesOwner
  ) {
    throw twbError_(
      'OWNER_SELF_LOCKOUT_BLOCKED',
      'You cannot demote or deactivate your own active OWNER account.'
    );
  }

  if (
    removesOwner &&
    activeOwnerCountPhase14_() <=
      1
  ) {
    throw twbError_(
      'LAST_OWNER_PROTECTED',
      'At least one active OWNER must remain.'
    );
  }

  var before =
    sanitizeUser_(
      target
    );

  var updated =
    dbUpdateById(
      'USERS',
      userId,
      stampUpdate_(
        actor,
        {
          display_name:
            displayName,
          role:
            role,
          status:
            status
        }
      ),
      {
        validate: true,
        audit: false
      }
    );

  writeAuditLog_(
    'UPDATE',
    'USERS',
    userId,
    before,
    sanitizeUser_(
      updated
    ),
    'Application user governance updated.'
  );

  return sanitizeUser_(
    updated
  );
}
