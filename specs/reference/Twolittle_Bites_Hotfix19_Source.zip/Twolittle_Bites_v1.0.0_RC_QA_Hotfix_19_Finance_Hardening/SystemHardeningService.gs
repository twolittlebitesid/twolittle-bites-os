/**
 * Twolittle.bites OS — Phase 15 System Hardening & Automation
 *
 * Goals:
 * - consolidated diagnostics
 * - cross-module read-only regression
 * - integrity checks
 * - lightweight error ring buffer
 * - exact Google Sheets backups
 * - non-destructive recovery copies
 * - scheduled maintenance trigger
 */

function systemDiagnosticsUser_() {
  return requirePermission_(
    'SETTINGS_WRITE'
  );
}

function systemOwnerUser_() {
  return requireRole_([
    TWB_ROLES.OWNER
  ]);
}

function systemErrorPropertyKey_() {
  return 'TWB_SYSTEM_ERROR_LOG_V1';
}

function recordSystemError_(payload) {
  payload = payload || {};

  try {
    var props =
      PropertiesService
        .getScriptProperties();

    var raw =
      props.getProperty(
        systemErrorPropertyKey_()
      );

    var rows = [];

    if (raw) {
      try {
        rows =
          JSON.parse(raw) || [];
      } catch (ignore) {
        rows = [];
      }
    }

    var email = '';

    try {
      email =
        resolveCurrentEmail_();
    } catch (ignoreEmail) {}

    rows.unshift({
      timestamp:
        nowIso_(),
      request_id:
        String(
          payload.requestId || ''
        ),
      action:
        String(
          payload.action || ''
        ).slice(0, 120),
      code:
        String(
          payload.code ||
          'INTERNAL_ERROR'
        ).slice(0, 120),
      message:
        String(
          payload.message || ''
        ).slice(0, 1000),
      stack:
        String(
          payload.stack || ''
        ).slice(0, 2500),
      email:
        email
    });

    rows =
      rows.slice(0, 50);

    props.setProperty(
      systemErrorPropertyKey_(),
      JSON.stringify(rows)
    );
  } catch (ignoreAll) {}

  return true;
}

function systemRecentErrors_() {
  var raw =
    PropertiesService
      .getScriptProperties()
      .getProperty(
        systemErrorPropertyKey_()
      );

  if (!raw) return [];

  try {
    return (
      JSON.parse(raw) || []
    ).slice(0, 25);
  } catch (e) {
    return [];
  }
}

function clearSystemErrorsPhase15() {
  systemDiagnosticsUser_();

  PropertiesService
    .getScriptProperties()
    .deleteProperty(
      systemErrorPropertyKey_()
    );

  return {
    cleared: true
  };
}

function systemMapBy_(
  rows,
  field
) {
  var map = {};

  (rows || [])
    .forEach(function(row) {
      map[
        String(
          row[field] || ''
        )
      ] = row;
    });

  return map;
}

function systemIssueCollector_(
  key,
  label
) {
  return {
    key: key,
    label: label,
    count: 0,
    examples: [],
    add: function(value) {
      this.count += 1;

      if (
        this.examples.length < 10
      ) {
        this.examples.push(
          String(value)
        );
      }
    }
  };
}

function systemIntegrityEngineVersion_() {
  return 'QA_HOTFIX_09_COMPOSITE_KEYS_V1';
}

function systemIntegrityKeyFields_(
  sheetName,
  schema
) {
  if (
    sheetName ===
    'DAILY_METRICS'
  ) {
    return [
      'metric_date',
      'metric_key'
    ];
  }

  if (
    sheetName ===
    'MONTHLY_METRICS'
  ) {
    return [
      'month',
      'metric_key'
    ];
  }

  return schema.primaryKey
    ? [
        schema.primaryKey
      ]
    : [];
}

function systemPrimaryKeyIntegrity_() {
  var issues = [];
  var rowCounts = {};

  TWB_SHEET_ORDER
    .forEach(function(sheetName) {
      var schema =
        getSheetSchema_(
          sheetName
        );

      var rows =
        listAllRecords_(
          sheetName
        );

      rowCounts[
        sheetName
      ] = rows.length;

      var keyFields =
        systemIntegrityKeyFields_(
          sheetName,
          schema
        );

      if (
        !keyFields.length
      ) {
        return;
      }

      var collector =
        systemIssueCollector_(
          'PK_' +
            sheetName,
          sheetName +
            (
              keyFields.length > 1
                ? ' composite key integrity'
                : ' primary key integrity'
            )
        );

      var seen = {};

      rows.forEach(function(row, index) {
        var parts =
          keyFields.map(function(field) {
            return String(
              row[field] || ''
            );
          });

        var hasBlank =
          parts.some(function(value) {
            return !value;
          });

        if (
          hasBlank
        ) {
          collector.add(
            'blank ' +
            keyFields.join('+') +
            '@row' +
            (index + 2)
          );

          return;
        }

        var value =
          parts.join('||');

        if (
          seen[value]
        ) {
          collector.add(
            value
          );
        }

        seen[value] = true;
      });

      if (
        collector.count
      ) {
        issues.push(
          collector
        );
      }
    });

  return {
    issues: issues,
    rowCounts:
      rowCounts
  };
}

function systemReferenceIntegrity_() {
  var issues = [];

  var customers =
    listAllRecords_(
      'CUSTOMERS'
    );

  var products =
    listAllRecords_(
      'PRODUCTS'
    );

  var orders =
    listAllRecords_(
      'ORDERS'
    );

  var orderItems =
    listAllRecords_(
      'ORDER_ITEMS'
    );

  var invoices =
    listAllRecords_(
      'INVOICES'
    );

  var payments =
    listAllRecords_(
      'PAYMENTS'
    );

  var plans =
    listAllRecords_(
      'PRODUCTION_PLANS'
    );

  var planItems =
    listAllRecords_(
      'PRODUCTION_PLAN_ITEMS'
    );

  var requirements =
    listAllRecords_(
      'PRODUCTION_REQUIREMENTS'
    );

  var ingredients =
    listAllRecords_(
      'INGREDIENTS'
    );

  var packaging =
    listAllRecords_(
      'PACKAGING'
    );

  var inventory =
    listAllRecords_(
      'INVENTORY'
    );

  var suppliers =
    listAllRecords_(
      'SUPPLIERS'
    );

  var purchases =
    listAllRecords_(
      'PURCHASES'
    );

  var purchaseItems =
    listAllRecords_(
      'PURCHASE_ITEMS'
    );

  var campaigns =
    listAllRecords_(
      'MARKETING_CAMPAIGNS'
    );

  var content =
    listAllRecords_(
      'CONTENT'
    );

  var expenses =
    listAllRecords_(
      'EXPENSES'
    );

  var customerMap =
    systemMapBy_(
      customers,
      'customer_id'
    );

  var productMap =
    systemMapBy_(
      products,
      'product_id'
    );

  var orderMap =
    systemMapBy_(
      orders,
      'order_id'
    );

  var invoiceMap =
    systemMapBy_(
      invoices,
      'invoice_id'
    );

  var planMap =
    systemMapBy_(
      plans,
      'production_plan_id'
    );

  var ingredientMap =
    systemMapBy_(
      ingredients,
      'ingredient_id'
    );

  var packagingMap =
    systemMapBy_(
      packaging,
      'packaging_id'
    );

  var supplierMap =
    systemMapBy_(
      suppliers,
      'supplier_id'
    );

  var purchaseMap =
    systemMapBy_(
      purchases,
      'purchase_id'
    );

  var campaignMap =
    systemMapBy_(
      campaigns,
      'marketing_campaign_id'
    );

  var contentMap =
    systemMapBy_(
      content,
      'content_id'
    );

  var expenseMap =
    systemMapBy_(
      expenses,
      'expense_id'
    );

  function collect_(
    key,
    label,
    rows,
    test,
    idField
  ) {
    var collector =
      systemIssueCollector_(
        key,
        label
      );

    rows.forEach(function(row) {
      if (
        !test(row)
      ) {
        collector.add(
          row[
            idField
          ] || '?'
        );
      }
    });

    if (
      collector.count
    ) {
      issues.push(
        collector
      );
    }
  }

  collect_(
    'ORDER_CUSTOMER',
    'Order → Customer references',
    orders,
    function(row) {
      return !!customerMap[
        row.customer_id
      ];
    },
    'order_id'
  );

  collect_(
    'ORDER_ITEM_ORDER',
    'Order Item → Order references',
    orderItems,
    function(row) {
      return !!orderMap[
        row.order_id
      ];
    },
    'order_item_id'
  );

  collect_(
    'ORDER_ITEM_PRODUCT',
    'Order Item → Product references',
    orderItems,
    function(row) {
      return !!productMap[
        row.product_id
      ];
    },
    'order_item_id'
  );

  collect_(
    'INVOICE_ORDER',
    'Invoice → Order references',
    invoices,
    function(row) {
      return !!orderMap[
        row.order_id
      ];
    },
    'invoice_id'
  );

  collect_(
    'INVOICE_CUSTOMER',
    'Invoice → Customer references',
    invoices,
    function(row) {
      return !!customerMap[
        row.customer_id
      ];
    },
    'invoice_id'
  );

  collect_(
    'PAYMENT_INVOICE',
    'Payment → Invoice references',
    payments,
    function(row) {
      return !!invoiceMap[
        row.invoice_id
      ];
    },
    'payment_id'
  );

  collect_(
    'PAYMENT_ORDER',
    'Payment → Order references',
    payments,
    function(row) {
      return !!orderMap[
        row.order_id
      ];
    },
    'payment_id'
  );

  collect_(
    'PLAN_ITEM_PLAN',
    'Production Plan Item → Plan references',
    planItems,
    function(row) {
      return !!planMap[
        row.production_plan_id
      ];
    },
    'production_plan_item_id'
  );

  collect_(
    'REQUIREMENT_PLAN',
    'Production Requirement → Plan references',
    requirements,
    function(row) {
      return !!planMap[
        row.production_plan_id
      ];
    },
    'requirement_id'
  );

  collect_(
    'INVENTORY_MATERIAL',
    'Inventory → Material references',
    inventory,
    function(row) {
      var type =
        String(
          row.item_type || ''
        ).toUpperCase();

      if (
        type === 'INGREDIENT'
      ) {
        return !!ingredientMap[
          row.item_id
        ];
      }

      if (
        type === 'PACKAGING'
      ) {
        return !!packagingMap[
          row.item_id
        ];
      }

      return false;
    },
    'inventory_id'
  );

  collect_(
    'PURCHASE_SUPPLIER',
    'Purchase → Supplier references',
    purchases,
    function(row) {
      return !!supplierMap[
        row.supplier_id
      ];
    },
    'purchase_id'
  );

  collect_(
    'PURCHASE_ITEM_PURCHASE',
    'Purchase Item → Purchase references',
    purchaseItems,
    function(row) {
      return !!purchaseMap[
        row.purchase_id
      ];
    },
    'purchase_item_id'
  );

  collect_(
    'CONTENT_CAMPAIGN',
    'Content → Campaign references',
    content.filter(
      function(row) {
        return !!row.marketing_campaign_id;
      }
    ),
    function(row) {
      return !!campaignMap[
        row.marketing_campaign_id
      ];
    },
    'content_id'
  );

  var logs =
    listAllRecords_(
      'ACTIVITY_LOG'
    );

  if (
    typeof marketingAttributionMap_ ===
      'function'
  ) {
    var attributionMap =
      marketingAttributionMap_(
        logs
      );

    var attrIssue =
      systemIssueCollector_(
        'MARKETING_ATTRIBUTION',
        'Active marketing attribution references'
      );

    Object.keys(
      attributionMap
    ).forEach(function(orderId) {
      var link =
        attributionMap[
          orderId
        ];

      if (
        !orderMap[
          orderId
        ] ||
        !campaignMap[
          link.marketing_campaign_id
        ] ||
        (
          link.content_id &&
          !contentMap[
            link.content_id
          ]
        )
      ) {
        attrIssue.add(
          orderId
        );
      }
    });

    if (
      attrIssue.count
    ) {
      issues.push(
        attrIssue
      );
    }
  }

  if (
    typeof marketingExpenseLinkMap_ ===
      'function'
  ) {
    var expenseLinks =
      marketingExpenseLinkMap_(
        logs
      );

    var expenseIssue =
      systemIssueCollector_(
        'MARKETING_EXPENSE_LINK',
        'Marketing Expense → Campaign references'
      );

    Object.keys(
      expenseLinks
    ).forEach(function(expenseId) {
      var link =
        expenseLinks[
          expenseId
        ];

      if (
        !expenseMap[
          expenseId
        ] ||
        !campaignMap[
          link.marketing_campaign_id
        ]
      ) {
        expenseIssue.add(
          expenseId
        );
      }
    });

    if (
      expenseIssue.count
    ) {
      issues.push(
        expenseIssue
      );
    }
  }

  return issues;
}

function systemFinancialIntegrity_() {
  var issues = [];

  var invoices =
    listAllRecords_(
      'INVOICES'
    );

  var invoiceBalance =
    systemIssueCollector_(
      'INVOICE_BALANCE',
      'Invoice balance arithmetic'
    );

  invoices.forEach(function(invoice) {
    var expected =
      roundNumber_(
        Math.max(
          0,
          Number(
            invoice.grand_total || 0
          ) -
          Number(
            invoice.paid_amount || 0
          )
        ),
        2
      );

    var actual =
      roundNumber_(
        Number(
          invoice.remaining_amount || 0
        ),
        2
      );

    if (
      Math.abs(
        expected -
        actual
      ) > 0.01
    ) {
      invoiceBalance.add(
        invoice.invoice_id
      );
    }
  });

  if (
    invoiceBalance.count
  ) {
    issues.push(
      invoiceBalance
    );
  }

  var purchaseItems =
    listAllRecords_(
      'PURCHASE_ITEMS'
    );

  var received =
    systemIssueCollector_(
      'PURCHASE_RECEIVED_QTY',
      'Purchase received quantity does not exceed ordered quantity'
    );

  purchaseItems.forEach(function(row) {
    if (
      Number(
        row.received_qty_base || 0
      ) >
      Number(
        row.quantity_base || 0
      ) + 0.000001
    ) {
      received.add(
        row.purchase_item_id
      );
    }
  });

  if (
    received.count
  ) {
    issues.push(
      received
    );
  }

  return issues;
}

function systemInventoryIntegrity_() {
  var issues = [];

  if (
    typeof inventoryReconciliationReport_ !==
      'function'
  ) {
    return issues;
  }

  var reconciliation =
    inventoryReconciliationReport_();

  var mismatch =
    systemIssueCollector_(
      'INVENTORY_LEDGER_MISMATCH',
      'Inventory cache equals movement ledger'
    );

  reconciliation
    .forEach(function(row) {
      if (!row.ok) {
        mismatch.add(
          row.itemId
        );
      }
    });

  if (
    mismatch.count
  ) {
    issues.push(
      mismatch
    );
  }

  return issues;
}

function systemIntegrityReport_() {
  var started =
    new Date().getTime();

  var primary =
    systemPrimaryKeyIntegrity_();

  var issues = []
    .concat(
      primary.issues
    )
    .concat(
      systemReferenceIntegrity_()
    )
    .concat(
      systemFinancialIntegrity_()
    )
    .concat(
      systemInventoryIntegrity_()
    );

  var activeOwners =
    typeof activeOwnerCountPhase14_ ===
      'function'
      ? activeOwnerCountPhase14_()
      : 0;

  if (
    activeOwners < 1
  ) {
    var ownerIssue =
      systemIssueCollector_(
        'ACTIVE_OWNER',
        'At least one ACTIVE OWNER'
      );

    ownerIssue.add(
      'none'
    );

    issues.unshift(
      ownerIssue
    );
  }

  var totalIssues =
    issues.reduce(
      function(sum, issue) {
        return (
          sum +
          Number(
            issue.count || 0
          )
        );
      },
      0
    );

  return {
    ok:
      totalIssues === 0,
    activeOwners:
      activeOwners,
    issueGroups:
      issues.length,
    totalIssues:
      totalIssues,
    issues:
      issues,
    rowCounts:
      primary.rowCounts,
    durationMs:
      new Date().getTime() -
      started
  };
}

function systemPerformanceProfile_() {
  var started =
    new Date().getTime();

  var ss =
    getDatabaseSpreadsheet_();

  var rows = [];

  TWB_SHEET_ORDER
    .forEach(function(sheetName) {
      var sheet =
        ss.getSheetByName(
          sheetName
        );

      rows.push({
        sheet:
          sheetName,
        dataRows:
          sheet
            ? Math.max(
                0,
                sheet.getLastRow() -
                1
              )
            : null,
        columns:
          sheet
            ? sheet.getLastColumn()
            : null
      });
    });

  var totalRows =
    rows.reduce(
      function(sum, row) {
        return (
          sum +
          Number(
            row.dataRows || 0
          )
        );
      },
      0
    );

  var largeSheets =
    rows.filter(
      function(row) {
        return (
          Number(
            row.dataRows || 0
          ) >= 5000
        );
      }
    );

  return {
    totalDataRows:
      totalRows,
    sheetCount:
      rows.length,
    largeSheetThreshold:
      5000,
    largeSheets:
      largeSheets,
    rows:
      rows,
    durationMs:
      new Date().getTime() -
      started,
    internalReadMode:
      'SINGLE_RANGE_FULL_SHEET'
  };
}

function systemBackupFolderId_() {
  return String(
    getConfig_(
      'SYSTEM_BACKUP_FOLDER_ID'
    ) || ''
  ).trim();
}

function getExistingSystemBackupFolder_() {
  var id =
    systemBackupFolderId_();

  if (!id) return null;

  try {
    return DriveApp
      .getFolderById(
        id
      );
  } catch (e) {
    return null;
  }
}

function getOrCreateSystemBackupFolder_(
  actorUserId
) {
  var existing =
    getExistingSystemBackupFolder_();

  if (existing) {
    return existing;
  }

  var folder =
    DriveApp.createFolder(
      'Twolittle.bites OS Backups'
    );

  setConfig_(
    'SYSTEM_BACKUP_FOLDER_ID',
    folder.getId(),
    'STRING',
    'Google Drive folder containing exact database spreadsheet backups.',
    actorUserId ||
      'SYSTEM'
  );

  return folder;
}

function verifySystemBackupFile_(
  fileId
) {
  var started =
    new Date().getTime();

  var ss =
    SpreadsheetApp.openById(
      fileId
    );

  var issues = [];

  TWB_SHEET_ORDER
    .forEach(function(sheetName) {
      var schema =
        getSheetSchema_(
          sheetName
        );

      var sheet =
        ss.getSheetByName(
          sheetName
        );

      if (!sheet) {
        issues.push(
          sheetName +
          ': missing sheet'
        );

        return;
      }

      var actual =
        sheet
          .getRange(
            1,
            1,
            1,
            schema.headers.length
          )
          .getValues()[0]
          .map(String);

      if (
        actual.join('|') !==
        schema.headers
          .map(String)
          .join('|')
      ) {
        issues.push(
          sheetName +
          ': header mismatch'
        );
      }
    });

  return {
    ok:
      issues.length === 0,
    spreadsheetId:
      ss.getId(),
    spreadsheetName:
      ss.getName(),
    issueCount:
      issues.length,
    issues:
      issues.slice(0, 30),
    durationMs:
      new Date().getTime() -
      started
  };
}

function createSystemBackupInternal_(
  actorUserId
) {
  var ss =
    getDatabaseSpreadsheet_();

  var folder =
    getOrCreateSystemBackupFolder_(
      actorUserId
    );

  var stamp =
    Utilities.formatDate(
      new Date(),
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd HH-mm-ss'
    );

  var name =
    'Twolittle.bites OS Backup ' +
    stamp +
    ' v' +
    TWB_APP.APP_VERSION;

  var sourceFile =
    DriveApp.getFileById(
      ss.getId()
    );

  var copy =
    sourceFile.makeCopy(
      name,
      folder
    );

  copy.setDescription(
    JSON.stringify({
      product:
        TWB_APP.NAME,
      appVersion:
        TWB_APP.APP_VERSION,
      schemaVersion:
        TWB_APP.SCHEMA_VERSION,
      createdAt:
        nowIso_(),
      sourceSpreadsheetId:
        ss.getId()
    })
  );

  var verification =
    verifySystemBackupFile_(
      copy.getId()
    );

  if (
    !verification.ok
  ) {
    copy.setTrashed(
      true
    );

    throw twbError_(
      'BACKUP_VERIFY_FAILED',
      'Backup copy failed schema verification.',
      verification
    );
  }

  return {
    fileId:
      copy.getId(),
    name:
      copy.getName(),
    url:
      copy.getUrl(),
    createdAt:
      nowIso_(),
    verified:
      true
  };
}

function createSystemBackupPhase15() {
  var user =
    systemOwnerUser_();

  var result =
    createSystemBackupInternal_(
      user.user_id
    );

  cleanupSystemBackups_();

  writeAuditLog_(
    'BACKUP',
    'SYSTEM',
    result.fileId,
    null,
    {
      name:
        result.name,
      verified:
        result.verified
    },
    'Exact database spreadsheet backup created.'
  );

  return result;
}

function listSystemBackups_() {
  var folder =
    getExistingSystemBackupFolder_();

  if (!folder) {
    return [];
  }

  var files =
    folder.getFiles();

  var rows = [];

  while (
    files.hasNext()
  ) {
    var file =
      files.next();

    rows.push({
      fileId:
        file.getId(),
      name:
        file.getName(),
      url:
        file.getUrl(),
      createdAt:
        file.getDateCreated()
          .toISOString(),
      sizeBytes:
        file.getSize()
    });
  }

  rows.sort(
    function(a, b) {
      return String(
        b.createdAt
      ).localeCompare(
        String(
          a.createdAt
        )
      );
    }
  );

  return rows.slice(
    0,
    30
  );
}

function cleanupSystemBackups_() {
  var folder =
    getExistingSystemBackupFolder_();

  if (!folder) {
    return {
      trashed: 0
    };
  }

  var retention =
    Number(
      getConfig_(
        'SYSTEM_BACKUP_RETENTION_DAYS'
      ) ||
      30
    );

  retention =
    Math.max(
      7,
      Math.min(
        3650,
        Math.round(
          retention
        )
      )
    );

  var cutoff =
    new Date().getTime() -
    retention *
      24 *
      60 *
      60 *
      1000;

  var files =
    folder.getFiles();

  var trashed = 0;

  while (
    files.hasNext()
  ) {
    var file =
      files.next();

    if (
      file.getDateCreated()
        .getTime() <
      cutoff
    ) {
      file.setTrashed(
        true
      );

      trashed += 1;
    }
  }

  return {
    trashed:
      trashed,
    retentionDays:
      retention
  };
}

function createRecoveryCopyFromBackupPhase15(
  backupFileId
) {
  var user =
    systemOwnerUser_();

  var verified =
    verifySystemBackupFile_(
      backupFileId
    );

  if (
    !verified.ok
  ) {
    throw twbError_(
      'BACKUP_INVALID',
      'Selected backup is not a valid Twolittle.bites database backup.',
      verified
    );
  }

  var source =
    DriveApp.getFileById(
      backupFileId
    );

  var name =
    'RECOVERY COPY — ' +
    source.getName() +
    ' — ' +
    Utilities.formatDate(
      new Date(),
      TWB_APP.TIMEZONE,
      'yyyy-MM-dd HH-mm-ss'
    );

  var copy =
    source.makeCopy(
      name
    );

  var validation =
    verifySystemBackupFile_(
      copy.getId()
    );

  writeAuditLog_(
    'RECOVERY_COPY',
    'SYSTEM',
    copy.getId(),
    null,
    {
      sourceBackupId:
        backupFileId,
      verified:
        validation.ok
    },
    'Non-destructive recovery spreadsheet copy created.'
  );

  return {
    fileId:
      copy.getId(),
    name:
      copy.getName(),
    url:
      copy.getUrl(),
    verified:
      validation.ok,
    note:
      'Current production database connection was NOT changed.'
  };
}

function systemMaintenanceTriggerStatus_() {
  var triggers =
    ScriptApp
      .getProjectTriggers()
      .filter(function(trigger) {
        return (
          trigger.getHandlerFunction() ===
          'runScheduledPhase15Maintenance'
        );
      });

  return {
    configured:
      triggers.length > 0,
    triggerCount:
      triggers.length,
    handler:
      'runScheduledPhase15Maintenance',
    timezone:
      TWB_APP.TIMEZONE
  };
}

function configurePhase15MaintenanceAutomation() {
  var user =
    systemOwnerUser_();

  ScriptApp
    .getProjectTriggers()
    .forEach(function(trigger) {
      if (
        trigger.getHandlerFunction() ===
        'runScheduledPhase15Maintenance'
      ) {
        ScriptApp.deleteTrigger(
          trigger
        );
      }
    });

  ScriptApp
    .newTrigger(
      'runScheduledPhase15Maintenance'
    )
    .timeBased()
    .atHour(2)
    .nearMinute(15)
    .everyDays(1)
    .inTimezone(
      TWB_APP.TIMEZONE
    )
    .create();

  setConfig_(
    'SYSTEM_BACKUP_ENABLED',
    true,
    'BOOLEAN',
    'Create database backup during scheduled Phase 15 maintenance.',
    user.user_id
  );

  setConfig_(
    'SYSTEM_REPORT_CACHE_REBUILD_ENABLED',
    true,
    'BOOLEAN',
    'Rebuild report metric cache during scheduled Phase 15 maintenance.',
    user.user_id
  );

  writeAuditLog_(
    'CONFIGURE_AUTOMATION',
    'SYSTEM',
    'PHASE15_MAINTENANCE',
    null,
    {
      backupEnabled:
        true,
      reportCacheEnabled:
        true,
      localSchedule:
        'Daily around 02:15'
    },
    'Phase 15 scheduled maintenance configured.'
  );

  return systemMaintenanceTriggerStatus_();
}

function removePhase15MaintenanceAutomation() {
  systemOwnerUser_();

  var removed = 0;

  ScriptApp
    .getProjectTriggers()
    .forEach(function(trigger) {
      if (
        trigger.getHandlerFunction() ===
        'runScheduledPhase15Maintenance'
      ) {
        ScriptApp.deleteTrigger(
          trigger
        );

        removed += 1;
      }
    });

  return {
    removed:
      removed,
    status:
      systemMaintenanceTriggerStatus_()
  };
}

function runScheduledPhase15Maintenance() {
  var result = {
    startedAt:
      nowIso_(),
    backup:
      null,
    reportCache:
      null,
    cleanup:
      null,
    errors: []
  };

  try {
    if (
      getConfig_(
        'SYSTEM_BACKUP_ENABLED'
      ) !== false
    ) {
      result.backup =
        createSystemBackupInternal_(
          'SYSTEM'
        );
    }
  } catch (e) {
    result.errors.push({
      step:
        'BACKUP',
      code:
        e.code ||
        'ERROR',
      message:
        e.message ||
        String(e)
    });

    recordSystemError_({
      action:
        'scheduled.backup',
      code:
        e.code ||
        'ERROR',
      message:
        e.message ||
        String(e),
      stack:
        e.stack || ''
    });
  }

  try {
    if (
      getConfig_(
        'SYSTEM_REPORT_CACHE_REBUILD_ENABLED'
      ) !== false
    ) {
      result.reportCache =
        rebuildReportMetricCaches({
          lookback_days:
            Number(
              getConfig_(
                'REPORT_CACHE_LOOKBACK_DAYS'
              ) ||
              400
            )
        });
    }
  } catch (e) {
    result.errors.push({
      step:
        'REPORT_CACHE',
      code:
        e.code ||
        'ERROR',
      message:
        e.message ||
        String(e)
    });

    recordSystemError_({
      action:
        'scheduled.reportCache',
      code:
        e.code ||
        'ERROR',
      message:
        e.message ||
        String(e),
      stack:
        e.stack || ''
    });
  }

  try {
    result.cleanup =
      cleanupSystemBackups_();
  } catch (e) {
    result.errors.push({
      step:
        'BACKUP_CLEANUP',
      code:
        e.code ||
        'ERROR',
      message:
        e.message ||
        String(e)
    });
  }

  result.completedAt =
    nowIso_();

  result.ok =
    result.errors.length ===
    0;

  return result;
}

function runPhase15MaintenanceNow() {
  systemOwnerUser_();

  var result =
    runScheduledPhase15Maintenance();

  writeAuditLog_(
    'RUN_MAINTENANCE',
    'SYSTEM',
    'PHASE15_MAINTENANCE',
    null,
    result,
    'Phase 15 maintenance run manually.'
  );

  return result;
}

function systemRegressionSuite_() {
  systemDiagnosticsUser_();

  var tests = [];

  function run_(
    name,
    fn
  ) {
    var started =
      new Date().getTime();

    try {
      var result =
        fn();

      tests.push({
        name:
          name,
        ok:
          true,
        durationMs:
          new Date().getTime() -
          started,
        detail:
          result
      });
    } catch (e) {
      tests.push({
        name:
          name,
        ok:
          false,
        durationMs:
          new Date().getTime() -
          started,
        errorCode:
          e.code ||
          'ERROR',
        errorMessage:
          e.message ||
          String(e)
      });
    }
  }

  run_(
    'EXECUTIVE',
    function() {
      var data = executiveModuleBootstrap({});
      return data.finance.completedOrders + ' completed order(s) in current period';
    }
  );

  run_(
    'BUSINESS',
    function() {
      var data = businessModuleBootstrap({});
      return data.healthCards.length + ' business health card(s)';
    }
  );

  run_(
    'PRODUCTS',
    function() {
      var data =
        productModuleBootstrap();

      return (
        data.products.length +
        ' product(s)'
      );
    }
  );

  run_(
    'CUSTOMERS',
    function() {
      var data =
        customerModuleBootstrap();

      return (
        data.customers.length +
        ' customer(s)'
      );
    }
  );

  run_(
    'ORDERS',
    function() {
      var data =
        orderModuleBootstrap();

      return (
        data.orders.length +
        ' order(s)'
      );
    }
  );

  run_(
    'FINANCE',
    function() {
      var data =
        financeModuleBootstrap({
          refreshOverdue:
            false
        });

      return (
        data.invoices.length +
        ' invoice(s)'
      );
    }
  );

  run_(
    'PRODUCTION',
    function() {
      var data =
        productionModuleBootstrap();

      return (
        data.plans.length +
        ' plan(s)'
      );
    }
  );

  run_(
    'INVENTORY',
    function() {
      var data =
        inventoryModuleBootstrap();

      return (
        data.materials.length +
        ' inventory row(s)'
      );
    }
  );

  run_(
    'PURCHASING',
    function() {
      var data =
        purchasingModuleBootstrap();

      return (
        data.purchases.length +
        ' purchase(s)'
      );
    }
  );

  run_(
    'PREORDERS',
    function() {
      var data =
        preorderModuleBootstrap();

      return (
        data.campaigns.length +
        ' campaign(s)'
      );
    }
  );

  run_(
    'MARKETING',
    function() {
      var data =
        marketingModuleBootstrap();

      return (
        data.campaigns.length +
        ' marketing campaign(s)'
      );
    }
  );

  run_(
    'REPORTS',
    function() {
      var data =
        reportModuleBootstrap({});

      return (
        data.daily.length +
        ' daily row(s)'
      );
    }
  );

  run_(
    'SETTINGS',
    function() {
      var data =
        settingsModuleBootstrap();

      return (
        data.system.validSheets +
        '/' +
        data.system.expectedSheets +
        ' sheets'
      );
    }
  );

  return {
    ok:
      tests.every(function(test) {
        return test.ok;
      }),
    tests:
      tests,
    passed:
      tests.filter(function(test) {
        return test.ok;
      }).length,
    total:
      tests.length
  };
}

function systemDiagnosticsBootstrap() {
  var user =
    systemDiagnosticsUser_();

  var integrity =
    systemIntegrityReport_();

  var performance =
    systemPerformanceProfile_();

  return {
    generatedAt:
      nowIso_(),
    integrity:
      integrity,
    performance:
      performance,
    recentErrors:
      systemRecentErrors_(),
    backups:
      user.role ===
        TWB_ROLES.OWNER
        ? listSystemBackups_()
        : [],
    automation:
      user.role ===
        TWB_ROLES.OWNER
        ? systemMaintenanceTriggerStatus_()
        : {
            configured:
              false,
            restricted:
              true
          },
    permissions: {
      canRunDiagnostics:
        true,
      canManageBackups:
        user.role ===
          TWB_ROLES.OWNER,
      canManageAutomation:
        user.role ===
          TWB_ROLES.OWNER
    }
  };
}


function runPhase15RegressionSuite() {
  return systemRegressionSuite_();
}

function runPhase15IntegrityCheck() {
  systemDiagnosticsUser_();
  return systemIntegrityReport_();
}


/**
 * QA Hotfix 03 — focused integrity output for Apps Script logs.
 * Read-only.
 */
function runQAHotfix03IntegrityDiagnostic() {
  var user =
    systemDiagnosticsUser_();

  var result =
    systemIntegrityReport_();

  var output = {
    ok:
      result.ok,
    activeOwners:
      result.activeOwners,
    issueGroups:
      result.issueGroups,
    totalIssues:
      result.totalIssues,
    issues:
      result.issues.map(function(issue) {
        return {
          key:
            issue.key,
          label:
            issue.label,
          count:
            issue.count,
          examples:
            issue.examples
        };
      }),
    durationMs:
      result.durationMs
  };

  console.log(
    JSON.stringify(
      output,
      null,
      2
    )
  );

  return output;
}
