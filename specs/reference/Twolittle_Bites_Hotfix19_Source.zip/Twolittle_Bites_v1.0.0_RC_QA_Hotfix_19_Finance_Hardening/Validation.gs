function validateRecord_(sheetName, record, isUpdate) {
  const schema = getSheetSchema_(sheetName);
  const missing = [];
  schema.required.forEach(function(field) {
    const value = record[field];
    if (value === null || value === undefined || value === '') missing.push(field);
  });
  if (missing.length) {
    throw twbError_('VALIDATION_REQUIRED', 'Missing required field(s) in ' + sheetName + ': ' + missing.join(', '), { fields: missing });
  }

  Object.keys(record).forEach(function(field) {
    if (schema.headers.indexOf(field) < 0 && field.indexOf('__') !== 0) {
      throw twbError_('VALIDATION_UNKNOWN_FIELD', 'Unknown field ' + field + ' for ' + sheetName);
    }
  });

  return true;
}

function enforceUniqueFields_(sheetName, record, currentId) {
  const schema = getSheetSchema_(sheetName);
  if (!schema.unique || !schema.unique.length) return;

  schema.unique.forEach(function(field) {
    const value = record[field];
    if (value === '' || value === null || value === undefined) return;
    const existing = dbFindOne(sheetName, field, value);
    if (!existing) return;
    if (currentId && schema.primaryKey && String(existing[schema.primaryKey]) === String(currentId)) return;
    throw twbError_('UNIQUE_VIOLATION', field + ' must be unique in ' + sheetName + ': ' + value);
  });
}

function requirePositive_(value, fieldName) {
  if (!(Number(value) > 0)) throw twbError_('VALIDATION_POSITIVE', (fieldName || 'value') + ' must be greater than 0.');
  return Number(value);
}

function requireNonNegative_(value, fieldName) {
  if (Number(value) < 0 || isNaN(Number(value))) throw twbError_('VALIDATION_NON_NEGATIVE', (fieldName || 'value') + ' cannot be negative.');
  return Number(value);
}
