/**
 * Twolittle.bites OS — Phase 13 upgrade.
 */
function upgradeToPhase13() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER
    ]);

  var schema =
    validateDatabaseSchema();

  if (!schema.ok) {
    throw twbError_(
      'SCHEMA_INVALID',
      'Database schema is not healthy.'
    );
  }

  setConfig_(
    'APP_VERSION',
    TWB_APP.APP_VERSION,
    'STRING',
    'Current application version.',
    user.user_id
  );

  setConfig_(
    'SCHEMA_VERSION',
    TWB_APP.SCHEMA_VERSION,
    'STRING',
    'Current database schema version.',
    user.user_id
  );

  setConfig_(
    'REPORT_CACHE_LOOKBACK_DAYS',
    400,
    'NUMBER',
    'Default lookback window used when rebuilding DAILY_METRICS and MONTHLY_METRICS.',
    user.user_id
  );

  setConfig_(
    'REPORT_DAILY_CACHE_MODE',
    'REBUILDABLE_DERIVED_CACHE',
    'STRING',
    'DAILY_METRICS is derived from operational source tables and may be rebuilt.',
    user.user_id
  );

  setConfig_(
    'REPORT_MONTHLY_CACHE_MODE',
    'AGGREGATED_FROM_DAILY_CACHE',
    'STRING',
    'MONTHLY_METRICS is derived from rebuilt daily metric rows.',
    user.user_id
  );

  setConfig_(
    'REPORT_WEEK_START',
    'MONDAY',
    'STRING',
    'Weekly business review groups dates from Monday.',
    user.user_id
  );

  setConfig_(
    'REPORT_EXPORT_FORMAT',
    'CSV_UTF8_BOM',
    'STRING',
    'Report export uses CSV with UTF-8 BOM for spreadsheet compatibility.',
    user.user_id
  );

  return runPhase13HealthCheck();
}
