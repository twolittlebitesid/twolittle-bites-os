/**
 * Twolittle.bites OS — Phase 11 CRM & Customer Intelligence
 *
 * No new tables.
 * Intelligence is derived from CUSTOMERS + ORDERS + ORDER_ITEMS.
 *
 * RFM is descriptive / heuristic:
 * - Recency: lower days since last completed order is better
 * - Frequency: more completed orders is better
 * - Monetary: higher completed-order spend is better
 */

function crmDormantDays_() {
  var value = Number(
    getConfig_('CRM_DORMANT_DAYS')
  );

  return value > 0 ? value : 60;
}

function crmProfileOrderLimit_() {
  var value = Number(
    getConfig_('CRM_PROFILE_ORDER_LIMIT')
  );

  return value > 0
    ? Math.min(200, Math.floor(value))
    : 50;
}

function crmTodayMs_() {
  var key = todayIso_();
  return new Date(
    key + 'T12:00:00'
  ).getTime();
}

function crmOrderDateKey_(order) {
  return financeDateKey_(
    order.fulfillment_date ||
    order.order_date ||
    order.created_at
  );
}

function crmDaysSince_(dateKey, nowMs) {
  if (!dateKey) return null;

  var parsed =
    new Date(
      dateKey + 'T12:00:00'
    ).getTime();

  if (isNaN(parsed)) return null;

  var base =
    isFinite(Number(nowMs))
      ? Number(nowMs)
      : crmTodayMs_();

  return Math.max(
    0,
    Math.floor(
      (base - parsed) /
      (24 * 60 * 60 * 1000)
    )
  );
}

function crmAverageDaysBetweenOrders_(
  dateKeys
) {
  var keys = (dateKeys || [])
    .filter(Boolean)
    .slice()
    .sort();

  if (keys.length < 2) return null;

  var gaps = [];

  for (var i = 1; i < keys.length; i++) {
    var previous =
      new Date(
        keys[i - 1] +
        'T12:00:00'
      ).getTime();

    var current =
      new Date(
        keys[i] +
        'T12:00:00'
      ).getTime();

    if (
      !isNaN(previous) &&
      !isNaN(current)
    ) {
      gaps.push(
        Math.max(
          0,
          Math.round(
            (current - previous) /
            (24 * 60 * 60 * 1000)
          )
        )
      );
    }
  }

  if (!gaps.length) return null;

  return roundNumber_(
    gaps.reduce(function(sum, gap) {
      return sum + gap;
    }, 0) / gaps.length,
    1
  );
}

function crmQuantileScore_(
  value,
  cohortValues,
  higherIsBetter
) {
  var values = (cohortValues || [])
    .map(Number)
    .filter(function(current) {
      return isFinite(current);
    })
    .sort(function(a, b) {
      return a - b;
    });

  if (!values.length) return 0;
  if (values.length === 1) return 3;

  var numeric =
    Number(value);

  var lessOrEqual = 0;

  values.forEach(function(current) {
    if (current <= numeric) {
      lessOrEqual += 1;
    }
  });

  var percentile =
    lessOrEqual /
    values.length;

  var score =
    Math.ceil(
      percentile * 5
    );

  score =
    Math.min(
      5,
      Math.max(1, score)
    );

  if (!higherIsBetter) {
    score = 6 - score;
  }

  return score;
}

function crmSegmentFromScores_(
  customer,
  dormantDays
) {
  var orders =
    Number(
      customer.completedOrders || 0
    );

  var recency =
    customer.recencyDays;

  if (!(orders > 0)) {
    return 'NEW';
  }

  if (
    recency != null &&
    recency > dormantDays
  ) {
    return 'DORMANT';
  }

  if (
    orders >= 3 &&
    Number(
      customer.rfmTotal || 0
    ) >= 13
  ) {
    return 'VIP';
  }

  if (
    Number(
      customer.mScore || 0
    ) >= 4 &&
    Number(
      customer.rfmTotal || 0
    ) >= 10
  ) {
    return 'HIGH_VALUE';
  }

  if (orders >= 2) {
    return 'REPEAT';
  }

  return 'NEW';
}

function maskWhatsappForLimited_(value) {
  var raw = String(value || '');

  if (raw.length <= 6) {
    return raw
      ? '••••'
      : '';
  }

  return (
    raw.slice(0, 4) +
    '••••' +
    raw.slice(-3)
  );
}

function maskEmailForLimited_(value) {
  var raw = String(value || '');

  if (!raw || raw.indexOf('@') < 0) {
    return '';
  }

  var parts = raw.split('@');

  var local =
    parts[0] || '';

  return (
    (
      local
        ? local.slice(0, 1)
        : ''
    ) +
    '•••@' +
    parts.slice(1).join('@')
  );
}

function customerViewerAccess_() {
  var user =
    requireCurrentUser_();

  var full =
    hasPermission_(
      user,
      'CUSTOMER_READ'
    );

  var limited =
    !full &&
    hasPermission_(
      user,
      'CUSTOMER_READ_LIMITED'
    );

  if (!full && !limited) {
    throw twbError_(
      'FORBIDDEN',
      'Customer read permission is required.'
    );
  }

  return {
    user: user,
    full: full,
    limited: limited
  };
}

function sanitizeCustomerForViewer_(
  customer,
  access
) {
  var clean =
    Object.assign(
      {},
      customer
    );

  if (
    access &&
    access.limited
  ) {
    clean.whatsapp =
      maskWhatsappForLimited_(
        clean.whatsapp
      );

    clean.email =
      maskEmailForLimited_(
        clean.email
      );

    clean.default_address = '';
    clean.notes = '';
  }

  return clean;
}

function buildCustomerIntelligenceDataset_(
  customers,
  orders,
  orderItems,
  products,
  nowMs
) {
  var completedOrders =
    (orders || [])
      .filter(function(order) {
        return (
          String(
            order.order_status || ''
          ).toUpperCase() ===
          'COMPLETED'
        );
      });

  var itemGroups = {};
  (orderItems || [])
    .forEach(function(item) {
      if (!itemGroups[item.order_id]) {
        itemGroups[item.order_id] = [];
      }

      itemGroups[item.order_id].push(
        item
      );
    });

  var customerOrderGroups = {};
  completedOrders
    .forEach(function(order) {
      if (
        !customerOrderGroups[
          order.customer_id
        ]
      ) {
        customerOrderGroups[
          order.customer_id
        ] = [];
      }

      customerOrderGroups[
        order.customer_id
      ].push(order);
    });

  var productMap = {};
  (products || [])
    .forEach(function(product) {
      productMap[
        product.product_id
      ] = product;
    });

  var rows =
    (customers || [])
      .map(function(customer) {
        var customerOrders =
          customerOrderGroups[
            customer.customer_id
          ] || [];

        customerOrders.sort(
          function(a, b) {
            return String(
              crmOrderDateKey_(a)
            ).localeCompare(
              String(
                crmOrderDateKey_(b)
              )
            );
          }
        );

        var spend = 0;
        var dates = [];
        var productQty = {};
        var productRevenue = {};
        var channelCount = {};
        var preorderCount = 0;

        customerOrders
          .forEach(function(order) {
            spend += Number(
              order.grand_total || 0
            );

            var dateKey =
              crmOrderDateKey_(
                order
              );

            if (dateKey) {
              dates.push(
                dateKey
              );
            }

            var channel =
              order.source_channel ||
              'UNKNOWN';

            channelCount[channel] =
              (
                channelCount[
                  channel
                ] || 0
              ) + 1;

            if (
              order.preorder_campaign_id
            ) {
              preorderCount += 1;
            }

            (
              itemGroups[
                order.order_id
              ] || []
            ).forEach(function(item) {
              var productId =
                item.product_id;

              productQty[productId] =
                (
                  productQty[
                    productId
                  ] || 0
                ) +
                Number(
                  item.quantity || 0
                );

              productRevenue[
                productId
              ] =
                (
                  productRevenue[
                    productId
                  ] || 0
                ) +
                Number(
                  item.line_total || 0
                );
            });
          });

        var firstDate =
          dates.length
            ? dates[0]
            : '';

        var lastDate =
          dates.length
            ? dates[
                dates.length - 1
              ]
            : '';

        var favoriteProductId = '';
        var favoriteQty = -1;

        Object.keys(productQty)
          .forEach(function(productId) {
            if (
              productQty[
                productId
              ] > favoriteQty
            ) {
              favoriteQty =
                productQty[
                  productId
                ];

              favoriteProductId =
                productId;
            }
          });

        var topChannel = '';
        var topChannelOrders = -1;

        Object.keys(channelCount)
          .forEach(function(channel) {
            if (
              channelCount[
                channel
              ] >
              topChannelOrders
            ) {
              topChannelOrders =
                channelCount[
                  channel
                ];

              topChannel =
                channel;
            }
          });

        return {
          customerId:
            customer.customer_id,
          name:
            customer.name,
          completedOrders:
            customerOrders.length,
          historicalValue:
            Math.round(spend),
          averageOrderValue:
            customerOrders.length
              ? Math.round(
                  spend /
                  customerOrders.length
                )
              : 0,
          firstOrderDate:
            firstDate,
          lastOrderDate:
            lastDate,
          recencyDays:
            crmDaysSince_(
              lastDate,
              nowMs
            ),
          averageDaysBetweenOrders:
            crmAverageDaysBetweenOrders_(
              dates
            ),
          favoriteProductId:
            favoriteProductId,
          favoriteProductName:
            favoriteProductId &&
            productMap[
              favoriteProductId
            ]
              ? productMap[
                  favoriteProductId
                ].product_name
              : '',
          topChannel:
            topChannel,
          preorderCount:
            preorderCount,
          rScore: 0,
          fScore: 0,
          mScore: 0,
          rfmTotal: 0,
          crmSegment:
            'NEW'
        };
      });

  var customersWithOrders =
    rows.filter(function(row) {
      return row.completedOrders > 0;
    });

  var recencyValues =
    customersWithOrders.map(
      function(row) {
        return Number(
          row.recencyDays || 0
        );
      }
    );

  var frequencyValues =
    customersWithOrders.map(
      function(row) {
        return row.completedOrders;
      }
    );

  var monetaryValues =
    customersWithOrders.map(
      function(row) {
        return row.historicalValue;
      }
    );

  var dormantDays =
    crmDormantDays_();

  rows.forEach(function(row) {
    if (
      row.completedOrders > 0
    ) {
      row.rScore =
        crmQuantileScore_(
          row.recencyDays,
          recencyValues,
          false
        );

      row.fScore =
        crmQuantileScore_(
          row.completedOrders,
          frequencyValues,
          true
        );

      row.mScore =
        crmQuantileScore_(
          row.historicalValue,
          monetaryValues,
          true
        );

      row.rfmTotal =
        row.rScore +
        row.fScore +
        row.mScore;
    }

    row.crmSegment =
      crmSegmentFromScores_(
        row,
        dormantDays
      );

    row.reactivationSignal =
      row.crmSegment ===
        'DORMANT';

    row.customerValueLabel =
      row.historicalValue > 0
        ? 'HISTORICAL_VALUE'
        : 'NO_COMPLETED_ORDER';
  });

  return rows;
}

function crmSummaryFromRows_(rows) {
  rows = rows || [];

  var buyers =
    rows.filter(function(row) {
      return row.completedOrders > 0;
    });

  var repeats =
    buyers.filter(function(row) {
      return row.completedOrders >= 2;
    });

  var dormant =
    rows.filter(function(row) {
      return row.crmSegment ===
        'DORMANT';
    });

  var vip =
    rows.filter(function(row) {
      return row.crmSegment ===
        'VIP';
    });

  var totalValue =
    buyers.reduce(function(sum, row) {
      return (
        sum +
        Number(
          row.historicalValue || 0
        )
      );
    }, 0);

  var totalOrders =
    buyers.reduce(function(sum, row) {
      return (
        sum +
        Number(
          row.completedOrders || 0
        )
      );
    }, 0);

  return {
    totalCustomers:
      rows.length,
    customersWithCompletedOrder:
      buyers.length,
    repeatCustomers:
      repeats.length,
    repeatCustomerRatePct:
      buyers.length
        ? roundNumber_(
            (
              repeats.length /
              buyers.length
            ) * 100,
            2
          )
        : 0,
    dormantCustomers:
      dormant.length,
    vipCustomers:
      vip.length,
    historicalCustomerValue:
      Math.round(totalValue),
    completedOrderAov:
      totalOrders
        ? Math.round(
            totalValue /
            totalOrders
          )
        : 0
  };
}

function crmSegmentSummary_(rows) {
  var groups = {};

  (rows || [])
    .forEach(function(row) {
      var segment =
        row.crmSegment ||
        'NEW';

      if (!groups[segment]) {
        groups[segment] = {
          segment: segment,
          customerCount: 0,
          completedOrders: 0,
          historicalValue: 0
        };
      }

      groups[segment]
        .customerCount += 1;

      groups[segment]
        .completedOrders +=
        Number(
          row.completedOrders || 0
        );

      groups[segment]
        .historicalValue +=
        Number(
          row.historicalValue || 0
        );
    });

  return Object.keys(groups)
    .map(function(key) {
      var row = groups[key];

      row.historicalValue =
        Math.round(
          row.historicalValue
        );

      row.averageValuePerCustomer =
        row.customerCount
          ? Math.round(
              row.historicalValue /
              row.customerCount
            )
          : 0;

      return row;
    })
    .sort(function(a, b) {
      return (
        b.historicalValue -
        a.historicalValue
      );
    });
}

function crmIntelligenceBootstrap() {
  var access =
    customerViewerAccess_();

  var customers =
    listAllRecords_(
      'CUSTOMERS'
    );

  var orders =
    listAllRecords_(
      'ORDERS'
    );

  var orderItems =
    listAllRecords_(
      'ORDER_ITEMS'
    );

  var products =
    listAllRecords_(
      'PRODUCTS'
    );

  var intelligence =
    buildCustomerIntelligenceDataset_(
      customers,
      orders,
      orderItems,
      products,
      crmTodayMs_()
    );

  var intelligenceMap = {};
  intelligence
    .forEach(function(row) {
      intelligenceMap[
        row.customerId
      ] = row;
    });

  var customerRows =
    customers.map(function(customer) {
      var intel =
        intelligenceMap[
          customer.customer_id
        ] || {};

      var clean =
        sanitizeCustomerForViewer_(
          stripInternalFields_(
            customer
          ),
          access
        );

      return Object.assign(
        {},
        clean,
        {
          crm_segment:
            intel.crmSegment ||
            'NEW',
          recency_days:
            intel.recencyDays,
          completed_orders_live:
            intel.completedOrders || 0,
          historical_value:
            intel.historicalValue || 0,
          average_order_value_live:
            intel.averageOrderValue || 0,
          r_score:
            intel.rScore || 0,
          f_score:
            intel.fScore || 0,
          m_score:
            intel.mScore || 0,
          rfm_total:
            intel.rfmTotal || 0,
          average_days_between_orders:
            intel.averageDaysBetweenOrders,
          favorite_product_name:
            intel.favoriteProductName || '',
          top_channel:
            intel.topChannel || '',
          preorder_count:
            intel.preorderCount || 0,
          reactivation_signal:
            !!intel.reactivationSignal
        }
      );
    });

  customerRows.sort(
    function(a, b) {
      var segmentWeight = {
        VIP: 1,
        HIGH_VALUE: 2,
        REPEAT: 3,
        NEW: 4,
        DORMANT: 5
      };

      return (
        (
          segmentWeight[
            a.crm_segment
          ] || 9
        ) -
        (
          segmentWeight[
            b.crm_segment
          ] || 9
        )
      ) ||
      (
        Number(
          b.historical_value || 0
        ) -
        Number(
          a.historical_value || 0
        )
      );
    }
  );

  return {
    customers:
      customerRows,
    summary:
      crmSummaryFromRows_(
        intelligence
      ),
    segments:
      crmSegmentSummary_(
        intelligence
      ),
    dormant:
      customerRows
        .filter(function(row) {
          return (
            row.reactivation_signal ===
            true
          );
        })
        .sort(function(a, b) {
          return (
            Number(
              b.historical_value || 0
            ) -
            Number(
              a.historical_value || 0
            )
          );
        }),
    config: {
      dormantDays:
        crmDormantDays_(),
      rfmMethod:
        'RELATIVE_QUINTILE_STYLE'
    },
    access: {
      limited:
        access.limited,
      canWrite:
        hasPermission_(
          access.user,
          'CUSTOMER_WRITE'
        )
    }
  };
}

function getCustomerProfile(
  customerId
) {
  var access =
    customerViewerAccess_();

  var customer =
    dbFindById(
      'CUSTOMERS',
      customerId
    );

  if (!customer) {
    throw twbError_(
      'NOT_FOUND',
      'Customer not found: ' +
      customerId
    );
  }

  var allOrders =
    dbFindMany(
      'ORDERS',
      'customer_id',
      customerId
    );

  var completed =
    allOrders.filter(
      function(order) {
        return (
          String(
            order.order_status
          ).toUpperCase() ===
          'COMPLETED'
        );
      }
    );

  var orderIds = {};
  allOrders.forEach(function(order) {
    orderIds[order.order_id] =
      true;
  });

  var allItems =
    listAllRecords_(
      'ORDER_ITEMS'
    ).filter(function(item) {
      return !!orderIds[
        item.order_id
      ];
    });

  var products =
    listAllRecords_(
      'PRODUCTS'
    );

  var intelligence =
    buildCustomerIntelligenceDataset_(
      [customer],
      allOrders,
      allItems,
      products,
      crmTodayMs_()
    )[0];

  /*
   * Re-score single customer against the whole cohort,
   * so profile scores match Directory.
   */
  var cohort =
    buildCustomerIntelligenceDataset_(
      listAllRecords_(
        'CUSTOMERS'
      ),
      listAllRecords_(
        'ORDERS'
      ),
      listAllRecords_(
        'ORDER_ITEMS'
      ),
      products,
      crmTodayMs_()
    );

  var cohortRow =
    cohort.filter(function(row) {
      return (
        String(row.customerId) ===
        String(customerId)
      );
    })[0];

  if (cohortRow) {
    intelligence =
      cohortRow;
  }

  var productMap = {};
  products.forEach(function(product) {
    productMap[
      product.product_id
    ] = product;
  });

  var itemGroups = {};
  allItems.forEach(function(item) {
    if (!itemGroups[item.order_id]) {
      itemGroups[item.order_id] = [];
    }

    itemGroups[item.order_id]
      .push(item);
  });

  var productAffinity = {};
  var channelMix = {};

  completed.forEach(function(order) {
    var channel =
      order.source_channel ||
      'UNKNOWN';

    if (!channelMix[channel]) {
      channelMix[channel] = {
        channel: channel,
        orderCount: 0,
        historicalValue: 0
      };
    }

    channelMix[channel]
      .orderCount += 1;

    channelMix[channel]
      .historicalValue +=
      Number(
        order.grand_total || 0
      );

    (
      itemGroups[
        order.order_id
      ] || []
    ).forEach(function(item) {
      var productId =
        item.product_id;

      if (!productAffinity[productId]) {
        productAffinity[productId] = {
          productId:
            productId,
          productName:
            productMap[productId]
              ? productMap[
                  productId
                ].product_name
              : item.product_name_snapshot,
          quantity: 0,
          revenue: 0,
          orderCountMap: {}
        };
      }

      var row =
        productAffinity[
          productId
        ];

      row.quantity +=
        Number(
          item.quantity || 0
        );

      row.revenue +=
        Number(
          item.line_total || 0
        );

      row.orderCountMap[
        order.order_id
      ] = true;
    });
  });

  var productRows =
    Object.keys(productAffinity)
      .map(function(key) {
        var row =
          productAffinity[key];

        return {
          productId:
            row.productId,
          productName:
            row.productName,
          quantity:
            roundNumber_(
              row.quantity,
              6
            ),
          revenue:
            Math.round(
              row.revenue
            ),
          completedOrderCount:
            Object.keys(
              row.orderCountMap
            ).length
        };
      })
      .sort(function(a, b) {
        return (
          b.quantity -
          a.quantity
        );
      });

  var channelRows =
    Object.keys(channelMix)
      .map(function(key) {
        var row =
          channelMix[key];

        row.historicalValue =
          Math.round(
            row.historicalValue
          );

        return row;
      })
      .sort(function(a, b) {
        return (
          b.orderCount -
          a.orderCount
        );
      });

  var history =
    allOrders
      .slice()
      .sort(function(a, b) {
        return String(
          crmOrderDateKey_(b)
        ).localeCompare(
          String(
            crmOrderDateKey_(a)
          )
        );
      })
      .slice(
        0,
        crmProfileOrderLimit_()
      )
      .map(function(order) {
        var orderItems =
          itemGroups[
            order.order_id
          ] || [];

        return {
          orderId:
            order.order_id,
          orderDate:
            order.order_date,
          fulfillmentDate:
            order.fulfillment_date,
          sourceChannel:
            order.source_channel,
          preorderCampaignId:
            order.preorder_campaign_id,
          orderStatus:
            order.order_status,
          paymentStatus:
            order.payment_status,
          grandTotal:
            Number(
              order.grand_total || 0
            ),
          itemCount:
            orderItems.reduce(
              function(sum, item) {
                return (
                  sum +
                  Number(
                    item.quantity || 0
                  )
                );
              },
              0
            ),
          productSummary:
            orderItems
              .map(function(item) {
                return (
                  item.product_name_snapshot +
                  ' × ' +
                  item.quantity
                );
              })
              .join(', ')
        };
      });

  return {
    customer:
      sanitizeCustomerForViewer_(
        stripInternalFields_(
          customer
        ),
        access
      ),
    intelligence:
      intelligence,
    productAffinity:
      productRows,
    channelMix:
      channelRows,
    orderHistory:
      history,
    access: {
      limited:
        access.limited,
      canWrite:
        hasPermission_(
          access.user,
          'CUSTOMER_WRITE'
        )
    }
  };
}

function rebuildCustomerMetricsPhase11() {
  var user =
    requireRole_([
      TWB_ROLES.OWNER,
      TWB_ROLES.ADMIN
    ]);

  var customers =
    listAllRecords_(
      'CUSTOMERS'
    );

  var updated = 0;

  customers.forEach(function(customer) {
    recalculateCustomerMetrics_(
      customer.customer_id,
      user
    );

    updated += 1;
  });

  return {
    updatedCustomers:
      updated,
    note:
      'Base customer metrics refreshed. CRM segment remains live-derived from the current customer cohort.'
  };
}
