# RELEASE_NOTES_v1.0.0.md
# Twolittle.bites OS v1.0.0

## Release

Twolittle.bites OS v1.0 is the first production baseline of the lightweight business operating system.

## Included modules

```text
Executive
Business
Orders
Pre-Orders
Products
Recipes / BOM
Recipe Scaling
Production
Inventory
Purchasing
Customers / CRM
Marketing / Attribution
Finance
Reports
Settings / Administration
Diagnostics / Backup
Release Governance
```

## Core capabilities

- Google Sheets-backed data foundation.
- Role-based access.
- Product / variant / recipe management.
- EXACT and FULL_BATCH recipe scaling.
- Customer and Order engine with snapshots.
- Invoice, partial payments, refunds, public invoice.
- wa.me invoice messaging.
- Production planning and requirement snapshots.
- Inventory movement ledger.
- Purchasing and receiving.
- Pre-Order capacity controls.
- Managerial Finance / P&L.
- CRM intelligence and RFM-style segmentation.
- Marketing campaign/content attribution.
- Daily / weekly / monthly reporting.
- Business targets and CSV export.
- Controlled Settings / User administration.
- Integrity diagnostics.
- Cross-module regression.
- Exact Google Sheets backups.
- Non-destructive recovery copies.
- Scheduled maintenance.
- v1.0 production release gate.

## Data model

Schema remains:

```text
1.0.0
33 canonical sheets
```

No Phase 16 schema migration is required.

## Release safeguards

- v1.0 feature freeze marker.
- verified backup required for final preflight.
- data-integrity gate.
- full cross-module regression gate.
- explicit manual Apps Script deployment.
- rollback governance and documented recovery plan.

## Known architectural boundaries

- Google Sheets is the v1.0 database.
- WhatsApp is a deep link, not an auto-send API.
- Finance is managerial reporting, not full accounting.
- Marketing attribution is operational manual last-touch, not causal incrementality.
- Apps Script deployment remains a manual release action.
